console.log("[Injected] Grandpa DeFi provider initializing");
const FALLBACK_CHAIN_ID_HEX = "0xaa36a7";
const EIP6963_ANNOUNCE_EVENT = "eip6963:announceProvider";
const EIP6963_REQUEST_EVENT = "eip6963:requestProvider";
const NATIVE_OLD_MAN_LOGO_SVG = `
<svg width="800" height="800" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" role="img" aria-labelledby="title">
  <title id="title">Old man icon</title>
  <g id="old-man" fill="none" fill-rule="evenodd">
    <path d="M53,62H13V52.409a9.784,9.784,0,0,1,6.049-8.948L33,37.5l13.951,5.961A9.784,9.784,0,0,1,53,52.409Z" fill="#D9F0E8" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <line x1="22" y1="58" x2="22" y2="53" fill="none" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <polygon points="38 46 33 50 28 46 28 34 38 34 38 46" fill="#D9F0E8" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <line x1="44" y1="58" x2="44" y2="53" fill="none" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <path d="M46.539,20.891V18.318C46.539,11.515,41.617,6,35.546,6H30.954c-6.071,0-10.993,5.515-10.993,12.318v2.573A2.634,2.634,0,0,0,17.5,23.749a2.9,2.9,0,0,0,1.165,2.173,2,2,0,0,0,2.075.329,14.856,14.856,0,0,0,9.21,11.524,13.062,13.062,0,0,0,6.187-.05l.437-.158a14.839,14.839,0,0,0,9.148-11.328,2.042,2.042,0,0,0,2.06-.262A2.833,2.833,0,0,0,48.981,24,2.665,2.665,0,0,0,46.539,20.891Z" fill="#D5E1DB" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <line x1="30" y1="53" x2="36" y2="53" fill="none" stroke="#4B5E56" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <rect x="22" y="57" width="22" height="5" fill="#4B5E56" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <path d="M39,34.769a6,6,0,0,0-12,0C27,37.955,33,44,33,44S39,37.955,39,34.769Z" fill="#D9F0E8" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <line x1="38" y1="23" x2="28" y2="23" fill="none" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <circle cx="37.5" cy="24.5" r="3.5" fill="#006A52"/>
    <circle cx="28.5" cy="24.5" r="3.5" fill="#006A52"/>
    <line x1="29" y1="14" x2="37" y2="14" fill="none" stroke="#7B8D85" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <line x1="29" y1="17" x2="37" y2="17" fill="none" stroke="#7B8D85" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <path d="M30,35a3,3,0,0,0,3-3" fill="none" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <path d="M33,32a3,3,0,0,0,3,3" fill="none" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
  </g>
</svg>
`;
const EIP6963_ICON_DATA_URI = `data:image/svg+xml;utf8,${encodeURIComponent(
  NATIVE_OLD_MAN_LOGO_SVG.trim()
)}`;
const GRANDPA_PROVIDER_INFO = {
  uuid: "98095ab1-4df2-4b19-ab8a-b57ce524f92f",
  name: "Grandpa Wallet",
  icon: EIP6963_ICON_DATA_URI,
  rdns: "org.grandpa.wallet"
};
class GrandpaProvider {
  isGrandpa = true;
  isMetaMask = true;
  chainId = FALLBACK_CHAIN_ID_HEX;
  selectedAddress = null;
  providers = [this];
  // Legacy MetaMask compatibility shape
  _metamask = {
    isUnlocked: async () => this._connected
  };
  _accounts = [];
  _connected = false;
  _legacyRpcId = 0;
  _listeners = /* @__PURE__ */ new Map();
  request = async (args) => {
    console.log("[Provider] Request:", args.method, args.params);
    const { method, params } = args;
    switch (method) {
      case "eth_requestAccounts":
        return this._handleRequestAccounts();
      case "eth_accounts":
        return this._accounts;
      case "eth_chainId":
        return this._ensureChainId();
      case "net_version": {
        const chainId = await this._ensureChainId();
        return Number.parseInt(chainId, 16).toString(10);
      }
      case "eth_coinbase":
        return this.selectedAddress;
      case "eth_sendTransaction":
        return this._handleSendTransaction(params);
      case "personal_sign":
        return this._handlePersonalSign(params);
      case "eth_signTypedData_v4":
        return this._handleSignTypedData(params);
      case "wallet_switchEthereumChain":
        return this._handleSwitchChain(params);
      case "wallet_addEthereumChain":
        return this._handleAddChain(params);
      case "wallet_getPermissions":
        return this._handleGetPermissions();
      case "wallet_requestPermissions":
        return this._handleRequestPermissions(params);
      default:
        throw new Error(`Method ${method} not supported`);
    }
  };
  enable = () => {
    return this.request({ method: "eth_requestAccounts" });
  };
  isConnected = () => {
    return this._connected;
  };
  send = (methodOrPayload, paramsOrCallback) => {
    if (typeof methodOrPayload === "string") {
      const params = typeof paramsOrCallback === "function" ? void 0 : paramsOrCallback;
      return this.request({ method: methodOrPayload, params });
    }
    const payload = {
      method: methodOrPayload.method,
      params: methodOrPayload.params
    };
    const callback = typeof paramsOrCallback === "function" ? paramsOrCallback : null;
    const id = methodOrPayload.id ?? ++this._legacyRpcId;
    const promise = this.request(payload);
    if (!callback) {
      return promise;
    }
    promise.then((result) => {
      callback(null, { id, jsonrpc: "2.0", result });
    }).catch((error) => {
      const err = error instanceof Error ? error : new Error("Unknown provider error");
      callback(err, {
        id,
        jsonrpc: "2.0",
        error: { code: -32603, message: err.message }
      });
    });
  };
  sendAsync = (payload, callback) => {
    return this.send(payload, callback);
  };
  on = (event, listener) => {
    if (!this._listeners.has(event)) {
      this._listeners.set(event, /* @__PURE__ */ new Set());
    }
    this._listeners.get(event).add(listener);
  };
  removeListener = (event, listener) => {
    const listeners = this._listeners.get(event);
    if (listeners) {
      listeners.delete(listener);
    }
  };
  handleExternalDisconnect() {
    this._setProviderState({ accounts: [] });
  }
  _normalizeChainIdHex(chainId) {
    if (typeof chainId === "number" && Number.isFinite(chainId) && chainId > 0) {
      return `0x${chainId.toString(16)}`;
    }
    if (typeof chainId === "string" && /^0x[a-fA-F0-9]+$/.test(chainId) && chainId.length > 2) {
      return `0x${chainId.slice(2).toLowerCase()}`;
    }
    return this.chainId;
  }
  _setProviderState(payload) {
    const nextAccounts = Array.isArray(payload.accounts) ? payload.accounts.filter(
      (value) => typeof value === "string"
    ) : this._accounts;
    const nextSelectedAddress = nextAccounts[0] ?? null;
    const nextChainId = this._normalizeChainIdHex(payload.chainId);
    const previousAccounts = JSON.stringify(this._accounts);
    const nextAccountsSerialized = JSON.stringify(nextAccounts);
    const chainChanged = nextChainId !== this.chainId;
    const accountsChanged = previousAccounts !== nextAccountsSerialized;
    const wasConnected = this._connected;
    this.chainId = nextChainId;
    this._accounts = nextAccounts;
    this.selectedAddress = nextSelectedAddress;
    this._connected = nextAccounts.length > 0;
    if (!wasConnected && this._connected) {
      this._emit("connect", { chainId: this.chainId });
    }
    if (chainChanged) {
      this._emit("chainChanged", this.chainId);
    }
    if (accountsChanged) {
      this._emit("accountsChanged", this._accounts);
    }
    if (wasConnected && !this._connected) {
      this._emit("disconnect");
    }
  }
  applyProviderState(payload) {
    this._setProviderState(payload);
  }
  _emit(event, ...args) {
    const listeners = this._listeners.get(event);
    if (listeners) {
      listeners.forEach((listener) => {
        try {
          listener(...args);
        } catch (error) {
          console.error("[Provider] Listener error:", error);
        }
      });
    }
  }
  async _sendToBackground(type, payload) {
    const id = Math.random().toString(36).substring(7);
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        window.removeEventListener("message", listener);
        reject(new Error("Request timeout"));
      }, 3e5);
      const listener = (event) => {
        if (event.data.target !== "grandpa-page") return;
        if (event.data.id !== id) return;
        clearTimeout(timeout);
        window.removeEventListener("message", listener);
        if (event.data.error) {
          reject(new Error(event.data.error));
        } else {
          resolve(event.data.response);
        }
      };
      window.addEventListener("message", listener);
      window.postMessage(
        {
          target: "grandpa-content",
          id,
          payload: { type, payload }
        },
        "*"
      );
    });
  }
  async _handleRequestAccounts() {
    if (this._connected && this._accounts.length > 0) {
      return this._accounts;
    }
    const response = await this._sendToBackground("CONNECT_SITE", {
      origin: window.location.origin
    });
    if (response.connected) {
      await this._ensureChainId();
      this._connected = true;
      this._accounts = response.accounts;
      this.selectedAddress = response.accounts[0] ?? null;
      this._emit("connect", { chainId: this.chainId });
      this._emit("accountsChanged", this._accounts);
      return this._accounts;
    }
    throw new Error("User rejected connection");
  }
  async _handleSendTransaction(params) {
    if (!this._connected) {
      throw new Error("Not connected. Call eth_requestAccounts first.");
    }
    const txParams = Array.isArray(params) && params.length > 0 ? params[0] : params;
    if (!txParams || !txParams.to) {
      throw new Error("Invalid transaction parameters");
    }
    const txHash = await this._sendToBackground("SEND_TRANSACTION", {
      to: txParams.to,
      value: txParams.value || "0x0",
      data: txParams.data || "0x"
    });
    return txHash;
  }
  _isHexAddress(value) {
    return /^0x[a-fA-F0-9]{40}$/.test(value);
  }
  _parsePersonalSignParams(params) {
    if (Array.isArray(params)) {
      const first = params[0];
      const second = params[1];
      if (typeof first !== "string") {
        throw new Error("Invalid personal_sign params");
      }
      if (typeof second !== "string") {
        return { message: first };
      }
      const firstIsAddress = this._isHexAddress(first);
      const secondIsAddress = this._isHexAddress(second);
      if (secondIsAddress) {
        return { message: first, address: second };
      }
      if (firstIsAddress) {
        return { message: second, address: first };
      }
      return { message: first };
    }
    if (params && typeof params === "object") {
      const objectParams = params;
      const message = typeof objectParams.data === "string" ? objectParams.data : typeof objectParams.message === "string" ? objectParams.message : null;
      if (!message) {
        throw new Error("Invalid personal_sign params");
      }
      if (typeof objectParams.from === "string" && this._isHexAddress(objectParams.from)) {
        return { message, address: objectParams.from };
      }
      return { message };
    }
    throw new Error("Invalid personal_sign params");
  }
  async _handlePersonalSign(params) {
    if (!this._connected) {
      throw new Error("Not connected. Call eth_requestAccounts first.");
    }
    const parsed = this._parsePersonalSignParams(params);
    const expectedAddress = this.selectedAddress;
    if (parsed.address && expectedAddress) {
      if (parsed.address.toLowerCase() !== expectedAddress.toLowerCase()) {
        throw new Error("Requested account does not match connected account");
      }
    }
    const addressForRequest = parsed.address ?? (expectedAddress && this._isHexAddress(expectedAddress) ? expectedAddress : void 0);
    const signature = await this._sendToBackground("SIGN_MESSAGE", {
      message: parsed.message,
      address: addressForRequest
    });
    return signature;
  }
  async _handleSignTypedData(_params) {
    if (!this._connected) {
      throw new Error("Not connected. Call eth_requestAccounts first.");
    }
    throw new Error("eth_signTypedData_v4 is not supported yet");
  }
  async _handleSwitchChain(params) {
    const chainId = Array.isArray(params) ? params[0] : params;
    if (!chainId?.chainId) {
      throw new Error("Missing chainId");
    }
    const parsedChainId = Number.parseInt(chainId.chainId, 16);
    if (!Number.isFinite(parsedChainId) || parsedChainId <= 0) {
      throw new Error("Invalid chainId");
    }
    const response = await this._sendToBackground("API_SWITCH_CHAIN", {
      chainId: parsedChainId
    });
    this._setProviderState({
      chainId: response?.chainId ?? parsedChainId,
      accounts: response?.accounts ?? this._accounts
    });
    return null;
  }
  async _handleAddChain(params) {
    const chainConfig = Array.isArray(params) ? params[0] : params;
    const requestedChainId = chainConfig?.chainId ? Number.parseInt(chainConfig.chainId, 16) : null;
    if (requestedChainId === 11155111 || requestedChainId === 11155420 || requestedChainId === 421614) {
      return null;
    }
    throw new Error("Adding chains is not supported for this network");
  }
  _handleGetPermissions() {
    if (!this._connected) {
      return [];
    }
    return [{ parentCapability: "eth_accounts" }];
  }
  async _handleRequestPermissions(params) {
    const request = Array.isArray(params) ? params[0] : void 0;
    const wantsAccounts = typeof request === "object" && request !== null && Object.prototype.hasOwnProperty.call(request, "eth_accounts");
    if (!wantsAccounts) {
      throw new Error("Only eth_accounts permission is supported");
    }
    await this._handleRequestAccounts();
    return [{ parentCapability: "eth_accounts" }];
  }
  async _ensureChainId() {
    try {
      const stored = await this._sendToBackground("API_GET_CHAIN_ID", {});
      if (typeof stored === "number" && stored > 0) {
        this._setProviderState({ chainId: stored });
      }
    } catch (error) {
      console.warn("[Provider] Failed to resolve chainId:", error);
    }
    return this.chainId;
  }
}
function getOrCreateProvidersList(existing2) {
  if (Array.isArray(existing2.providers)) {
    return existing2.providers;
  }
  return [existing2];
}
function hasGrandpaProvider(providers) {
  return providers.some(
    (provider) => typeof provider === "object" && provider !== null && provider.isGrandpa === true
  );
}
function announceEip6963Provider(provider) {
  const detail = {
    info: GRANDPA_PROVIDER_INFO,
    provider
  };
  window.dispatchEvent(
    new CustomEvent(EIP6963_ANNOUNCE_EVENT, { detail })
  );
}
const grandpaProvider = new GrandpaProvider();
const existing = window.ethereum ?? null;
if (!existing) {
  window.ethereum = grandpaProvider;
  console.log("[Injected] Provider injected as window.ethereum");
} else {
  const providers = getOrCreateProvidersList(existing);
  if (!hasGrandpaProvider(providers)) {
    providers.push(grandpaProvider);
    existing.providers = providers;
    console.log(
      "[Injected] Grandpa provider added to window.ethereum.providers"
    );
  } else {
    console.log("[Injected] Grandpa provider already present");
  }
}
window.addEventListener(EIP6963_REQUEST_EVENT, () => {
  announceEip6963Provider(grandpaProvider);
});
announceEip6963Provider(grandpaProvider);
setTimeout(() => announceEip6963Provider(grandpaProvider), 0);
window.addEventListener("message", (event) => {
  if (event.data.target === "grandpa-page" && event.data.type === "disconnect") {
    grandpaProvider.handleExternalDisconnect();
    return;
  }
  if (event.data.target === "grandpa-page" && event.data.type === "providerStateChanged") {
    grandpaProvider.applyProviderState(
      event.data.payload ?? {}
    );
  }
});
window.dispatchEvent(new Event("ethereum#initialized"));
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5qZWN0ZWQuanMiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9jb250ZW50L2luamVjdGVkLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEluamVjdGVkIFByb3ZpZGVyIC0gUnVucyBpbiBwYWdlIGNvbnRleHQsIHByb3ZpZGVzIHdpbmRvdy5ldGhlcmV1bVxuXG5jb25zb2xlLmxvZyhcIltJbmplY3RlZF0gR3JhbmRwYSBEZUZpIHByb3ZpZGVyIGluaXRpYWxpemluZ1wiKTtcblxuY29uc3QgRkFMTEJBQ0tfQ0hBSU5fSURfSEVYID0gXCIweGFhMzZhN1wiOyAvLyBTZXBvbGlhXG5jb25zdCBFSVA2OTYzX0FOTk9VTkNFX0VWRU5UID0gXCJlaXA2OTYzOmFubm91bmNlUHJvdmlkZXJcIjtcbmNvbnN0IEVJUDY5NjNfUkVRVUVTVF9FVkVOVCA9IFwiZWlwNjk2MzpyZXF1ZXN0UHJvdmlkZXJcIjtcblxuaW50ZXJmYWNlIFJlcXVlc3RBcmd1bWVudHMge1xuICBtZXRob2Q6IHN0cmluZztcbiAgcGFyYW1zPzogdW5rbm93bltdIHwgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG59XG5cbmludGVyZmFjZSBMZWdhY3lScGNQYXlsb2FkIHtcbiAgaWQ/OiBudW1iZXI7XG4gIGpzb25ycGM/OiBzdHJpbmc7XG4gIG1ldGhvZDogc3RyaW5nO1xuICBwYXJhbXM/OiB1bmtub3duW10gfCBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbn1cblxuaW50ZXJmYWNlIExlZ2FjeVJwY1Jlc3BvbnNlIHtcbiAgaWQ6IG51bWJlcjtcbiAganNvbnJwYzogXCIyLjBcIjtcbiAgcmVzdWx0PzogdW5rbm93bjtcbiAgZXJyb3I/OiB7IGNvZGU6IG51bWJlcjsgbWVzc2FnZTogc3RyaW5nIH07XG59XG5cbnR5cGUgTGVnYWN5UnBjQ2FsbGJhY2sgPSAoXG4gIGVycm9yOiBFcnJvciB8IG51bGwsXG4gIHJlc3BvbnNlOiBMZWdhY3lScGNSZXNwb25zZSxcbikgPT4gdm9pZDtcblxuaW50ZXJmYWNlIEdyYW5kcGFFdGhlcmV1bUxpa2Uge1xuICBpc0dyYW5kcGE/OiBib29sZWFuO1xuICBwcm92aWRlcnM/OiB1bmtub3duW107XG59XG5cbmludGVyZmFjZSBFaXA2OTYzUHJvdmlkZXJJbmZvIHtcbiAgdXVpZDogc3RyaW5nO1xuICBuYW1lOiBzdHJpbmc7XG4gIGljb246IHN0cmluZztcbiAgcmRuczogc3RyaW5nO1xufVxuXG5pbnRlcmZhY2UgRWlwNjk2M0Fubm91bmNlRGV0YWlsIHtcbiAgaW5mbzogRWlwNjk2M1Byb3ZpZGVySW5mbztcbiAgcHJvdmlkZXI6IEdyYW5kcGFQcm92aWRlcjtcbn1cblxuaW50ZXJmYWNlIFdhbGxldFBlcm1pc3Npb24ge1xuICBwYXJlbnRDYXBhYmlsaXR5OiBcImV0aF9hY2NvdW50c1wiO1xufVxuXG5pbnRlcmZhY2UgUHJvdmlkZXJTdGF0ZVBheWxvYWQge1xuICBjaGFpbklkPzogbnVtYmVyIHwgc3RyaW5nIHwgbnVsbDtcbiAgYWNjb3VudHM/OiBzdHJpbmdbXSB8IG51bGw7XG59XG5cbi8vIEtlZXAgdGhpcyBTVkcgYWxpZ25lZCB3aXRoIGFwcHMvbmF0aXZlL2NvbXBvbmVudHMvYnJhbmQvT2xkTWFuTG9nby50c3ggKExJR0hUX0xPR09fU1ZHKS5cbmNvbnN0IE5BVElWRV9PTERfTUFOX0xPR09fU1ZHID0gYFxuPHN2ZyB3aWR0aD1cIjgwMFwiIGhlaWdodD1cIjgwMFwiIHZpZXdCb3g9XCIwIDAgNjQgNjRcIiB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgcm9sZT1cImltZ1wiIGFyaWEtbGFiZWxsZWRieT1cInRpdGxlXCI+XG4gIDx0aXRsZSBpZD1cInRpdGxlXCI+T2xkIG1hbiBpY29uPC90aXRsZT5cbiAgPGcgaWQ9XCJvbGQtbWFuXCIgZmlsbD1cIm5vbmVcIiBmaWxsLXJ1bGU9XCJldmVub2RkXCI+XG4gICAgPHBhdGggZD1cIk01Myw2MkgxM1Y1Mi40MDlhOS43ODQsOS43ODQsMCwwLDEsNi4wNDktOC45NDhMMzMsMzcuNWwxMy45NTEsNS45NjFBOS43ODQsOS43ODQsMCwwLDEsNTMsNTIuNDA5WlwiIGZpbGw9XCIjRDlGMEU4XCIgc3Ryb2tlPVwiIzAwNkE1MlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZS13aWR0aD1cIjJweFwiLz5cbiAgICA8bGluZSB4MT1cIjIyXCIgeTE9XCI1OFwiIHgyPVwiMjJcIiB5Mj1cIjUzXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCIjMDA2QTUyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlLXdpZHRoPVwiMnB4XCIvPlxuICAgIDxwb2x5Z29uIHBvaW50cz1cIjM4IDQ2IDMzIDUwIDI4IDQ2IDI4IDM0IDM4IDM0IDM4IDQ2XCIgZmlsbD1cIiNEOUYwRThcIiBzdHJva2U9XCIjMDA2QTUyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlLXdpZHRoPVwiMnB4XCIvPlxuICAgIDxsaW5lIHgxPVwiNDRcIiB5MT1cIjU4XCIgeDI9XCI0NFwiIHkyPVwiNTNcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cIiMwMDZBNTJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBzdHJva2Utd2lkdGg9XCIycHhcIi8+XG4gICAgPHBhdGggZD1cIk00Ni41MzksMjAuODkxVjE4LjMxOEM0Ni41MzksMTEuNTE1LDQxLjYxNyw2LDM1LjU0Niw2SDMwLjk1NGMtNi4wNzEsMC0xMC45OTMsNS41MTUtMTAuOTkzLDEyLjMxOHYyLjU3M0EyLjYzNCwyLjYzNCwwLDAsMCwxNy41LDIzLjc0OWEyLjksMi45LDAsMCwwLDEuMTY1LDIuMTczLDIsMiwwLDAsMCwyLjA3NS4zMjksMTQuODU2LDE0Ljg1NiwwLDAsMCw5LjIxLDExLjUyNCwxMy4wNjIsMTMuMDYyLDAsMCwwLDYuMTg3LS4wNWwuNDM3LS4xNThhMTQuODM5LDE0LjgzOSwwLDAsMCw5LjE0OC0xMS4zMjgsMi4wNDIsMi4wNDIsMCwwLDAsMi4wNi0uMjYyQTIuODMzLDIuODMzLDAsMCwwLDQ4Ljk4MSwyNCwyLjY2NSwyLjY2NSwwLDAsMCw0Ni41MzksMjAuODkxWlwiIGZpbGw9XCIjRDVFMURCXCIgc3Ryb2tlPVwiIzAwNkE1MlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZS13aWR0aD1cIjJweFwiLz5cbiAgICA8bGluZSB4MT1cIjMwXCIgeTE9XCI1M1wiIHgyPVwiMzZcIiB5Mj1cIjUzXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCIjNEI1RTU2XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlLXdpZHRoPVwiMnB4XCIvPlxuICAgIDxyZWN0IHg9XCIyMlwiIHk9XCI1N1wiIHdpZHRoPVwiMjJcIiBoZWlnaHQ9XCI1XCIgZmlsbD1cIiM0QjVFNTZcIiBzdHJva2U9XCIjMDA2QTUyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlLXdpZHRoPVwiMnB4XCIvPlxuICAgIDxwYXRoIGQ9XCJNMzksMzQuNzY5YTYsNiwwLDAsMC0xMiwwQzI3LDM3Ljk1NSwzMyw0NCwzMyw0NFMzOSwzNy45NTUsMzksMzQuNzY5WlwiIGZpbGw9XCIjRDlGMEU4XCIgc3Ryb2tlPVwiIzAwNkE1MlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZS13aWR0aD1cIjJweFwiLz5cbiAgICA8bGluZSB4MT1cIjM4XCIgeTE9XCIyM1wiIHgyPVwiMjhcIiB5Mj1cIjIzXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCIjMDA2QTUyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlLXdpZHRoPVwiMnB4XCIvPlxuICAgIDxjaXJjbGUgY3g9XCIzNy41XCIgY3k9XCIyNC41XCIgcj1cIjMuNVwiIGZpbGw9XCIjMDA2QTUyXCIvPlxuICAgIDxjaXJjbGUgY3g9XCIyOC41XCIgY3k9XCIyNC41XCIgcj1cIjMuNVwiIGZpbGw9XCIjMDA2QTUyXCIvPlxuICAgIDxsaW5lIHgxPVwiMjlcIiB5MT1cIjE0XCIgeDI9XCIzN1wiIHkyPVwiMTRcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cIiM3QjhEODVcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBzdHJva2Utd2lkdGg9XCIycHhcIi8+XG4gICAgPGxpbmUgeDE9XCIyOVwiIHkxPVwiMTdcIiB4Mj1cIjM3XCIgeTI9XCIxN1wiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiIzdCOEQ4NVwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZS13aWR0aD1cIjJweFwiLz5cbiAgICA8cGF0aCBkPVwiTTMwLDM1YTMsMywwLDAsMCwzLTNcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cIiMwMDZBNTJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBzdHJva2Utd2lkdGg9XCIycHhcIi8+XG4gICAgPHBhdGggZD1cIk0zMywzMmEzLDMsMCwwLDAsMywzXCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCIjMDA2QTUyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlLXdpZHRoPVwiMnB4XCIvPlxuICA8L2c+XG48L3N2Zz5cbmA7XG5cbmNvbnN0IEVJUDY5NjNfSUNPTl9EQVRBX1VSSSA9IGBkYXRhOmltYWdlL3N2Zyt4bWw7dXRmOCwke2VuY29kZVVSSUNvbXBvbmVudChcbiAgTkFUSVZFX09MRF9NQU5fTE9HT19TVkcudHJpbSgpLFxuKX1gO1xuXG5jb25zdCBHUkFORFBBX1BST1ZJREVSX0lORk86IEVpcDY5NjNQcm92aWRlckluZm8gPSB7XG4gIHV1aWQ6IFwiOTgwOTVhYjEtNGRmMi00YjE5LWFiOGEtYjU3Y2U1MjRmOTJmXCIsXG4gIG5hbWU6IFwiR3JhbmRwYSBXYWxsZXRcIixcbiAgaWNvbjogRUlQNjk2M19JQ09OX0RBVEFfVVJJLFxuICByZG5zOiBcIm9yZy5ncmFuZHBhLndhbGxldFwiLFxufTtcblxuY2xhc3MgR3JhbmRwYVByb3ZpZGVyIHtcbiAgcHVibGljIGlzR3JhbmRwYSA9IHRydWU7XG4gIHB1YmxpYyBpc01ldGFNYXNrID0gdHJ1ZTtcbiAgcHVibGljIGNoYWluSWQgPSBGQUxMQkFDS19DSEFJTl9JRF9IRVg7XG4gIHB1YmxpYyBzZWxlY3RlZEFkZHJlc3M6IHN0cmluZyB8IG51bGwgPSBudWxsO1xuICBwdWJsaWMgcHJvdmlkZXJzOiBHcmFuZHBhUHJvdmlkZXJbXSA9IFt0aGlzXTtcblxuICAvLyBMZWdhY3kgTWV0YU1hc2sgY29tcGF0aWJpbGl0eSBzaGFwZVxuICBwdWJsaWMgX21ldGFtYXNrID0ge1xuICAgIGlzVW5sb2NrZWQ6IGFzeW5jICgpID0+IHRoaXMuX2Nvbm5lY3RlZCxcbiAgfTtcblxuICBwcml2YXRlIF9hY2NvdW50czogc3RyaW5nW10gPSBbXTtcbiAgcHJpdmF0ZSBfY29ubmVjdGVkID0gZmFsc2U7XG4gIHByaXZhdGUgX2xlZ2FjeVJwY0lkID0gMDtcbiAgcHJpdmF0ZSBfbGlzdGVuZXJzOiBNYXA8c3RyaW5nLCBTZXQ8KC4uLmFyZ3M6IHVua25vd25bXSkgPT4gdm9pZD4+ID1cbiAgICBuZXcgTWFwKCk7XG5cbiAgcmVxdWVzdCA9IGFzeW5jIChhcmdzOiBSZXF1ZXN0QXJndW1lbnRzKTogUHJvbWlzZTx1bmtub3duPiA9PiB7XG4gICAgY29uc29sZS5sb2coXCJbUHJvdmlkZXJdIFJlcXVlc3Q6XCIsIGFyZ3MubWV0aG9kLCBhcmdzLnBhcmFtcyk7XG5cbiAgICBjb25zdCB7IG1ldGhvZCwgcGFyYW1zIH0gPSBhcmdzO1xuXG4gICAgc3dpdGNoIChtZXRob2QpIHtcbiAgICAgIGNhc2UgXCJldGhfcmVxdWVzdEFjY291bnRzXCI6XG4gICAgICAgIHJldHVybiB0aGlzLl9oYW5kbGVSZXF1ZXN0QWNjb3VudHMoKTtcblxuICAgICAgY2FzZSBcImV0aF9hY2NvdW50c1wiOlxuICAgICAgICByZXR1cm4gdGhpcy5fYWNjb3VudHM7XG5cbiAgICAgIGNhc2UgXCJldGhfY2hhaW5JZFwiOlxuICAgICAgICByZXR1cm4gdGhpcy5fZW5zdXJlQ2hhaW5JZCgpO1xuXG4gICAgICBjYXNlIFwibmV0X3ZlcnNpb25cIjoge1xuICAgICAgICBjb25zdCBjaGFpbklkID0gYXdhaXQgdGhpcy5fZW5zdXJlQ2hhaW5JZCgpO1xuICAgICAgICByZXR1cm4gTnVtYmVyLnBhcnNlSW50KGNoYWluSWQsIDE2KS50b1N0cmluZygxMCk7XG4gICAgICB9XG5cbiAgICAgIGNhc2UgXCJldGhfY29pbmJhc2VcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuc2VsZWN0ZWRBZGRyZXNzO1xuXG4gICAgICBjYXNlIFwiZXRoX3NlbmRUcmFuc2FjdGlvblwiOlxuICAgICAgICByZXR1cm4gdGhpcy5faGFuZGxlU2VuZFRyYW5zYWN0aW9uKHBhcmFtcyk7XG5cbiAgICAgIGNhc2UgXCJwZXJzb25hbF9zaWduXCI6XG4gICAgICAgIHJldHVybiB0aGlzLl9oYW5kbGVQZXJzb25hbFNpZ24ocGFyYW1zKTtcblxuICAgICAgY2FzZSBcImV0aF9zaWduVHlwZWREYXRhX3Y0XCI6XG4gICAgICAgIHJldHVybiB0aGlzLl9oYW5kbGVTaWduVHlwZWREYXRhKHBhcmFtcyk7XG5cbiAgICAgIGNhc2UgXCJ3YWxsZXRfc3dpdGNoRXRoZXJldW1DaGFpblwiOlxuICAgICAgICByZXR1cm4gdGhpcy5faGFuZGxlU3dpdGNoQ2hhaW4ocGFyYW1zKTtcblxuICAgICAgY2FzZSBcIndhbGxldF9hZGRFdGhlcmV1bUNoYWluXCI6XG4gICAgICAgIHJldHVybiB0aGlzLl9oYW5kbGVBZGRDaGFpbihwYXJhbXMpO1xuXG4gICAgICBjYXNlIFwid2FsbGV0X2dldFBlcm1pc3Npb25zXCI6XG4gICAgICAgIHJldHVybiB0aGlzLl9oYW5kbGVHZXRQZXJtaXNzaW9ucygpO1xuXG4gICAgICBjYXNlIFwid2FsbGV0X3JlcXVlc3RQZXJtaXNzaW9uc1wiOlxuICAgICAgICByZXR1cm4gdGhpcy5faGFuZGxlUmVxdWVzdFBlcm1pc3Npb25zKHBhcmFtcyk7XG5cbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgTWV0aG9kICR7bWV0aG9kfSBub3Qgc3VwcG9ydGVkYCk7XG4gICAgfVxuICB9O1xuXG4gIGVuYWJsZSA9ICgpOiBQcm9taXNlPHN0cmluZ1tdPiA9PiB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdCh7IG1ldGhvZDogXCJldGhfcmVxdWVzdEFjY291bnRzXCIgfSkgYXMgUHJvbWlzZTxzdHJpbmdbXT47XG4gIH07XG5cbiAgaXNDb25uZWN0ZWQgPSAoKTogYm9vbGVhbiA9PiB7XG4gICAgcmV0dXJuIHRoaXMuX2Nvbm5lY3RlZDtcbiAgfTtcblxuICBzZW5kID0gKFxuICAgIG1ldGhvZE9yUGF5bG9hZDogc3RyaW5nIHwgTGVnYWN5UnBjUGF5bG9hZCxcbiAgICBwYXJhbXNPckNhbGxiYWNrPzogdW5rbm93bltdIHwgUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBMZWdhY3lScGNDYWxsYmFjayxcbiAgKTogUHJvbWlzZTx1bmtub3duPiB8IHZvaWQgPT4ge1xuICAgIGlmICh0eXBlb2YgbWV0aG9kT3JQYXlsb2FkID09PSBcInN0cmluZ1wiKSB7XG4gICAgICBjb25zdCBwYXJhbXMgPVxuICAgICAgICB0eXBlb2YgcGFyYW1zT3JDYWxsYmFjayA9PT0gXCJmdW5jdGlvblwiID8gdW5kZWZpbmVkIDogcGFyYW1zT3JDYWxsYmFjaztcbiAgICAgIHJldHVybiB0aGlzLnJlcXVlc3QoeyBtZXRob2Q6IG1ldGhvZE9yUGF5bG9hZCwgcGFyYW1zIH0pO1xuICAgIH1cblxuICAgIGNvbnN0IHBheWxvYWQ6IFJlcXVlc3RBcmd1bWVudHMgPSB7XG4gICAgICBtZXRob2Q6IG1ldGhvZE9yUGF5bG9hZC5tZXRob2QsXG4gICAgICBwYXJhbXM6IG1ldGhvZE9yUGF5bG9hZC5wYXJhbXMsXG4gICAgfTtcbiAgICBjb25zdCBjYWxsYmFjayA9XG4gICAgICB0eXBlb2YgcGFyYW1zT3JDYWxsYmFjayA9PT0gXCJmdW5jdGlvblwiID8gcGFyYW1zT3JDYWxsYmFjayA6IG51bGw7XG4gICAgY29uc3QgaWQgPSBtZXRob2RPclBheWxvYWQuaWQgPz8gKyt0aGlzLl9sZWdhY3lScGNJZDtcbiAgICBjb25zdCBwcm9taXNlID0gdGhpcy5yZXF1ZXN0KHBheWxvYWQpO1xuXG4gICAgaWYgKCFjYWxsYmFjaykge1xuICAgICAgcmV0dXJuIHByb21pc2U7XG4gICAgfVxuXG4gICAgcHJvbWlzZVxuICAgICAgLnRoZW4oKHJlc3VsdCkgPT4ge1xuICAgICAgICBjYWxsYmFjayhudWxsLCB7IGlkLCBqc29ucnBjOiBcIjIuMFwiLCByZXN1bHQgfSk7XG4gICAgICB9KVxuICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgICBjb25zdCBlcnIgPVxuICAgICAgICAgIGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvciA6IG5ldyBFcnJvcihcIlVua25vd24gcHJvdmlkZXIgZXJyb3JcIik7XG4gICAgICAgIGNhbGxiYWNrKGVyciwge1xuICAgICAgICAgIGlkLFxuICAgICAgICAgIGpzb25ycGM6IFwiMi4wXCIsXG4gICAgICAgICAgZXJyb3I6IHsgY29kZTogLTMyNjAzLCBtZXNzYWdlOiBlcnIubWVzc2FnZSB9LFxuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICB9O1xuXG4gIHNlbmRBc3luYyA9IChcbiAgICBwYXlsb2FkOiBMZWdhY3lScGNQYXlsb2FkLFxuICAgIGNhbGxiYWNrOiBMZWdhY3lScGNDYWxsYmFjayxcbiAgKTogdm9pZCB8IFByb21pc2U8dW5rbm93bj4gPT4ge1xuICAgIHJldHVybiB0aGlzLnNlbmQocGF5bG9hZCwgY2FsbGJhY2spO1xuICB9O1xuXG4gIG9uID0gKGV2ZW50OiBzdHJpbmcsIGxpc3RlbmVyOiAoLi4uYXJnczogdW5rbm93bltdKSA9PiB2b2lkKTogdm9pZCA9PiB7XG4gICAgaWYgKCF0aGlzLl9saXN0ZW5lcnMuaGFzKGV2ZW50KSkge1xuICAgICAgdGhpcy5fbGlzdGVuZXJzLnNldChldmVudCwgbmV3IFNldCgpKTtcbiAgICB9XG4gICAgdGhpcy5fbGlzdGVuZXJzLmdldChldmVudCkhLmFkZChsaXN0ZW5lcik7XG4gIH07XG5cbiAgcmVtb3ZlTGlzdGVuZXIgPSAoXG4gICAgZXZlbnQ6IHN0cmluZyxcbiAgICBsaXN0ZW5lcjogKC4uLmFyZ3M6IHVua25vd25bXSkgPT4gdm9pZCxcbiAgKTogdm9pZCA9PiB7XG4gICAgY29uc3QgbGlzdGVuZXJzID0gdGhpcy5fbGlzdGVuZXJzLmdldChldmVudCk7XG4gICAgaWYgKGxpc3RlbmVycykge1xuICAgICAgbGlzdGVuZXJzLmRlbGV0ZShsaXN0ZW5lcik7XG4gICAgfVxuICB9O1xuXG4gIGhhbmRsZUV4dGVybmFsRGlzY29ubmVjdCgpOiB2b2lkIHtcbiAgICB0aGlzLl9zZXRQcm92aWRlclN0YXRlKHsgYWNjb3VudHM6IFtdIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBfbm9ybWFsaXplQ2hhaW5JZEhleChcbiAgICBjaGFpbklkOiBudW1iZXIgfCBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkLFxuICApOiBzdHJpbmcge1xuICAgIGlmIChcbiAgICAgIHR5cGVvZiBjaGFpbklkID09PSBcIm51bWJlclwiICYmXG4gICAgICBOdW1iZXIuaXNGaW5pdGUoY2hhaW5JZCkgJiZcbiAgICAgIGNoYWluSWQgPiAwXG4gICAgKSB7XG4gICAgICByZXR1cm4gYDB4JHtjaGFpbklkLnRvU3RyaW5nKDE2KX1gO1xuICAgIH1cblxuICAgIGlmIChcbiAgICAgIHR5cGVvZiBjaGFpbklkID09PSBcInN0cmluZ1wiICYmXG4gICAgICAvXjB4W2EtZkEtRjAtOV0rJC8udGVzdChjaGFpbklkKSAmJlxuICAgICAgY2hhaW5JZC5sZW5ndGggPiAyXG4gICAgKSB7XG4gICAgICByZXR1cm4gYDB4JHtjaGFpbklkLnNsaWNlKDIpLnRvTG93ZXJDYXNlKCl9YDtcbiAgICB9XG5cbiAgICByZXR1cm4gdGhpcy5jaGFpbklkO1xuICB9XG5cbiAgcHJpdmF0ZSBfc2V0UHJvdmlkZXJTdGF0ZShwYXlsb2FkOiBQcm92aWRlclN0YXRlUGF5bG9hZCk6IHZvaWQge1xuICAgIGNvbnN0IG5leHRBY2NvdW50cyA9IEFycmF5LmlzQXJyYXkocGF5bG9hZC5hY2NvdW50cylcbiAgICAgID8gcGF5bG9hZC5hY2NvdW50cy5maWx0ZXIoXG4gICAgICAgICAgKHZhbHVlKTogdmFsdWUgaXMgc3RyaW5nID0+IHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIixcbiAgICAgICAgKVxuICAgICAgOiB0aGlzLl9hY2NvdW50cztcbiAgICBjb25zdCBuZXh0U2VsZWN0ZWRBZGRyZXNzID0gbmV4dEFjY291bnRzWzBdID8/IG51bGw7XG4gICAgY29uc3QgbmV4dENoYWluSWQgPSB0aGlzLl9ub3JtYWxpemVDaGFpbklkSGV4KHBheWxvYWQuY2hhaW5JZCk7XG5cbiAgICBjb25zdCBwcmV2aW91c0FjY291bnRzID0gSlNPTi5zdHJpbmdpZnkodGhpcy5fYWNjb3VudHMpO1xuICAgIGNvbnN0IG5leHRBY2NvdW50c1NlcmlhbGl6ZWQgPSBKU09OLnN0cmluZ2lmeShuZXh0QWNjb3VudHMpO1xuICAgIGNvbnN0IGNoYWluQ2hhbmdlZCA9IG5leHRDaGFpbklkICE9PSB0aGlzLmNoYWluSWQ7XG4gICAgY29uc3QgYWNjb3VudHNDaGFuZ2VkID0gcHJldmlvdXNBY2NvdW50cyAhPT0gbmV4dEFjY291bnRzU2VyaWFsaXplZDtcbiAgICBjb25zdCB3YXNDb25uZWN0ZWQgPSB0aGlzLl9jb25uZWN0ZWQ7XG5cbiAgICB0aGlzLmNoYWluSWQgPSBuZXh0Q2hhaW5JZDtcbiAgICB0aGlzLl9hY2NvdW50cyA9IG5leHRBY2NvdW50cztcbiAgICB0aGlzLnNlbGVjdGVkQWRkcmVzcyA9IG5leHRTZWxlY3RlZEFkZHJlc3M7XG4gICAgdGhpcy5fY29ubmVjdGVkID0gbmV4dEFjY291bnRzLmxlbmd0aCA+IDA7XG5cbiAgICBpZiAoIXdhc0Nvbm5lY3RlZCAmJiB0aGlzLl9jb25uZWN0ZWQpIHtcbiAgICAgIHRoaXMuX2VtaXQoXCJjb25uZWN0XCIsIHsgY2hhaW5JZDogdGhpcy5jaGFpbklkIH0pO1xuICAgIH1cbiAgICBpZiAoY2hhaW5DaGFuZ2VkKSB7XG4gICAgICB0aGlzLl9lbWl0KFwiY2hhaW5DaGFuZ2VkXCIsIHRoaXMuY2hhaW5JZCk7XG4gICAgfVxuICAgIGlmIChhY2NvdW50c0NoYW5nZWQpIHtcbiAgICAgIHRoaXMuX2VtaXQoXCJhY2NvdW50c0NoYW5nZWRcIiwgdGhpcy5fYWNjb3VudHMpO1xuICAgIH1cbiAgICBpZiAod2FzQ29ubmVjdGVkICYmICF0aGlzLl9jb25uZWN0ZWQpIHtcbiAgICAgIHRoaXMuX2VtaXQoXCJkaXNjb25uZWN0XCIpO1xuICAgIH1cbiAgfVxuXG4gIGFwcGx5UHJvdmlkZXJTdGF0ZShwYXlsb2FkOiBQcm92aWRlclN0YXRlUGF5bG9hZCk6IHZvaWQge1xuICAgIHRoaXMuX3NldFByb3ZpZGVyU3RhdGUocGF5bG9hZCk7XG4gIH1cblxuICBwcml2YXRlIF9lbWl0KGV2ZW50OiBzdHJpbmcsIC4uLmFyZ3M6IHVua25vd25bXSk6IHZvaWQge1xuICAgIGNvbnN0IGxpc3RlbmVycyA9IHRoaXMuX2xpc3RlbmVycy5nZXQoZXZlbnQpO1xuICAgIGlmIChsaXN0ZW5lcnMpIHtcbiAgICAgIGxpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lcikgPT4ge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGxpc3RlbmVyKC4uLmFyZ3MpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJbUHJvdmlkZXJdIExpc3RlbmVyIGVycm9yOlwiLCBlcnJvcik7XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgX3NlbmRUb0JhY2tncm91bmQoXG4gICAgdHlwZTogc3RyaW5nLFxuICAgIHBheWxvYWQ6IHVua25vd24sXG4gICk6IFByb21pc2U8dW5rbm93bj4ge1xuICAgIGNvbnN0IGlkID0gTWF0aC5yYW5kb20oKS50b1N0cmluZygzNikuc3Vic3RyaW5nKDcpO1xuXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGNvbnN0IHRpbWVvdXQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIGxpc3RlbmVyKTtcbiAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihcIlJlcXVlc3QgdGltZW91dFwiKSk7XG4gICAgICB9LCAzMDAwMDApO1xuXG4gICAgICBjb25zdCBsaXN0ZW5lciA9IChldmVudDogTWVzc2FnZUV2ZW50KSA9PiB7XG4gICAgICAgIGlmIChldmVudC5kYXRhLnRhcmdldCAhPT0gXCJncmFuZHBhLXBhZ2VcIikgcmV0dXJuO1xuICAgICAgICBpZiAoZXZlbnQuZGF0YS5pZCAhPT0gaWQpIHJldHVybjtcblxuICAgICAgICBjbGVhclRpbWVvdXQodGltZW91dCk7XG4gICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCBsaXN0ZW5lcik7XG5cbiAgICAgICAgaWYgKGV2ZW50LmRhdGEuZXJyb3IpIHtcbiAgICAgICAgICByZWplY3QobmV3IEVycm9yKGV2ZW50LmRhdGEuZXJyb3IpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXNvbHZlKGV2ZW50LmRhdGEucmVzcG9uc2UpO1xuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgbGlzdGVuZXIpO1xuXG4gICAgICB3aW5kb3cucG9zdE1lc3NhZ2UoXG4gICAgICAgIHtcbiAgICAgICAgICB0YXJnZXQ6IFwiZ3JhbmRwYS1jb250ZW50XCIsXG4gICAgICAgICAgaWQsXG4gICAgICAgICAgcGF5bG9hZDogeyB0eXBlLCBwYXlsb2FkIH0sXG4gICAgICAgIH0sXG4gICAgICAgIFwiKlwiLFxuICAgICAgKTtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgX2hhbmRsZVJlcXVlc3RBY2NvdW50cygpOiBQcm9taXNlPHN0cmluZ1tdPiB7XG4gICAgaWYgKHRoaXMuX2Nvbm5lY3RlZCAmJiB0aGlzLl9hY2NvdW50cy5sZW5ndGggPiAwKSB7XG4gICAgICByZXR1cm4gdGhpcy5fYWNjb3VudHM7XG4gICAgfVxuXG4gICAgY29uc3QgcmVzcG9uc2UgPSAoYXdhaXQgdGhpcy5fc2VuZFRvQmFja2dyb3VuZChcIkNPTk5FQ1RfU0lURVwiLCB7XG4gICAgICBvcmlnaW46IHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4sXG4gICAgfSkpIGFzIHsgY29ubmVjdGVkOiBib29sZWFuOyBhY2NvdW50czogc3RyaW5nW10gfTtcblxuICAgIGlmIChyZXNwb25zZS5jb25uZWN0ZWQpIHtcbiAgICAgIGF3YWl0IHRoaXMuX2Vuc3VyZUNoYWluSWQoKTtcbiAgICAgIHRoaXMuX2Nvbm5lY3RlZCA9IHRydWU7XG4gICAgICB0aGlzLl9hY2NvdW50cyA9IHJlc3BvbnNlLmFjY291bnRzO1xuICAgICAgdGhpcy5zZWxlY3RlZEFkZHJlc3MgPSByZXNwb25zZS5hY2NvdW50c1swXSA/PyBudWxsO1xuICAgICAgdGhpcy5fZW1pdChcImNvbm5lY3RcIiwgeyBjaGFpbklkOiB0aGlzLmNoYWluSWQgfSk7XG4gICAgICB0aGlzLl9lbWl0KFwiYWNjb3VudHNDaGFuZ2VkXCIsIHRoaXMuX2FjY291bnRzKTtcbiAgICAgIHJldHVybiB0aGlzLl9hY2NvdW50cztcbiAgICB9XG5cbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJVc2VyIHJlamVjdGVkIGNvbm5lY3Rpb25cIik7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIF9oYW5kbGVTZW5kVHJhbnNhY3Rpb24ocGFyYW1zOiB1bmtub3duKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBpZiAoIXRoaXMuX2Nvbm5lY3RlZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm90IGNvbm5lY3RlZC4gQ2FsbCBldGhfcmVxdWVzdEFjY291bnRzIGZpcnN0LlwiKTtcbiAgICB9XG5cbiAgICBjb25zdCB0eFBhcmFtcyA9XG4gICAgICBBcnJheS5pc0FycmF5KHBhcmFtcykgJiYgcGFyYW1zLmxlbmd0aCA+IDBcbiAgICAgICAgPyAocGFyYW1zWzBdIGFzIHtcbiAgICAgICAgICAgIHRvPzogc3RyaW5nO1xuICAgICAgICAgICAgdmFsdWU/OiBzdHJpbmc7XG4gICAgICAgICAgICBkYXRhPzogc3RyaW5nO1xuICAgICAgICAgIH0pXG4gICAgICAgIDogKHBhcmFtcyBhcyB7XG4gICAgICAgICAgICB0bz86IHN0cmluZztcbiAgICAgICAgICAgIHZhbHVlPzogc3RyaW5nO1xuICAgICAgICAgICAgZGF0YT86IHN0cmluZztcbiAgICAgICAgICB9IHwgbnVsbCk7XG5cbiAgICBpZiAoIXR4UGFyYW1zIHx8ICF0eFBhcmFtcy50bykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCB0cmFuc2FjdGlvbiBwYXJhbWV0ZXJzXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHR4SGFzaCA9IChhd2FpdCB0aGlzLl9zZW5kVG9CYWNrZ3JvdW5kKFwiU0VORF9UUkFOU0FDVElPTlwiLCB7XG4gICAgICB0bzogdHhQYXJhbXMudG8sXG4gICAgICB2YWx1ZTogdHhQYXJhbXMudmFsdWUgfHwgXCIweDBcIixcbiAgICAgIGRhdGE6IHR4UGFyYW1zLmRhdGEgfHwgXCIweFwiLFxuICAgIH0pKSBhcyBzdHJpbmc7XG5cbiAgICByZXR1cm4gdHhIYXNoO1xuICB9XG5cbiAgcHJpdmF0ZSBfaXNIZXhBZGRyZXNzKHZhbHVlOiBzdHJpbmcpOiB2YWx1ZSBpcyBgMHgke3N0cmluZ31gIHtcbiAgICByZXR1cm4gL14weFthLWZBLUYwLTldezQwfSQvLnRlc3QodmFsdWUpO1xuICB9XG5cbiAgcHJpdmF0ZSBfcGFyc2VQZXJzb25hbFNpZ25QYXJhbXMocGFyYW1zOiB1bmtub3duKToge1xuICAgIG1lc3NhZ2U6IHN0cmluZztcbiAgICBhZGRyZXNzPzogYDB4JHtzdHJpbmd9YDtcbiAgfSB7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkocGFyYW1zKSkge1xuICAgICAgY29uc3QgZmlyc3QgPSBwYXJhbXNbMF07XG4gICAgICBjb25zdCBzZWNvbmQgPSBwYXJhbXNbMV07XG5cbiAgICAgIGlmICh0eXBlb2YgZmlyc3QgIT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCBwZXJzb25hbF9zaWduIHBhcmFtc1wiKTtcbiAgICAgIH1cblxuICAgICAgaWYgKHR5cGVvZiBzZWNvbmQgIT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgcmV0dXJuIHsgbWVzc2FnZTogZmlyc3QgfTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgZmlyc3RJc0FkZHJlc3MgPSB0aGlzLl9pc0hleEFkZHJlc3MoZmlyc3QpO1xuICAgICAgY29uc3Qgc2Vjb25kSXNBZGRyZXNzID0gdGhpcy5faXNIZXhBZGRyZXNzKHNlY29uZCk7XG5cbiAgICAgIGlmIChzZWNvbmRJc0FkZHJlc3MpIHtcbiAgICAgICAgcmV0dXJuIHsgbWVzc2FnZTogZmlyc3QsIGFkZHJlc3M6IHNlY29uZCB9O1xuICAgICAgfVxuICAgICAgaWYgKGZpcnN0SXNBZGRyZXNzKSB7XG4gICAgICAgIHJldHVybiB7IG1lc3NhZ2U6IHNlY29uZCwgYWRkcmVzczogZmlyc3QgfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IG1lc3NhZ2U6IGZpcnN0IH07XG4gICAgfVxuXG4gICAgaWYgKHBhcmFtcyAmJiB0eXBlb2YgcGFyYW1zID09PSBcIm9iamVjdFwiKSB7XG4gICAgICBjb25zdCBvYmplY3RQYXJhbXMgPSBwYXJhbXMgYXMge1xuICAgICAgICBkYXRhPzogdW5rbm93bjtcbiAgICAgICAgbWVzc2FnZT86IHVua25vd247XG4gICAgICAgIGZyb20/OiB1bmtub3duO1xuICAgICAgfTtcbiAgICAgIGNvbnN0IG1lc3NhZ2UgPVxuICAgICAgICB0eXBlb2Ygb2JqZWN0UGFyYW1zLmRhdGEgPT09IFwic3RyaW5nXCJcbiAgICAgICAgICA/IG9iamVjdFBhcmFtcy5kYXRhXG4gICAgICAgICAgOiB0eXBlb2Ygb2JqZWN0UGFyYW1zLm1lc3NhZ2UgPT09IFwic3RyaW5nXCJcbiAgICAgICAgICAgID8gb2JqZWN0UGFyYW1zLm1lc3NhZ2VcbiAgICAgICAgICAgIDogbnVsbDtcblxuICAgICAgaWYgKCFtZXNzYWdlKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgcGVyc29uYWxfc2lnbiBwYXJhbXNcIik7XG4gICAgICB9XG5cbiAgICAgIGlmIChcbiAgICAgICAgdHlwZW9mIG9iamVjdFBhcmFtcy5mcm9tID09PSBcInN0cmluZ1wiICYmXG4gICAgICAgIHRoaXMuX2lzSGV4QWRkcmVzcyhvYmplY3RQYXJhbXMuZnJvbSlcbiAgICAgICkge1xuICAgICAgICByZXR1cm4geyBtZXNzYWdlLCBhZGRyZXNzOiBvYmplY3RQYXJhbXMuZnJvbSB9O1xuICAgICAgfVxuICAgICAgcmV0dXJuIHsgbWVzc2FnZSB9O1xuICAgIH1cblxuICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgcGVyc29uYWxfc2lnbiBwYXJhbXNcIik7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIF9oYW5kbGVQZXJzb25hbFNpZ24ocGFyYW1zOiB1bmtub3duKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBpZiAoIXRoaXMuX2Nvbm5lY3RlZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm90IGNvbm5lY3RlZC4gQ2FsbCBldGhfcmVxdWVzdEFjY291bnRzIGZpcnN0LlwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBwYXJzZWQgPSB0aGlzLl9wYXJzZVBlcnNvbmFsU2lnblBhcmFtcyhwYXJhbXMpO1xuICAgIGNvbnN0IGV4cGVjdGVkQWRkcmVzcyA9IHRoaXMuc2VsZWN0ZWRBZGRyZXNzO1xuICAgIGlmIChwYXJzZWQuYWRkcmVzcyAmJiBleHBlY3RlZEFkZHJlc3MpIHtcbiAgICAgIGlmIChwYXJzZWQuYWRkcmVzcy50b0xvd2VyQ2FzZSgpICE9PSBleHBlY3RlZEFkZHJlc3MudG9Mb3dlckNhc2UoKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJSZXF1ZXN0ZWQgYWNjb3VudCBkb2VzIG5vdCBtYXRjaCBjb25uZWN0ZWQgYWNjb3VudFwiKTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICBjb25zdCBhZGRyZXNzRm9yUmVxdWVzdCA9XG4gICAgICBwYXJzZWQuYWRkcmVzcyA/P1xuICAgICAgKGV4cGVjdGVkQWRkcmVzcyAmJiB0aGlzLl9pc0hleEFkZHJlc3MoZXhwZWN0ZWRBZGRyZXNzKVxuICAgICAgICA/IGV4cGVjdGVkQWRkcmVzc1xuICAgICAgICA6IHVuZGVmaW5lZCk7XG5cbiAgICBjb25zdCBzaWduYXR1cmUgPSAoYXdhaXQgdGhpcy5fc2VuZFRvQmFja2dyb3VuZChcIlNJR05fTUVTU0FHRVwiLCB7XG4gICAgICBtZXNzYWdlOiBwYXJzZWQubWVzc2FnZSxcbiAgICAgIGFkZHJlc3M6IGFkZHJlc3NGb3JSZXF1ZXN0LFxuICAgIH0pKSBhcyBzdHJpbmc7XG5cbiAgICByZXR1cm4gc2lnbmF0dXJlO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBfaGFuZGxlU2lnblR5cGVkRGF0YShfcGFyYW1zOiB1bmtub3duKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBpZiAoIXRoaXMuX2Nvbm5lY3RlZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm90IGNvbm5lY3RlZC4gQ2FsbCBldGhfcmVxdWVzdEFjY291bnRzIGZpcnN0LlwiKTtcbiAgICB9XG4gICAgdm9pZCBfcGFyYW1zO1xuICAgIHRocm93IG5ldyBFcnJvcihcImV0aF9zaWduVHlwZWREYXRhX3Y0IGlzIG5vdCBzdXBwb3J0ZWQgeWV0XCIpO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBfaGFuZGxlU3dpdGNoQ2hhaW4ocGFyYW1zOiB1bmtub3duKTogUHJvbWlzZTxudWxsPiB7XG4gICAgY29uc3QgY2hhaW5JZCA9IChBcnJheS5pc0FycmF5KHBhcmFtcykgPyBwYXJhbXNbMF0gOiBwYXJhbXMpIGFzXG4gICAgICB8IHsgY2hhaW5JZD86IHN0cmluZyB9XG4gICAgICB8IHVuZGVmaW5lZDtcblxuICAgIGlmICghY2hhaW5JZD8uY2hhaW5JZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTWlzc2luZyBjaGFpbklkXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHBhcnNlZENoYWluSWQgPSBOdW1iZXIucGFyc2VJbnQoY2hhaW5JZC5jaGFpbklkLCAxNik7XG4gICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUocGFyc2VkQ2hhaW5JZCkgfHwgcGFyc2VkQ2hhaW5JZCA8PSAwKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIGNoYWluSWRcIik7XG4gICAgfVxuXG4gICAgY29uc3QgcmVzcG9uc2UgPSAoYXdhaXQgdGhpcy5fc2VuZFRvQmFja2dyb3VuZChcIkFQSV9TV0lUQ0hfQ0hBSU5cIiwge1xuICAgICAgY2hhaW5JZDogcGFyc2VkQ2hhaW5JZCxcbiAgICB9KSkgYXMgUHJvdmlkZXJTdGF0ZVBheWxvYWQgfCBudWxsO1xuICAgIHRoaXMuX3NldFByb3ZpZGVyU3RhdGUoe1xuICAgICAgY2hhaW5JZDogcmVzcG9uc2U/LmNoYWluSWQgPz8gcGFyc2VkQ2hhaW5JZCxcbiAgICAgIGFjY291bnRzOiByZXNwb25zZT8uYWNjb3VudHMgPz8gdGhpcy5fYWNjb3VudHMsXG4gICAgfSk7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIF9oYW5kbGVBZGRDaGFpbihwYXJhbXM/OiB1bmtub3duKTogUHJvbWlzZTxudWxsPiB7XG4gICAgY29uc3QgY2hhaW5Db25maWcgPSAoQXJyYXkuaXNBcnJheShwYXJhbXMpID8gcGFyYW1zWzBdIDogcGFyYW1zKSBhc1xuICAgICAgfCB7IGNoYWluSWQ/OiBzdHJpbmcgfVxuICAgICAgfCB1bmRlZmluZWQ7XG4gICAgY29uc3QgcmVxdWVzdGVkQ2hhaW5JZCA9IGNoYWluQ29uZmlnPy5jaGFpbklkXG4gICAgICA/IE51bWJlci5wYXJzZUludChjaGFpbkNvbmZpZy5jaGFpbklkLCAxNilcbiAgICAgIDogbnVsbDtcblxuICAgIGlmIChcbiAgICAgIHJlcXVlc3RlZENoYWluSWQgPT09IDExMTU1MTExIHx8XG4gICAgICByZXF1ZXN0ZWRDaGFpbklkID09PSAxMTE1NTQyMCB8fFxuICAgICAgcmVxdWVzdGVkQ2hhaW5JZCA9PT0gNDIxNjE0XG4gICAgKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJBZGRpbmcgY2hhaW5zIGlzIG5vdCBzdXBwb3J0ZWQgZm9yIHRoaXMgbmV0d29ya1wiKTtcbiAgfVxuXG4gIHByaXZhdGUgX2hhbmRsZUdldFBlcm1pc3Npb25zKCk6IFdhbGxldFBlcm1pc3Npb25bXSB7XG4gICAgaWYgKCF0aGlzLl9jb25uZWN0ZWQpIHtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgcmV0dXJuIFt7IHBhcmVudENhcGFiaWxpdHk6IFwiZXRoX2FjY291bnRzXCIgfV07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIF9oYW5kbGVSZXF1ZXN0UGVybWlzc2lvbnMoXG4gICAgcGFyYW1zOiB1bmtub3duLFxuICApOiBQcm9taXNlPFdhbGxldFBlcm1pc3Npb25bXT4ge1xuICAgIGNvbnN0IHJlcXVlc3QgPSBBcnJheS5pc0FycmF5KHBhcmFtcykgPyBwYXJhbXNbMF0gOiB1bmRlZmluZWQ7XG4gICAgY29uc3Qgd2FudHNBY2NvdW50cyA9XG4gICAgICB0eXBlb2YgcmVxdWVzdCA9PT0gXCJvYmplY3RcIiAmJlxuICAgICAgcmVxdWVzdCAhPT0gbnVsbCAmJlxuICAgICAgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHJlcXVlc3QsIFwiZXRoX2FjY291bnRzXCIpO1xuXG4gICAgaWYgKCF3YW50c0FjY291bnRzKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJPbmx5IGV0aF9hY2NvdW50cyBwZXJtaXNzaW9uIGlzIHN1cHBvcnRlZFwiKTtcbiAgICB9XG5cbiAgICBhd2FpdCB0aGlzLl9oYW5kbGVSZXF1ZXN0QWNjb3VudHMoKTtcbiAgICByZXR1cm4gW3sgcGFyZW50Q2FwYWJpbGl0eTogXCJldGhfYWNjb3VudHNcIiB9XTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgX2Vuc3VyZUNoYWluSWQoKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgc3RvcmVkID0gYXdhaXQgdGhpcy5fc2VuZFRvQmFja2dyb3VuZChcIkFQSV9HRVRfQ0hBSU5fSURcIiwge30pO1xuICAgICAgaWYgKHR5cGVvZiBzdG9yZWQgPT09IFwibnVtYmVyXCIgJiYgc3RvcmVkID4gMCkge1xuICAgICAgICB0aGlzLl9zZXRQcm92aWRlclN0YXRlKHsgY2hhaW5JZDogc3RvcmVkIH0pO1xuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLndhcm4oXCJbUHJvdmlkZXJdIEZhaWxlZCB0byByZXNvbHZlIGNoYWluSWQ6XCIsIGVycm9yKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuY2hhaW5JZDtcbiAgfVxufVxuXG5mdW5jdGlvbiBnZXRPckNyZWF0ZVByb3ZpZGVyc0xpc3QoZXhpc3Rpbmc6IEdyYW5kcGFFdGhlcmV1bUxpa2UpOiB1bmtub3duW10ge1xuICBpZiAoQXJyYXkuaXNBcnJheShleGlzdGluZy5wcm92aWRlcnMpKSB7XG4gICAgcmV0dXJuIGV4aXN0aW5nLnByb3ZpZGVycztcbiAgfVxuICByZXR1cm4gW2V4aXN0aW5nXTtcbn1cblxuZnVuY3Rpb24gaGFzR3JhbmRwYVByb3ZpZGVyKHByb3ZpZGVyczogdW5rbm93bltdKTogYm9vbGVhbiB7XG4gIHJldHVybiBwcm92aWRlcnMuc29tZShcbiAgICAocHJvdmlkZXIpID0+XG4gICAgICB0eXBlb2YgcHJvdmlkZXIgPT09IFwib2JqZWN0XCIgJiZcbiAgICAgIHByb3ZpZGVyICE9PSBudWxsICYmXG4gICAgICAocHJvdmlkZXIgYXMgR3JhbmRwYUV0aGVyZXVtTGlrZSkuaXNHcmFuZHBhID09PSB0cnVlLFxuICApO1xufVxuXG5mdW5jdGlvbiBhbm5vdW5jZUVpcDY5NjNQcm92aWRlcihwcm92aWRlcjogR3JhbmRwYVByb3ZpZGVyKTogdm9pZCB7XG4gIGNvbnN0IGRldGFpbDogRWlwNjk2M0Fubm91bmNlRGV0YWlsID0ge1xuICAgIGluZm86IEdSQU5EUEFfUFJPVklERVJfSU5GTyxcbiAgICBwcm92aWRlcixcbiAgfTtcbiAgd2luZG93LmRpc3BhdGNoRXZlbnQoXG4gICAgbmV3IEN1c3RvbUV2ZW50PEVpcDY5NjNBbm5vdW5jZURldGFpbD4oRUlQNjk2M19BTk5PVU5DRV9FVkVOVCwgeyBkZXRhaWwgfSksXG4gICk7XG59XG5cbmNvbnN0IGdyYW5kcGFQcm92aWRlciA9IG5ldyBHcmFuZHBhUHJvdmlkZXIoKTtcbmNvbnN0IGV4aXN0aW5nID0gKHdpbmRvdy5ldGhlcmV1bSBhcyBHcmFuZHBhRXRoZXJldW1MaWtlIHwgdW5kZWZpbmVkKSA/PyBudWxsO1xuXG5pZiAoIWV4aXN0aW5nKSB7XG4gIHdpbmRvdy5ldGhlcmV1bSA9IGdyYW5kcGFQcm92aWRlciBhcyB1bmtub3duO1xuICBjb25zb2xlLmxvZyhcIltJbmplY3RlZF0gUHJvdmlkZXIgaW5qZWN0ZWQgYXMgd2luZG93LmV0aGVyZXVtXCIpO1xufSBlbHNlIHtcbiAgY29uc3QgcHJvdmlkZXJzID0gZ2V0T3JDcmVhdGVQcm92aWRlcnNMaXN0KGV4aXN0aW5nKTtcbiAgaWYgKCFoYXNHcmFuZHBhUHJvdmlkZXIocHJvdmlkZXJzKSkge1xuICAgIHByb3ZpZGVycy5wdXNoKGdyYW5kcGFQcm92aWRlcik7XG4gICAgZXhpc3RpbmcucHJvdmlkZXJzID0gcHJvdmlkZXJzO1xuICAgIGNvbnNvbGUubG9nKFxuICAgICAgXCJbSW5qZWN0ZWRdIEdyYW5kcGEgcHJvdmlkZXIgYWRkZWQgdG8gd2luZG93LmV0aGVyZXVtLnByb3ZpZGVyc1wiLFxuICAgICk7XG4gIH0gZWxzZSB7XG4gICAgY29uc29sZS5sb2coXCJbSW5qZWN0ZWRdIEdyYW5kcGEgcHJvdmlkZXIgYWxyZWFkeSBwcmVzZW50XCIpO1xuICB9XG59XG5cbndpbmRvdy5hZGRFdmVudExpc3RlbmVyKEVJUDY5NjNfUkVRVUVTVF9FVkVOVCwgKCkgPT4ge1xuICBhbm5vdW5jZUVpcDY5NjNQcm92aWRlcihncmFuZHBhUHJvdmlkZXIpO1xufSk7XG5hbm5vdW5jZUVpcDY5NjNQcm92aWRlcihncmFuZHBhUHJvdmlkZXIpO1xuc2V0VGltZW91dCgoKSA9PiBhbm5vdW5jZUVpcDY5NjNQcm92aWRlcihncmFuZHBhUHJvdmlkZXIpLCAwKTtcblxuLy8gTGlzdGVuIGZvciBkaXNjb25uZWN0XG53aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgKGV2ZW50KSA9PiB7XG4gIGlmIChcbiAgICBldmVudC5kYXRhLnRhcmdldCA9PT0gXCJncmFuZHBhLXBhZ2VcIiAmJlxuICAgIGV2ZW50LmRhdGEudHlwZSA9PT0gXCJkaXNjb25uZWN0XCJcbiAgKSB7XG4gICAgZ3JhbmRwYVByb3ZpZGVyLmhhbmRsZUV4dGVybmFsRGlzY29ubmVjdCgpO1xuICAgIHJldHVybjtcbiAgfVxuXG4gIGlmIChcbiAgICBldmVudC5kYXRhLnRhcmdldCA9PT0gXCJncmFuZHBhLXBhZ2VcIiAmJlxuICAgIGV2ZW50LmRhdGEudHlwZSA9PT0gXCJwcm92aWRlclN0YXRlQ2hhbmdlZFwiXG4gICkge1xuICAgIGdyYW5kcGFQcm92aWRlci5hcHBseVByb3ZpZGVyU3RhdGUoXG4gICAgICAoZXZlbnQuZGF0YS5wYXlsb2FkIGFzIFByb3ZpZGVyU3RhdGVQYXlsb2FkIHwgbnVsbCkgPz8ge30sXG4gICAgKTtcbiAgfVxufSk7XG5cbi8vIEFubm91bmNlIHByb3ZpZGVyIGZvciBsZWdhY3kgZGV0ZWN0LXByb3ZpZGVyIGludGVncmF0aW9uc1xud2luZG93LmRpc3BhdGNoRXZlbnQobmV3IEV2ZW50KFwiZXRoZXJldW0jaW5pdGlhbGl6ZWRcIikpO1xuIl0sIm5hbWVzIjpbImV4aXN0aW5nIl0sIm1hcHBpbmdzIjoiQUFFQSxRQUFRLElBQUksK0NBQStDO0FBRTNELE1BQU0sd0JBQXdCO0FBQzlCLE1BQU0seUJBQXlCO0FBQy9CLE1BQU0sd0JBQXdCO0FBcUQ5QixNQUFNLDBCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXVCaEMsTUFBTSx3QkFBd0IsMkJBQTJCO0FBQUEsRUFDdkQsd0JBQXdCLEtBQUE7QUFDMUIsQ0FBQztBQUVELE1BQU0sd0JBQTZDO0FBQUEsRUFDakQsTUFBTTtBQUFBLEVBQ04sTUFBTTtBQUFBLEVBQ04sTUFBTTtBQUFBLEVBQ04sTUFBTTtBQUNSO0FBRUEsTUFBTSxnQkFBZ0I7QUFBQSxFQUNiLFlBQVk7QUFBQSxFQUNaLGFBQWE7QUFBQSxFQUNiLFVBQVU7QUFBQSxFQUNWLGtCQUFpQztBQUFBLEVBQ2pDLFlBQStCLENBQUMsSUFBSTtBQUFBO0FBQUEsRUFHcEMsWUFBWTtBQUFBLElBQ2pCLFlBQVksWUFBWSxLQUFLO0FBQUEsRUFBQTtBQUFBLEVBR3ZCLFlBQXNCLENBQUE7QUFBQSxFQUN0QixhQUFhO0FBQUEsRUFDYixlQUFlO0FBQUEsRUFDZixpQ0FDRixJQUFBO0FBQUEsRUFFTixVQUFVLE9BQU8sU0FBNkM7QUFDNUQsWUFBUSxJQUFJLHVCQUF1QixLQUFLLFFBQVEsS0FBSyxNQUFNO0FBRTNELFVBQU0sRUFBRSxRQUFRLE9BQUEsSUFBVztBQUUzQixZQUFRLFFBQUE7QUFBQSxNQUNOLEtBQUs7QUFDSCxlQUFPLEtBQUssdUJBQUE7QUFBQSxNQUVkLEtBQUs7QUFDSCxlQUFPLEtBQUs7QUFBQSxNQUVkLEtBQUs7QUFDSCxlQUFPLEtBQUssZUFBQTtBQUFBLE1BRWQsS0FBSyxlQUFlO0FBQ2xCLGNBQU0sVUFBVSxNQUFNLEtBQUssZUFBQTtBQUMzQixlQUFPLE9BQU8sU0FBUyxTQUFTLEVBQUUsRUFBRSxTQUFTLEVBQUU7QUFBQSxNQUNqRDtBQUFBLE1BRUEsS0FBSztBQUNILGVBQU8sS0FBSztBQUFBLE1BRWQsS0FBSztBQUNILGVBQU8sS0FBSyx1QkFBdUIsTUFBTTtBQUFBLE1BRTNDLEtBQUs7QUFDSCxlQUFPLEtBQUssb0JBQW9CLE1BQU07QUFBQSxNQUV4QyxLQUFLO0FBQ0gsZUFBTyxLQUFLLHFCQUFxQixNQUFNO0FBQUEsTUFFekMsS0FBSztBQUNILGVBQU8sS0FBSyxtQkFBbUIsTUFBTTtBQUFBLE1BRXZDLEtBQUs7QUFDSCxlQUFPLEtBQUssZ0JBQWdCLE1BQU07QUFBQSxNQUVwQyxLQUFLO0FBQ0gsZUFBTyxLQUFLLHNCQUFBO0FBQUEsTUFFZCxLQUFLO0FBQ0gsZUFBTyxLQUFLLDBCQUEwQixNQUFNO0FBQUEsTUFFOUM7QUFDRSxjQUFNLElBQUksTUFBTSxVQUFVLE1BQU0sZ0JBQWdCO0FBQUEsSUFBQTtBQUFBLEVBRXREO0FBQUEsRUFFQSxTQUFTLE1BQXlCO0FBQ2hDLFdBQU8sS0FBSyxRQUFRLEVBQUUsUUFBUSx1QkFBdUI7QUFBQSxFQUN2RDtBQUFBLEVBRUEsY0FBYyxNQUFlO0FBQzNCLFdBQU8sS0FBSztBQUFBLEVBQ2Q7QUFBQSxFQUVBLE9BQU8sQ0FDTCxpQkFDQSxxQkFDNEI7QUFDNUIsUUFBSSxPQUFPLG9CQUFvQixVQUFVO0FBQ3ZDLFlBQU0sU0FDSixPQUFPLHFCQUFxQixhQUFhLFNBQVk7QUFDdkQsYUFBTyxLQUFLLFFBQVEsRUFBRSxRQUFRLGlCQUFpQixRQUFRO0FBQUEsSUFDekQ7QUFFQSxVQUFNLFVBQTRCO0FBQUEsTUFDaEMsUUFBUSxnQkFBZ0I7QUFBQSxNQUN4QixRQUFRLGdCQUFnQjtBQUFBLElBQUE7QUFFMUIsVUFBTSxXQUNKLE9BQU8scUJBQXFCLGFBQWEsbUJBQW1CO0FBQzlELFVBQU0sS0FBSyxnQkFBZ0IsTUFBTSxFQUFFLEtBQUs7QUFDeEMsVUFBTSxVQUFVLEtBQUssUUFBUSxPQUFPO0FBRXBDLFFBQUksQ0FBQyxVQUFVO0FBQ2IsYUFBTztBQUFBLElBQ1Q7QUFFQSxZQUNHLEtBQUssQ0FBQyxXQUFXO0FBQ2hCLGVBQVMsTUFBTSxFQUFFLElBQUksU0FBUyxPQUFPLFFBQVE7QUFBQSxJQUMvQyxDQUFDLEVBQ0EsTUFBTSxDQUFDLFVBQVU7QUFDaEIsWUFBTSxNQUNKLGlCQUFpQixRQUFRLFFBQVEsSUFBSSxNQUFNLHdCQUF3QjtBQUNyRSxlQUFTLEtBQUs7QUFBQSxRQUNaO0FBQUEsUUFDQSxTQUFTO0FBQUEsUUFDVCxPQUFPLEVBQUUsTUFBTSxRQUFRLFNBQVMsSUFBSSxRQUFBO0FBQUEsTUFBUSxDQUM3QztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0w7QUFBQSxFQUVBLFlBQVksQ0FDVixTQUNBLGFBQzRCO0FBQzVCLFdBQU8sS0FBSyxLQUFLLFNBQVMsUUFBUTtBQUFBLEVBQ3BDO0FBQUEsRUFFQSxLQUFLLENBQUMsT0FBZSxhQUFpRDtBQUNwRSxRQUFJLENBQUMsS0FBSyxXQUFXLElBQUksS0FBSyxHQUFHO0FBQy9CLFdBQUssV0FBVyxJQUFJLE9BQU8sb0JBQUksS0FBSztBQUFBLElBQ3RDO0FBQ0EsU0FBSyxXQUFXLElBQUksS0FBSyxFQUFHLElBQUksUUFBUTtBQUFBLEVBQzFDO0FBQUEsRUFFQSxpQkFBaUIsQ0FDZixPQUNBLGFBQ1M7QUFDVCxVQUFNLFlBQVksS0FBSyxXQUFXLElBQUksS0FBSztBQUMzQyxRQUFJLFdBQVc7QUFDYixnQkFBVSxPQUFPLFFBQVE7QUFBQSxJQUMzQjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLDJCQUFpQztBQUMvQixTQUFLLGtCQUFrQixFQUFFLFVBQVUsQ0FBQSxHQUFJO0FBQUEsRUFDekM7QUFBQSxFQUVRLHFCQUNOLFNBQ1E7QUFDUixRQUNFLE9BQU8sWUFBWSxZQUNuQixPQUFPLFNBQVMsT0FBTyxLQUN2QixVQUFVLEdBQ1Y7QUFDQSxhQUFPLEtBQUssUUFBUSxTQUFTLEVBQUUsQ0FBQztBQUFBLElBQ2xDO0FBRUEsUUFDRSxPQUFPLFlBQVksWUFDbkIsbUJBQW1CLEtBQUssT0FBTyxLQUMvQixRQUFRLFNBQVMsR0FDakI7QUFDQSxhQUFPLEtBQUssUUFBUSxNQUFNLENBQUMsRUFBRSxhQUFhO0FBQUEsSUFDNUM7QUFFQSxXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQUEsRUFFUSxrQkFBa0IsU0FBcUM7QUFDN0QsVUFBTSxlQUFlLE1BQU0sUUFBUSxRQUFRLFFBQVEsSUFDL0MsUUFBUSxTQUFTO0FBQUEsTUFDZixDQUFDLFVBQTJCLE9BQU8sVUFBVTtBQUFBLElBQUEsSUFFL0MsS0FBSztBQUNULFVBQU0sc0JBQXNCLGFBQWEsQ0FBQyxLQUFLO0FBQy9DLFVBQU0sY0FBYyxLQUFLLHFCQUFxQixRQUFRLE9BQU87QUFFN0QsVUFBTSxtQkFBbUIsS0FBSyxVQUFVLEtBQUssU0FBUztBQUN0RCxVQUFNLHlCQUF5QixLQUFLLFVBQVUsWUFBWTtBQUMxRCxVQUFNLGVBQWUsZ0JBQWdCLEtBQUs7QUFDMUMsVUFBTSxrQkFBa0IscUJBQXFCO0FBQzdDLFVBQU0sZUFBZSxLQUFLO0FBRTFCLFNBQUssVUFBVTtBQUNmLFNBQUssWUFBWTtBQUNqQixTQUFLLGtCQUFrQjtBQUN2QixTQUFLLGFBQWEsYUFBYSxTQUFTO0FBRXhDLFFBQUksQ0FBQyxnQkFBZ0IsS0FBSyxZQUFZO0FBQ3BDLFdBQUssTUFBTSxXQUFXLEVBQUUsU0FBUyxLQUFLLFNBQVM7QUFBQSxJQUNqRDtBQUNBLFFBQUksY0FBYztBQUNoQixXQUFLLE1BQU0sZ0JBQWdCLEtBQUssT0FBTztBQUFBLElBQ3pDO0FBQ0EsUUFBSSxpQkFBaUI7QUFDbkIsV0FBSyxNQUFNLG1CQUFtQixLQUFLLFNBQVM7QUFBQSxJQUM5QztBQUNBLFFBQUksZ0JBQWdCLENBQUMsS0FBSyxZQUFZO0FBQ3BDLFdBQUssTUFBTSxZQUFZO0FBQUEsSUFDekI7QUFBQSxFQUNGO0FBQUEsRUFFQSxtQkFBbUIsU0FBcUM7QUFDdEQsU0FBSyxrQkFBa0IsT0FBTztBQUFBLEVBQ2hDO0FBQUEsRUFFUSxNQUFNLFVBQWtCLE1BQXVCO0FBQ3JELFVBQU0sWUFBWSxLQUFLLFdBQVcsSUFBSSxLQUFLO0FBQzNDLFFBQUksV0FBVztBQUNiLGdCQUFVLFFBQVEsQ0FBQyxhQUFhO0FBQzlCLFlBQUk7QUFDRixtQkFBUyxHQUFHLElBQUk7QUFBQSxRQUNsQixTQUFTLE9BQU87QUFDZCxrQkFBUSxNQUFNLDhCQUE4QixLQUFLO0FBQUEsUUFDbkQ7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBYyxrQkFDWixNQUNBLFNBQ2tCO0FBQ2xCLFVBQU0sS0FBSyxLQUFLLE9BQUEsRUFBUyxTQUFTLEVBQUUsRUFBRSxVQUFVLENBQUM7QUFFakQsV0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDdEMsWUFBTSxVQUFVLFdBQVcsTUFBTTtBQUMvQixlQUFPLG9CQUFvQixXQUFXLFFBQVE7QUFDOUMsZUFBTyxJQUFJLE1BQU0saUJBQWlCLENBQUM7QUFBQSxNQUNyQyxHQUFHLEdBQU07QUFFVCxZQUFNLFdBQVcsQ0FBQyxVQUF3QjtBQUN4QyxZQUFJLE1BQU0sS0FBSyxXQUFXLGVBQWdCO0FBQzFDLFlBQUksTUFBTSxLQUFLLE9BQU8sR0FBSTtBQUUxQixxQkFBYSxPQUFPO0FBQ3BCLGVBQU8sb0JBQW9CLFdBQVcsUUFBUTtBQUU5QyxZQUFJLE1BQU0sS0FBSyxPQUFPO0FBQ3BCLGlCQUFPLElBQUksTUFBTSxNQUFNLEtBQUssS0FBSyxDQUFDO0FBQUEsUUFDcEMsT0FBTztBQUNMLGtCQUFRLE1BQU0sS0FBSyxRQUFRO0FBQUEsUUFDN0I7QUFBQSxNQUNGO0FBRUEsYUFBTyxpQkFBaUIsV0FBVyxRQUFRO0FBRTNDLGFBQU87QUFBQSxRQUNMO0FBQUEsVUFDRSxRQUFRO0FBQUEsVUFDUjtBQUFBLFVBQ0EsU0FBUyxFQUFFLE1BQU0sUUFBQTtBQUFBLFFBQVE7QUFBQSxRQUUzQjtBQUFBLE1BQUE7QUFBQSxJQUVKLENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFjLHlCQUE0QztBQUN4RCxRQUFJLEtBQUssY0FBYyxLQUFLLFVBQVUsU0FBUyxHQUFHO0FBQ2hELGFBQU8sS0FBSztBQUFBLElBQ2Q7QUFFQSxVQUFNLFdBQVksTUFBTSxLQUFLLGtCQUFrQixnQkFBZ0I7QUFBQSxNQUM3RCxRQUFRLE9BQU8sU0FBUztBQUFBLElBQUEsQ0FDekI7QUFFRCxRQUFJLFNBQVMsV0FBVztBQUN0QixZQUFNLEtBQUssZUFBQTtBQUNYLFdBQUssYUFBYTtBQUNsQixXQUFLLFlBQVksU0FBUztBQUMxQixXQUFLLGtCQUFrQixTQUFTLFNBQVMsQ0FBQyxLQUFLO0FBQy9DLFdBQUssTUFBTSxXQUFXLEVBQUUsU0FBUyxLQUFLLFNBQVM7QUFDL0MsV0FBSyxNQUFNLG1CQUFtQixLQUFLLFNBQVM7QUFDNUMsYUFBTyxLQUFLO0FBQUEsSUFDZDtBQUVBLFVBQU0sSUFBSSxNQUFNLDBCQUEwQjtBQUFBLEVBQzVDO0FBQUEsRUFFQSxNQUFjLHVCQUF1QixRQUFrQztBQUNyRSxRQUFJLENBQUMsS0FBSyxZQUFZO0FBQ3BCLFlBQU0sSUFBSSxNQUFNLGdEQUFnRDtBQUFBLElBQ2xFO0FBRUEsVUFBTSxXQUNKLE1BQU0sUUFBUSxNQUFNLEtBQUssT0FBTyxTQUFTLElBQ3BDLE9BQU8sQ0FBQyxJQUtSO0FBTVAsUUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLElBQUk7QUFDN0IsWUFBTSxJQUFJLE1BQU0sZ0NBQWdDO0FBQUEsSUFDbEQ7QUFFQSxVQUFNLFNBQVUsTUFBTSxLQUFLLGtCQUFrQixvQkFBb0I7QUFBQSxNQUMvRCxJQUFJLFNBQVM7QUFBQSxNQUNiLE9BQU8sU0FBUyxTQUFTO0FBQUEsTUFDekIsTUFBTSxTQUFTLFFBQVE7QUFBQSxJQUFBLENBQ3hCO0FBRUQsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVRLGNBQWMsT0FBdUM7QUFDM0QsV0FBTyxzQkFBc0IsS0FBSyxLQUFLO0FBQUEsRUFDekM7QUFBQSxFQUVRLHlCQUF5QixRQUcvQjtBQUNBLFFBQUksTUFBTSxRQUFRLE1BQU0sR0FBRztBQUN6QixZQUFNLFFBQVEsT0FBTyxDQUFDO0FBQ3RCLFlBQU0sU0FBUyxPQUFPLENBQUM7QUFFdkIsVUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM3QixjQUFNLElBQUksTUFBTSw4QkFBOEI7QUFBQSxNQUNoRDtBQUVBLFVBQUksT0FBTyxXQUFXLFVBQVU7QUFDOUIsZUFBTyxFQUFFLFNBQVMsTUFBQTtBQUFBLE1BQ3BCO0FBRUEsWUFBTSxpQkFBaUIsS0FBSyxjQUFjLEtBQUs7QUFDL0MsWUFBTSxrQkFBa0IsS0FBSyxjQUFjLE1BQU07QUFFakQsVUFBSSxpQkFBaUI7QUFDbkIsZUFBTyxFQUFFLFNBQVMsT0FBTyxTQUFTLE9BQUE7QUFBQSxNQUNwQztBQUNBLFVBQUksZ0JBQWdCO0FBQ2xCLGVBQU8sRUFBRSxTQUFTLFFBQVEsU0FBUyxNQUFBO0FBQUEsTUFDckM7QUFDQSxhQUFPLEVBQUUsU0FBUyxNQUFBO0FBQUEsSUFDcEI7QUFFQSxRQUFJLFVBQVUsT0FBTyxXQUFXLFVBQVU7QUFDeEMsWUFBTSxlQUFlO0FBS3JCLFlBQU0sVUFDSixPQUFPLGFBQWEsU0FBUyxXQUN6QixhQUFhLE9BQ2IsT0FBTyxhQUFhLFlBQVksV0FDOUIsYUFBYSxVQUNiO0FBRVIsVUFBSSxDQUFDLFNBQVM7QUFDWixjQUFNLElBQUksTUFBTSw4QkFBOEI7QUFBQSxNQUNoRDtBQUVBLFVBQ0UsT0FBTyxhQUFhLFNBQVMsWUFDN0IsS0FBSyxjQUFjLGFBQWEsSUFBSSxHQUNwQztBQUNBLGVBQU8sRUFBRSxTQUFTLFNBQVMsYUFBYSxLQUFBO0FBQUEsTUFDMUM7QUFDQSxhQUFPLEVBQUUsUUFBQTtBQUFBLElBQ1g7QUFFQSxVQUFNLElBQUksTUFBTSw4QkFBOEI7QUFBQSxFQUNoRDtBQUFBLEVBRUEsTUFBYyxvQkFBb0IsUUFBa0M7QUFDbEUsUUFBSSxDQUFDLEtBQUssWUFBWTtBQUNwQixZQUFNLElBQUksTUFBTSxnREFBZ0Q7QUFBQSxJQUNsRTtBQUVBLFVBQU0sU0FBUyxLQUFLLHlCQUF5QixNQUFNO0FBQ25ELFVBQU0sa0JBQWtCLEtBQUs7QUFDN0IsUUFBSSxPQUFPLFdBQVcsaUJBQWlCO0FBQ3JDLFVBQUksT0FBTyxRQUFRLFlBQUEsTUFBa0IsZ0JBQWdCLGVBQWU7QUFDbEUsY0FBTSxJQUFJLE1BQU0sb0RBQW9EO0FBQUEsTUFDdEU7QUFBQSxJQUNGO0FBRUEsVUFBTSxvQkFDSixPQUFPLFlBQ04sbUJBQW1CLEtBQUssY0FBYyxlQUFlLElBQ2xELGtCQUNBO0FBRU4sVUFBTSxZQUFhLE1BQU0sS0FBSyxrQkFBa0IsZ0JBQWdCO0FBQUEsTUFDOUQsU0FBUyxPQUFPO0FBQUEsTUFDaEIsU0FBUztBQUFBLElBQUEsQ0FDVjtBQUVELFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFjLHFCQUFxQixTQUFtQztBQUNwRSxRQUFJLENBQUMsS0FBSyxZQUFZO0FBQ3BCLFlBQU0sSUFBSSxNQUFNLGdEQUFnRDtBQUFBLElBQ2xFO0FBRUEsVUFBTSxJQUFJLE1BQU0sMkNBQTJDO0FBQUEsRUFDN0Q7QUFBQSxFQUVBLE1BQWMsbUJBQW1CLFFBQWdDO0FBQy9ELFVBQU0sVUFBVyxNQUFNLFFBQVEsTUFBTSxJQUFJLE9BQU8sQ0FBQyxJQUFJO0FBSXJELFFBQUksQ0FBQyxTQUFTLFNBQVM7QUFDckIsWUFBTSxJQUFJLE1BQU0saUJBQWlCO0FBQUEsSUFDbkM7QUFFQSxVQUFNLGdCQUFnQixPQUFPLFNBQVMsUUFBUSxTQUFTLEVBQUU7QUFDekQsUUFBSSxDQUFDLE9BQU8sU0FBUyxhQUFhLEtBQUssaUJBQWlCLEdBQUc7QUFDekQsWUFBTSxJQUFJLE1BQU0saUJBQWlCO0FBQUEsSUFDbkM7QUFFQSxVQUFNLFdBQVksTUFBTSxLQUFLLGtCQUFrQixvQkFBb0I7QUFBQSxNQUNqRSxTQUFTO0FBQUEsSUFBQSxDQUNWO0FBQ0QsU0FBSyxrQkFBa0I7QUFBQSxNQUNyQixTQUFTLFVBQVUsV0FBVztBQUFBLE1BQzlCLFVBQVUsVUFBVSxZQUFZLEtBQUs7QUFBQSxJQUFBLENBQ3RDO0FBQ0QsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVBLE1BQWMsZ0JBQWdCLFFBQWlDO0FBQzdELFVBQU0sY0FBZSxNQUFNLFFBQVEsTUFBTSxJQUFJLE9BQU8sQ0FBQyxJQUFJO0FBR3pELFVBQU0sbUJBQW1CLGFBQWEsVUFDbEMsT0FBTyxTQUFTLFlBQVksU0FBUyxFQUFFLElBQ3ZDO0FBRUosUUFDRSxxQkFBcUIsWUFDckIscUJBQXFCLFlBQ3JCLHFCQUFxQixRQUNyQjtBQUNBLGFBQU87QUFBQSxJQUNUO0FBRUEsVUFBTSxJQUFJLE1BQU0saURBQWlEO0FBQUEsRUFDbkU7QUFBQSxFQUVRLHdCQUE0QztBQUNsRCxRQUFJLENBQUMsS0FBSyxZQUFZO0FBQ3BCLGFBQU8sQ0FBQTtBQUFBLElBQ1Q7QUFDQSxXQUFPLENBQUMsRUFBRSxrQkFBa0IsZ0JBQWdCO0FBQUEsRUFDOUM7QUFBQSxFQUVBLE1BQWMsMEJBQ1osUUFDNkI7QUFDN0IsVUFBTSxVQUFVLE1BQU0sUUFBUSxNQUFNLElBQUksT0FBTyxDQUFDLElBQUk7QUFDcEQsVUFBTSxnQkFDSixPQUFPLFlBQVksWUFDbkIsWUFBWSxRQUNaLE9BQU8sVUFBVSxlQUFlLEtBQUssU0FBUyxjQUFjO0FBRTlELFFBQUksQ0FBQyxlQUFlO0FBQ2xCLFlBQU0sSUFBSSxNQUFNLDJDQUEyQztBQUFBLElBQzdEO0FBRUEsVUFBTSxLQUFLLHVCQUFBO0FBQ1gsV0FBTyxDQUFDLEVBQUUsa0JBQWtCLGdCQUFnQjtBQUFBLEVBQzlDO0FBQUEsRUFFQSxNQUFjLGlCQUFrQztBQUM5QyxRQUFJO0FBQ0YsWUFBTSxTQUFTLE1BQU0sS0FBSyxrQkFBa0Isb0JBQW9CLENBQUEsQ0FBRTtBQUNsRSxVQUFJLE9BQU8sV0FBVyxZQUFZLFNBQVMsR0FBRztBQUM1QyxhQUFLLGtCQUFrQixFQUFFLFNBQVMsT0FBQSxDQUFRO0FBQUEsTUFDNUM7QUFBQSxJQUNGLFNBQVMsT0FBTztBQUNkLGNBQVEsS0FBSyx5Q0FBeUMsS0FBSztBQUFBLElBQzdEO0FBQ0EsV0FBTyxLQUFLO0FBQUEsRUFDZDtBQUNGO0FBRUEsU0FBUyx5QkFBeUJBLFdBQTBDO0FBQzFFLE1BQUksTUFBTSxRQUFRQSxVQUFTLFNBQVMsR0FBRztBQUNyQyxXQUFPQSxVQUFTO0FBQUEsRUFDbEI7QUFDQSxTQUFPLENBQUNBLFNBQVE7QUFDbEI7QUFFQSxTQUFTLG1CQUFtQixXQUErQjtBQUN6RCxTQUFPLFVBQVU7QUFBQSxJQUNmLENBQUMsYUFDQyxPQUFPLGFBQWEsWUFDcEIsYUFBYSxRQUNaLFNBQWlDLGNBQWM7QUFBQSxFQUFBO0FBRXREO0FBRUEsU0FBUyx3QkFBd0IsVUFBaUM7QUFDaEUsUUFBTSxTQUFnQztBQUFBLElBQ3BDLE1BQU07QUFBQSxJQUNOO0FBQUEsRUFBQTtBQUVGLFNBQU87QUFBQSxJQUNMLElBQUksWUFBbUMsd0JBQXdCLEVBQUUsUUFBUTtBQUFBLEVBQUE7QUFFN0U7QUFFQSxNQUFNLGtCQUFrQixJQUFJLGdCQUFBO0FBQzVCLE1BQU0sV0FBWSxPQUFPLFlBQWdEO0FBRXpFLElBQUksQ0FBQyxVQUFVO0FBQ2IsU0FBTyxXQUFXO0FBQ2xCLFVBQVEsSUFBSSxpREFBaUQ7QUFDL0QsT0FBTztBQUNMLFFBQU0sWUFBWSx5QkFBeUIsUUFBUTtBQUNuRCxNQUFJLENBQUMsbUJBQW1CLFNBQVMsR0FBRztBQUNsQyxjQUFVLEtBQUssZUFBZTtBQUM5QixhQUFTLFlBQVk7QUFDckIsWUFBUTtBQUFBLE1BQ047QUFBQSxJQUFBO0FBQUEsRUFFSixPQUFPO0FBQ0wsWUFBUSxJQUFJLDZDQUE2QztBQUFBLEVBQzNEO0FBQ0Y7QUFFQSxPQUFPLGlCQUFpQix1QkFBdUIsTUFBTTtBQUNuRCwwQkFBd0IsZUFBZTtBQUN6QyxDQUFDO0FBQ0Qsd0JBQXdCLGVBQWU7QUFDdkMsV0FBVyxNQUFNLHdCQUF3QixlQUFlLEdBQUcsQ0FBQztBQUc1RCxPQUFPLGlCQUFpQixXQUFXLENBQUMsVUFBVTtBQUM1QyxNQUNFLE1BQU0sS0FBSyxXQUFXLGtCQUN0QixNQUFNLEtBQUssU0FBUyxjQUNwQjtBQUNBLG9CQUFnQix5QkFBQTtBQUNoQjtBQUFBLEVBQ0Y7QUFFQSxNQUNFLE1BQU0sS0FBSyxXQUFXLGtCQUN0QixNQUFNLEtBQUssU0FBUyx3QkFDcEI7QUFDQSxvQkFBZ0I7QUFBQSxNQUNiLE1BQU0sS0FBSyxXQUEyQyxDQUFBO0FBQUEsSUFBQztBQUFBLEVBRTVEO0FBQ0YsQ0FBQztBQUdELE9BQU8sY0FBYyxJQUFJLE1BQU0sc0JBQXNCLENBQUM7In0=
