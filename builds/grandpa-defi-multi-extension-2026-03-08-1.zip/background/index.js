import { D as DEFAULT_SETTINGS, S as STORAGE_KEYS, j as getNetworkByChainId, s as sleep, k as authHeaders, w as withErrorCause, l as getAxiosErrorMessage, m as createIdempotencyKey, n as refreshWithToken, c as apiClient, o as initializeApiClient } from "../chunks/utils.DMNWPQT_.js";
const DEFAULT_API_SESSION = {
  accessToken: null,
  refreshToken: null,
  accessTokenExpiresAt: null,
  credentialId: null,
  rpId: null
};
function readStorageKey(result, key, fallback) {
  const value = result[key];
  return value ?? fallback;
}
function normalizeOrigin(value) {
  try {
    const url = new URL(value);
    const protocol = url.protocol.toLowerCase();
    const hostname = url.hostname.toLowerCase();
    const port = url.port;
    const includePort = port.length > 0 && !(protocol === "https:" && port === "443" || protocol === "http:" && port === "80");
    const host = includePort ? `${hostname}:${port}` : hostname;
    return `${protocol}//${host}`;
  } catch {
    return value.trim().toLowerCase();
  }
}
class StorageManager {
  buildConnectedSiteKey(entry) {
    return [
      entry.walletScope,
      entry.walletAddress.toLowerCase(),
      String(entry.chainId),
      entry.normalizedOrigin
    ].join("|");
  }
  isConnectedSiteRecord(value) {
    if (!value || typeof value !== "object") return false;
    const record = value;
    return typeof record.connectionId === "string" && typeof record.origin === "string" && typeof record.normalizedOrigin === "string" && typeof record.host === "string" && (record.walletScope === "pocket" || record.walletScope === "vault") && typeof record.walletAddress === "string" && typeof record.chainId === "number";
  }
  async initialize() {
    const existing = await this.getAll();
    if (!existing.settings) {
      await chrome.storage.local.set({
        [STORAGE_KEYS.SETTINGS]: DEFAULT_SETTINGS,
        [STORAGE_KEYS.CONNECTED_SITES]: {},
        [STORAGE_KEYS.API_SESSION]: DEFAULT_API_SESSION,
        [STORAGE_KEYS.API_POCKETS]: [],
        [STORAGE_KEYS.API_SELECTED_POCKET_ID]: null,
        [STORAGE_KEYS.API_PENDING_USER_OPERATIONS]: [],
        [STORAGE_KEYS.API_DAPP_CONNECTIONS]: [],
        [STORAGE_KEYS.API_CHAIN_ID]: null,
        [STORAGE_KEYS.API_VAULT]: null
      });
      console.log("[Storage] Initialized with defaults");
    }
  }
  async getAll() {
    return chrome.storage.local.get(null);
  }
  async clearAll() {
    await chrome.storage.local.clear();
  }
  async getSettings() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.SETTINGS
    );
    return readStorageKey(result, STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
  }
  async setSettings(settings) {
    await chrome.storage.local.set({ [STORAGE_KEYS.SETTINGS]: settings });
  }
  async updateSettings(updates) {
    const settings = await this.getSettings();
    await this.setSettings({ ...settings, ...updates });
  }
  // Connected sites management
  async getConnectedSites() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.CONNECTED_SITES
    );
    const raw = readStorageKey(result, STORAGE_KEYS.CONNECTED_SITES, {});
    const entries = Object.entries(raw);
    const next = {};
    for (const [key, value] of entries) {
      if (!this.isConnectedSiteRecord(value)) continue;
      next[key] = value;
    }
    return next;
  }
  async addConnectedSite(site) {
    const sites = await this.getConnectedSites();
    const normalizedOrigin = normalizeOrigin(
      site.normalizedOrigin || site.origin
    );
    const now = Date.now();
    const key = this.buildConnectedSiteKey({
      normalizedOrigin,
      walletScope: site.walletScope,
      walletAddress: site.walletAddress,
      chainId: site.chainId
    });
    sites[key] = {
      ...site,
      origin: normalizeOrigin(site.origin),
      normalizedOrigin,
      connectedAt: site.connectedAt || now,
      lastUsedAt: site.lastUsedAt || now
    };
    await chrome.storage.local.set({ [STORAGE_KEYS.CONNECTED_SITES]: sites });
  }
  async removeConnectedSite(connectionId) {
    const sites = await this.getConnectedSites();
    for (const [key, entry] of Object.entries(sites)) {
      if (entry.connectionId !== connectionId) continue;
      delete sites[key];
    }
    await chrome.storage.local.set({ [STORAGE_KEYS.CONNECTED_SITES]: sites });
  }
  async removeConnectedSitesForOrigin(origin, walletAddress) {
    const sites = await this.getConnectedSites();
    const normalizedOrigin = normalizeOrigin(origin);
    const normalizedWalletAddress = walletAddress?.toLowerCase() ?? null;
    for (const [key, entry] of Object.entries(sites)) {
      if (entry.normalizedOrigin !== normalizedOrigin) continue;
      if (normalizedWalletAddress && entry.walletAddress.toLowerCase() !== normalizedWalletAddress) {
        continue;
      }
      delete sites[key];
    }
    await chrome.storage.local.set({ [STORAGE_KEYS.CONNECTED_SITES]: sites });
  }
  async findConnectedSite(params) {
    const sites = await this.getConnectedSites();
    const normalizedOrigin = normalizeOrigin(params.origin);
    const normalizedWalletAddress = params.walletAddress.toLowerCase();
    const match = Object.values(sites).find(
      (site) => site.normalizedOrigin === normalizedOrigin && site.walletScope === params.walletScope && site.chainId === params.chainId && site.walletAddress.toLowerCase() === normalizedWalletAddress
    );
    return match ?? null;
  }
  async isConnectedSite(params) {
    return await this.findConnectedSite(params) !== null;
  }
  async touchConnectedSite(connectionId) {
    const sites = await this.getConnectedSites();
    let didUpdate = false;
    for (const [key, site] of Object.entries(sites)) {
      if (site.connectionId !== connectionId) continue;
      sites[key] = {
        ...site,
        lastUsedAt: Date.now()
      };
      didUpdate = true;
    }
    if (didUpdate) {
      await chrome.storage.local.set({ [STORAGE_KEYS.CONNECTED_SITES]: sites });
    }
  }
  // API session management (new backend)
  async getApiSession() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.API_SESSION
    );
    return readStorageKey(
      result,
      STORAGE_KEYS.API_SESSION,
      DEFAULT_API_SESSION
    );
  }
  async setApiSession(session) {
    await chrome.storage.local.set({ [STORAGE_KEYS.API_SESSION]: session });
  }
  async clearApiSession() {
    await this.setApiSession(DEFAULT_API_SESSION);
  }
  async getApiPockets() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.API_POCKETS
    );
    return readStorageKey(result, STORAGE_KEYS.API_POCKETS, []);
  }
  async setApiPockets(pockets) {
    await chrome.storage.local.set({ [STORAGE_KEYS.API_POCKETS]: pockets });
  }
  async getApiSelectedPocketId() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.API_SELECTED_POCKET_ID
    );
    return readStorageKey(result, STORAGE_KEYS.API_SELECTED_POCKET_ID, null);
  }
  async setApiSelectedPocketId(pocketId) {
    await chrome.storage.local.set({
      [STORAGE_KEYS.API_SELECTED_POCKET_ID]: pocketId
    });
  }
  async getApiPendingUserOperations() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.API_PENDING_USER_OPERATIONS
    );
    return readStorageKey(
      result,
      STORAGE_KEYS.API_PENDING_USER_OPERATIONS,
      []
    );
  }
  async setApiPendingUserOperations(operations) {
    await chrome.storage.local.set({
      [STORAGE_KEYS.API_PENDING_USER_OPERATIONS]: operations
    });
  }
  async getApiDappConnections() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.API_DAPP_CONNECTIONS
    );
    return readStorageKey(
      result,
      STORAGE_KEYS.API_DAPP_CONNECTIONS,
      []
    );
  }
  async setApiDappConnections(connections) {
    await chrome.storage.local.set({
      [STORAGE_KEYS.API_DAPP_CONNECTIONS]: connections
    });
  }
  async getApiChainId() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.API_CHAIN_ID
    );
    return readStorageKey(result, STORAGE_KEYS.API_CHAIN_ID, null);
  }
  async setApiChainId(chainId) {
    await chrome.storage.local.set({ [STORAGE_KEYS.API_CHAIN_ID]: chainId });
  }
  async getApiVault() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.API_VAULT
    );
    return readStorageKey(result, STORAGE_KEYS.API_VAULT, null);
  }
  async setApiVault(vault) {
    await chrome.storage.local.set({ [STORAGE_KEYS.API_VAULT]: vault });
  }
}
const DAPP_CONFIRM_TIMEOUT_MS = 5 * 6e4;
const CONNECT_TIMEOUT_MS = 2 * 6e4;
const CONNECT_POLL_INTERVAL_MS = 500;
class MessageHandler {
  constructor(storage2, api) {
    this.storage = storage2;
    this.api = api;
    chrome.windows.onRemoved.addListener((windowId) => {
      for (const [requestId, entry] of this.pendingDappConnects) {
        if (entry.windowId !== windowId) continue;
        clearTimeout(entry.timeoutId);
        this.pendingDappConnects.delete(requestId);
        entry.reject(new Error("Connection confirmation was closed"));
      }
      for (const [operationId, entry] of this.pendingDappTransactions) {
        if (entry.windowId !== windowId) continue;
        clearTimeout(entry.timeoutId);
        this.pendingDappTransactions.delete(operationId);
        entry.reject(new Error("Transaction confirmation was closed"));
      }
      for (const [requestId, entry] of this.pendingDappSignatures) {
        if (entry.windowId !== windowId) continue;
        clearTimeout(entry.timeoutId);
        this.pendingDappSignatures.delete(requestId);
        entry.reject(new Error("Signature confirmation was closed"));
      }
    });
  }
  pendingDappConnects = /* @__PURE__ */ new Map();
  pendingDappTransactions = /* @__PURE__ */ new Map();
  pendingDappSignatures = /* @__PURE__ */ new Map();
  async handleMessage(message, sender) {
    console.log("[MessageHandler] Handling:", message.type);
    switch (message.type) {
      case "CONNECT_SITE":
        return this.handleConnectSite(message.payload, sender);
      case "DISCONNECT_SITE":
        return this.handleDisconnectSite(message.payload);
      case "SEND_TRANSACTION":
        return this.handleSendTransaction(message.payload, sender);
      case "SIGN_MESSAGE":
        return this.handleSignMessage(message.payload, sender);
      case "CLEAR_ALL_DATA":
        return this.handleClearAllData();
      case "API_GET_SESSION":
        return this.api.getSession();
      case "API_SET_SESSION":
        return this.api.setSession(message.payload);
      case "API_CLEAR_SESSION":
        return this.handleClearSession();
      case "API_GET_CHAIN_ID":
        return this.api.getChainId();
      case "API_USERS_ME":
        return this.api.getMe();
      case "API_POCKET_SELECT":
        return this.handlePocketSelect(message.payload);
      case "API_POCKET_PREPARE":
        return this.api.preparePocket();
      case "API_POCKET_SUBMIT":
        return this.api.submitPocket(
          message.payload
        );
      case "API_SWITCH_CHAIN":
        return this.handleSwitchChain(message.payload, sender);
      case "API_POCKET_SEND_PREPARE":
        return this.api.preparePocketSend(
          message.payload.pocketId,
          message.payload.request
        );
      case "API_POCKET_SEND_SUBMIT":
        return this.api.submitPocketSend(
          message.payload.pocketId,
          message.payload.request
        );
      case "API_POCKET_CUSTOM_PREPARE":
        return this.api.preparePocketCustom(
          message.payload.pocketId,
          message.payload.request
        );
      case "API_POCKET_CUSTOM_SUBMIT":
        return this.api.submitPocketCustom(
          message.payload.pocketId,
          message.payload.request
        );
      case "API_POCKET_PERSONAL_SIGN_PREPARE":
        return this.api.preparePocketPersonalSign(
          message.payload.pocketId,
          message.payload.request
        );
      case "API_POCKET_PERSONAL_SIGN_SUBMIT":
        return this.api.submitPocketPersonalSign(
          message.payload.pocketId,
          message.payload.request
        );
      case "API_POCKET_BALANCES":
        return this.api.getPocketBalances(message.payload.pocketId);
      case "API_POCKET_ACTIVITIES":
        return this.api.getPocketActivities(message.payload.pocketId, {
          cursor: message.payload.cursor,
          limit: message.payload.limit
        });
      case "API_USEROP_GET":
        return this.api.getUserOperation(message.payload.operationId);
      case "API_USEROP_CANCEL":
        return this.api.cancelUserOperation(message.payload.operationId);
      case "API_DAPP_CONNECT_CONTEXT":
        return this.handleApiDappConnectContext(message.payload);
      case "API_DAPP_CONNECT_RESULT":
        return this.handleApiDappConnectResult(message.payload);
      case "API_DAPP_TX_CONTEXT":
        return this.handleApiDappTxContext(message.payload);
      case "API_DAPP_TX_RESULT":
        return this.handleApiDappTxResult(message.payload);
      case "API_DAPP_SIGN_CONTEXT":
        return this.handleApiDappSignContext(message.payload);
      case "API_DAPP_SIGN_RESULT":
        return this.handleApiDappSignResult(message.payload);
      case "API_ADDRESS_BOOK_LIST":
        return this.api.listAddressBook();
      case "API_ADDRESS_BOOK_UPSERT":
        return this.api.upsertAddressBook(
          message.payload
        );
      case "API_ADDRESS_BOOK_DELETE":
        return this.api.deleteAddressBook(
          message.payload
        );
      default:
        throw new Error(
          `Unknown message type: ${message.type ?? "unknown"}`
        );
    }
  }
  normalizeOrigin(value) {
    try {
      const url = new URL(value);
      const protocol = url.protocol.toLowerCase();
      const hostname = url.hostname.toLowerCase();
      const port = url.port;
      const includePort = port.length > 0 && !(protocol === "https:" && port === "443" || protocol === "http:" && port === "80");
      const host = includePort ? `${hostname}:${port}` : hostname;
      return `${protocol}//${host}`;
    } catch {
      return value.trim().toLowerCase();
    }
  }
  toConnectedSiteRecord(connection) {
    const now = Date.now();
    return {
      connectionId: connection.connectionId,
      origin: connection.origin,
      normalizedOrigin: connection.normalizedOrigin,
      host: connection.host,
      walletScope: connection.walletScope,
      walletId: connection.walletId,
      walletAddress: connection.walletAddress,
      chainId: connection.chainId,
      trustLevel: connection.trustLevel,
      connectedAt: connection.connectedAt ? Date.parse(connection.connectedAt) || now : now,
      lastUsedAt: now
    };
  }
  buildUnknownSigningWarning(host) {
    return {
      tone: "soft",
      title: "Unknown dApp",
      message: `${host} is not in the trusted list. Review details carefully before signing.`
    };
  }
  async recordSignEvent(connectionId, kind, outcome) {
    try {
      await this.api.recordDappConnectionSignEvent(connectionId, {
        kind,
        outcome
      });
    } catch (error) {
      console.warn("[MessageHandler] Failed to record dApp sign event:", error);
    }
  }
  selectPocket(pockets, selectedPocketId, requireDeployed) {
    if (pockets.length === 0) {
      return null;
    }
    const selectedPocket = pockets.find((pocket) => pocket.pocketId === selectedPocketId) ?? null;
    if (selectedPocket && (!requireDeployed || selectedPocket.deployState === "DEPLOYED")) {
      return selectedPocket;
    }
    if (requireDeployed) {
      return pockets.find((pocket) => pocket.deployState === "DEPLOYED") ?? null;
    }
    return selectedPocket ?? pockets[0] ?? null;
  }
  async getStoredPockets() {
    let pockets = await this.storage.getApiPockets();
    if (pockets.length > 0) {
      return pockets;
    }
    try {
      await this.api.getMe();
    } catch (error) {
      console.warn("[MessageHandler] Failed to refresh pockets:", error);
    }
    pockets = await this.storage.getApiPockets();
    return pockets;
  }
  async getPrimaryPocket(options) {
    const pockets = await this.getStoredPockets();
    const selectedPocketId = await this.storage.getApiSelectedPocketId();
    return this.selectPocket(
      pockets,
      selectedPocketId,
      options?.requireDeployed ?? false
    );
  }
  async findPocketByAddressAndChain(address, chainId, options) {
    const pockets = await this.getStoredPockets();
    return pockets.find(
      (pocket) => pocket.address.toLowerCase() === address.toLowerCase() && pocket.chainId === chainId && (!options?.requireDeployed || pocket.deployState === "DEPLOYED")
    ) ?? null;
  }
  async broadcastRuntimeMessage(message) {
    const tabs = await chrome.tabs.query({});
    await Promise.all(
      tabs.map(async (tab) => {
        if (typeof tab.id !== "number") {
          return;
        }
        try {
          await chrome.tabs.sendMessage(tab.id, message);
        } catch {
        }
      })
    );
  }
  async broadcastProviderStateChange(pocket) {
    await this.broadcastRuntimeMessage({
      type: "PROVIDER_STATE_CHANGED",
      payload: {
        chainId: pocket?.chainId ?? null,
        accounts: pocket ? [pocket.address] : []
      }
    });
  }
  async broadcastDisconnect() {
    await this.broadcastRuntimeMessage({ type: "SITE_DISCONNECTED" });
  }
  async hasConnectedApprovalForOrigin(origin, walletAddress) {
    const normalizedOrigin = this.normalizeOrigin(origin);
    const localSites = await this.storage.getConnectedSites();
    const localMatch = Object.values(localSites).find(
      (site) => site.walletScope === "pocket" && site.normalizedOrigin === normalizedOrigin && site.walletAddress.toLowerCase() === walletAddress.toLowerCase()
    ) ?? null;
    if (localMatch) {
      return localMatch;
    }
    try {
      const remote = await this.api.listDappConnections({
        walletScope: "pocket",
        status: "connected"
      });
      const remoteMatch = remote.connections.find(
        (connection) => connection.normalizedOrigin === normalizedOrigin && connection.walletAddress.toLowerCase() === walletAddress.toLowerCase()
      ) ?? null;
      if (!remoteMatch) {
        return null;
      }
      const record = this.toConnectedSiteRecord(remoteMatch);
      await this.storage.addConnectedSite(record);
      return record;
    } catch (error) {
      console.warn(
        "[MessageHandler] Failed to resolve cross-chain dApp approval:",
        error
      );
      return null;
    }
  }
  async ensureConnectedSiteForPocket(origin, pocket) {
    const existing = await this.resolveConnectedSiteForPocket(origin, pocket);
    if (existing) {
      return existing;
    }
    const priorApproval = await this.hasConnectedApprovalForOrigin(
      origin,
      pocket.address
    );
    if (!priorApproval) {
      return null;
    }
    const prepared = await this.api.prepareDappConnection({
      origin: this.normalizeOrigin(origin),
      walletScope: "pocket",
      walletAddress: pocket.address,
      chainId: pocket.chainId,
      pocketId: pocket.pocketId
    });
    if (prepared.connection.trustLevel === "blocked") {
      throw new Error(prepared.warningMessage || "This dApp is blocked");
    }
    if (prepared.alreadyConnected && prepared.connection.status === "connected") {
      const record2 = this.toConnectedSiteRecord(prepared.connection);
      await this.storage.addConnectedSite(record2);
      return record2;
    }
    const confirmed = await this.api.confirmDappConnection(
      prepared.connection.connectionId
    );
    const record = this.toConnectedSiteRecord(confirmed.connection);
    await this.storage.addConnectedSite(record);
    return record;
  }
  async resolveConnectedSiteForPocket(origin, pocket) {
    const local = await this.storage.findConnectedSite({
      origin,
      walletAddress: pocket.address,
      chainId: pocket.chainId,
      walletScope: "pocket"
    });
    if (local) {
      return local;
    }
    try {
      const normalizedOrigin = this.normalizeOrigin(origin);
      const remote = await this.api.listDappConnections({
        walletScope: "pocket",
        walletId: pocket.pocketId,
        status: "connected"
      });
      const match = remote.connections.find(
        (connection) => connection.normalizedOrigin === normalizedOrigin
      );
      if (!match) {
        return null;
      }
      const record = this.toConnectedSiteRecord(match);
      await this.storage.addConnectedSite(record);
      return record;
    } catch (error) {
      console.warn("[MessageHandler] Failed to resolve connected dApp:", error);
      return null;
    }
  }
  async handleConnectSite(payload, sender) {
    const rawOrigin = payload.origin || sender.origin || sender.url;
    if (!rawOrigin) {
      throw new Error("No origin provided");
    }
    const origin = this.normalizeOrigin(rawOrigin);
    const pocket = await this.ensurePrimaryPocketReady({
      requireDeployed: true
    });
    if (!pocket) {
      throw new Error(
        "Wallet not ready. Sign in to an existing deployed pocket first."
      );
    }
    const autoConnected = await this.ensureConnectedSiteForPocket(
      origin,
      pocket
    );
    if (autoConnected) {
      return {
        connected: true,
        accounts: [pocket.address]
      };
    }
    const prepared = await this.api.prepareDappConnection({
      origin,
      walletScope: "pocket",
      walletAddress: pocket.address,
      chainId: pocket.chainId,
      pocketId: pocket.pocketId
    });
    if (prepared.connection.trustLevel === "blocked") {
      throw new Error(prepared.warningMessage || "This dApp is blocked");
    }
    if (prepared.alreadyConnected && prepared.connection.status === "connected") {
      await this.storage.addConnectedSite(
        this.toConnectedSiteRecord(prepared.connection)
      );
      return {
        connected: true,
        accounts: [pocket.address]
      };
    }
    const requestId = crypto.randomUUID();
    const windowId = await this.openConnectConfirmWindow(requestId);
    let approved = false;
    try {
      approved = await this.awaitDappConnectConfirmation(requestId, {
        windowId,
        origin,
        walletAddress: pocket.address,
        connection: prepared.connection,
        warning: {
          tone: prepared.warningTone,
          title: prepared.warningTitle,
          message: prepared.warningMessage
        }
      });
    } catch (error) {
      await this.api.rejectDappConnection(prepared.connection.connectionId).catch(() => void 0);
      throw error;
    }
    if (!approved) {
      await this.api.rejectDappConnection(prepared.connection.connectionId).catch(() => void 0);
      throw new Error("User rejected connection");
    }
    const confirmed = await this.api.confirmDappConnection(
      prepared.connection.connectionId
    );
    await this.storage.addConnectedSite(
      this.toConnectedSiteRecord(confirmed.connection)
    );
    return {
      connected: true,
      accounts: [pocket.address]
    };
  }
  async handleDisconnectSite(payload) {
    const pocket = await this.getPrimaryPocket();
    if (!pocket) {
      await this.storage.removeConnectedSitesForOrigin(payload.origin);
      return { success: true };
    }
    const site = await this.storage.findConnectedSite({
      origin: payload.origin,
      walletAddress: pocket.address,
      chainId: pocket.chainId,
      walletScope: "pocket"
    });
    if (site) {
      await this.api.disconnectDappConnection(site.connectionId).catch((error) => {
        console.warn("[MessageHandler] Failed to disconnect dApp:", error);
      });
      await this.storage.removeConnectedSite(site.connectionId);
    }
    await this.storage.removeConnectedSitesForOrigin(
      payload.origin,
      pocket.address
    );
    return { success: true };
  }
  async handleSendTransaction(payload, sender) {
    const origin = sender.origin || sender.url;
    if (!origin) {
      throw new Error("No origin provided");
    }
    if (!payload.to) {
      throw new Error("Invalid transaction parameters");
    }
    const pocket = await this.getPrimaryPocket({ requireDeployed: true });
    if (!pocket) {
      throw new Error("No pocket available");
    }
    const connection = await this.ensureConnectedSiteForPocket(origin, pocket);
    if (!connection) {
      throw new Error("Site not connected");
    }
    if (connection.trustLevel === "blocked") {
      throw new Error("This dApp is blocked");
    }
    await this.storage.touchConnectedSite(connection.connectionId);
    void this.recordSignEvent(
      connection.connectionId,
      "transaction",
      "requested"
    );
    const warning = connection.trustLevel === "unknown" ? this.buildUnknownSigningWarning(connection.host) : null;
    const prepared = await this.api.preparePocketCustom(pocket.pocketId, {
      metaTransactions: [
        {
          to: payload.to,
          value: payload.value || "0x0",
          data: payload.data || "0x"
        }
      ]
    });
    const windowId = await this.openConfirmWindow(prepared.operationId);
    return this.awaitDappConfirmation(prepared.operationId, {
      windowId,
      origin: connection.origin,
      connection,
      warning
    });
  }
  async handleSignMessage(payload, sender) {
    const origin = sender.origin || sender.url;
    if (!origin) {
      throw new Error("No origin provided");
    }
    if (typeof payload.message !== "string") {
      throw new Error("Invalid sign message parameters");
    }
    const pocket = await this.getPrimaryPocket({ requireDeployed: true });
    if (!pocket) {
      throw new Error("No pocket available");
    }
    const connection = await this.ensureConnectedSiteForPocket(origin, pocket);
    if (!connection) {
      throw new Error("Site not connected");
    }
    if (connection.trustLevel === "blocked") {
      throw new Error("This dApp is blocked");
    }
    const requestedAddress = payload.address?.toLowerCase();
    if (requestedAddress && requestedAddress !== pocket.address.toLowerCase()) {
      throw new Error("Requested account does not match selected pocket");
    }
    await this.storage.touchConnectedSite(connection.connectionId);
    void this.recordSignEvent(connection.connectionId, "message", "requested");
    const warning = connection.trustLevel === "unknown" ? this.buildUnknownSigningWarning(connection.host) : null;
    const requestId = crypto.randomUUID();
    const windowId = await this.openSignConfirmWindow(requestId);
    return this.awaitDappSignConfirmation(requestId, {
      windowId,
      message: payload.message,
      address: pocket.address,
      origin: connection.origin,
      pocketId: pocket.pocketId,
      connection,
      warning
    });
  }
  async handleClearAllData() {
    await this.storage.clearAll();
    await this.broadcastDisconnect();
    return { success: true };
  }
  async handleClearSession() {
    await this.api.clearSession();
    await this.broadcastDisconnect();
    return { success: true };
  }
  async handlePocketSelect(payload) {
    const selectedPocket = await this.api.setSelectedPocketId(payload.pocketId);
    await this.broadcastProviderStateChange(selectedPocket);
    return {
      pocketId: selectedPocket?.pocketId ?? null,
      chainId: selectedPocket?.chainId ?? null
    };
  }
  async handleSwitchChain(payload, sender) {
    const rawOrigin = sender.origin || sender.url;
    if (!rawOrigin) {
      throw new Error("No origin provided");
    }
    if (!getNetworkByChainId(payload.chainId)) {
      throw new Error(`Chain ${payload.chainId} is not supported.`);
    }
    const currentPocket = await this.getPrimaryPocket({
      requireDeployed: true
    });
    if (!currentPocket) {
      throw new Error("No deployed pocket available");
    }
    if (currentPocket.chainId === payload.chainId) {
      return {
        chainId: currentPocket.chainId,
        accounts: [currentPocket.address],
        walletAddress: currentPocket.address,
        addressChanged: false
      };
    }
    const priorApproval = await this.hasConnectedApprovalForOrigin(
      rawOrigin,
      currentPocket.address
    );
    if (!priorApproval) {
      throw new Error("Site not connected");
    }
    const targetPocket = await this.findPocketByAddressAndChain(
      currentPocket.address,
      payload.chainId,
      { requireDeployed: true }
    );
    if (!targetPocket) {
      throw new Error(
        "No deployed pocket is available on the requested chain."
      );
    }
    const addressChanged = targetPocket.address.toLowerCase() !== currentPocket.address.toLowerCase();
    await this.api.setSelectedPocketId(targetPocket.pocketId);
    const connection = await this.ensureConnectedSiteForPocket(
      rawOrigin,
      targetPocket
    );
    if (!connection) {
      throw new Error("Failed to connect the dApp on the requested chain.");
    }
    await this.broadcastProviderStateChange(targetPocket);
    return {
      chainId: targetPocket.chainId,
      accounts: [targetPocket.address],
      walletAddress: targetPocket.address,
      addressChanged
    };
  }
  async ensurePrimaryPocketReady(options) {
    const existing = await this.getPrimaryPocket(options);
    if (existing) {
      return existing;
    }
    const windowId = await this.openExtensionWindow();
    try {
      return this.awaitPrimaryPocket(CONNECT_TIMEOUT_MS, options);
    } finally {
      if (windowId) {
        chrome.windows.remove(windowId, () => void 0);
      }
    }
  }
  async awaitPrimaryPocket(timeoutMs, options) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const pocket = await this.getPrimaryPocket(options);
      if (pocket) {
        return pocket;
      }
      await sleep(CONNECT_POLL_INTERVAL_MS);
    }
    return null;
  }
  async openConfirmWindow(operationId) {
    const url = chrome.runtime.getURL(
      `popup/index.html#/confirm-tx?operationId=${encodeURIComponent(
        operationId
      )}`
    );
    return new Promise((resolve) => {
      chrome.windows.create(
        {
          url,
          type: "popup",
          width: 420,
          height: 720,
          focused: true
        },
        (window) => {
          resolve(window?.id);
        }
      );
    });
  }
  async openConnectConfirmWindow(requestId) {
    const url = chrome.runtime.getURL(
      `popup/index.html#/confirm-connect?requestId=${encodeURIComponent(
        requestId
      )}`
    );
    return new Promise((resolve) => {
      chrome.windows.create(
        {
          url,
          type: "popup",
          width: 420,
          height: 720,
          focused: true
        },
        (window) => {
          resolve(window?.id);
        }
      );
    });
  }
  async openSignConfirmWindow(requestId) {
    const url = chrome.runtime.getURL(
      `popup/index.html#/confirm-sign?requestId=${encodeURIComponent(
        requestId
      )}`
    );
    return new Promise((resolve) => {
      chrome.windows.create(
        {
          url,
          type: "popup",
          width: 420,
          height: 720,
          focused: true
        },
        (window) => {
          resolve(window?.id);
        }
      );
    });
  }
  async openExtensionWindow() {
    const url = chrome.runtime.getURL("popup/index.html#/");
    return new Promise((resolve) => {
      chrome.windows.create(
        {
          url,
          type: "popup",
          width: 420,
          height: 720,
          focused: true
        },
        (window) => {
          resolve(window?.id);
        }
      );
    });
  }
  awaitDappConnectConfirmation(requestId, payload) {
    if (this.pendingDappConnects.has(requestId)) {
      this.pendingDappConnects.get(requestId)?.reject(new Error("Duplicate connect request"));
      this.pendingDappConnects.delete(requestId);
    }
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        this.pendingDappConnects.delete(requestId);
        reject(new Error("Connection confirmation timed out"));
      }, DAPP_CONFIRM_TIMEOUT_MS);
      this.pendingDappConnects.set(requestId, {
        resolve,
        reject,
        timeoutId,
        ...payload
      });
    });
  }
  awaitDappConfirmation(operationId, payload) {
    if (this.pendingDappTransactions.has(operationId)) {
      this.pendingDappTransactions.get(operationId)?.reject(new Error("Duplicate transaction request"));
      this.pendingDappTransactions.delete(operationId);
    }
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        this.pendingDappTransactions.delete(operationId);
        reject(new Error("Transaction confirmation timed out"));
      }, DAPP_CONFIRM_TIMEOUT_MS);
      this.pendingDappTransactions.set(operationId, {
        resolve,
        reject,
        timeoutId,
        ...payload
      });
    });
  }
  awaitDappSignConfirmation(requestId, payload) {
    if (this.pendingDappSignatures.has(requestId)) {
      this.pendingDappSignatures.get(requestId)?.reject(new Error("Duplicate sign request"));
      this.pendingDappSignatures.delete(requestId);
    }
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        this.pendingDappSignatures.delete(requestId);
        reject(new Error("Signature confirmation timed out"));
      }, DAPP_CONFIRM_TIMEOUT_MS);
      this.pendingDappSignatures.set(requestId, {
        resolve,
        reject,
        timeoutId,
        ...payload
      });
    });
  }
  async handleApiDappConnectContext(payload) {
    const entry = this.pendingDappConnects.get(payload.requestId);
    if (!entry) {
      throw new Error("Connect request not found");
    }
    return {
      requestId: payload.requestId,
      origin: entry.origin,
      walletAddress: entry.walletAddress,
      chainId: entry.connection.chainId,
      connectionId: entry.connection.connectionId,
      host: entry.connection.host,
      trustLevel: entry.connection.trustLevel,
      warningTone: entry.warning.tone,
      warningTitle: entry.warning.title,
      warningMessage: entry.warning.message
    };
  }
  async handleApiDappConnectResult(payload) {
    const entry = this.pendingDappConnects.get(payload.requestId);
    if (!entry) {
      return { success: true };
    }
    clearTimeout(entry.timeoutId);
    this.pendingDappConnects.delete(payload.requestId);
    if (payload.status === "approved") {
      entry.resolve(true);
      return { success: true };
    }
    if (payload.status === "rejected") {
      entry.resolve(false);
      return { success: true };
    }
    entry.reject(new Error(payload.error || "Connection was rejected"));
    return { success: true };
  }
  async handleApiDappTxContext(payload) {
    const entry = this.pendingDappTransactions.get(payload.operationId);
    if (!entry) {
      throw new Error("Transaction request not found");
    }
    return {
      operationId: payload.operationId,
      origin: entry.origin,
      chainId: entry.connection?.chainId ?? null,
      connectionId: entry.connection?.connectionId ?? null,
      host: entry.connection?.host ?? null,
      trustLevel: entry.connection?.trustLevel ?? null,
      warning: entry.warning
    };
  }
  async handleApiDappTxResult(payload) {
    const entry = this.pendingDappTransactions.get(payload.operationId);
    if (!entry) {
      return { success: true };
    }
    clearTimeout(entry.timeoutId);
    this.pendingDappTransactions.delete(payload.operationId);
    if (entry.connection) {
      const outcome = payload.status === "confirmed" ? "approved" : payload.status === "rejected" ? "rejected" : "failed";
      void this.recordSignEvent(
        entry.connection.connectionId,
        "transaction",
        outcome
      );
    }
    if (payload.status === "confirmed") {
      if (!payload.txHash) {
        entry.reject(
          new Error("Transaction confirmed but tx hash unavailable")
        );
        return { success: true };
      }
      entry.resolve(payload.txHash);
      return { success: true };
    }
    const errorMessage = payload.error || "Transaction was rejected by the user";
    entry.reject(new Error(errorMessage));
    return { success: true };
  }
  async handleApiDappSignContext(payload) {
    const entry = this.pendingDappSignatures.get(payload.requestId);
    if (!entry) {
      throw new Error("Sign request not found");
    }
    return {
      requestId: payload.requestId,
      message: entry.message,
      address: entry.address,
      origin: entry.origin,
      pocketId: entry.pocketId,
      chainId: entry.connection?.chainId ?? null,
      connectionId: entry.connection?.connectionId ?? null,
      host: entry.connection?.host ?? null,
      trustLevel: entry.connection?.trustLevel ?? null,
      warning: entry.warning
    };
  }
  async handleApiDappSignResult(payload) {
    const entry = this.pendingDappSignatures.get(payload.requestId);
    if (!entry) {
      return { success: true };
    }
    clearTimeout(entry.timeoutId);
    this.pendingDappSignatures.delete(payload.requestId);
    if (entry.connection) {
      const outcome = payload.status === "signed" ? "approved" : payload.status === "rejected" ? "rejected" : "failed";
      void this.recordSignEvent(
        entry.connection.connectionId,
        "message",
        outcome
      );
    }
    if (payload.status === "signed") {
      if (!payload.signature) {
        entry.reject(new Error("Missing signature result"));
        return { success: true };
      }
      entry.resolve(payload.signature);
      return { success: true };
    }
    const errorMessage = payload.error || "Message signing was rejected by the user";
    entry.reject(new Error(errorMessage));
    return { success: true };
  }
}
const FALLBACK_EXPIRY_MS = 60 * 60 * 1e3;
function normalizeBase64Url(value) {
  let normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const paddingNeeded = normalized.length % 4;
  if (paddingNeeded === 2) normalized += "==";
  else if (paddingNeeded === 3) normalized += "=";
  else if (paddingNeeded !== 0) normalized += "==";
  return normalized;
}
function decodeJwtExpiration(token) {
  try {
    const segments = token.split(".");
    if (segments.length < 2) return null;
    const payloadSegment = segments[1];
    if (!payloadSegment) return null;
    const normalized = normalizeBase64Url(payloadSegment);
    if (typeof globalThis.atob !== "function") return null;
    const json = globalThis.atob(normalized);
    const payload = JSON.parse(json);
    if (typeof payload.exp !== "number") return null;
    return payload.exp * 1e3;
  } catch {
    return null;
  }
}
function buildAccessExpiry(token) {
  return decodeJwtExpiration(token) ?? Date.now() + FALLBACK_EXPIRY_MS;
}
async function getMe(client, accessToken) {
  try {
    const res = await client.get("/v1/users/me", authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to load user profile"), error);
  }
}
async function prepareDappConnection(client, accessToken, payload) {
  try {
    const res = await client.post("/v1/dapps/connections/prepare", payload, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to prepare dApp connection"), error);
  }
}
async function confirmDappConnection(client, accessToken, connectionId) {
  try {
    const res = await client.post(`/v1/dapps/connections/${connectionId}/confirm`, {}, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to confirm dApp connection"), error);
  }
}
async function rejectDappConnection(client, accessToken, connectionId) {
  try {
    const res = await client.post(`/v1/dapps/connections/${connectionId}/reject`, {}, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to reject dApp connection"), error);
  }
}
async function disconnectDappConnection(client, accessToken, connectionId) {
  try {
    const res = await client.post(`/v1/dapps/connections/${connectionId}/disconnect`, {}, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to disconnect dApp"), error);
  }
}
async function listDappConnections(client, accessToken, params) {
  try {
    const res = await client.get("/v1/dapps/connections", {
      ...authHeaders(accessToken),
      params
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to load dApp connections"), error);
  }
}
async function recordDappConnectionSignEvent(client, accessToken, connectionId, payload) {
  try {
    const res = await client.post(`/v1/dapps/connections/${connectionId}/sign-events`, payload, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to record dApp sign event"), error);
  }
}
async function preparePocket(client, accessToken, opts) {
  const idempotencyKey = createIdempotencyKey();
  const payload = {};
  try {
    const res = await client.post("/v1/pockets/new/prepare", payload, {
      ...authHeaders(accessToken),
      headers: {
        ...authHeaders(accessToken).headers,
        "Idempotency-Key": idempotencyKey
      }
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to prepare pocket"), error);
  }
}
async function submitPocket(client, accessToken, payload, opts) {
  const idempotencyKey = createIdempotencyKey();
  try {
    const res = await client.post("/v1/pockets/new/submit", payload, {
      ...authHeaders(accessToken),
      headers: {
        ...authHeaders(accessToken).headers,
        "Idempotency-Key": idempotencyKey
      }
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to submit pocket"), error);
  }
}
async function preparePocketTxSend(client, accessToken, pocketId, payload, opts) {
  const idempotencyKey = createIdempotencyKey();
  try {
    const res = await client.post(`/v1/pockets/${pocketId}/tx/send/prepare`, payload, {
      ...authHeaders(accessToken),
      headers: {
        ...authHeaders(accessToken).headers,
        "Idempotency-Key": idempotencyKey
      }
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to prepare transfer"), error);
  }
}
async function submitPocketTxSend(client, accessToken, pocketId, payload, opts) {
  const idempotencyKey = createIdempotencyKey();
  try {
    const res = await client.post(`/v1/pockets/${pocketId}/tx/send/submit`, payload, {
      ...authHeaders(accessToken),
      headers: {
        ...authHeaders(accessToken).headers,
        "Idempotency-Key": idempotencyKey
      }
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to submit transfer"), error);
  }
}
async function preparePocketTxCustom(client, accessToken, pocketId, payload, opts) {
  const idempotencyKey = createIdempotencyKey();
  try {
    const res = await client.post(`/v1/pockets/${pocketId}/tx/custom/prepare`, payload, {
      ...authHeaders(accessToken),
      headers: {
        ...authHeaders(accessToken).headers,
        "Idempotency-Key": idempotencyKey
      }
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to prepare transaction"), error);
  }
}
async function submitPocketTxCustom(client, accessToken, pocketId, payload, opts) {
  const idempotencyKey = createIdempotencyKey();
  try {
    const res = await client.post(`/v1/pockets/${pocketId}/tx/custom/submit`, payload, {
      ...authHeaders(accessToken),
      headers: {
        ...authHeaders(accessToken).headers,
        "Idempotency-Key": idempotencyKey
      }
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to submit transaction"), error);
  }
}
async function preparePocketPersonalSign(client, accessToken, pocketId, payload) {
  try {
    const res = await client.post(`/v1/pockets/${pocketId}/sign/personal/prepare`, payload, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to prepare personal sign"), error);
  }
}
async function submitPocketPersonalSign(client, accessToken, pocketId, payload) {
  try {
    const res = await client.post(`/v1/pockets/${pocketId}/sign/personal/submit`, payload, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to submit personal sign"), error);
  }
}
async function getPocketBalances(client, accessToken, pocketId) {
  try {
    const res = await client.get(`/v1/pockets/${pocketId}/balances`, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to load pocket balances"), error);
  }
}
async function getPocketActivities(client, accessToken, pocketId, params) {
  try {
    const res = await client.get(`/v1/pockets/${pocketId}/activities`, {
      ...authHeaders(accessToken),
      params: {
        cursor: params?.cursor,
        limit: params?.limit
      }
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to load pocket activity"), error);
  }
}
async function getUserOperation(client, accessToken, operationId) {
  try {
    const res = await client.get(`/v1/user_operations/${operationId}`, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to load operation status"), error);
  }
}
async function cancelUserOperation(client, accessToken, operationId) {
  try {
    const res = await client.delete(`/v1/user_operations/${operationId}`, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to cancel the pending transaction"), error);
  }
}
async function getAddressBook(client, accessToken) {
  try {
    const res = await client.get("/v1/address_book", authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to load address book"), error);
  }
}
async function upsertAddressBookEntry(client, accessToken, payload) {
  try {
    const res = await client.post("/v1/address_book", payload, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to save entry"), error);
  }
}
async function deleteAddressBookEntry(client, accessToken, payload) {
  try {
    const res = await client.delete("/v1/address_book", {
      ...authHeaders(accessToken),
      data: payload
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to delete entry"), error);
  }
}
const ACCESS_TOKEN_BUFFER_MS = 6e4;
class ApiController {
  constructor(storage2) {
    this.storage = storage2;
  }
  selectPreferredPocket(pockets, selectedPocketId) {
    if (pockets.length === 0) {
      return null;
    }
    const selectedPocket = pockets.find((pocket) => pocket.pocketId === selectedPocketId) ?? null;
    if (selectedPocket?.deployState === "DEPLOYED") {
      return selectedPocket;
    }
    const firstDeployed = pockets.find((pocket) => pocket.deployState === "DEPLOYED") ?? null;
    if (firstDeployed) {
      return firstDeployed;
    }
    return selectedPocket ?? pockets[0] ?? null;
  }
  async syncSelectedPocketState(pockets, selectedPocketId) {
    const currentSelectedPocketId = selectedPocketId ?? await this.storage.getApiSelectedPocketId();
    const selectedPocket = this.selectPreferredPocket(
      pockets,
      currentSelectedPocketId
    );
    await this.storage.setApiSelectedPocketId(selectedPocket?.pocketId ?? null);
    await this.storage.setApiChainId(selectedPocket?.chainId ?? null);
    return selectedPocket;
  }
  async getSession() {
    return this.storage.getApiSession();
  }
  async setSession(payload) {
    const accessTokenExpiresAt = payload.accessToken ? payload.accessTokenExpiresAt ?? buildAccessExpiry(payload.accessToken) : null;
    const session = {
      ...payload,
      accessTokenExpiresAt
    };
    await this.storage.setApiSession(session);
    return session;
  }
  async clearSession() {
    await this.storage.clearApiSession();
    await this.storage.setApiSelectedPocketId(null);
    await this.storage.setApiChainId(null);
  }
  async getChainId() {
    const pockets = await this.storage.getApiPockets();
    const selectedPocketId = await this.storage.getApiSelectedPocketId();
    const selectedPocket = this.selectPreferredPocket(
      pockets,
      selectedPocketId
    );
    const chainId = selectedPocket?.chainId ?? null;
    if (chainId !== await this.storage.getApiChainId()) {
      await this.storage.setApiChainId(chainId);
    }
    return chainId;
  }
  async setSelectedPocketId(pocketId) {
    const pockets = await this.storage.getApiPockets();
    return this.syncSelectedPocketState(pockets, pocketId);
  }
  async getValidAccessToken() {
    const session = await this.storage.getApiSession();
    if (!session.refreshToken) {
      throw new Error("SESSION_EXPIRED");
    }
    const hasValidToken = session.accessToken && session.accessTokenExpiresAt && session.accessTokenExpiresAt > Date.now() + ACCESS_TOKEN_BUFFER_MS;
    if (hasValidToken) {
      return session.accessToken;
    }
    try {
      const refreshed = await refreshWithToken(apiClient, session.refreshToken);
      const accessTokenExpiresAt = buildAccessExpiry(refreshed.accessToken);
      const nextSession = {
        ...session,
        accessToken: refreshed.accessToken,
        refreshToken: refreshed.refreshToken,
        accessTokenExpiresAt
      };
      await this.storage.setApiSession(nextSession);
      return refreshed.accessToken;
    } catch {
      await this.storage.clearApiSession();
      throw new Error("SESSION_EXPIRED");
    }
  }
  async getMe() {
    const accessToken = await this.getValidAccessToken();
    const me = await getMe(apiClient, accessToken);
    await this.storage.setApiPockets(me.pockets);
    await this.storage.setApiPendingUserOperations(me.pendingUserOperations);
    await this.storage.setApiDappConnections(me.dappConnections);
    await this.syncSelectedPocketState(me.pockets);
    return me;
  }
  async preparePocket() {
    const accessToken = await this.getValidAccessToken();
    return preparePocket(apiClient, accessToken);
  }
  async submitPocket(request) {
    const accessToken = await this.getValidAccessToken();
    return submitPocket(apiClient, accessToken, request);
  }
  async preparePocketSend(pocketId, request) {
    const accessToken = await this.getValidAccessToken();
    return preparePocketTxSend(apiClient, accessToken, pocketId, request);
  }
  async submitPocketSend(pocketId, request) {
    const accessToken = await this.getValidAccessToken();
    return submitPocketTxSend(apiClient, accessToken, pocketId, request);
  }
  async preparePocketCustom(pocketId, request) {
    const accessToken = await this.getValidAccessToken();
    return preparePocketTxCustom(apiClient, accessToken, pocketId, request);
  }
  async submitPocketCustom(pocketId, request) {
    const accessToken = await this.getValidAccessToken();
    return submitPocketTxCustom(apiClient, accessToken, pocketId, request);
  }
  async preparePocketPersonalSign(pocketId, request) {
    const accessToken = await this.getValidAccessToken();
    return preparePocketPersonalSign(apiClient, accessToken, pocketId, request);
  }
  async submitPocketPersonalSign(pocketId, request) {
    const accessToken = await this.getValidAccessToken();
    return submitPocketPersonalSign(apiClient, accessToken, pocketId, request);
  }
  async getPocketBalances(pocketId) {
    const accessToken = await this.getValidAccessToken();
    return getPocketBalances(apiClient, accessToken, pocketId);
  }
  async getPocketActivities(pocketId, params) {
    const accessToken = await this.getValidAccessToken();
    return getPocketActivities(apiClient, accessToken, pocketId, params);
  }
  async getUserOperation(operationId) {
    const accessToken = await this.getValidAccessToken();
    return getUserOperation(apiClient, accessToken, operationId);
  }
  async cancelUserOperation(operationId) {
    const accessToken = await this.getValidAccessToken();
    return cancelUserOperation(apiClient, accessToken, operationId);
  }
  async listAddressBook() {
    const accessToken = await this.getValidAccessToken();
    return getAddressBook(apiClient, accessToken);
  }
  async upsertAddressBook(payload) {
    const accessToken = await this.getValidAccessToken();
    return upsertAddressBookEntry(apiClient, accessToken, payload);
  }
  async deleteAddressBook(payload) {
    const accessToken = await this.getValidAccessToken();
    return deleteAddressBookEntry(apiClient, accessToken, payload);
  }
  async prepareDappConnection(payload) {
    const accessToken = await this.getValidAccessToken();
    return prepareDappConnection(apiClient, accessToken, payload);
  }
  async confirmDappConnection(connectionId) {
    const accessToken = await this.getValidAccessToken();
    return confirmDappConnection(apiClient, accessToken, connectionId);
  }
  async rejectDappConnection(connectionId) {
    const accessToken = await this.getValidAccessToken();
    return rejectDappConnection(apiClient, accessToken, connectionId);
  }
  async disconnectDappConnection(connectionId) {
    const accessToken = await this.getValidAccessToken();
    return disconnectDappConnection(apiClient, accessToken, connectionId);
  }
  async listDappConnections(params) {
    const accessToken = await this.getValidAccessToken();
    return listDappConnections(apiClient, accessToken, params);
  }
  async recordDappConnectionSignEvent(connectionId, payload) {
    const accessToken = await this.getValidAccessToken();
    return recordDappConnectionSignEvent(
      apiClient,
      accessToken,
      connectionId,
      payload
    );
  }
}
console.log("[Background] Grandpa DeFi Extension loaded");
console.log(
  "[Background] Service Worker ID:",
  self.registration?.active?.scriptURL
);
let keepAliveInterval;
function keepServiceWorkerAlive() {
  if (keepAliveInterval) {
    clearInterval(keepAliveInterval);
  }
  keepAliveInterval = setInterval(() => {
    console.log("[Background] Keep-alive ping");
  }, 2e4);
}
keepServiceWorkerAlive();
self.addEventListener("error", (event) => {
  console.error("[Background] Uncaught error:", event.error);
  console.error("[Background] Error message:", event.message);
  console.error("[Background] Error stack:", event.error?.stack);
  console.error(
    "[Background] Error at:",
    event.filename,
    event.lineno,
    event.colno
  );
});
self.addEventListener("unhandledrejection", (event) => {
  console.error("[Background] Unhandled promise rejection:", event.reason);
  console.error("[Background] Rejection stack:", event.reason?.stack);
  console.error("[Background] Promise:", event.promise);
});
const storage = new StorageManager();
const apiController = new ApiController(storage);
const messageHandler = new MessageHandler(storage, apiController);
async function initializeExtension() {
  console.log("[Background] Initializing extension...");
  await Promise.all([storage.initialize(), initializeApiClient()]);
  console.log("[Background] Extension initialized");
}
chrome.runtime.onInstalled.addListener(async () => {
  console.log("[Background] Extension installed");
  await initializeExtension();
});
chrome.runtime.onMessage.addListener(
  (message, sender, sendResponse) => {
    console.log("[Background] Received message:", message.type);
    console.log(
      "[Background] Message payload:",
      "payload" in message ? message.payload : "no payload"
    );
    console.log("[Background] Sender:", sender.tab?.id || "popup", sender.url);
    try {
      messageHandler.handleMessage(message, sender).then((response) => {
        console.log(
          "[Background] Message handled successfully:",
          message.type
        );
        sendResponse({ success: true, data: response });
      }).catch((error) => {
        console.error("[Background] Message handler error:", error);
        console.error("[Background] Error type:", error.constructor.name);
        console.error("[Background] Error message:", error.message);
        console.error("[Background] Error stack:", error.stack);
        sendResponse({
          success: false,
          error: error.message || "Unknown error"
        });
      });
    } catch (error) {
      console.error(
        "[Background] Synchronous error in message handler:",
        error
      );
      sendResponse({
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
    return true;
  }
);
chrome.runtime.onStartup.addListener(async () => {
  console.log("[Background] Extension started on browser startup");
  await initializeExtension();
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9iYWNrZ3JvdW5kL3N0b3JhZ2UtbWFuYWdlci50cyIsIi4uLy4uL3NyYy9iYWNrZ3JvdW5kL21lc3NhZ2UtaGFuZGxlci50cyIsIi4uLy4uL3NyYy9saWIvYXV0aC90b2tlbi11dGlscy50cyIsIi4uLy4uLy4uLy4uL3BhY2thZ2VzL2FwaS1jbGllbnQvZGlzdC91c2Vycy5qcyIsIi4uLy4uLy4uLy4uL3BhY2thZ2VzL2FwaS1jbGllbnQvZGlzdC9kYXBwcy5qcyIsIi4uLy4uLy4uLy4uL3BhY2thZ2VzL2FwaS1jbGllbnQvZGlzdC9wb2NrZXRzLmpzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvYXBpLWNsaWVudC9kaXN0L3VzZXItb3BlcmF0aW9ucy5qcyIsIi4uLy4uLy4uLy4uL3BhY2thZ2VzL2FwaS1jbGllbnQvZGlzdC9hZGRyZXNzLWJvb2suanMiLCIuLi8uLi9zcmMvYmFja2dyb3VuZC9jb250cm9sbGVycy9hcGktY29udHJvbGxlci50cyIsIi4uLy4uL3NyYy9iYWNrZ3JvdW5kL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFN0b3JhZ2UgTWFuYWdlciAtIEhhbmRsZXMgY2hyb21lLnN0b3JhZ2Ugb3BlcmF0aW9ucyAoQVBJLWZpcnN0KVxuXG5pbXBvcnQgdHlwZSB7XG4gIEFwaURhcHBDb25uZWN0aW9uLFxuICBBcGlTZXNzaW9uLFxuICBBcGlWYXVsdCxcbiAgQ29ubmVjdGVkU2l0ZVJlY29yZCxcbiAgU2V0dGluZ3MsXG4gIFN0b3JhZ2VTY2hlbWEsXG59IGZyb20gXCJAL3NoYXJlZC90eXBlc1wiO1xuaW1wb3J0IHR5cGUgeyBNZVBvY2tldCwgTWVQZW5kaW5nVXNlck9wZXJhdGlvbiB9IGZyb20gXCJAcmVwby9hcGktY2xpZW50L3VzZXJzXCI7XG5pbXBvcnQgeyBTVE9SQUdFX0tFWVMsIERFRkFVTFRfU0VUVElOR1MgfSBmcm9tIFwiQC9zaGFyZWQvY29uc3RhbnRzXCI7XG5cbmNvbnN0IERFRkFVTFRfQVBJX1NFU1NJT046IEFwaVNlc3Npb24gPSB7XG4gIGFjY2Vzc1Rva2VuOiBudWxsLFxuICByZWZyZXNoVG9rZW46IG51bGwsXG4gIGFjY2Vzc1Rva2VuRXhwaXJlc0F0OiBudWxsLFxuICBjcmVkZW50aWFsSWQ6IG51bGwsXG4gIHJwSWQ6IG51bGwsXG59O1xuXG5mdW5jdGlvbiByZWFkU3RvcmFnZUtleTxUPihcbiAgcmVzdWx0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbiAga2V5OiBzdHJpbmcsXG4gIGZhbGxiYWNrOiBULFxuKTogVCB7XG4gIGNvbnN0IHZhbHVlID0gcmVzdWx0W2tleV07XG4gIHJldHVybiAodmFsdWUgYXMgVCkgPz8gZmFsbGJhY2s7XG59XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZU9yaWdpbih2YWx1ZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgdHJ5IHtcbiAgICBjb25zdCB1cmwgPSBuZXcgVVJMKHZhbHVlKTtcbiAgICBjb25zdCBwcm90b2NvbCA9IHVybC5wcm90b2NvbC50b0xvd2VyQ2FzZSgpO1xuICAgIGNvbnN0IGhvc3RuYW1lID0gdXJsLmhvc3RuYW1lLnRvTG93ZXJDYXNlKCk7XG4gICAgY29uc3QgcG9ydCA9IHVybC5wb3J0O1xuICAgIGNvbnN0IGluY2x1ZGVQb3J0ID1cbiAgICAgIHBvcnQubGVuZ3RoID4gMCAmJlxuICAgICAgIShcbiAgICAgICAgKHByb3RvY29sID09PSBcImh0dHBzOlwiICYmIHBvcnQgPT09IFwiNDQzXCIpIHx8XG4gICAgICAgIChwcm90b2NvbCA9PT0gXCJodHRwOlwiICYmIHBvcnQgPT09IFwiODBcIilcbiAgICAgICk7XG4gICAgY29uc3QgaG9zdCA9IGluY2x1ZGVQb3J0ID8gYCR7aG9zdG5hbWV9OiR7cG9ydH1gIDogaG9zdG5hbWU7XG4gICAgcmV0dXJuIGAke3Byb3RvY29sfS8vJHtob3N0fWA7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiB2YWx1ZS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgU3RvcmFnZU1hbmFnZXIge1xuICBwcml2YXRlIGJ1aWxkQ29ubmVjdGVkU2l0ZUtleShlbnRyeToge1xuICAgIG5vcm1hbGl6ZWRPcmlnaW46IHN0cmluZztcbiAgICB3YWxsZXRTY29wZTogQ29ubmVjdGVkU2l0ZVJlY29yZFtcIndhbGxldFNjb3BlXCJdO1xuICAgIHdhbGxldEFkZHJlc3M6IGAweCR7c3RyaW5nfWA7XG4gICAgY2hhaW5JZDogbnVtYmVyO1xuICB9KTogc3RyaW5nIHtcbiAgICByZXR1cm4gW1xuICAgICAgZW50cnkud2FsbGV0U2NvcGUsXG4gICAgICBlbnRyeS53YWxsZXRBZGRyZXNzLnRvTG93ZXJDYXNlKCksXG4gICAgICBTdHJpbmcoZW50cnkuY2hhaW5JZCksXG4gICAgICBlbnRyeS5ub3JtYWxpemVkT3JpZ2luLFxuICAgIF0uam9pbihcInxcIik7XG4gIH1cblxuICBwcml2YXRlIGlzQ29ubmVjdGVkU2l0ZVJlY29yZCh2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIENvbm5lY3RlZFNpdGVSZWNvcmQge1xuICAgIGlmICghdmFsdWUgfHwgdHlwZW9mIHZhbHVlICE9PSBcIm9iamVjdFwiKSByZXR1cm4gZmFsc2U7XG4gICAgY29uc3QgcmVjb3JkID0gdmFsdWUgYXMgUGFydGlhbDxDb25uZWN0ZWRTaXRlUmVjb3JkPjtcbiAgICByZXR1cm4gKFxuICAgICAgdHlwZW9mIHJlY29yZC5jb25uZWN0aW9uSWQgPT09IFwic3RyaW5nXCIgJiZcbiAgICAgIHR5cGVvZiByZWNvcmQub3JpZ2luID09PSBcInN0cmluZ1wiICYmXG4gICAgICB0eXBlb2YgcmVjb3JkLm5vcm1hbGl6ZWRPcmlnaW4gPT09IFwic3RyaW5nXCIgJiZcbiAgICAgIHR5cGVvZiByZWNvcmQuaG9zdCA9PT0gXCJzdHJpbmdcIiAmJlxuICAgICAgKHJlY29yZC53YWxsZXRTY29wZSA9PT0gXCJwb2NrZXRcIiB8fCByZWNvcmQud2FsbGV0U2NvcGUgPT09IFwidmF1bHRcIikgJiZcbiAgICAgIHR5cGVvZiByZWNvcmQud2FsbGV0QWRkcmVzcyA9PT0gXCJzdHJpbmdcIiAmJlxuICAgICAgdHlwZW9mIHJlY29yZC5jaGFpbklkID09PSBcIm51bWJlclwiXG4gICAgKTtcbiAgfVxuXG4gIGFzeW5jIGluaXRpYWxpemUoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCB0aGlzLmdldEFsbCgpO1xuXG4gICAgaWYgKCFleGlzdGluZy5zZXR0aW5ncykge1xuICAgICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHtcbiAgICAgICAgW1NUT1JBR0VfS0VZUy5TRVRUSU5HU106IERFRkFVTFRfU0VUVElOR1MsXG4gICAgICAgIFtTVE9SQUdFX0tFWVMuQ09OTkVDVEVEX1NJVEVTXToge30sXG4gICAgICAgIFtTVE9SQUdFX0tFWVMuQVBJX1NFU1NJT05dOiBERUZBVUxUX0FQSV9TRVNTSU9OLFxuICAgICAgICBbU1RPUkFHRV9LRVlTLkFQSV9QT0NLRVRTXTogW10sXG4gICAgICAgIFtTVE9SQUdFX0tFWVMuQVBJX1NFTEVDVEVEX1BPQ0tFVF9JRF06IG51bGwsXG4gICAgICAgIFtTVE9SQUdFX0tFWVMuQVBJX1BFTkRJTkdfVVNFUl9PUEVSQVRJT05TXTogW10sXG4gICAgICAgIFtTVE9SQUdFX0tFWVMuQVBJX0RBUFBfQ09OTkVDVElPTlNdOiBbXSxcbiAgICAgICAgW1NUT1JBR0VfS0VZUy5BUElfQ0hBSU5fSURdOiBudWxsLFxuICAgICAgICBbU1RPUkFHRV9LRVlTLkFQSV9WQVVMVF06IG51bGwsXG4gICAgICB9KTtcbiAgICAgIGNvbnNvbGUubG9nKFwiW1N0b3JhZ2VdIEluaXRpYWxpemVkIHdpdGggZGVmYXVsdHNcIik7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZ2V0QWxsKCk6IFByb21pc2U8UGFydGlhbDxTdG9yYWdlU2NoZW1hPj4ge1xuICAgIHJldHVybiBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQobnVsbCkgYXMgUHJvbWlzZTxQYXJ0aWFsPFN0b3JhZ2VTY2hlbWE+PjtcbiAgfVxuXG4gIGFzeW5jIGNsZWFyQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmNsZWFyKCk7XG4gIH1cblxuICBhc3luYyBnZXRTZXR0aW5ncygpOiBQcm9taXNlPFNldHRpbmdzPiB7XG4gICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChcbiAgICAgIFNUT1JBR0VfS0VZUy5TRVRUSU5HUyxcbiAgICApKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICByZXR1cm4gcmVhZFN0b3JhZ2VLZXkocmVzdWx0LCBTVE9SQUdFX0tFWVMuU0VUVElOR1MsIERFRkFVTFRfU0VUVElOR1MpO1xuICB9XG5cbiAgYXN5bmMgc2V0U2V0dGluZ3Moc2V0dGluZ3M6IFNldHRpbmdzKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NUT1JBR0VfS0VZUy5TRVRUSU5HU106IHNldHRpbmdzIH0pO1xuICB9XG5cbiAgYXN5bmMgdXBkYXRlU2V0dGluZ3ModXBkYXRlczogUGFydGlhbDxTZXR0aW5ncz4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IHRoaXMuZ2V0U2V0dGluZ3MoKTtcbiAgICBhd2FpdCB0aGlzLnNldFNldHRpbmdzKHsgLi4uc2V0dGluZ3MsIC4uLnVwZGF0ZXMgfSk7XG4gIH1cblxuICAvLyBDb25uZWN0ZWQgc2l0ZXMgbWFuYWdlbWVudFxuICBhc3luYyBnZXRDb25uZWN0ZWRTaXRlcygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIENvbm5lY3RlZFNpdGVSZWNvcmQ+PiB7XG4gICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChcbiAgICAgIFNUT1JBR0VfS0VZUy5DT05ORUNURURfU0lURVMsXG4gICAgKSkgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgY29uc3QgcmF3ID0gcmVhZFN0b3JhZ2VLZXkocmVzdWx0LCBTVE9SQUdFX0tFWVMuQ09OTkVDVEVEX1NJVEVTLCB7fSk7XG4gICAgY29uc3QgZW50cmllcyA9IE9iamVjdC5lbnRyaWVzKHJhdyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik7XG4gICAgY29uc3QgbmV4dDogUmVjb3JkPHN0cmluZywgQ29ubmVjdGVkU2l0ZVJlY29yZD4gPSB7fTtcbiAgICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBlbnRyaWVzKSB7XG4gICAgICBpZiAoIXRoaXMuaXNDb25uZWN0ZWRTaXRlUmVjb3JkKHZhbHVlKSkgY29udGludWU7XG4gICAgICBuZXh0W2tleV0gPSB2YWx1ZTtcbiAgICB9XG4gICAgcmV0dXJuIG5leHQ7XG4gIH1cblxuICBhc3luYyBhZGRDb25uZWN0ZWRTaXRlKHNpdGU6IENvbm5lY3RlZFNpdGVSZWNvcmQpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBzaXRlcyA9IGF3YWl0IHRoaXMuZ2V0Q29ubmVjdGVkU2l0ZXMoKTtcbiAgICBjb25zdCBub3JtYWxpemVkT3JpZ2luID0gbm9ybWFsaXplT3JpZ2luKFxuICAgICAgc2l0ZS5ub3JtYWxpemVkT3JpZ2luIHx8IHNpdGUub3JpZ2luLFxuICAgICk7XG4gICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgICBjb25zdCBrZXkgPSB0aGlzLmJ1aWxkQ29ubmVjdGVkU2l0ZUtleSh7XG4gICAgICBub3JtYWxpemVkT3JpZ2luLFxuICAgICAgd2FsbGV0U2NvcGU6IHNpdGUud2FsbGV0U2NvcGUsXG4gICAgICB3YWxsZXRBZGRyZXNzOiBzaXRlLndhbGxldEFkZHJlc3MsXG4gICAgICBjaGFpbklkOiBzaXRlLmNoYWluSWQsXG4gICAgfSk7XG4gICAgc2l0ZXNba2V5XSA9IHtcbiAgICAgIC4uLnNpdGUsXG4gICAgICBvcmlnaW46IG5vcm1hbGl6ZU9yaWdpbihzaXRlLm9yaWdpbiksXG4gICAgICBub3JtYWxpemVkT3JpZ2luLFxuICAgICAgY29ubmVjdGVkQXQ6IHNpdGUuY29ubmVjdGVkQXQgfHwgbm93LFxuICAgICAgbGFzdFVzZWRBdDogc2l0ZS5sYXN0VXNlZEF0IHx8IG5vdyxcbiAgICB9O1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTVE9SQUdFX0tFWVMuQ09OTkVDVEVEX1NJVEVTXTogc2l0ZXMgfSk7XG4gIH1cblxuICBhc3luYyByZW1vdmVDb25uZWN0ZWRTaXRlKGNvbm5lY3Rpb25JZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3Qgc2l0ZXMgPSBhd2FpdCB0aGlzLmdldENvbm5lY3RlZFNpdGVzKCk7XG4gICAgZm9yIChjb25zdCBba2V5LCBlbnRyeV0gb2YgT2JqZWN0LmVudHJpZXMoc2l0ZXMpKSB7XG4gICAgICBpZiAoZW50cnkuY29ubmVjdGlvbklkICE9PSBjb25uZWN0aW9uSWQpIGNvbnRpbnVlO1xuICAgICAgZGVsZXRlIHNpdGVzW2tleV07XG4gICAgfVxuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTVE9SQUdFX0tFWVMuQ09OTkVDVEVEX1NJVEVTXTogc2l0ZXMgfSk7XG4gIH1cblxuICBhc3luYyByZW1vdmVDb25uZWN0ZWRTaXRlc0Zvck9yaWdpbihcbiAgICBvcmlnaW46IHN0cmluZyxcbiAgICB3YWxsZXRBZGRyZXNzPzogYDB4JHtzdHJpbmd9YCB8IG51bGwsXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IHNpdGVzID0gYXdhaXQgdGhpcy5nZXRDb25uZWN0ZWRTaXRlcygpO1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRPcmlnaW4gPSBub3JtYWxpemVPcmlnaW4ob3JpZ2luKTtcbiAgICBjb25zdCBub3JtYWxpemVkV2FsbGV0QWRkcmVzcyA9IHdhbGxldEFkZHJlc3M/LnRvTG93ZXJDYXNlKCkgPz8gbnVsbDtcbiAgICBmb3IgKGNvbnN0IFtrZXksIGVudHJ5XSBvZiBPYmplY3QuZW50cmllcyhzaXRlcykpIHtcbiAgICAgIGlmIChlbnRyeS5ub3JtYWxpemVkT3JpZ2luICE9PSBub3JtYWxpemVkT3JpZ2luKSBjb250aW51ZTtcbiAgICAgIGlmIChcbiAgICAgICAgbm9ybWFsaXplZFdhbGxldEFkZHJlc3MgJiZcbiAgICAgICAgZW50cnkud2FsbGV0QWRkcmVzcy50b0xvd2VyQ2FzZSgpICE9PSBub3JtYWxpemVkV2FsbGV0QWRkcmVzc1xuICAgICAgKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgZGVsZXRlIHNpdGVzW2tleV07XG4gICAgfVxuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTVE9SQUdFX0tFWVMuQ09OTkVDVEVEX1NJVEVTXTogc2l0ZXMgfSk7XG4gIH1cblxuICBhc3luYyBmaW5kQ29ubmVjdGVkU2l0ZShwYXJhbXM6IHtcbiAgICBvcmlnaW46IHN0cmluZztcbiAgICB3YWxsZXRBZGRyZXNzOiBgMHgke3N0cmluZ31gO1xuICAgIGNoYWluSWQ6IG51bWJlcjtcbiAgICB3YWxsZXRTY29wZTogQ29ubmVjdGVkU2l0ZVJlY29yZFtcIndhbGxldFNjb3BlXCJdO1xuICB9KTogUHJvbWlzZTxDb25uZWN0ZWRTaXRlUmVjb3JkIHwgbnVsbD4ge1xuICAgIGNvbnN0IHNpdGVzID0gYXdhaXQgdGhpcy5nZXRDb25uZWN0ZWRTaXRlcygpO1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRPcmlnaW4gPSBub3JtYWxpemVPcmlnaW4ocGFyYW1zLm9yaWdpbik7XG4gICAgY29uc3Qgbm9ybWFsaXplZFdhbGxldEFkZHJlc3MgPSBwYXJhbXMud2FsbGV0QWRkcmVzcy50b0xvd2VyQ2FzZSgpO1xuICAgIGNvbnN0IG1hdGNoID0gT2JqZWN0LnZhbHVlcyhzaXRlcykuZmluZChcbiAgICAgIChzaXRlKSA9PlxuICAgICAgICBzaXRlLm5vcm1hbGl6ZWRPcmlnaW4gPT09IG5vcm1hbGl6ZWRPcmlnaW4gJiZcbiAgICAgICAgc2l0ZS53YWxsZXRTY29wZSA9PT0gcGFyYW1zLndhbGxldFNjb3BlICYmXG4gICAgICAgIHNpdGUuY2hhaW5JZCA9PT0gcGFyYW1zLmNoYWluSWQgJiZcbiAgICAgICAgc2l0ZS53YWxsZXRBZGRyZXNzLnRvTG93ZXJDYXNlKCkgPT09IG5vcm1hbGl6ZWRXYWxsZXRBZGRyZXNzLFxuICAgICk7XG4gICAgcmV0dXJuIG1hdGNoID8/IG51bGw7XG4gIH1cblxuICBhc3luYyBpc0Nvbm5lY3RlZFNpdGUocGFyYW1zOiB7XG4gICAgb3JpZ2luOiBzdHJpbmc7XG4gICAgd2FsbGV0QWRkcmVzczogYDB4JHtzdHJpbmd9YDtcbiAgICBjaGFpbklkOiBudW1iZXI7XG4gICAgd2FsbGV0U2NvcGU6IENvbm5lY3RlZFNpdGVSZWNvcmRbXCJ3YWxsZXRTY29wZVwiXTtcbiAgfSk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHJldHVybiAoYXdhaXQgdGhpcy5maW5kQ29ubmVjdGVkU2l0ZShwYXJhbXMpKSAhPT0gbnVsbDtcbiAgfVxuXG4gIGFzeW5jIHRvdWNoQ29ubmVjdGVkU2l0ZShjb25uZWN0aW9uSWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IHNpdGVzID0gYXdhaXQgdGhpcy5nZXRDb25uZWN0ZWRTaXRlcygpO1xuICAgIGxldCBkaWRVcGRhdGUgPSBmYWxzZTtcbiAgICBmb3IgKGNvbnN0IFtrZXksIHNpdGVdIG9mIE9iamVjdC5lbnRyaWVzKHNpdGVzKSkge1xuICAgICAgaWYgKHNpdGUuY29ubmVjdGlvbklkICE9PSBjb25uZWN0aW9uSWQpIGNvbnRpbnVlO1xuICAgICAgc2l0ZXNba2V5XSA9IHtcbiAgICAgICAgLi4uc2l0ZSxcbiAgICAgICAgbGFzdFVzZWRBdDogRGF0ZS5ub3coKSxcbiAgICAgIH07XG4gICAgICBkaWRVcGRhdGUgPSB0cnVlO1xuICAgIH1cblxuICAgIGlmIChkaWRVcGRhdGUpIHtcbiAgICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTVE9SQUdFX0tFWVMuQ09OTkVDVEVEX1NJVEVTXTogc2l0ZXMgfSk7XG4gICAgfVxuICB9XG5cbiAgLy8gQVBJIHNlc3Npb24gbWFuYWdlbWVudCAobmV3IGJhY2tlbmQpXG4gIGFzeW5jIGdldEFwaVNlc3Npb24oKTogUHJvbWlzZTxBcGlTZXNzaW9uPiB7XG4gICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChcbiAgICAgIFNUT1JBR0VfS0VZUy5BUElfU0VTU0lPTixcbiAgICApKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICByZXR1cm4gcmVhZFN0b3JhZ2VLZXkoXG4gICAgICByZXN1bHQsXG4gICAgICBTVE9SQUdFX0tFWVMuQVBJX1NFU1NJT04sXG4gICAgICBERUZBVUxUX0FQSV9TRVNTSU9OLFxuICAgICk7XG4gIH1cblxuICBhc3luYyBzZXRBcGlTZXNzaW9uKHNlc3Npb246IEFwaVNlc3Npb24pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbU1RPUkFHRV9LRVlTLkFQSV9TRVNTSU9OXTogc2Vzc2lvbiB9KTtcbiAgfVxuXG4gIGFzeW5jIGNsZWFyQXBpU2Vzc2lvbigpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCB0aGlzLnNldEFwaVNlc3Npb24oREVGQVVMVF9BUElfU0VTU0lPTik7XG4gIH1cblxuICBhc3luYyBnZXRBcGlQb2NrZXRzKCk6IFByb21pc2U8TWVQb2NrZXRbXT4ge1xuICAgIGNvbnN0IHJlc3VsdCA9IChhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoXG4gICAgICBTVE9SQUdFX0tFWVMuQVBJX1BPQ0tFVFMsXG4gICAgKSkgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgcmV0dXJuIHJlYWRTdG9yYWdlS2V5KHJlc3VsdCwgU1RPUkFHRV9LRVlTLkFQSV9QT0NLRVRTLCBbXSBhcyBNZVBvY2tldFtdKTtcbiAgfVxuXG4gIGFzeW5jIHNldEFwaVBvY2tldHMocG9ja2V0czogTWVQb2NrZXRbXSk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTVE9SQUdFX0tFWVMuQVBJX1BPQ0tFVFNdOiBwb2NrZXRzIH0pO1xuICB9XG5cbiAgYXN5bmMgZ2V0QXBpU2VsZWN0ZWRQb2NrZXRJZCgpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgICBjb25zdCByZXN1bHQgPSAoYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFxuICAgICAgU1RPUkFHRV9LRVlTLkFQSV9TRUxFQ1RFRF9QT0NLRVRfSUQsXG4gICAgKSkgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgcmV0dXJuIHJlYWRTdG9yYWdlS2V5KHJlc3VsdCwgU1RPUkFHRV9LRVlTLkFQSV9TRUxFQ1RFRF9QT0NLRVRfSUQsIG51bGwpO1xuICB9XG5cbiAgYXN5bmMgc2V0QXBpU2VsZWN0ZWRQb2NrZXRJZChwb2NrZXRJZDogc3RyaW5nIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgICBbU1RPUkFHRV9LRVlTLkFQSV9TRUxFQ1RFRF9QT0NLRVRfSURdOiBwb2NrZXRJZCxcbiAgICB9KTtcbiAgfVxuXG4gIGFzeW5jIGdldEFwaVBlbmRpbmdVc2VyT3BlcmF0aW9ucygpOiBQcm9taXNlPE1lUGVuZGluZ1VzZXJPcGVyYXRpb25bXT4ge1xuICAgIGNvbnN0IHJlc3VsdCA9IChhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoXG4gICAgICBTVE9SQUdFX0tFWVMuQVBJX1BFTkRJTkdfVVNFUl9PUEVSQVRJT05TLFxuICAgICkpIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgIHJldHVybiByZWFkU3RvcmFnZUtleShcbiAgICAgIHJlc3VsdCxcbiAgICAgIFNUT1JBR0VfS0VZUy5BUElfUEVORElOR19VU0VSX09QRVJBVElPTlMsXG4gICAgICBbXSBhcyBNZVBlbmRpbmdVc2VyT3BlcmF0aW9uW10sXG4gICAgKTtcbiAgfVxuXG4gIGFzeW5jIHNldEFwaVBlbmRpbmdVc2VyT3BlcmF0aW9ucyhcbiAgICBvcGVyYXRpb25zOiBNZVBlbmRpbmdVc2VyT3BlcmF0aW9uW10sXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgICBbU1RPUkFHRV9LRVlTLkFQSV9QRU5ESU5HX1VTRVJfT1BFUkFUSU9OU106IG9wZXJhdGlvbnMsXG4gICAgfSk7XG4gIH1cblxuICBhc3luYyBnZXRBcGlEYXBwQ29ubmVjdGlvbnMoKTogUHJvbWlzZTxBcGlEYXBwQ29ubmVjdGlvbltdPiB7XG4gICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChcbiAgICAgIFNUT1JBR0VfS0VZUy5BUElfREFQUF9DT05ORUNUSU9OUyxcbiAgICApKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICByZXR1cm4gcmVhZFN0b3JhZ2VLZXkoXG4gICAgICByZXN1bHQsXG4gICAgICBTVE9SQUdFX0tFWVMuQVBJX0RBUFBfQ09OTkVDVElPTlMsXG4gICAgICBbXSBhcyBBcGlEYXBwQ29ubmVjdGlvbltdLFxuICAgICk7XG4gIH1cblxuICBhc3luYyBzZXRBcGlEYXBwQ29ubmVjdGlvbnMoY29ubmVjdGlvbnM6IEFwaURhcHBDb25uZWN0aW9uW10pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoe1xuICAgICAgW1NUT1JBR0VfS0VZUy5BUElfREFQUF9DT05ORUNUSU9OU106IGNvbm5lY3Rpb25zLFxuICAgIH0pO1xuICB9XG5cbiAgYXN5bmMgZ2V0QXBpQ2hhaW5JZCgpOiBQcm9taXNlPG51bWJlciB8IG51bGw+IHtcbiAgICBjb25zdCByZXN1bHQgPSAoYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFxuICAgICAgU1RPUkFHRV9LRVlTLkFQSV9DSEFJTl9JRCxcbiAgICApKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICByZXR1cm4gcmVhZFN0b3JhZ2VLZXkocmVzdWx0LCBTVE9SQUdFX0tFWVMuQVBJX0NIQUlOX0lELCBudWxsKTtcbiAgfVxuXG4gIGFzeW5jIHNldEFwaUNoYWluSWQoY2hhaW5JZDogbnVtYmVyIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTVE9SQUdFX0tFWVMuQVBJX0NIQUlOX0lEXTogY2hhaW5JZCB9KTtcbiAgfVxuXG4gIGFzeW5jIGdldEFwaVZhdWx0KCk6IFByb21pc2U8QXBpVmF1bHQgfCBudWxsPiB7XG4gICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChcbiAgICAgIFNUT1JBR0VfS0VZUy5BUElfVkFVTFQsXG4gICAgKSkgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgcmV0dXJuIHJlYWRTdG9yYWdlS2V5KHJlc3VsdCwgU1RPUkFHRV9LRVlTLkFQSV9WQVVMVCwgbnVsbCk7XG4gIH1cblxuICBhc3luYyBzZXRBcGlWYXVsdCh2YXVsdDogQXBpVmF1bHQgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NUT1JBR0VfS0VZUy5BUElfVkFVTFRdOiB2YXVsdCB9KTtcbiAgfVxufVxuIiwiLy8gTWVzc2FnZSBIYW5kbGVyIC0gUm91dGVzIG1lc3NhZ2VzIHRvIGFwcHJvcHJpYXRlIGhhbmRsZXJzIChBUEktZmlyc3QpXG5cbmltcG9ydCB0eXBlIHsgU3RvcmFnZU1hbmFnZXIgfSBmcm9tIFwiLi9zdG9yYWdlLW1hbmFnZXJcIjtcbmltcG9ydCB7IGdldE5ldHdvcmtCeUNoYWluSWQgfSBmcm9tIFwiQC9zaGFyZWQvY29uc3RhbnRzXCI7XG5pbXBvcnQgdHlwZSB7XG4gIENvbm5lY3RlZFNpdGVSZWNvcmQsXG4gIERhcHBXYXJuaW5nQ29udGV4dCxcbiAgTWVzc2FnZSxcbiAgU2lnbk1lc3NhZ2VSZXF1ZXN0LFxuICBUcmFuc2FjdGlvblJlcXVlc3QsXG59IGZyb20gXCJAL3NoYXJlZC90eXBlc1wiO1xuaW1wb3J0IHR5cGUgeyBBcGlDb250cm9sbGVyIH0gZnJvbSBcIi4vY29udHJvbGxlcnMvYXBpLWNvbnRyb2xsZXJcIjtcbmltcG9ydCB0eXBlIHsgTWVQb2NrZXQgfSBmcm9tIFwiQHJlcG8vYXBpLWNsaWVudC91c2Vyc1wiO1xuaW1wb3J0IHR5cGUgeyBEYXBwQ29ubmVjdGlvblN1bW1hcnkgfSBmcm9tIFwiQHJlcG8vYXBpLWNsaWVudC9kYXBwc1wiO1xuaW1wb3J0IHR5cGUge1xuICBQb2NrZXRNZXRhVHJhbnNhY3Rpb24sXG4gIFBvY2tldERlcGxveVN1Ym1pdFJlcXVlc3QsXG4gIFBvY2tldFBlcnNvbmFsU2lnblByZXBhcmVSZXF1ZXN0LFxuICBQb2NrZXRQZXJzb25hbFNpZ25TdWJtaXRSZXF1ZXN0LFxuICBQb2NrZXRTdWJtaXRSZXF1ZXN0LFxuICBQb2NrZXRUeFNlbmRQcmVwYXJlUmVxdWVzdCxcbn0gZnJvbSBcIkByZXBvL2FwaS1jbGllbnQvcG9ja2V0c1wiO1xuaW1wb3J0IHR5cGUge1xuICBBZGRyZXNzQm9va0RlbGV0ZVJlcXVlc3QsXG4gIEFkZHJlc3NCb29rVXBzZXJ0UmVxdWVzdCxcbn0gZnJvbSBcIkByZXBvL2FwaS1jbGllbnQvYWRkcmVzcy1ib29rXCI7XG5pbXBvcnQgeyBzbGVlcCB9IGZyb20gXCJAL3NoYXJlZC91dGlsc1wiO1xuXG5jb25zdCBEQVBQX0NPTkZJUk1fVElNRU9VVF9NUyA9IDUgKiA2MF8wMDA7XG5jb25zdCBDT05ORUNUX1RJTUVPVVRfTVMgPSAyICogNjBfMDAwO1xuY29uc3QgQ09OTkVDVF9QT0xMX0lOVEVSVkFMX01TID0gNTAwO1xuXG50eXBlIFBlbmRpbmdEYXBwQ29ubmVjdCA9IHtcbiAgcmVzb2x2ZTogKGFwcHJvdmVkOiBib29sZWFuKSA9PiB2b2lkO1xuICByZWplY3Q6IChlcnJvcjogRXJyb3IpID0+IHZvaWQ7XG4gIHRpbWVvdXRJZDogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0VGltZW91dD47XG4gIHdpbmRvd0lkPzogbnVtYmVyO1xuICBvcmlnaW46IHN0cmluZztcbiAgd2FsbGV0QWRkcmVzczogYDB4JHtzdHJpbmd9YDtcbiAgY29ubmVjdGlvbjogRGFwcENvbm5lY3Rpb25TdW1tYXJ5O1xuICB3YXJuaW5nOiBEYXBwV2FybmluZ0NvbnRleHQ7XG59O1xuXG50eXBlIFBlbmRpbmdEYXBwVHJhbnNhY3Rpb24gPSB7XG4gIHJlc29sdmU6ICh0eEhhc2g6IGAweCR7c3RyaW5nfWApID0+IHZvaWQ7XG4gIHJlamVjdDogKGVycm9yOiBFcnJvcikgPT4gdm9pZDtcbiAgdGltZW91dElkOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PjtcbiAgd2luZG93SWQ/OiBudW1iZXI7XG4gIG9yaWdpbjogc3RyaW5nO1xuICBjb25uZWN0aW9uOiBDb25uZWN0ZWRTaXRlUmVjb3JkIHwgbnVsbDtcbiAgd2FybmluZzogRGFwcFdhcm5pbmdDb250ZXh0IHwgbnVsbDtcbn07XG5cbnR5cGUgUGVuZGluZ0RhcHBTaWduYXR1cmUgPSB7XG4gIHJlc29sdmU6IChzaWduYXR1cmU6IGAweCR7c3RyaW5nfWApID0+IHZvaWQ7XG4gIHJlamVjdDogKGVycm9yOiBFcnJvcikgPT4gdm9pZDtcbiAgdGltZW91dElkOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PjtcbiAgd2luZG93SWQ/OiBudW1iZXI7XG4gIG1lc3NhZ2U6IHN0cmluZztcbiAgYWRkcmVzczogYDB4JHtzdHJpbmd9YDtcbiAgb3JpZ2luOiBzdHJpbmc7XG4gIHBvY2tldElkOiBzdHJpbmc7XG4gIGNvbm5lY3Rpb246IENvbm5lY3RlZFNpdGVSZWNvcmQgfCBudWxsO1xuICB3YXJuaW5nOiBEYXBwV2FybmluZ0NvbnRleHQgfCBudWxsO1xufTtcblxuZXhwb3J0IGNsYXNzIE1lc3NhZ2VIYW5kbGVyIHtcbiAgcHJpdmF0ZSBwZW5kaW5nRGFwcENvbm5lY3RzID0gbmV3IE1hcDxzdHJpbmcsIFBlbmRpbmdEYXBwQ29ubmVjdD4oKTtcbiAgcHJpdmF0ZSBwZW5kaW5nRGFwcFRyYW5zYWN0aW9ucyA9IG5ldyBNYXA8c3RyaW5nLCBQZW5kaW5nRGFwcFRyYW5zYWN0aW9uPigpO1xuICBwcml2YXRlIHBlbmRpbmdEYXBwU2lnbmF0dXJlcyA9IG5ldyBNYXA8c3RyaW5nLCBQZW5kaW5nRGFwcFNpZ25hdHVyZT4oKTtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHN0b3JhZ2U6IFN0b3JhZ2VNYW5hZ2VyLFxuICAgIHByaXZhdGUgYXBpOiBBcGlDb250cm9sbGVyLFxuICApIHtcbiAgICBjaHJvbWUud2luZG93cy5vblJlbW92ZWQuYWRkTGlzdGVuZXIoKHdpbmRvd0lkKSA9PiB7XG4gICAgICBmb3IgKGNvbnN0IFtyZXF1ZXN0SWQsIGVudHJ5XSBvZiB0aGlzLnBlbmRpbmdEYXBwQ29ubmVjdHMpIHtcbiAgICAgICAgaWYgKGVudHJ5LndpbmRvd0lkICE9PSB3aW5kb3dJZCkgY29udGludWU7XG4gICAgICAgIGNsZWFyVGltZW91dChlbnRyeS50aW1lb3V0SWQpO1xuICAgICAgICB0aGlzLnBlbmRpbmdEYXBwQ29ubmVjdHMuZGVsZXRlKHJlcXVlc3RJZCk7XG4gICAgICAgIGVudHJ5LnJlamVjdChuZXcgRXJyb3IoXCJDb25uZWN0aW9uIGNvbmZpcm1hdGlvbiB3YXMgY2xvc2VkXCIpKTtcbiAgICAgIH1cblxuICAgICAgZm9yIChjb25zdCBbb3BlcmF0aW9uSWQsIGVudHJ5XSBvZiB0aGlzLnBlbmRpbmdEYXBwVHJhbnNhY3Rpb25zKSB7XG4gICAgICAgIGlmIChlbnRyeS53aW5kb3dJZCAhPT0gd2luZG93SWQpIGNvbnRpbnVlO1xuICAgICAgICBjbGVhclRpbWVvdXQoZW50cnkudGltZW91dElkKTtcbiAgICAgICAgdGhpcy5wZW5kaW5nRGFwcFRyYW5zYWN0aW9ucy5kZWxldGUob3BlcmF0aW9uSWQpO1xuICAgICAgICBlbnRyeS5yZWplY3QobmV3IEVycm9yKFwiVHJhbnNhY3Rpb24gY29uZmlybWF0aW9uIHdhcyBjbG9zZWRcIikpO1xuICAgICAgfVxuXG4gICAgICBmb3IgKGNvbnN0IFtyZXF1ZXN0SWQsIGVudHJ5XSBvZiB0aGlzLnBlbmRpbmdEYXBwU2lnbmF0dXJlcykge1xuICAgICAgICBpZiAoZW50cnkud2luZG93SWQgIT09IHdpbmRvd0lkKSBjb250aW51ZTtcbiAgICAgICAgY2xlYXJUaW1lb3V0KGVudHJ5LnRpbWVvdXRJZCk7XG4gICAgICAgIHRoaXMucGVuZGluZ0RhcHBTaWduYXR1cmVzLmRlbGV0ZShyZXF1ZXN0SWQpO1xuICAgICAgICBlbnRyeS5yZWplY3QobmV3IEVycm9yKFwiU2lnbmF0dXJlIGNvbmZpcm1hdGlvbiB3YXMgY2xvc2VkXCIpKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuXG4gIGFzeW5jIGhhbmRsZU1lc3NhZ2UoXG4gICAgbWVzc2FnZTogTWVzc2FnZSxcbiAgICBzZW5kZXI6IGNocm9tZS5ydW50aW1lLk1lc3NhZ2VTZW5kZXIsXG4gICk6IFByb21pc2U8dW5rbm93bj4ge1xuICAgIGNvbnNvbGUubG9nKFwiW01lc3NhZ2VIYW5kbGVyXSBIYW5kbGluZzpcIiwgbWVzc2FnZS50eXBlKTtcblxuICAgIHN3aXRjaCAobWVzc2FnZS50eXBlKSB7XG4gICAgICBjYXNlIFwiQ09OTkVDVF9TSVRFXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmhhbmRsZUNvbm5lY3RTaXRlKG1lc3NhZ2UucGF5bG9hZCwgc2VuZGVyKTtcblxuICAgICAgY2FzZSBcIkRJU0NPTk5FQ1RfU0lURVwiOlxuICAgICAgICByZXR1cm4gdGhpcy5oYW5kbGVEaXNjb25uZWN0U2l0ZShtZXNzYWdlLnBheWxvYWQpO1xuXG4gICAgICBjYXNlIFwiU0VORF9UUkFOU0FDVElPTlwiOlxuICAgICAgICByZXR1cm4gdGhpcy5oYW5kbGVTZW5kVHJhbnNhY3Rpb24obWVzc2FnZS5wYXlsb2FkLCBzZW5kZXIpO1xuXG4gICAgICBjYXNlIFwiU0lHTl9NRVNTQUdFXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmhhbmRsZVNpZ25NZXNzYWdlKG1lc3NhZ2UucGF5bG9hZCwgc2VuZGVyKTtcblxuICAgICAgY2FzZSBcIkNMRUFSX0FMTF9EQVRBXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmhhbmRsZUNsZWFyQWxsRGF0YSgpO1xuXG4gICAgICBjYXNlIFwiQVBJX0dFVF9TRVNTSU9OXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmFwaS5nZXRTZXNzaW9uKCk7XG5cbiAgICAgIGNhc2UgXCJBUElfU0VUX1NFU1NJT05cIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuYXBpLnNldFNlc3Npb24obWVzc2FnZS5wYXlsb2FkKTtcblxuICAgICAgY2FzZSBcIkFQSV9DTEVBUl9TRVNTSU9OXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmhhbmRsZUNsZWFyU2Vzc2lvbigpO1xuXG4gICAgICBjYXNlIFwiQVBJX0dFVF9DSEFJTl9JRFwiOlxuICAgICAgICByZXR1cm4gdGhpcy5hcGkuZ2V0Q2hhaW5JZCgpO1xuXG4gICAgICBjYXNlIFwiQVBJX1VTRVJTX01FXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmFwaS5nZXRNZSgpO1xuXG4gICAgICBjYXNlIFwiQVBJX1BPQ0tFVF9TRUxFQ1RcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlUG9ja2V0U2VsZWN0KG1lc3NhZ2UucGF5bG9hZCk7XG5cbiAgICAgIGNhc2UgXCJBUElfUE9DS0VUX1BSRVBBUkVcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuYXBpLnByZXBhcmVQb2NrZXQoKTtcblxuICAgICAgY2FzZSBcIkFQSV9QT0NLRVRfU1VCTUlUXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmFwaS5zdWJtaXRQb2NrZXQoXG4gICAgICAgICAgbWVzc2FnZS5wYXlsb2FkIGFzIFBvY2tldERlcGxveVN1Ym1pdFJlcXVlc3QsXG4gICAgICAgICk7XG5cbiAgICAgIGNhc2UgXCJBUElfU1dJVENIX0NIQUlOXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmhhbmRsZVN3aXRjaENoYWluKG1lc3NhZ2UucGF5bG9hZCwgc2VuZGVyKTtcblxuICAgICAgY2FzZSBcIkFQSV9QT0NLRVRfU0VORF9QUkVQQVJFXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmFwaS5wcmVwYXJlUG9ja2V0U2VuZChcbiAgICAgICAgICBtZXNzYWdlLnBheWxvYWQucG9ja2V0SWQsXG4gICAgICAgICAgbWVzc2FnZS5wYXlsb2FkLnJlcXVlc3QgYXMgUG9ja2V0VHhTZW5kUHJlcGFyZVJlcXVlc3QsXG4gICAgICAgICk7XG5cbiAgICAgIGNhc2UgXCJBUElfUE9DS0VUX1NFTkRfU1VCTUlUXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmFwaS5zdWJtaXRQb2NrZXRTZW5kKFxuICAgICAgICAgIG1lc3NhZ2UucGF5bG9hZC5wb2NrZXRJZCxcbiAgICAgICAgICBtZXNzYWdlLnBheWxvYWQucmVxdWVzdCBhcyBQb2NrZXRTdWJtaXRSZXF1ZXN0LFxuICAgICAgICApO1xuXG4gICAgICBjYXNlIFwiQVBJX1BPQ0tFVF9DVVNUT01fUFJFUEFSRVwiOlxuICAgICAgICByZXR1cm4gdGhpcy5hcGkucHJlcGFyZVBvY2tldEN1c3RvbShcbiAgICAgICAgICBtZXNzYWdlLnBheWxvYWQucG9ja2V0SWQsXG4gICAgICAgICAgbWVzc2FnZS5wYXlsb2FkLnJlcXVlc3QgYXMge1xuICAgICAgICAgICAgbWV0YVRyYW5zYWN0aW9uczogUG9ja2V0TWV0YVRyYW5zYWN0aW9uW107XG4gICAgICAgICAgfSxcbiAgICAgICAgKTtcblxuICAgICAgY2FzZSBcIkFQSV9QT0NLRVRfQ1VTVE9NX1NVQk1JVFwiOlxuICAgICAgICByZXR1cm4gdGhpcy5hcGkuc3VibWl0UG9ja2V0Q3VzdG9tKFxuICAgICAgICAgIG1lc3NhZ2UucGF5bG9hZC5wb2NrZXRJZCxcbiAgICAgICAgICBtZXNzYWdlLnBheWxvYWQucmVxdWVzdCBhcyBQb2NrZXRTdWJtaXRSZXF1ZXN0LFxuICAgICAgICApO1xuXG4gICAgICBjYXNlIFwiQVBJX1BPQ0tFVF9QRVJTT05BTF9TSUdOX1BSRVBBUkVcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuYXBpLnByZXBhcmVQb2NrZXRQZXJzb25hbFNpZ24oXG4gICAgICAgICAgbWVzc2FnZS5wYXlsb2FkLnBvY2tldElkLFxuICAgICAgICAgIG1lc3NhZ2UucGF5bG9hZC5yZXF1ZXN0IGFzIFBvY2tldFBlcnNvbmFsU2lnblByZXBhcmVSZXF1ZXN0LFxuICAgICAgICApO1xuXG4gICAgICBjYXNlIFwiQVBJX1BPQ0tFVF9QRVJTT05BTF9TSUdOX1NVQk1JVFwiOlxuICAgICAgICByZXR1cm4gdGhpcy5hcGkuc3VibWl0UG9ja2V0UGVyc29uYWxTaWduKFxuICAgICAgICAgIG1lc3NhZ2UucGF5bG9hZC5wb2NrZXRJZCxcbiAgICAgICAgICBtZXNzYWdlLnBheWxvYWQucmVxdWVzdCBhcyBQb2NrZXRQZXJzb25hbFNpZ25TdWJtaXRSZXF1ZXN0LFxuICAgICAgICApO1xuXG4gICAgICBjYXNlIFwiQVBJX1BPQ0tFVF9CQUxBTkNFU1wiOlxuICAgICAgICByZXR1cm4gdGhpcy5hcGkuZ2V0UG9ja2V0QmFsYW5jZXMobWVzc2FnZS5wYXlsb2FkLnBvY2tldElkKTtcblxuICAgICAgY2FzZSBcIkFQSV9QT0NLRVRfQUNUSVZJVElFU1wiOlxuICAgICAgICByZXR1cm4gdGhpcy5hcGkuZ2V0UG9ja2V0QWN0aXZpdGllcyhtZXNzYWdlLnBheWxvYWQucG9ja2V0SWQsIHtcbiAgICAgICAgICBjdXJzb3I6IG1lc3NhZ2UucGF5bG9hZC5jdXJzb3IsXG4gICAgICAgICAgbGltaXQ6IG1lc3NhZ2UucGF5bG9hZC5saW1pdCxcbiAgICAgICAgfSk7XG5cbiAgICAgIGNhc2UgXCJBUElfVVNFUk9QX0dFVFwiOlxuICAgICAgICByZXR1cm4gdGhpcy5hcGkuZ2V0VXNlck9wZXJhdGlvbihtZXNzYWdlLnBheWxvYWQub3BlcmF0aW9uSWQpO1xuXG4gICAgICBjYXNlIFwiQVBJX1VTRVJPUF9DQU5DRUxcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuYXBpLmNhbmNlbFVzZXJPcGVyYXRpb24obWVzc2FnZS5wYXlsb2FkLm9wZXJhdGlvbklkKTtcblxuICAgICAgY2FzZSBcIkFQSV9EQVBQX0NPTk5FQ1RfQ09OVEVYVFwiOlxuICAgICAgICByZXR1cm4gdGhpcy5oYW5kbGVBcGlEYXBwQ29ubmVjdENvbnRleHQobWVzc2FnZS5wYXlsb2FkKTtcblxuICAgICAgY2FzZSBcIkFQSV9EQVBQX0NPTk5FQ1RfUkVTVUxUXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmhhbmRsZUFwaURhcHBDb25uZWN0UmVzdWx0KG1lc3NhZ2UucGF5bG9hZCk7XG5cbiAgICAgIGNhc2UgXCJBUElfREFQUF9UWF9DT05URVhUXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmhhbmRsZUFwaURhcHBUeENvbnRleHQobWVzc2FnZS5wYXlsb2FkKTtcblxuICAgICAgY2FzZSBcIkFQSV9EQVBQX1RYX1JFU1VMVFwiOlxuICAgICAgICByZXR1cm4gdGhpcy5oYW5kbGVBcGlEYXBwVHhSZXN1bHQobWVzc2FnZS5wYXlsb2FkKTtcblxuICAgICAgY2FzZSBcIkFQSV9EQVBQX1NJR05fQ09OVEVYVFwiOlxuICAgICAgICByZXR1cm4gdGhpcy5oYW5kbGVBcGlEYXBwU2lnbkNvbnRleHQobWVzc2FnZS5wYXlsb2FkKTtcblxuICAgICAgY2FzZSBcIkFQSV9EQVBQX1NJR05fUkVTVUxUXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmhhbmRsZUFwaURhcHBTaWduUmVzdWx0KG1lc3NhZ2UucGF5bG9hZCk7XG5cbiAgICAgIGNhc2UgXCJBUElfQUREUkVTU19CT09LX0xJU1RcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuYXBpLmxpc3RBZGRyZXNzQm9vaygpO1xuXG4gICAgICBjYXNlIFwiQVBJX0FERFJFU1NfQk9PS19VUFNFUlRcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuYXBpLnVwc2VydEFkZHJlc3NCb29rKFxuICAgICAgICAgIG1lc3NhZ2UucGF5bG9hZCBhcyBBZGRyZXNzQm9va1Vwc2VydFJlcXVlc3QsXG4gICAgICAgICk7XG5cbiAgICAgIGNhc2UgXCJBUElfQUREUkVTU19CT09LX0RFTEVURVwiOlxuICAgICAgICByZXR1cm4gdGhpcy5hcGkuZGVsZXRlQWRkcmVzc0Jvb2soXG4gICAgICAgICAgbWVzc2FnZS5wYXlsb2FkIGFzIEFkZHJlc3NCb29rRGVsZXRlUmVxdWVzdCxcbiAgICAgICAgKTtcblxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgIGBVbmtub3duIG1lc3NhZ2UgdHlwZTogJHtcbiAgICAgICAgICAgIChtZXNzYWdlIGFzIHsgdHlwZT86IHN0cmluZyB9KS50eXBlID8/IFwidW5rbm93blwiXG4gICAgICAgICAgfWAsXG4gICAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBub3JtYWxpemVPcmlnaW4odmFsdWU6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVybCA9IG5ldyBVUkwodmFsdWUpO1xuICAgICAgY29uc3QgcHJvdG9jb2wgPSB1cmwucHJvdG9jb2wudG9Mb3dlckNhc2UoKTtcbiAgICAgIGNvbnN0IGhvc3RuYW1lID0gdXJsLmhvc3RuYW1lLnRvTG93ZXJDYXNlKCk7XG4gICAgICBjb25zdCBwb3J0ID0gdXJsLnBvcnQ7XG4gICAgICBjb25zdCBpbmNsdWRlUG9ydCA9XG4gICAgICAgIHBvcnQubGVuZ3RoID4gMCAmJlxuICAgICAgICAhKFxuICAgICAgICAgIChwcm90b2NvbCA9PT0gXCJodHRwczpcIiAmJiBwb3J0ID09PSBcIjQ0M1wiKSB8fFxuICAgICAgICAgIChwcm90b2NvbCA9PT0gXCJodHRwOlwiICYmIHBvcnQgPT09IFwiODBcIilcbiAgICAgICAgKTtcbiAgICAgIGNvbnN0IGhvc3QgPSBpbmNsdWRlUG9ydCA/IGAke2hvc3RuYW1lfToke3BvcnR9YCA6IGhvc3RuYW1lO1xuICAgICAgcmV0dXJuIGAke3Byb3RvY29sfS8vJHtob3N0fWA7XG4gICAgfSBjYXRjaCB7XG4gICAgICByZXR1cm4gdmFsdWUudHJpbSgpLnRvTG93ZXJDYXNlKCk7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSB0b0Nvbm5lY3RlZFNpdGVSZWNvcmQoXG4gICAgY29ubmVjdGlvbjogRGFwcENvbm5lY3Rpb25TdW1tYXJ5LFxuICApOiBDb25uZWN0ZWRTaXRlUmVjb3JkIHtcbiAgICBjb25zdCBub3cgPSBEYXRlLm5vdygpO1xuICAgIHJldHVybiB7XG4gICAgICBjb25uZWN0aW9uSWQ6IGNvbm5lY3Rpb24uY29ubmVjdGlvbklkLFxuICAgICAgb3JpZ2luOiBjb25uZWN0aW9uLm9yaWdpbixcbiAgICAgIG5vcm1hbGl6ZWRPcmlnaW46IGNvbm5lY3Rpb24ubm9ybWFsaXplZE9yaWdpbixcbiAgICAgIGhvc3Q6IGNvbm5lY3Rpb24uaG9zdCxcbiAgICAgIHdhbGxldFNjb3BlOiBjb25uZWN0aW9uLndhbGxldFNjb3BlLFxuICAgICAgd2FsbGV0SWQ6IGNvbm5lY3Rpb24ud2FsbGV0SWQsXG4gICAgICB3YWxsZXRBZGRyZXNzOiBjb25uZWN0aW9uLndhbGxldEFkZHJlc3MsXG4gICAgICBjaGFpbklkOiBjb25uZWN0aW9uLmNoYWluSWQsXG4gICAgICB0cnVzdExldmVsOiBjb25uZWN0aW9uLnRydXN0TGV2ZWwsXG4gICAgICBjb25uZWN0ZWRBdDogY29ubmVjdGlvbi5jb25uZWN0ZWRBdFxuICAgICAgICA/IERhdGUucGFyc2UoY29ubmVjdGlvbi5jb25uZWN0ZWRBdCkgfHwgbm93XG4gICAgICAgIDogbm93LFxuICAgICAgbGFzdFVzZWRBdDogbm93LFxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIGJ1aWxkVW5rbm93blNpZ25pbmdXYXJuaW5nKGhvc3Q6IHN0cmluZyk6IERhcHBXYXJuaW5nQ29udGV4dCB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHRvbmU6IFwic29mdFwiLFxuICAgICAgdGl0bGU6IFwiVW5rbm93biBkQXBwXCIsXG4gICAgICBtZXNzYWdlOiBgJHtob3N0fSBpcyBub3QgaW4gdGhlIHRydXN0ZWQgbGlzdC4gUmV2aWV3IGRldGFpbHMgY2FyZWZ1bGx5IGJlZm9yZSBzaWduaW5nLmAsXG4gICAgfTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgcmVjb3JkU2lnbkV2ZW50KFxuICAgIGNvbm5lY3Rpb25JZDogc3RyaW5nLFxuICAgIGtpbmQ6IFwidHJhbnNhY3Rpb25cIiB8IFwibWVzc2FnZVwiLFxuICAgIG91dGNvbWU6IFwicmVxdWVzdGVkXCIgfCBcImFwcHJvdmVkXCIgfCBcInJlamVjdGVkXCIgfCBcImZhaWxlZFwiLFxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5hcGkucmVjb3JkRGFwcENvbm5lY3Rpb25TaWduRXZlbnQoY29ubmVjdGlvbklkLCB7XG4gICAgICAgIGtpbmQsXG4gICAgICAgIG91dGNvbWUsXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS53YXJuKFwiW01lc3NhZ2VIYW5kbGVyXSBGYWlsZWQgdG8gcmVjb3JkIGRBcHAgc2lnbiBldmVudDpcIiwgZXJyb3IpO1xuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgc2VsZWN0UG9ja2V0KFxuICAgIHBvY2tldHM6IE1lUG9ja2V0W10sXG4gICAgc2VsZWN0ZWRQb2NrZXRJZDogc3RyaW5nIHwgbnVsbCxcbiAgICByZXF1aXJlRGVwbG95ZWQ6IGJvb2xlYW4sXG4gICk6IE1lUG9ja2V0IHwgbnVsbCB7XG4gICAgaWYgKHBvY2tldHMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICBjb25zdCBzZWxlY3RlZFBvY2tldCA9XG4gICAgICBwb2NrZXRzLmZpbmQoKHBvY2tldCkgPT4gcG9ja2V0LnBvY2tldElkID09PSBzZWxlY3RlZFBvY2tldElkKSA/PyBudWxsO1xuICAgIGlmIChcbiAgICAgIHNlbGVjdGVkUG9ja2V0ICYmXG4gICAgICAoIXJlcXVpcmVEZXBsb3llZCB8fCBzZWxlY3RlZFBvY2tldC5kZXBsb3lTdGF0ZSA9PT0gXCJERVBMT1lFRFwiKVxuICAgICkge1xuICAgICAgcmV0dXJuIHNlbGVjdGVkUG9ja2V0O1xuICAgIH1cblxuICAgIGlmIChyZXF1aXJlRGVwbG95ZWQpIHtcbiAgICAgIHJldHVybiAoXG4gICAgICAgIHBvY2tldHMuZmluZCgocG9ja2V0KSA9PiBwb2NrZXQuZGVwbG95U3RhdGUgPT09IFwiREVQTE9ZRURcIikgPz8gbnVsbFxuICAgICAgKTtcbiAgICB9XG5cbiAgICByZXR1cm4gc2VsZWN0ZWRQb2NrZXQgPz8gcG9ja2V0c1swXSA/PyBudWxsO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBnZXRTdG9yZWRQb2NrZXRzKCk6IFByb21pc2U8TWVQb2NrZXRbXT4ge1xuICAgIGxldCBwb2NrZXRzID0gYXdhaXQgdGhpcy5zdG9yYWdlLmdldEFwaVBvY2tldHMoKTtcbiAgICBpZiAocG9ja2V0cy5sZW5ndGggPiAwKSB7XG4gICAgICByZXR1cm4gcG9ja2V0cztcbiAgICB9XG5cbiAgICB0cnkge1xuICAgICAgYXdhaXQgdGhpcy5hcGkuZ2V0TWUoKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS53YXJuKFwiW01lc3NhZ2VIYW5kbGVyXSBGYWlsZWQgdG8gcmVmcmVzaCBwb2NrZXRzOlwiLCBlcnJvcik7XG4gICAgfVxuXG4gICAgcG9ja2V0cyA9IGF3YWl0IHRoaXMuc3RvcmFnZS5nZXRBcGlQb2NrZXRzKCk7XG4gICAgcmV0dXJuIHBvY2tldHM7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGdldFByaW1hcnlQb2NrZXQob3B0aW9ucz86IHtcbiAgICByZXF1aXJlRGVwbG95ZWQ/OiBib29sZWFuO1xuICB9KTogUHJvbWlzZTxNZVBvY2tldCB8IG51bGw+IHtcbiAgICBjb25zdCBwb2NrZXRzID0gYXdhaXQgdGhpcy5nZXRTdG9yZWRQb2NrZXRzKCk7XG4gICAgY29uc3Qgc2VsZWN0ZWRQb2NrZXRJZCA9IGF3YWl0IHRoaXMuc3RvcmFnZS5nZXRBcGlTZWxlY3RlZFBvY2tldElkKCk7XG4gICAgcmV0dXJuIHRoaXMuc2VsZWN0UG9ja2V0KFxuICAgICAgcG9ja2V0cyxcbiAgICAgIHNlbGVjdGVkUG9ja2V0SWQsXG4gICAgICBvcHRpb25zPy5yZXF1aXJlRGVwbG95ZWQgPz8gZmFsc2UsXG4gICAgKTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZmluZFBvY2tldEJ5QWRkcmVzc0FuZENoYWluKFxuICAgIGFkZHJlc3M6IGAweCR7c3RyaW5nfWAsXG4gICAgY2hhaW5JZDogbnVtYmVyLFxuICAgIG9wdGlvbnM/OiB7IHJlcXVpcmVEZXBsb3llZD86IGJvb2xlYW4gfSxcbiAgKTogUHJvbWlzZTxNZVBvY2tldCB8IG51bGw+IHtcbiAgICBjb25zdCBwb2NrZXRzID0gYXdhaXQgdGhpcy5nZXRTdG9yZWRQb2NrZXRzKCk7XG4gICAgcmV0dXJuIChcbiAgICAgIHBvY2tldHMuZmluZChcbiAgICAgICAgKHBvY2tldCkgPT5cbiAgICAgICAgICBwb2NrZXQuYWRkcmVzcy50b0xvd2VyQ2FzZSgpID09PSBhZGRyZXNzLnRvTG93ZXJDYXNlKCkgJiZcbiAgICAgICAgICBwb2NrZXQuY2hhaW5JZCA9PT0gY2hhaW5JZCAmJlxuICAgICAgICAgICghb3B0aW9ucz8ucmVxdWlyZURlcGxveWVkIHx8IHBvY2tldC5kZXBsb3lTdGF0ZSA9PT0gXCJERVBMT1lFRFwiKSxcbiAgICAgICkgPz8gbnVsbFxuICAgICk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGJyb2FkY2FzdFJ1bnRpbWVNZXNzYWdlKG1lc3NhZ2U6IHtcbiAgICB0eXBlOiBzdHJpbmc7XG4gICAgcGF5bG9hZD86IHVua25vd247XG4gIH0pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCB0YWJzID0gYXdhaXQgY2hyb21lLnRhYnMucXVlcnkoe30pO1xuICAgIGF3YWl0IFByb21pc2UuYWxsKFxuICAgICAgdGFicy5tYXAoYXN5bmMgKHRhYikgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIHRhYi5pZCAhPT0gXCJudW1iZXJcIikge1xuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgYXdhaXQgY2hyb21lLnRhYnMuc2VuZE1lc3NhZ2UodGFiLmlkLCBtZXNzYWdlKTtcbiAgICAgICAgfSBjYXRjaCB7XG4gICAgICAgICAgLy8gSWdub3JlIHRhYnMgd2l0aG91dCB0aGUgY29udGVudCBzY3JpcHQgaW5qZWN0ZWQuXG4gICAgICAgIH1cbiAgICAgIH0pLFxuICAgICk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGJyb2FkY2FzdFByb3ZpZGVyU3RhdGVDaGFuZ2UoXG4gICAgcG9ja2V0OiBNZVBvY2tldCB8IG51bGwsXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IHRoaXMuYnJvYWRjYXN0UnVudGltZU1lc3NhZ2Uoe1xuICAgICAgdHlwZTogXCJQUk9WSURFUl9TVEFURV9DSEFOR0VEXCIsXG4gICAgICBwYXlsb2FkOiB7XG4gICAgICAgIGNoYWluSWQ6IHBvY2tldD8uY2hhaW5JZCA/PyBudWxsLFxuICAgICAgICBhY2NvdW50czogcG9ja2V0ID8gW3BvY2tldC5hZGRyZXNzXSA6IFtdLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgYnJvYWRjYXN0RGlzY29ubmVjdCgpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCB0aGlzLmJyb2FkY2FzdFJ1bnRpbWVNZXNzYWdlKHsgdHlwZTogXCJTSVRFX0RJU0NPTk5FQ1RFRFwiIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBoYXNDb25uZWN0ZWRBcHByb3ZhbEZvck9yaWdpbihcbiAgICBvcmlnaW46IHN0cmluZyxcbiAgICB3YWxsZXRBZGRyZXNzOiBgMHgke3N0cmluZ31gLFxuICApOiBQcm9taXNlPENvbm5lY3RlZFNpdGVSZWNvcmQgfCBudWxsPiB7XG4gICAgY29uc3Qgbm9ybWFsaXplZE9yaWdpbiA9IHRoaXMubm9ybWFsaXplT3JpZ2luKG9yaWdpbik7XG4gICAgY29uc3QgbG9jYWxTaXRlcyA9IGF3YWl0IHRoaXMuc3RvcmFnZS5nZXRDb25uZWN0ZWRTaXRlcygpO1xuICAgIGNvbnN0IGxvY2FsTWF0Y2ggPVxuICAgICAgT2JqZWN0LnZhbHVlcyhsb2NhbFNpdGVzKS5maW5kKFxuICAgICAgICAoc2l0ZSkgPT5cbiAgICAgICAgICBzaXRlLndhbGxldFNjb3BlID09PSBcInBvY2tldFwiICYmXG4gICAgICAgICAgc2l0ZS5ub3JtYWxpemVkT3JpZ2luID09PSBub3JtYWxpemVkT3JpZ2luICYmXG4gICAgICAgICAgc2l0ZS53YWxsZXRBZGRyZXNzLnRvTG93ZXJDYXNlKCkgPT09IHdhbGxldEFkZHJlc3MudG9Mb3dlckNhc2UoKSxcbiAgICAgICkgPz8gbnVsbDtcbiAgICBpZiAobG9jYWxNYXRjaCkge1xuICAgICAgcmV0dXJuIGxvY2FsTWF0Y2g7XG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlbW90ZSA9IGF3YWl0IHRoaXMuYXBpLmxpc3REYXBwQ29ubmVjdGlvbnMoe1xuICAgICAgICB3YWxsZXRTY29wZTogXCJwb2NrZXRcIixcbiAgICAgICAgc3RhdHVzOiBcImNvbm5lY3RlZFwiLFxuICAgICAgfSk7XG4gICAgICBjb25zdCByZW1vdGVNYXRjaCA9XG4gICAgICAgIHJlbW90ZS5jb25uZWN0aW9ucy5maW5kKFxuICAgICAgICAgIChjb25uZWN0aW9uKSA9PlxuICAgICAgICAgICAgY29ubmVjdGlvbi5ub3JtYWxpemVkT3JpZ2luID09PSBub3JtYWxpemVkT3JpZ2luICYmXG4gICAgICAgICAgICBjb25uZWN0aW9uLndhbGxldEFkZHJlc3MudG9Mb3dlckNhc2UoKSA9PT1cbiAgICAgICAgICAgICAgd2FsbGV0QWRkcmVzcy50b0xvd2VyQ2FzZSgpLFxuICAgICAgICApID8/IG51bGw7XG4gICAgICBpZiAoIXJlbW90ZU1hdGNoKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuXG4gICAgICBjb25zdCByZWNvcmQgPSB0aGlzLnRvQ29ubmVjdGVkU2l0ZVJlY29yZChyZW1vdGVNYXRjaCk7XG4gICAgICBhd2FpdCB0aGlzLnN0b3JhZ2UuYWRkQ29ubmVjdGVkU2l0ZShyZWNvcmQpO1xuICAgICAgcmV0dXJuIHJlY29yZDtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICBcIltNZXNzYWdlSGFuZGxlcl0gRmFpbGVkIHRvIHJlc29sdmUgY3Jvc3MtY2hhaW4gZEFwcCBhcHByb3ZhbDpcIixcbiAgICAgICAgZXJyb3IsXG4gICAgICApO1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBlbnN1cmVDb25uZWN0ZWRTaXRlRm9yUG9ja2V0KFxuICAgIG9yaWdpbjogc3RyaW5nLFxuICAgIHBvY2tldDogTWVQb2NrZXQsXG4gICk6IFByb21pc2U8Q29ubmVjdGVkU2l0ZVJlY29yZCB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IHRoaXMucmVzb2x2ZUNvbm5lY3RlZFNpdGVGb3JQb2NrZXQob3JpZ2luLCBwb2NrZXQpO1xuICAgIGlmIChleGlzdGluZykge1xuICAgICAgcmV0dXJuIGV4aXN0aW5nO1xuICAgIH1cblxuICAgIGNvbnN0IHByaW9yQXBwcm92YWwgPSBhd2FpdCB0aGlzLmhhc0Nvbm5lY3RlZEFwcHJvdmFsRm9yT3JpZ2luKFxuICAgICAgb3JpZ2luLFxuICAgICAgcG9ja2V0LmFkZHJlc3MsXG4gICAgKTtcbiAgICBpZiAoIXByaW9yQXBwcm92YWwpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIGNvbnN0IHByZXBhcmVkID0gYXdhaXQgdGhpcy5hcGkucHJlcGFyZURhcHBDb25uZWN0aW9uKHtcbiAgICAgIG9yaWdpbjogdGhpcy5ub3JtYWxpemVPcmlnaW4ob3JpZ2luKSxcbiAgICAgIHdhbGxldFNjb3BlOiBcInBvY2tldFwiLFxuICAgICAgd2FsbGV0QWRkcmVzczogcG9ja2V0LmFkZHJlc3MsXG4gICAgICBjaGFpbklkOiBwb2NrZXQuY2hhaW5JZCxcbiAgICAgIHBvY2tldElkOiBwb2NrZXQucG9ja2V0SWQsXG4gICAgfSk7XG5cbiAgICBpZiAocHJlcGFyZWQuY29ubmVjdGlvbi50cnVzdExldmVsID09PSBcImJsb2NrZWRcIikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHByZXBhcmVkLndhcm5pbmdNZXNzYWdlIHx8IFwiVGhpcyBkQXBwIGlzIGJsb2NrZWRcIik7XG4gICAgfVxuXG4gICAgaWYgKFxuICAgICAgcHJlcGFyZWQuYWxyZWFkeUNvbm5lY3RlZCAmJlxuICAgICAgcHJlcGFyZWQuY29ubmVjdGlvbi5zdGF0dXMgPT09IFwiY29ubmVjdGVkXCJcbiAgICApIHtcbiAgICAgIGNvbnN0IHJlY29yZCA9IHRoaXMudG9Db25uZWN0ZWRTaXRlUmVjb3JkKHByZXBhcmVkLmNvbm5lY3Rpb24pO1xuICAgICAgYXdhaXQgdGhpcy5zdG9yYWdlLmFkZENvbm5lY3RlZFNpdGUocmVjb3JkKTtcbiAgICAgIHJldHVybiByZWNvcmQ7XG4gICAgfVxuXG4gICAgY29uc3QgY29uZmlybWVkID0gYXdhaXQgdGhpcy5hcGkuY29uZmlybURhcHBDb25uZWN0aW9uKFxuICAgICAgcHJlcGFyZWQuY29ubmVjdGlvbi5jb25uZWN0aW9uSWQsXG4gICAgKTtcbiAgICBjb25zdCByZWNvcmQgPSB0aGlzLnRvQ29ubmVjdGVkU2l0ZVJlY29yZChjb25maXJtZWQuY29ubmVjdGlvbik7XG4gICAgYXdhaXQgdGhpcy5zdG9yYWdlLmFkZENvbm5lY3RlZFNpdGUocmVjb3JkKTtcbiAgICByZXR1cm4gcmVjb3JkO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyByZXNvbHZlQ29ubmVjdGVkU2l0ZUZvclBvY2tldChcbiAgICBvcmlnaW46IHN0cmluZyxcbiAgICBwb2NrZXQ6IE1lUG9ja2V0LFxuICApOiBQcm9taXNlPENvbm5lY3RlZFNpdGVSZWNvcmQgfCBudWxsPiB7XG4gICAgY29uc3QgbG9jYWwgPSBhd2FpdCB0aGlzLnN0b3JhZ2UuZmluZENvbm5lY3RlZFNpdGUoe1xuICAgICAgb3JpZ2luLFxuICAgICAgd2FsbGV0QWRkcmVzczogcG9ja2V0LmFkZHJlc3MsXG4gICAgICBjaGFpbklkOiBwb2NrZXQuY2hhaW5JZCxcbiAgICAgIHdhbGxldFNjb3BlOiBcInBvY2tldFwiLFxuICAgIH0pO1xuICAgIGlmIChsb2NhbCkge1xuICAgICAgcmV0dXJuIGxvY2FsO1xuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBub3JtYWxpemVkT3JpZ2luID0gdGhpcy5ub3JtYWxpemVPcmlnaW4ob3JpZ2luKTtcbiAgICAgIGNvbnN0IHJlbW90ZSA9IGF3YWl0IHRoaXMuYXBpLmxpc3REYXBwQ29ubmVjdGlvbnMoe1xuICAgICAgICB3YWxsZXRTY29wZTogXCJwb2NrZXRcIixcbiAgICAgICAgd2FsbGV0SWQ6IHBvY2tldC5wb2NrZXRJZCxcbiAgICAgICAgc3RhdHVzOiBcImNvbm5lY3RlZFwiLFxuICAgICAgfSk7XG4gICAgICBjb25zdCBtYXRjaCA9IHJlbW90ZS5jb25uZWN0aW9ucy5maW5kKFxuICAgICAgICAoY29ubmVjdGlvbikgPT4gY29ubmVjdGlvbi5ub3JtYWxpemVkT3JpZ2luID09PSBub3JtYWxpemVkT3JpZ2luLFxuICAgICAgKTtcbiAgICAgIGlmICghbWF0Y2gpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHJlY29yZCA9IHRoaXMudG9Db25uZWN0ZWRTaXRlUmVjb3JkKG1hdGNoKTtcbiAgICAgIGF3YWl0IHRoaXMuc3RvcmFnZS5hZGRDb25uZWN0ZWRTaXRlKHJlY29yZCk7XG4gICAgICByZXR1cm4gcmVjb3JkO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLndhcm4oXCJbTWVzc2FnZUhhbmRsZXJdIEZhaWxlZCB0byByZXNvbHZlIGNvbm5lY3RlZCBkQXBwOlwiLCBlcnJvcik7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGhhbmRsZUNvbm5lY3RTaXRlKFxuICAgIHBheWxvYWQ6IHsgb3JpZ2luOiBzdHJpbmcgfSxcbiAgICBzZW5kZXI6IGNocm9tZS5ydW50aW1lLk1lc3NhZ2VTZW5kZXIsXG4gICkge1xuICAgIGNvbnN0IHJhd09yaWdpbiA9IHBheWxvYWQub3JpZ2luIHx8IHNlbmRlci5vcmlnaW4gfHwgc2VuZGVyLnVybDtcbiAgICBpZiAoIXJhd09yaWdpbikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm8gb3JpZ2luIHByb3ZpZGVkXCIpO1xuICAgIH1cbiAgICBjb25zdCBvcmlnaW4gPSB0aGlzLm5vcm1hbGl6ZU9yaWdpbihyYXdPcmlnaW4pO1xuXG4gICAgY29uc3QgcG9ja2V0ID0gYXdhaXQgdGhpcy5lbnN1cmVQcmltYXJ5UG9ja2V0UmVhZHkoe1xuICAgICAgcmVxdWlyZURlcGxveWVkOiB0cnVlLFxuICAgIH0pO1xuICAgIGlmICghcG9ja2V0KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIFwiV2FsbGV0IG5vdCByZWFkeS4gU2lnbiBpbiB0byBhbiBleGlzdGluZyBkZXBsb3llZCBwb2NrZXQgZmlyc3QuXCIsXG4gICAgICApO1xuICAgIH1cblxuICAgIGNvbnN0IGF1dG9Db25uZWN0ZWQgPSBhd2FpdCB0aGlzLmVuc3VyZUNvbm5lY3RlZFNpdGVGb3JQb2NrZXQoXG4gICAgICBvcmlnaW4sXG4gICAgICBwb2NrZXQsXG4gICAgKTtcbiAgICBpZiAoYXV0b0Nvbm5lY3RlZCkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgY29ubmVjdGVkOiB0cnVlLFxuICAgICAgICBhY2NvdW50czogW3BvY2tldC5hZGRyZXNzXSxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgY29uc3QgcHJlcGFyZWQgPSBhd2FpdCB0aGlzLmFwaS5wcmVwYXJlRGFwcENvbm5lY3Rpb24oe1xuICAgICAgb3JpZ2luLFxuICAgICAgd2FsbGV0U2NvcGU6IFwicG9ja2V0XCIsXG4gICAgICB3YWxsZXRBZGRyZXNzOiBwb2NrZXQuYWRkcmVzcyxcbiAgICAgIGNoYWluSWQ6IHBvY2tldC5jaGFpbklkLFxuICAgICAgcG9ja2V0SWQ6IHBvY2tldC5wb2NrZXRJZCxcbiAgICB9KTtcblxuICAgIGlmIChwcmVwYXJlZC5jb25uZWN0aW9uLnRydXN0TGV2ZWwgPT09IFwiYmxvY2tlZFwiKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IocHJlcGFyZWQud2FybmluZ01lc3NhZ2UgfHwgXCJUaGlzIGRBcHAgaXMgYmxvY2tlZFwiKTtcbiAgICB9XG5cbiAgICBpZiAoXG4gICAgICBwcmVwYXJlZC5hbHJlYWR5Q29ubmVjdGVkICYmXG4gICAgICBwcmVwYXJlZC5jb25uZWN0aW9uLnN0YXR1cyA9PT0gXCJjb25uZWN0ZWRcIlxuICAgICkge1xuICAgICAgYXdhaXQgdGhpcy5zdG9yYWdlLmFkZENvbm5lY3RlZFNpdGUoXG4gICAgICAgIHRoaXMudG9Db25uZWN0ZWRTaXRlUmVjb3JkKHByZXBhcmVkLmNvbm5lY3Rpb24pLFxuICAgICAgKTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGNvbm5lY3RlZDogdHJ1ZSxcbiAgICAgICAgYWNjb3VudHM6IFtwb2NrZXQuYWRkcmVzc10sXG4gICAgICB9O1xuICAgIH1cblxuICAgIGNvbnN0IHJlcXVlc3RJZCA9IGNyeXB0by5yYW5kb21VVUlEKCk7XG4gICAgY29uc3Qgd2luZG93SWQgPSBhd2FpdCB0aGlzLm9wZW5Db25uZWN0Q29uZmlybVdpbmRvdyhyZXF1ZXN0SWQpO1xuXG4gICAgbGV0IGFwcHJvdmVkID0gZmFsc2U7XG4gICAgdHJ5IHtcbiAgICAgIGFwcHJvdmVkID0gYXdhaXQgdGhpcy5hd2FpdERhcHBDb25uZWN0Q29uZmlybWF0aW9uKHJlcXVlc3RJZCwge1xuICAgICAgICB3aW5kb3dJZCxcbiAgICAgICAgb3JpZ2luLFxuICAgICAgICB3YWxsZXRBZGRyZXNzOiBwb2NrZXQuYWRkcmVzcyxcbiAgICAgICAgY29ubmVjdGlvbjogcHJlcGFyZWQuY29ubmVjdGlvbixcbiAgICAgICAgd2FybmluZzoge1xuICAgICAgICAgIHRvbmU6IHByZXBhcmVkLndhcm5pbmdUb25lLFxuICAgICAgICAgIHRpdGxlOiBwcmVwYXJlZC53YXJuaW5nVGl0bGUsXG4gICAgICAgICAgbWVzc2FnZTogcHJlcGFyZWQud2FybmluZ01lc3NhZ2UsXG4gICAgICAgIH0sXG4gICAgICB9KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgYXdhaXQgdGhpcy5hcGlcbiAgICAgICAgLnJlamVjdERhcHBDb25uZWN0aW9uKHByZXBhcmVkLmNvbm5lY3Rpb24uY29ubmVjdGlvbklkKVxuICAgICAgICAuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKTtcbiAgICAgIHRocm93IGVycm9yO1xuICAgIH1cblxuICAgIGlmICghYXBwcm92ZWQpIHtcbiAgICAgIGF3YWl0IHRoaXMuYXBpXG4gICAgICAgIC5yZWplY3REYXBwQ29ubmVjdGlvbihwcmVwYXJlZC5jb25uZWN0aW9uLmNvbm5lY3Rpb25JZClcbiAgICAgICAgLmNhdGNoKCgpID0+IHVuZGVmaW5lZCk7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJVc2VyIHJlamVjdGVkIGNvbm5lY3Rpb25cIik7XG4gICAgfVxuXG4gICAgY29uc3QgY29uZmlybWVkID0gYXdhaXQgdGhpcy5hcGkuY29uZmlybURhcHBDb25uZWN0aW9uKFxuICAgICAgcHJlcGFyZWQuY29ubmVjdGlvbi5jb25uZWN0aW9uSWQsXG4gICAgKTtcbiAgICBhd2FpdCB0aGlzLnN0b3JhZ2UuYWRkQ29ubmVjdGVkU2l0ZShcbiAgICAgIHRoaXMudG9Db25uZWN0ZWRTaXRlUmVjb3JkKGNvbmZpcm1lZC5jb25uZWN0aW9uKSxcbiAgICApO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIGNvbm5lY3RlZDogdHJ1ZSxcbiAgICAgIGFjY291bnRzOiBbcG9ja2V0LmFkZHJlc3NdLFxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGhhbmRsZURpc2Nvbm5lY3RTaXRlKHBheWxvYWQ6IHsgb3JpZ2luOiBzdHJpbmcgfSkge1xuICAgIGNvbnN0IHBvY2tldCA9IGF3YWl0IHRoaXMuZ2V0UHJpbWFyeVBvY2tldCgpO1xuICAgIGlmICghcG9ja2V0KSB7XG4gICAgICBhd2FpdCB0aGlzLnN0b3JhZ2UucmVtb3ZlQ29ubmVjdGVkU2l0ZXNGb3JPcmlnaW4ocGF5bG9hZC5vcmlnaW4pO1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xuICAgIH1cblxuICAgIGNvbnN0IHNpdGUgPSBhd2FpdCB0aGlzLnN0b3JhZ2UuZmluZENvbm5lY3RlZFNpdGUoe1xuICAgICAgb3JpZ2luOiBwYXlsb2FkLm9yaWdpbixcbiAgICAgIHdhbGxldEFkZHJlc3M6IHBvY2tldC5hZGRyZXNzLFxuICAgICAgY2hhaW5JZDogcG9ja2V0LmNoYWluSWQsXG4gICAgICB3YWxsZXRTY29wZTogXCJwb2NrZXRcIixcbiAgICB9KTtcblxuICAgIGlmIChzaXRlKSB7XG4gICAgICBhd2FpdCB0aGlzLmFwaVxuICAgICAgICAuZGlzY29ubmVjdERhcHBDb25uZWN0aW9uKHNpdGUuY29ubmVjdGlvbklkKVxuICAgICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICAgICAgY29uc29sZS53YXJuKFwiW01lc3NhZ2VIYW5kbGVyXSBGYWlsZWQgdG8gZGlzY29ubmVjdCBkQXBwOlwiLCBlcnJvcik7XG4gICAgICAgIH0pO1xuICAgICAgYXdhaXQgdGhpcy5zdG9yYWdlLnJlbW92ZUNvbm5lY3RlZFNpdGUoc2l0ZS5jb25uZWN0aW9uSWQpO1xuICAgIH1cblxuICAgIGF3YWl0IHRoaXMuc3RvcmFnZS5yZW1vdmVDb25uZWN0ZWRTaXRlc0Zvck9yaWdpbihcbiAgICAgIHBheWxvYWQub3JpZ2luLFxuICAgICAgcG9ja2V0LmFkZHJlc3MsXG4gICAgKTtcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGhhbmRsZVNlbmRUcmFuc2FjdGlvbihcbiAgICBwYXlsb2FkOiBUcmFuc2FjdGlvblJlcXVlc3QsXG4gICAgc2VuZGVyOiBjaHJvbWUucnVudGltZS5NZXNzYWdlU2VuZGVyLFxuICApOiBQcm9taXNlPGAweCR7c3RyaW5nfWA+IHtcbiAgICBjb25zdCBvcmlnaW4gPSBzZW5kZXIub3JpZ2luIHx8IHNlbmRlci51cmw7XG4gICAgaWYgKCFvcmlnaW4pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIk5vIG9yaWdpbiBwcm92aWRlZFwiKTtcbiAgICB9XG5cbiAgICBpZiAoIXBheWxvYWQudG8pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgdHJhbnNhY3Rpb24gcGFyYW1ldGVyc1wiKTtcbiAgICB9XG5cbiAgICBjb25zdCBwb2NrZXQgPSBhd2FpdCB0aGlzLmdldFByaW1hcnlQb2NrZXQoeyByZXF1aXJlRGVwbG95ZWQ6IHRydWUgfSk7XG4gICAgaWYgKCFwb2NrZXQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIk5vIHBvY2tldCBhdmFpbGFibGVcIik7XG4gICAgfVxuXG4gICAgY29uc3QgY29ubmVjdGlvbiA9IGF3YWl0IHRoaXMuZW5zdXJlQ29ubmVjdGVkU2l0ZUZvclBvY2tldChvcmlnaW4sIHBvY2tldCk7XG4gICAgaWYgKCFjb25uZWN0aW9uKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJTaXRlIG5vdCBjb25uZWN0ZWRcIik7XG4gICAgfVxuICAgIGlmIChjb25uZWN0aW9uLnRydXN0TGV2ZWwgPT09IFwiYmxvY2tlZFwiKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUaGlzIGRBcHAgaXMgYmxvY2tlZFwiKTtcbiAgICB9XG5cbiAgICBhd2FpdCB0aGlzLnN0b3JhZ2UudG91Y2hDb25uZWN0ZWRTaXRlKGNvbm5lY3Rpb24uY29ubmVjdGlvbklkKTtcbiAgICB2b2lkIHRoaXMucmVjb3JkU2lnbkV2ZW50KFxuICAgICAgY29ubmVjdGlvbi5jb25uZWN0aW9uSWQsXG4gICAgICBcInRyYW5zYWN0aW9uXCIsXG4gICAgICBcInJlcXVlc3RlZFwiLFxuICAgICk7XG5cbiAgICBjb25zdCB3YXJuaW5nID1cbiAgICAgIGNvbm5lY3Rpb24udHJ1c3RMZXZlbCA9PT0gXCJ1bmtub3duXCJcbiAgICAgICAgPyB0aGlzLmJ1aWxkVW5rbm93blNpZ25pbmdXYXJuaW5nKGNvbm5lY3Rpb24uaG9zdClcbiAgICAgICAgOiBudWxsO1xuXG4gICAgY29uc3QgcHJlcGFyZWQgPSBhd2FpdCB0aGlzLmFwaS5wcmVwYXJlUG9ja2V0Q3VzdG9tKHBvY2tldC5wb2NrZXRJZCwge1xuICAgICAgbWV0YVRyYW5zYWN0aW9uczogW1xuICAgICAgICB7XG4gICAgICAgICAgdG86IHBheWxvYWQudG8gYXMgYDB4JHtzdHJpbmd9YCxcbiAgICAgICAgICB2YWx1ZTogKHBheWxvYWQudmFsdWUgfHwgXCIweDBcIikgYXMgYDB4JHtzdHJpbmd9YCxcbiAgICAgICAgICBkYXRhOiAocGF5bG9hZC5kYXRhIHx8IFwiMHhcIikgYXMgYDB4JHtzdHJpbmd9YCxcbiAgICAgICAgfSxcbiAgICAgIF0sXG4gICAgfSk7XG5cbiAgICBjb25zdCB3aW5kb3dJZCA9IGF3YWl0IHRoaXMub3BlbkNvbmZpcm1XaW5kb3cocHJlcGFyZWQub3BlcmF0aW9uSWQpO1xuICAgIHJldHVybiB0aGlzLmF3YWl0RGFwcENvbmZpcm1hdGlvbihwcmVwYXJlZC5vcGVyYXRpb25JZCwge1xuICAgICAgd2luZG93SWQsXG4gICAgICBvcmlnaW46IGNvbm5lY3Rpb24ub3JpZ2luLFxuICAgICAgY29ubmVjdGlvbixcbiAgICAgIHdhcm5pbmcsXG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGhhbmRsZVNpZ25NZXNzYWdlKFxuICAgIHBheWxvYWQ6IFNpZ25NZXNzYWdlUmVxdWVzdCxcbiAgICBzZW5kZXI6IGNocm9tZS5ydW50aW1lLk1lc3NhZ2VTZW5kZXIsXG4gICk6IFByb21pc2U8YDB4JHtzdHJpbmd9YD4ge1xuICAgIGNvbnN0IG9yaWdpbiA9IHNlbmRlci5vcmlnaW4gfHwgc2VuZGVyLnVybDtcbiAgICBpZiAoIW9yaWdpbikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm8gb3JpZ2luIHByb3ZpZGVkXCIpO1xuICAgIH1cblxuICAgIGlmICh0eXBlb2YgcGF5bG9hZC5tZXNzYWdlICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHNpZ24gbWVzc2FnZSBwYXJhbWV0ZXJzXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHBvY2tldCA9IGF3YWl0IHRoaXMuZ2V0UHJpbWFyeVBvY2tldCh7IHJlcXVpcmVEZXBsb3llZDogdHJ1ZSB9KTtcbiAgICBpZiAoIXBvY2tldCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm8gcG9ja2V0IGF2YWlsYWJsZVwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBjb25uZWN0aW9uID0gYXdhaXQgdGhpcy5lbnN1cmVDb25uZWN0ZWRTaXRlRm9yUG9ja2V0KG9yaWdpbiwgcG9ja2V0KTtcbiAgICBpZiAoIWNvbm5lY3Rpb24pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlNpdGUgbm90IGNvbm5lY3RlZFwiKTtcbiAgICB9XG4gICAgaWYgKGNvbm5lY3Rpb24udHJ1c3RMZXZlbCA9PT0gXCJibG9ja2VkXCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRoaXMgZEFwcCBpcyBibG9ja2VkXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHJlcXVlc3RlZEFkZHJlc3MgPSBwYXlsb2FkLmFkZHJlc3M/LnRvTG93ZXJDYXNlKCk7XG4gICAgaWYgKHJlcXVlc3RlZEFkZHJlc3MgJiYgcmVxdWVzdGVkQWRkcmVzcyAhPT0gcG9ja2V0LmFkZHJlc3MudG9Mb3dlckNhc2UoKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiUmVxdWVzdGVkIGFjY291bnQgZG9lcyBub3QgbWF0Y2ggc2VsZWN0ZWQgcG9ja2V0XCIpO1xuICAgIH1cblxuICAgIGF3YWl0IHRoaXMuc3RvcmFnZS50b3VjaENvbm5lY3RlZFNpdGUoY29ubmVjdGlvbi5jb25uZWN0aW9uSWQpO1xuICAgIHZvaWQgdGhpcy5yZWNvcmRTaWduRXZlbnQoY29ubmVjdGlvbi5jb25uZWN0aW9uSWQsIFwibWVzc2FnZVwiLCBcInJlcXVlc3RlZFwiKTtcblxuICAgIGNvbnN0IHdhcm5pbmcgPVxuICAgICAgY29ubmVjdGlvbi50cnVzdExldmVsID09PSBcInVua25vd25cIlxuICAgICAgICA/IHRoaXMuYnVpbGRVbmtub3duU2lnbmluZ1dhcm5pbmcoY29ubmVjdGlvbi5ob3N0KVxuICAgICAgICA6IG51bGw7XG5cbiAgICBjb25zdCByZXF1ZXN0SWQgPSBjcnlwdG8ucmFuZG9tVVVJRCgpO1xuICAgIGNvbnN0IHdpbmRvd0lkID0gYXdhaXQgdGhpcy5vcGVuU2lnbkNvbmZpcm1XaW5kb3cocmVxdWVzdElkKTtcbiAgICByZXR1cm4gdGhpcy5hd2FpdERhcHBTaWduQ29uZmlybWF0aW9uKHJlcXVlc3RJZCwge1xuICAgICAgd2luZG93SWQsXG4gICAgICBtZXNzYWdlOiBwYXlsb2FkLm1lc3NhZ2UsXG4gICAgICBhZGRyZXNzOiBwb2NrZXQuYWRkcmVzcyxcbiAgICAgIG9yaWdpbjogY29ubmVjdGlvbi5vcmlnaW4sXG4gICAgICBwb2NrZXRJZDogcG9ja2V0LnBvY2tldElkLFxuICAgICAgY29ubmVjdGlvbixcbiAgICAgIHdhcm5pbmcsXG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGhhbmRsZUNsZWFyQWxsRGF0YSgpIHtcbiAgICBhd2FpdCB0aGlzLnN0b3JhZ2UuY2xlYXJBbGwoKTtcbiAgICBhd2FpdCB0aGlzLmJyb2FkY2FzdERpc2Nvbm5lY3QoKTtcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGhhbmRsZUNsZWFyU2Vzc2lvbigpIHtcbiAgICBhd2FpdCB0aGlzLmFwaS5jbGVhclNlc3Npb24oKTtcbiAgICBhd2FpdCB0aGlzLmJyb2FkY2FzdERpc2Nvbm5lY3QoKTtcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGhhbmRsZVBvY2tldFNlbGVjdChwYXlsb2FkOiB7IHBvY2tldElkOiBzdHJpbmcgfCBudWxsIH0pIHtcbiAgICBjb25zdCBzZWxlY3RlZFBvY2tldCA9IGF3YWl0IHRoaXMuYXBpLnNldFNlbGVjdGVkUG9ja2V0SWQocGF5bG9hZC5wb2NrZXRJZCk7XG4gICAgYXdhaXQgdGhpcy5icm9hZGNhc3RQcm92aWRlclN0YXRlQ2hhbmdlKHNlbGVjdGVkUG9ja2V0KTtcbiAgICByZXR1cm4ge1xuICAgICAgcG9ja2V0SWQ6IHNlbGVjdGVkUG9ja2V0Py5wb2NrZXRJZCA/PyBudWxsLFxuICAgICAgY2hhaW5JZDogc2VsZWN0ZWRQb2NrZXQ/LmNoYWluSWQgPz8gbnVsbCxcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBoYW5kbGVTd2l0Y2hDaGFpbihcbiAgICBwYXlsb2FkOiB7IGNoYWluSWQ6IG51bWJlciB9LFxuICAgIHNlbmRlcjogY2hyb21lLnJ1bnRpbWUuTWVzc2FnZVNlbmRlcixcbiAgKSB7XG4gICAgY29uc3QgcmF3T3JpZ2luID0gc2VuZGVyLm9yaWdpbiB8fCBzZW5kZXIudXJsO1xuICAgIGlmICghcmF3T3JpZ2luKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBvcmlnaW4gcHJvdmlkZWRcIik7XG4gICAgfVxuXG4gICAgaWYgKCFnZXROZXR3b3JrQnlDaGFpbklkKHBheWxvYWQuY2hhaW5JZCkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgQ2hhaW4gJHtwYXlsb2FkLmNoYWluSWR9IGlzIG5vdCBzdXBwb3J0ZWQuYCk7XG4gICAgfVxuXG4gICAgY29uc3QgY3VycmVudFBvY2tldCA9IGF3YWl0IHRoaXMuZ2V0UHJpbWFyeVBvY2tldCh7XG4gICAgICByZXF1aXJlRGVwbG95ZWQ6IHRydWUsXG4gICAgfSk7XG4gICAgaWYgKCFjdXJyZW50UG9ja2V0KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBkZXBsb3llZCBwb2NrZXQgYXZhaWxhYmxlXCIpO1xuICAgIH1cblxuICAgIGlmIChjdXJyZW50UG9ja2V0LmNoYWluSWQgPT09IHBheWxvYWQuY2hhaW5JZCkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgY2hhaW5JZDogY3VycmVudFBvY2tldC5jaGFpbklkLFxuICAgICAgICBhY2NvdW50czogW2N1cnJlbnRQb2NrZXQuYWRkcmVzc10sXG4gICAgICAgIHdhbGxldEFkZHJlc3M6IGN1cnJlbnRQb2NrZXQuYWRkcmVzcyxcbiAgICAgICAgYWRkcmVzc0NoYW5nZWQ6IGZhbHNlLFxuICAgICAgfTtcbiAgICB9XG5cbiAgICBjb25zdCBwcmlvckFwcHJvdmFsID0gYXdhaXQgdGhpcy5oYXNDb25uZWN0ZWRBcHByb3ZhbEZvck9yaWdpbihcbiAgICAgIHJhd09yaWdpbixcbiAgICAgIGN1cnJlbnRQb2NrZXQuYWRkcmVzcyxcbiAgICApO1xuICAgIGlmICghcHJpb3JBcHByb3ZhbCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiU2l0ZSBub3QgY29ubmVjdGVkXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHRhcmdldFBvY2tldCA9IGF3YWl0IHRoaXMuZmluZFBvY2tldEJ5QWRkcmVzc0FuZENoYWluKFxuICAgICAgY3VycmVudFBvY2tldC5hZGRyZXNzLFxuICAgICAgcGF5bG9hZC5jaGFpbklkLFxuICAgICAgeyByZXF1aXJlRGVwbG95ZWQ6IHRydWUgfSxcbiAgICApO1xuICAgIGlmICghdGFyZ2V0UG9ja2V0KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIFwiTm8gZGVwbG95ZWQgcG9ja2V0IGlzIGF2YWlsYWJsZSBvbiB0aGUgcmVxdWVzdGVkIGNoYWluLlwiLFxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBhZGRyZXNzQ2hhbmdlZCA9XG4gICAgICB0YXJnZXRQb2NrZXQuYWRkcmVzcy50b0xvd2VyQ2FzZSgpICE9PVxuICAgICAgY3VycmVudFBvY2tldC5hZGRyZXNzLnRvTG93ZXJDYXNlKCk7XG5cbiAgICBhd2FpdCB0aGlzLmFwaS5zZXRTZWxlY3RlZFBvY2tldElkKHRhcmdldFBvY2tldC5wb2NrZXRJZCk7XG4gICAgY29uc3QgY29ubmVjdGlvbiA9IGF3YWl0IHRoaXMuZW5zdXJlQ29ubmVjdGVkU2l0ZUZvclBvY2tldChcbiAgICAgIHJhd09yaWdpbixcbiAgICAgIHRhcmdldFBvY2tldCxcbiAgICApO1xuICAgIGlmICghY29ubmVjdGlvbikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIGNvbm5lY3QgdGhlIGRBcHAgb24gdGhlIHJlcXVlc3RlZCBjaGFpbi5cIik7XG4gICAgfVxuXG4gICAgYXdhaXQgdGhpcy5icm9hZGNhc3RQcm92aWRlclN0YXRlQ2hhbmdlKHRhcmdldFBvY2tldCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgY2hhaW5JZDogdGFyZ2V0UG9ja2V0LmNoYWluSWQsXG4gICAgICBhY2NvdW50czogW3RhcmdldFBvY2tldC5hZGRyZXNzXSxcbiAgICAgIHdhbGxldEFkZHJlc3M6IHRhcmdldFBvY2tldC5hZGRyZXNzLFxuICAgICAgYWRkcmVzc0NoYW5nZWQsXG4gICAgfTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZW5zdXJlUHJpbWFyeVBvY2tldFJlYWR5KG9wdGlvbnM/OiB7XG4gICAgcmVxdWlyZURlcGxveWVkPzogYm9vbGVhbjtcbiAgfSk6IFByb21pc2U8TWVQb2NrZXQgfCBudWxsPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCB0aGlzLmdldFByaW1hcnlQb2NrZXQob3B0aW9ucyk7XG4gICAgaWYgKGV4aXN0aW5nKSB7XG4gICAgICByZXR1cm4gZXhpc3Rpbmc7XG4gICAgfVxuXG4gICAgY29uc3Qgd2luZG93SWQgPSBhd2FpdCB0aGlzLm9wZW5FeHRlbnNpb25XaW5kb3coKTtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIHRoaXMuYXdhaXRQcmltYXJ5UG9ja2V0KENPTk5FQ1RfVElNRU9VVF9NUywgb3B0aW9ucyk7XG4gICAgfSBmaW5hbGx5IHtcbiAgICAgIGlmICh3aW5kb3dJZCkge1xuICAgICAgICBjaHJvbWUud2luZG93cy5yZW1vdmUod2luZG93SWQsICgpID0+IHVuZGVmaW5lZCk7XG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBhd2FpdFByaW1hcnlQb2NrZXQoXG4gICAgdGltZW91dE1zOiBudW1iZXIsXG4gICAgb3B0aW9ucz86IHsgcmVxdWlyZURlcGxveWVkPzogYm9vbGVhbiB9LFxuICApOiBQcm9taXNlPE1lUG9ja2V0IHwgbnVsbD4ge1xuICAgIGNvbnN0IHN0YXJ0ID0gRGF0ZS5ub3coKTtcbiAgICB3aGlsZSAoRGF0ZS5ub3coKSAtIHN0YXJ0IDwgdGltZW91dE1zKSB7XG4gICAgICBjb25zdCBwb2NrZXQgPSBhd2FpdCB0aGlzLmdldFByaW1hcnlQb2NrZXQob3B0aW9ucyk7XG4gICAgICBpZiAocG9ja2V0KSB7XG4gICAgICAgIHJldHVybiBwb2NrZXQ7XG4gICAgICB9XG4gICAgICBhd2FpdCBzbGVlcChDT05ORUNUX1BPTExfSU5URVJWQUxfTVMpO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgb3BlbkNvbmZpcm1XaW5kb3coXG4gICAgb3BlcmF0aW9uSWQ6IHN0cmluZyxcbiAgKTogUHJvbWlzZTxudW1iZXIgfCB1bmRlZmluZWQ+IHtcbiAgICBjb25zdCB1cmwgPSBjaHJvbWUucnVudGltZS5nZXRVUkwoXG4gICAgICBgcG9wdXAvaW5kZXguaHRtbCMvY29uZmlybS10eD9vcGVyYXRpb25JZD0ke2VuY29kZVVSSUNvbXBvbmVudChcbiAgICAgICAgb3BlcmF0aW9uSWQsXG4gICAgICApfWAsXG4gICAgKTtcblxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgY2hyb21lLndpbmRvd3MuY3JlYXRlKFxuICAgICAgICB7XG4gICAgICAgICAgdXJsLFxuICAgICAgICAgIHR5cGU6IFwicG9wdXBcIixcbiAgICAgICAgICB3aWR0aDogNDIwLFxuICAgICAgICAgIGhlaWdodDogNzIwLFxuICAgICAgICAgIGZvY3VzZWQ6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgICh3aW5kb3cpID0+IHtcbiAgICAgICAgICByZXNvbHZlKHdpbmRvdz8uaWQpO1xuICAgICAgICB9LFxuICAgICAgKTtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgb3BlbkNvbm5lY3RDb25maXJtV2luZG93KFxuICAgIHJlcXVlc3RJZDogc3RyaW5nLFxuICApOiBQcm9taXNlPG51bWJlciB8IHVuZGVmaW5lZD4ge1xuICAgIGNvbnN0IHVybCA9IGNocm9tZS5ydW50aW1lLmdldFVSTChcbiAgICAgIGBwb3B1cC9pbmRleC5odG1sIy9jb25maXJtLWNvbm5lY3Q/cmVxdWVzdElkPSR7ZW5jb2RlVVJJQ29tcG9uZW50KFxuICAgICAgICByZXF1ZXN0SWQsXG4gICAgICApfWAsXG4gICAgKTtcblxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgY2hyb21lLndpbmRvd3MuY3JlYXRlKFxuICAgICAgICB7XG4gICAgICAgICAgdXJsLFxuICAgICAgICAgIHR5cGU6IFwicG9wdXBcIixcbiAgICAgICAgICB3aWR0aDogNDIwLFxuICAgICAgICAgIGhlaWdodDogNzIwLFxuICAgICAgICAgIGZvY3VzZWQ6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgICh3aW5kb3cpID0+IHtcbiAgICAgICAgICByZXNvbHZlKHdpbmRvdz8uaWQpO1xuICAgICAgICB9LFxuICAgICAgKTtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgb3BlblNpZ25Db25maXJtV2luZG93KFxuICAgIHJlcXVlc3RJZDogc3RyaW5nLFxuICApOiBQcm9taXNlPG51bWJlciB8IHVuZGVmaW5lZD4ge1xuICAgIGNvbnN0IHVybCA9IGNocm9tZS5ydW50aW1lLmdldFVSTChcbiAgICAgIGBwb3B1cC9pbmRleC5odG1sIy9jb25maXJtLXNpZ24/cmVxdWVzdElkPSR7ZW5jb2RlVVJJQ29tcG9uZW50KFxuICAgICAgICByZXF1ZXN0SWQsXG4gICAgICApfWAsXG4gICAgKTtcblxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgY2hyb21lLndpbmRvd3MuY3JlYXRlKFxuICAgICAgICB7XG4gICAgICAgICAgdXJsLFxuICAgICAgICAgIHR5cGU6IFwicG9wdXBcIixcbiAgICAgICAgICB3aWR0aDogNDIwLFxuICAgICAgICAgIGhlaWdodDogNzIwLFxuICAgICAgICAgIGZvY3VzZWQ6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgICh3aW5kb3cpID0+IHtcbiAgICAgICAgICByZXNvbHZlKHdpbmRvdz8uaWQpO1xuICAgICAgICB9LFxuICAgICAgKTtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgb3BlbkV4dGVuc2lvbldpbmRvdygpOiBQcm9taXNlPG51bWJlciB8IHVuZGVmaW5lZD4ge1xuICAgIGNvbnN0IHVybCA9IGNocm9tZS5ydW50aW1lLmdldFVSTChcInBvcHVwL2luZGV4Lmh0bWwjL1wiKTtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgIGNocm9tZS53aW5kb3dzLmNyZWF0ZShcbiAgICAgICAge1xuICAgICAgICAgIHVybCxcbiAgICAgICAgICB0eXBlOiBcInBvcHVwXCIsXG4gICAgICAgICAgd2lkdGg6IDQyMCxcbiAgICAgICAgICBoZWlnaHQ6IDcyMCxcbiAgICAgICAgICBmb2N1c2VkOiB0cnVlLFxuICAgICAgICB9LFxuICAgICAgICAod2luZG93KSA9PiB7XG4gICAgICAgICAgcmVzb2x2ZSh3aW5kb3c/LmlkKTtcbiAgICAgICAgfSxcbiAgICAgICk7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGF3YWl0RGFwcENvbm5lY3RDb25maXJtYXRpb24oXG4gICAgcmVxdWVzdElkOiBzdHJpbmcsXG4gICAgcGF5bG9hZDogT21pdDxQZW5kaW5nRGFwcENvbm5lY3QsIFwicmVzb2x2ZVwiIHwgXCJyZWplY3RcIiB8IFwidGltZW91dElkXCI+LFxuICApOiBQcm9taXNlPGJvb2xlYW4+IHtcbiAgICBpZiAodGhpcy5wZW5kaW5nRGFwcENvbm5lY3RzLmhhcyhyZXF1ZXN0SWQpKSB7XG4gICAgICB0aGlzLnBlbmRpbmdEYXBwQ29ubmVjdHNcbiAgICAgICAgLmdldChyZXF1ZXN0SWQpXG4gICAgICAgID8ucmVqZWN0KG5ldyBFcnJvcihcIkR1cGxpY2F0ZSBjb25uZWN0IHJlcXVlc3RcIikpO1xuICAgICAgdGhpcy5wZW5kaW5nRGFwcENvbm5lY3RzLmRlbGV0ZShyZXF1ZXN0SWQpO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBjb25zdCB0aW1lb3V0SWQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdGhpcy5wZW5kaW5nRGFwcENvbm5lY3RzLmRlbGV0ZShyZXF1ZXN0SWQpO1xuICAgICAgICByZWplY3QobmV3IEVycm9yKFwiQ29ubmVjdGlvbiBjb25maXJtYXRpb24gdGltZWQgb3V0XCIpKTtcbiAgICAgIH0sIERBUFBfQ09ORklSTV9USU1FT1VUX01TKTtcblxuICAgICAgdGhpcy5wZW5kaW5nRGFwcENvbm5lY3RzLnNldChyZXF1ZXN0SWQsIHtcbiAgICAgICAgcmVzb2x2ZSxcbiAgICAgICAgcmVqZWN0LFxuICAgICAgICB0aW1lb3V0SWQsXG4gICAgICAgIC4uLnBheWxvYWQsXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgYXdhaXREYXBwQ29uZmlybWF0aW9uKFxuICAgIG9wZXJhdGlvbklkOiBzdHJpbmcsXG4gICAgcGF5bG9hZDogT21pdDxQZW5kaW5nRGFwcFRyYW5zYWN0aW9uLCBcInJlc29sdmVcIiB8IFwicmVqZWN0XCIgfCBcInRpbWVvdXRJZFwiPixcbiAgKTogUHJvbWlzZTxgMHgke3N0cmluZ31gPiB7XG4gICAgaWYgKHRoaXMucGVuZGluZ0RhcHBUcmFuc2FjdGlvbnMuaGFzKG9wZXJhdGlvbklkKSkge1xuICAgICAgdGhpcy5wZW5kaW5nRGFwcFRyYW5zYWN0aW9uc1xuICAgICAgICAuZ2V0KG9wZXJhdGlvbklkKVxuICAgICAgICA/LnJlamVjdChuZXcgRXJyb3IoXCJEdXBsaWNhdGUgdHJhbnNhY3Rpb24gcmVxdWVzdFwiKSk7XG4gICAgICB0aGlzLnBlbmRpbmdEYXBwVHJhbnNhY3Rpb25zLmRlbGV0ZShvcGVyYXRpb25JZCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGNvbnN0IHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0aGlzLnBlbmRpbmdEYXBwVHJhbnNhY3Rpb25zLmRlbGV0ZShvcGVyYXRpb25JZCk7XG4gICAgICAgIHJlamVjdChuZXcgRXJyb3IoXCJUcmFuc2FjdGlvbiBjb25maXJtYXRpb24gdGltZWQgb3V0XCIpKTtcbiAgICAgIH0sIERBUFBfQ09ORklSTV9USU1FT1VUX01TKTtcblxuICAgICAgdGhpcy5wZW5kaW5nRGFwcFRyYW5zYWN0aW9ucy5zZXQob3BlcmF0aW9uSWQsIHtcbiAgICAgICAgcmVzb2x2ZSxcbiAgICAgICAgcmVqZWN0LFxuICAgICAgICB0aW1lb3V0SWQsXG4gICAgICAgIC4uLnBheWxvYWQsXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgYXdhaXREYXBwU2lnbkNvbmZpcm1hdGlvbihcbiAgICByZXF1ZXN0SWQ6IHN0cmluZyxcbiAgICBwYXlsb2FkOiBPbWl0PFBlbmRpbmdEYXBwU2lnbmF0dXJlLCBcInJlc29sdmVcIiB8IFwicmVqZWN0XCIgfCBcInRpbWVvdXRJZFwiPixcbiAgKTogUHJvbWlzZTxgMHgke3N0cmluZ31gPiB7XG4gICAgaWYgKHRoaXMucGVuZGluZ0RhcHBTaWduYXR1cmVzLmhhcyhyZXF1ZXN0SWQpKSB7XG4gICAgICB0aGlzLnBlbmRpbmdEYXBwU2lnbmF0dXJlc1xuICAgICAgICAuZ2V0KHJlcXVlc3RJZClcbiAgICAgICAgPy5yZWplY3QobmV3IEVycm9yKFwiRHVwbGljYXRlIHNpZ24gcmVxdWVzdFwiKSk7XG4gICAgICB0aGlzLnBlbmRpbmdEYXBwU2lnbmF0dXJlcy5kZWxldGUocmVxdWVzdElkKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgY29uc3QgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHRoaXMucGVuZGluZ0RhcHBTaWduYXR1cmVzLmRlbGV0ZShyZXF1ZXN0SWQpO1xuICAgICAgICByZWplY3QobmV3IEVycm9yKFwiU2lnbmF0dXJlIGNvbmZpcm1hdGlvbiB0aW1lZCBvdXRcIikpO1xuICAgICAgfSwgREFQUF9DT05GSVJNX1RJTUVPVVRfTVMpO1xuXG4gICAgICB0aGlzLnBlbmRpbmdEYXBwU2lnbmF0dXJlcy5zZXQocmVxdWVzdElkLCB7XG4gICAgICAgIHJlc29sdmUsXG4gICAgICAgIHJlamVjdCxcbiAgICAgICAgdGltZW91dElkLFxuICAgICAgICAuLi5wYXlsb2FkLFxuICAgICAgfSk7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGhhbmRsZUFwaURhcHBDb25uZWN0Q29udGV4dChwYXlsb2FkOiB7IHJlcXVlc3RJZDogc3RyaW5nIH0pIHtcbiAgICBjb25zdCBlbnRyeSA9IHRoaXMucGVuZGluZ0RhcHBDb25uZWN0cy5nZXQocGF5bG9hZC5yZXF1ZXN0SWQpO1xuICAgIGlmICghZW50cnkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkNvbm5lY3QgcmVxdWVzdCBub3QgZm91bmRcIik7XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIHJlcXVlc3RJZDogcGF5bG9hZC5yZXF1ZXN0SWQsXG4gICAgICBvcmlnaW46IGVudHJ5Lm9yaWdpbixcbiAgICAgIHdhbGxldEFkZHJlc3M6IGVudHJ5LndhbGxldEFkZHJlc3MsXG4gICAgICBjaGFpbklkOiBlbnRyeS5jb25uZWN0aW9uLmNoYWluSWQsXG4gICAgICBjb25uZWN0aW9uSWQ6IGVudHJ5LmNvbm5lY3Rpb24uY29ubmVjdGlvbklkLFxuICAgICAgaG9zdDogZW50cnkuY29ubmVjdGlvbi5ob3N0LFxuICAgICAgdHJ1c3RMZXZlbDogZW50cnkuY29ubmVjdGlvbi50cnVzdExldmVsLFxuICAgICAgd2FybmluZ1RvbmU6IGVudHJ5Lndhcm5pbmcudG9uZSxcbiAgICAgIHdhcm5pbmdUaXRsZTogZW50cnkud2FybmluZy50aXRsZSxcbiAgICAgIHdhcm5pbmdNZXNzYWdlOiBlbnRyeS53YXJuaW5nLm1lc3NhZ2UsXG4gICAgfTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgaGFuZGxlQXBpRGFwcENvbm5lY3RSZXN1bHQocGF5bG9hZDoge1xuICAgIHJlcXVlc3RJZDogc3RyaW5nO1xuICAgIHN0YXR1czogXCJhcHByb3ZlZFwiIHwgXCJyZWplY3RlZFwiIHwgXCJmYWlsZWRcIjtcbiAgICBlcnJvcj86IHN0cmluZztcbiAgfSkge1xuICAgIGNvbnN0IGVudHJ5ID0gdGhpcy5wZW5kaW5nRGFwcENvbm5lY3RzLmdldChwYXlsb2FkLnJlcXVlc3RJZCk7XG4gICAgaWYgKCFlbnRyeSkge1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xuICAgIH1cblxuICAgIGNsZWFyVGltZW91dChlbnRyeS50aW1lb3V0SWQpO1xuICAgIHRoaXMucGVuZGluZ0RhcHBDb25uZWN0cy5kZWxldGUocGF5bG9hZC5yZXF1ZXN0SWQpO1xuXG4gICAgaWYgKHBheWxvYWQuc3RhdHVzID09PSBcImFwcHJvdmVkXCIpIHtcbiAgICAgIGVudHJ5LnJlc29sdmUodHJ1ZSk7XG4gICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gICAgfVxuICAgIGlmIChwYXlsb2FkLnN0YXR1cyA9PT0gXCJyZWplY3RlZFwiKSB7XG4gICAgICBlbnRyeS5yZXNvbHZlKGZhbHNlKTtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbiAgICB9XG5cbiAgICBlbnRyeS5yZWplY3QobmV3IEVycm9yKHBheWxvYWQuZXJyb3IgfHwgXCJDb25uZWN0aW9uIHdhcyByZWplY3RlZFwiKSk7XG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBoYW5kbGVBcGlEYXBwVHhDb250ZXh0KHBheWxvYWQ6IHsgb3BlcmF0aW9uSWQ6IHN0cmluZyB9KSB7XG4gICAgY29uc3QgZW50cnkgPSB0aGlzLnBlbmRpbmdEYXBwVHJhbnNhY3Rpb25zLmdldChwYXlsb2FkLm9wZXJhdGlvbklkKTtcbiAgICBpZiAoIWVudHJ5KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJUcmFuc2FjdGlvbiByZXF1ZXN0IG5vdCBmb3VuZFwiKTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgb3BlcmF0aW9uSWQ6IHBheWxvYWQub3BlcmF0aW9uSWQsXG4gICAgICBvcmlnaW46IGVudHJ5Lm9yaWdpbixcbiAgICAgIGNoYWluSWQ6IGVudHJ5LmNvbm5lY3Rpb24/LmNoYWluSWQgPz8gbnVsbCxcbiAgICAgIGNvbm5lY3Rpb25JZDogZW50cnkuY29ubmVjdGlvbj8uY29ubmVjdGlvbklkID8/IG51bGwsXG4gICAgICBob3N0OiBlbnRyeS5jb25uZWN0aW9uPy5ob3N0ID8/IG51bGwsXG4gICAgICB0cnVzdExldmVsOiBlbnRyeS5jb25uZWN0aW9uPy50cnVzdExldmVsID8/IG51bGwsXG4gICAgICB3YXJuaW5nOiBlbnRyeS53YXJuaW5nLFxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGhhbmRsZUFwaURhcHBUeFJlc3VsdChwYXlsb2FkOiB7XG4gICAgb3BlcmF0aW9uSWQ6IHN0cmluZztcbiAgICBzdGF0dXM6IFwiY29uZmlybWVkXCIgfCBcInJlamVjdGVkXCIgfCBcImZhaWxlZFwiO1xuICAgIHR4SGFzaD86IGAweCR7c3RyaW5nfWAgfCBudWxsO1xuICAgIGVycm9yPzogc3RyaW5nO1xuICB9KSB7XG4gICAgY29uc3QgZW50cnkgPSB0aGlzLnBlbmRpbmdEYXBwVHJhbnNhY3Rpb25zLmdldChwYXlsb2FkLm9wZXJhdGlvbklkKTtcbiAgICBpZiAoIWVudHJ5KSB7XG4gICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gICAgfVxuXG4gICAgY2xlYXJUaW1lb3V0KGVudHJ5LnRpbWVvdXRJZCk7XG4gICAgdGhpcy5wZW5kaW5nRGFwcFRyYW5zYWN0aW9ucy5kZWxldGUocGF5bG9hZC5vcGVyYXRpb25JZCk7XG5cbiAgICBpZiAoZW50cnkuY29ubmVjdGlvbikge1xuICAgICAgY29uc3Qgb3V0Y29tZSA9XG4gICAgICAgIHBheWxvYWQuc3RhdHVzID09PSBcImNvbmZpcm1lZFwiXG4gICAgICAgICAgPyBcImFwcHJvdmVkXCJcbiAgICAgICAgICA6IHBheWxvYWQuc3RhdHVzID09PSBcInJlamVjdGVkXCJcbiAgICAgICAgICAgID8gXCJyZWplY3RlZFwiXG4gICAgICAgICAgICA6IFwiZmFpbGVkXCI7XG4gICAgICB2b2lkIHRoaXMucmVjb3JkU2lnbkV2ZW50KFxuICAgICAgICBlbnRyeS5jb25uZWN0aW9uLmNvbm5lY3Rpb25JZCxcbiAgICAgICAgXCJ0cmFuc2FjdGlvblwiLFxuICAgICAgICBvdXRjb21lLFxuICAgICAgKTtcbiAgICB9XG5cbiAgICBpZiAocGF5bG9hZC5zdGF0dXMgPT09IFwiY29uZmlybWVkXCIpIHtcbiAgICAgIGlmICghcGF5bG9hZC50eEhhc2gpIHtcbiAgICAgICAgZW50cnkucmVqZWN0KFxuICAgICAgICAgIG5ldyBFcnJvcihcIlRyYW5zYWN0aW9uIGNvbmZpcm1lZCBidXQgdHggaGFzaCB1bmF2YWlsYWJsZVwiKSxcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xuICAgICAgfVxuICAgICAgZW50cnkucmVzb2x2ZShwYXlsb2FkLnR4SGFzaCk7XG4gICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gICAgfVxuXG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID1cbiAgICAgIHBheWxvYWQuZXJyb3IgfHwgXCJUcmFuc2FjdGlvbiB3YXMgcmVqZWN0ZWQgYnkgdGhlIHVzZXJcIjtcbiAgICBlbnRyeS5yZWplY3QobmV3IEVycm9yKGVycm9yTWVzc2FnZSkpO1xuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgaGFuZGxlQXBpRGFwcFNpZ25Db250ZXh0KHBheWxvYWQ6IHsgcmVxdWVzdElkOiBzdHJpbmcgfSkge1xuICAgIGNvbnN0IGVudHJ5ID0gdGhpcy5wZW5kaW5nRGFwcFNpZ25hdHVyZXMuZ2V0KHBheWxvYWQucmVxdWVzdElkKTtcbiAgICBpZiAoIWVudHJ5KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJTaWduIHJlcXVlc3Qgbm90IGZvdW5kXCIpO1xuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICByZXF1ZXN0SWQ6IHBheWxvYWQucmVxdWVzdElkLFxuICAgICAgbWVzc2FnZTogZW50cnkubWVzc2FnZSxcbiAgICAgIGFkZHJlc3M6IGVudHJ5LmFkZHJlc3MsXG4gICAgICBvcmlnaW46IGVudHJ5Lm9yaWdpbixcbiAgICAgIHBvY2tldElkOiBlbnRyeS5wb2NrZXRJZCxcbiAgICAgIGNoYWluSWQ6IGVudHJ5LmNvbm5lY3Rpb24/LmNoYWluSWQgPz8gbnVsbCxcbiAgICAgIGNvbm5lY3Rpb25JZDogZW50cnkuY29ubmVjdGlvbj8uY29ubmVjdGlvbklkID8/IG51bGwsXG4gICAgICBob3N0OiBlbnRyeS5jb25uZWN0aW9uPy5ob3N0ID8/IG51bGwsXG4gICAgICB0cnVzdExldmVsOiBlbnRyeS5jb25uZWN0aW9uPy50cnVzdExldmVsID8/IG51bGwsXG4gICAgICB3YXJuaW5nOiBlbnRyeS53YXJuaW5nLFxuICAgIH07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGhhbmRsZUFwaURhcHBTaWduUmVzdWx0KHBheWxvYWQ6IHtcbiAgICByZXF1ZXN0SWQ6IHN0cmluZztcbiAgICBzdGF0dXM6IFwic2lnbmVkXCIgfCBcInJlamVjdGVkXCIgfCBcImZhaWxlZFwiO1xuICAgIHNpZ25hdHVyZT86IGAweCR7c3RyaW5nfWA7XG4gICAgZXJyb3I/OiBzdHJpbmc7XG4gIH0pIHtcbiAgICBjb25zdCBlbnRyeSA9IHRoaXMucGVuZGluZ0RhcHBTaWduYXR1cmVzLmdldChwYXlsb2FkLnJlcXVlc3RJZCk7XG4gICAgaWYgKCFlbnRyeSkge1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xuICAgIH1cblxuICAgIGNsZWFyVGltZW91dChlbnRyeS50aW1lb3V0SWQpO1xuICAgIHRoaXMucGVuZGluZ0RhcHBTaWduYXR1cmVzLmRlbGV0ZShwYXlsb2FkLnJlcXVlc3RJZCk7XG5cbiAgICBpZiAoZW50cnkuY29ubmVjdGlvbikge1xuICAgICAgY29uc3Qgb3V0Y29tZSA9XG4gICAgICAgIHBheWxvYWQuc3RhdHVzID09PSBcInNpZ25lZFwiXG4gICAgICAgICAgPyBcImFwcHJvdmVkXCJcbiAgICAgICAgICA6IHBheWxvYWQuc3RhdHVzID09PSBcInJlamVjdGVkXCJcbiAgICAgICAgICAgID8gXCJyZWplY3RlZFwiXG4gICAgICAgICAgICA6IFwiZmFpbGVkXCI7XG4gICAgICB2b2lkIHRoaXMucmVjb3JkU2lnbkV2ZW50KFxuICAgICAgICBlbnRyeS5jb25uZWN0aW9uLmNvbm5lY3Rpb25JZCxcbiAgICAgICAgXCJtZXNzYWdlXCIsXG4gICAgICAgIG91dGNvbWUsXG4gICAgICApO1xuICAgIH1cblxuICAgIGlmIChwYXlsb2FkLnN0YXR1cyA9PT0gXCJzaWduZWRcIikge1xuICAgICAgaWYgKCFwYXlsb2FkLnNpZ25hdHVyZSkge1xuICAgICAgICBlbnRyeS5yZWplY3QobmV3IEVycm9yKFwiTWlzc2luZyBzaWduYXR1cmUgcmVzdWx0XCIpKTtcbiAgICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xuICAgICAgfVxuICAgICAgZW50cnkucmVzb2x2ZShwYXlsb2FkLnNpZ25hdHVyZSk7XG4gICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gICAgfVxuXG4gICAgY29uc3QgZXJyb3JNZXNzYWdlID1cbiAgICAgIHBheWxvYWQuZXJyb3IgfHwgXCJNZXNzYWdlIHNpZ25pbmcgd2FzIHJlamVjdGVkIGJ5IHRoZSB1c2VyXCI7XG4gICAgZW50cnkucmVqZWN0KG5ldyBFcnJvcihlcnJvck1lc3NhZ2UpKTtcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gIH1cbn1cbiIsImNvbnN0IEZBTExCQUNLX0VYUElSWV9NUyA9IDYwICogNjAgKiAxMDAwO1xuXG5mdW5jdGlvbiBub3JtYWxpemVCYXNlNjRVcmwodmFsdWU6IHN0cmluZykge1xuICBsZXQgbm9ybWFsaXplZCA9IHZhbHVlLnJlcGxhY2UoLy0vZywgXCIrXCIpLnJlcGxhY2UoL18vZywgXCIvXCIpO1xuICBjb25zdCBwYWRkaW5nTmVlZGVkID0gbm9ybWFsaXplZC5sZW5ndGggJSA0O1xuICBpZiAocGFkZGluZ05lZWRlZCA9PT0gMikgbm9ybWFsaXplZCArPSBcIj09XCI7XG4gIGVsc2UgaWYgKHBhZGRpbmdOZWVkZWQgPT09IDMpIG5vcm1hbGl6ZWQgKz0gXCI9XCI7XG4gIGVsc2UgaWYgKHBhZGRpbmdOZWVkZWQgIT09IDApIG5vcm1hbGl6ZWQgKz0gXCI9PVwiO1xuICByZXR1cm4gbm9ybWFsaXplZDtcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRlY29kZUp3dEV4cGlyYXRpb24odG9rZW46IHN0cmluZyk6IG51bWJlciB8IG51bGwge1xuICB0cnkge1xuICAgIGNvbnN0IHNlZ21lbnRzID0gdG9rZW4uc3BsaXQoXCIuXCIpO1xuICAgIGlmIChzZWdtZW50cy5sZW5ndGggPCAyKSByZXR1cm4gbnVsbDtcbiAgICBjb25zdCBwYXlsb2FkU2VnbWVudCA9IHNlZ21lbnRzWzFdO1xuICAgIGlmICghcGF5bG9hZFNlZ21lbnQpIHJldHVybiBudWxsO1xuICAgIGNvbnN0IG5vcm1hbGl6ZWQgPSBub3JtYWxpemVCYXNlNjRVcmwocGF5bG9hZFNlZ21lbnQpO1xuICAgIGlmICh0eXBlb2YgZ2xvYmFsVGhpcy5hdG9iICE9PSBcImZ1bmN0aW9uXCIpIHJldHVybiBudWxsO1xuICAgIGNvbnN0IGpzb24gPSBnbG9iYWxUaGlzLmF0b2Iobm9ybWFsaXplZCk7XG4gICAgY29uc3QgcGF5bG9hZCA9IEpTT04ucGFyc2UoanNvbikgYXMgeyBleHA/OiBudW1iZXIgfTtcbiAgICBpZiAodHlwZW9mIHBheWxvYWQuZXhwICE9PSBcIm51bWJlclwiKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gcGF5bG9hZC5leHAgKiAxMDAwO1xuICB9IGNhdGNoIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gYnVpbGRBY2Nlc3NFeHBpcnkodG9rZW46IHN0cmluZykge1xuICByZXR1cm4gZGVjb2RlSnd0RXhwaXJhdGlvbih0b2tlbikgPz8gRGF0ZS5ub3coKSArIEZBTExCQUNLX0VYUElSWV9NUztcbn1cbiIsImltcG9ydCB7IGF1dGhIZWFkZXJzLCBnZXRBeGlvc0Vycm9yTWVzc2FnZSwgd2l0aEVycm9yQ2F1c2UgfSBmcm9tIFwiLi9jbGllbnQuanNcIjtcbmV4cG9ydCBmdW5jdGlvbiBjYW5Vc2VyU2VuZEZyb21NZShtZSkge1xuICAgIHJldHVybiAobWUuZGVwbG95bWVudFJlYWRpbmVzcy5wb2NrZXQ/LmNhblNlbmQgPz8gbWUuZGVwbG95bWVudFJlYWRpbmVzcy5jYW5TZW5kKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRNaXNzaW5nRGVwbG95bWVudENoYWlucyhtZSkge1xuICAgIHJldHVybiAobWUuZGVwbG95bWVudFJlYWRpbmVzcy5wb2NrZXQ/Lm1pc3NpbmdDaGFpbnMgPz9cbiAgICAgICAgbWUuZGVwbG95bWVudFJlYWRpbmVzcy5taXNzaW5nQ2hhaW5zKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRNZShjbGllbnQsIGFjY2Vzc1Rva2VuKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LmdldChcIi92MS91c2Vycy9tZVwiLCBhdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikpO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byBsb2FkIHVzZXIgcHJvZmlsZVwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IGF1dGhIZWFkZXJzLCBnZXRBeGlvc0Vycm9yTWVzc2FnZSwgd2l0aEVycm9yQ2F1c2UgfSBmcm9tIFwiLi9jbGllbnQuanNcIjtcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcmVwYXJlRGFwcENvbm5lY3Rpb24oY2xpZW50LCBhY2Nlc3NUb2tlbiwgcGF5bG9hZCkge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5wb3N0KFwiL3YxL2RhcHBzL2Nvbm5lY3Rpb25zL3ByZXBhcmVcIiwgcGF5bG9hZCwgYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pKTtcbiAgICAgICAgcmV0dXJuIHJlcy5kYXRhLmRhdGE7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gcHJlcGFyZSBkQXBwIGNvbm5lY3Rpb25cIiksIGVycm9yKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY29uZmlybURhcHBDb25uZWN0aW9uKGNsaWVudCwgYWNjZXNzVG9rZW4sIGNvbm5lY3Rpb25JZCkge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5wb3N0KGAvdjEvZGFwcHMvY29ubmVjdGlvbnMvJHtjb25uZWN0aW9uSWR9L2NvbmZpcm1gLCB7fSwgYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pKTtcbiAgICAgICAgcmV0dXJuIHJlcy5kYXRhLmRhdGE7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gY29uZmlybSBkQXBwIGNvbm5lY3Rpb25cIiksIGVycm9yKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVqZWN0RGFwcENvbm5lY3Rpb24oY2xpZW50LCBhY2Nlc3NUb2tlbiwgY29ubmVjdGlvbklkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LnBvc3QoYC92MS9kYXBwcy9jb25uZWN0aW9ucy8ke2Nvbm5lY3Rpb25JZH0vcmVqZWN0YCwge30sIGF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIHJlamVjdCBkQXBwIGNvbm5lY3Rpb25cIiksIGVycm9yKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGlzY29ubmVjdERhcHBDb25uZWN0aW9uKGNsaWVudCwgYWNjZXNzVG9rZW4sIGNvbm5lY3Rpb25JZCkge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5wb3N0KGAvdjEvZGFwcHMvY29ubmVjdGlvbnMvJHtjb25uZWN0aW9uSWR9L2Rpc2Nvbm5lY3RgLCB7fSwgYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pKTtcbiAgICAgICAgcmV0dXJuIHJlcy5kYXRhLmRhdGE7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gZGlzY29ubmVjdCBkQXBwXCIpLCBlcnJvcik7XG4gICAgfVxufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGxpc3REYXBwQ29ubmVjdGlvbnMoY2xpZW50LCBhY2Nlc3NUb2tlbiwgcGFyYW1zKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LmdldChcIi92MS9kYXBwcy9jb25uZWN0aW9uc1wiLCB7XG4gICAgICAgICAgICAuLi5hdXRoSGVhZGVycyhhY2Nlc3NUb2tlbiksXG4gICAgICAgICAgICBwYXJhbXMsXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byBsb2FkIGRBcHAgY29ubmVjdGlvbnNcIiksIGVycm9yKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVjb3JkRGFwcENvbm5lY3Rpb25TaWduRXZlbnQoY2xpZW50LCBhY2Nlc3NUb2tlbiwgY29ubmVjdGlvbklkLCBwYXlsb2FkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LnBvc3QoYC92MS9kYXBwcy9jb25uZWN0aW9ucy8ke2Nvbm5lY3Rpb25JZH0vc2lnbi1ldmVudHNgLCBwYXlsb2FkLCBhdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikpO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byByZWNvcmQgZEFwcCBzaWduIGV2ZW50XCIpLCBlcnJvcik7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgYXV0aEhlYWRlcnMsIGNyZWF0ZUlkZW1wb3RlbmN5S2V5LCBnZXRBeGlvc0Vycm9yTWVzc2FnZSwgd2l0aEVycm9yQ2F1c2UsIH0gZnJvbSBcIi4vY2xpZW50LmpzXCI7XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJlcGFyZVBvY2tldChjbGllbnQsIGFjY2Vzc1Rva2VuLCBvcHRzKSB7XG4gICAgY29uc3QgaWRlbXBvdGVuY3lLZXkgPSBvcHRzPy5pZGVtcG90ZW5jeUtleSA/PyBjcmVhdGVJZGVtcG90ZW5jeUtleSgpO1xuICAgIGNvbnN0IHBheWxvYWQgPSB7fTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQucG9zdChcIi92MS9wb2NrZXRzL25ldy9wcmVwYXJlXCIsIHBheWxvYWQsIHtcbiAgICAgICAgICAgIC4uLmF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSxcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgICAuLi5hdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikuaGVhZGVycyxcbiAgICAgICAgICAgICAgICBcIklkZW1wb3RlbmN5LUtleVwiOiBpZGVtcG90ZW5jeUtleSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byBwcmVwYXJlIHBvY2tldFwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzdWJtaXRQb2NrZXQoY2xpZW50LCBhY2Nlc3NUb2tlbiwgcGF5bG9hZCwgb3B0cykge1xuICAgIGNvbnN0IGlkZW1wb3RlbmN5S2V5ID0gb3B0cz8uaWRlbXBvdGVuY3lLZXkgPz8gY3JlYXRlSWRlbXBvdGVuY3lLZXkoKTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQucG9zdChcIi92MS9wb2NrZXRzL25ldy9zdWJtaXRcIiwgcGF5bG9hZCwge1xuICAgICAgICAgICAgLi4uYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pLFxuICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAgIC4uLmF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKS5oZWFkZXJzLFxuICAgICAgICAgICAgICAgIFwiSWRlbXBvdGVuY3ktS2V5XCI6IGlkZW1wb3RlbmN5S2V5LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIHN1Ym1pdCBwb2NrZXRcIiksIGVycm9yKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJlcGFyZVBvY2tldFR4U2VuZChjbGllbnQsIGFjY2Vzc1Rva2VuLCBwb2NrZXRJZCwgcGF5bG9hZCwgb3B0cykge1xuICAgIGNvbnN0IGlkZW1wb3RlbmN5S2V5ID0gb3B0cz8uaWRlbXBvdGVuY3lLZXkgPz8gY3JlYXRlSWRlbXBvdGVuY3lLZXkoKTtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQucG9zdChgL3YxL3BvY2tldHMvJHtwb2NrZXRJZH0vdHgvc2VuZC9wcmVwYXJlYCwgcGF5bG9hZCwge1xuICAgICAgICAgICAgLi4uYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pLFxuICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAgIC4uLmF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKS5oZWFkZXJzLFxuICAgICAgICAgICAgICAgIFwiSWRlbXBvdGVuY3ktS2V5XCI6IGlkZW1wb3RlbmN5S2V5LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIHByZXBhcmUgdHJhbnNmZXJcIiksIGVycm9yKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3VibWl0UG9ja2V0VHhTZW5kKGNsaWVudCwgYWNjZXNzVG9rZW4sIHBvY2tldElkLCBwYXlsb2FkLCBvcHRzKSB7XG4gICAgY29uc3QgaWRlbXBvdGVuY3lLZXkgPSBvcHRzPy5pZGVtcG90ZW5jeUtleSA/PyBjcmVhdGVJZGVtcG90ZW5jeUtleSgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5wb3N0KGAvdjEvcG9ja2V0cy8ke3BvY2tldElkfS90eC9zZW5kL3N1Ym1pdGAsIHBheWxvYWQsIHtcbiAgICAgICAgICAgIC4uLmF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSxcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgICAuLi5hdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikuaGVhZGVycyxcbiAgICAgICAgICAgICAgICBcIklkZW1wb3RlbmN5LUtleVwiOiBpZGVtcG90ZW5jeUtleSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byBzdWJtaXQgdHJhbnNmZXJcIiksIGVycm9yKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHJlcGFyZVBvY2tldFR4Q3VzdG9tKGNsaWVudCwgYWNjZXNzVG9rZW4sIHBvY2tldElkLCBwYXlsb2FkLCBvcHRzKSB7XG4gICAgY29uc3QgaWRlbXBvdGVuY3lLZXkgPSBvcHRzPy5pZGVtcG90ZW5jeUtleSA/PyBjcmVhdGVJZGVtcG90ZW5jeUtleSgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5wb3N0KGAvdjEvcG9ja2V0cy8ke3BvY2tldElkfS90eC9jdXN0b20vcHJlcGFyZWAsIHBheWxvYWQsIHtcbiAgICAgICAgICAgIC4uLmF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSxcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcbiAgICAgICAgICAgICAgICAuLi5hdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikuaGVhZGVycyxcbiAgICAgICAgICAgICAgICBcIklkZW1wb3RlbmN5LUtleVwiOiBpZGVtcG90ZW5jeUtleSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byBwcmVwYXJlIHRyYW5zYWN0aW9uXCIpLCBlcnJvcik7XG4gICAgfVxufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdFBvY2tldFR4Q3VzdG9tKGNsaWVudCwgYWNjZXNzVG9rZW4sIHBvY2tldElkLCBwYXlsb2FkLCBvcHRzKSB7XG4gICAgY29uc3QgaWRlbXBvdGVuY3lLZXkgPSBvcHRzPy5pZGVtcG90ZW5jeUtleSA/PyBjcmVhdGVJZGVtcG90ZW5jeUtleSgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5wb3N0KGAvdjEvcG9ja2V0cy8ke3BvY2tldElkfS90eC9jdXN0b20vc3VibWl0YCwgcGF5bG9hZCwge1xuICAgICAgICAgICAgLi4uYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pLFxuICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAgIC4uLmF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKS5oZWFkZXJzLFxuICAgICAgICAgICAgICAgIFwiSWRlbXBvdGVuY3ktS2V5XCI6IGlkZW1wb3RlbmN5S2V5LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIHN1Ym1pdCB0cmFuc2FjdGlvblwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcmVwYXJlUG9ja2V0UGVyc29uYWxTaWduKGNsaWVudCwgYWNjZXNzVG9rZW4sIHBvY2tldElkLCBwYXlsb2FkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LnBvc3QoYC92MS9wb2NrZXRzLyR7cG9ja2V0SWR9L3NpZ24vcGVyc29uYWwvcHJlcGFyZWAsIHBheWxvYWQsIGF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIHByZXBhcmUgcGVyc29uYWwgc2lnblwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzdWJtaXRQb2NrZXRQZXJzb25hbFNpZ24oY2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQsIHBheWxvYWQpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQucG9zdChgL3YxL3BvY2tldHMvJHtwb2NrZXRJZH0vc2lnbi9wZXJzb25hbC9zdWJtaXRgLCBwYXlsb2FkLCBhdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikpO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byBzdWJtaXQgcGVyc29uYWwgc2lnblwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVQb2NrZXRMYWJlbChjbGllbnQsIGFjY2Vzc1Rva2VuLCBwb2NrZXRJZCwgbGFiZWwpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQucGF0Y2goYC92MS9wb2NrZXRzLyR7cG9ja2V0SWR9YCwgeyBsYWJlbCB9LCBhdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikpO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byB1cGRhdGUgd2FsbGV0IG5hbWVcIiksIGVycm9yKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbGlzdFBvY2tldHMoY2xpZW50LCBhY2Nlc3NUb2tlbiwgb3B0cykge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5nZXQoXCIvdjEvcG9ja2V0c1wiLCB7XG4gICAgICAgICAgICAuLi5hdXRoSGVhZGVycyhhY2Nlc3NUb2tlbiksXG4gICAgICAgICAgICBwYXJhbXM6IHsgc3RhdGU6IG9wdHM/LnN0YXRlIH0sXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YS5wb2NrZXRzO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIGxvYWQgcG9ja2V0c1wiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhcmNoaXZlUG9ja2V0KGNsaWVudCwgYWNjZXNzVG9rZW4sIHBvY2tldElkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LnBvc3QoYC92MS9wb2NrZXRzLyR7cG9ja2V0SWR9L2FyY2hpdmVgLCB7fSwgYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pKTtcbiAgICAgICAgcmV0dXJuIHJlcy5kYXRhLmRhdGE7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gYXJjaGl2ZSB3YWxsZXRcIiksIGVycm9yKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdW5hcmNoaXZlUG9ja2V0KGNsaWVudCwgYWNjZXNzVG9rZW4sIHBvY2tldElkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LnBvc3QoYC92MS9wb2NrZXRzLyR7cG9ja2V0SWR9L3VuYXJjaGl2ZWAsIHt9LCBhdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikpO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byB1bmFyY2hpdmUgd2FsbGV0XCIpLCBlcnJvcik7XG4gICAgfVxufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFBvY2tldEJhbGFuY2VzKGNsaWVudCwgYWNjZXNzVG9rZW4sIHBvY2tldElkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LmdldChgL3YxL3BvY2tldHMvJHtwb2NrZXRJZH0vYmFsYW5jZXNgLCBhdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikpO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byBsb2FkIHBvY2tldCBiYWxhbmNlc1wiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRQb2NrZXRBY3Rpdml0aWVzKGNsaWVudCwgYWNjZXNzVG9rZW4sIHBvY2tldElkLCBwYXJhbXMpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQuZ2V0KGAvdjEvcG9ja2V0cy8ke3BvY2tldElkfS9hY3Rpdml0aWVzYCwge1xuICAgICAgICAgICAgLi4uYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgY3Vyc29yOiBwYXJhbXM/LmN1cnNvcixcbiAgICAgICAgICAgICAgICBsaW1pdDogcGFyYW1zPy5saW1pdCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byBsb2FkIHBvY2tldCBhY3Rpdml0eVwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IGF1dGhIZWFkZXJzLCBnZXRBeGlvc0Vycm9yTWVzc2FnZSwgd2l0aEVycm9yQ2F1c2UgfSBmcm9tIFwiLi9jbGllbnQuanNcIjtcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRVc2VyT3BlcmF0aW9uKGNsaWVudCwgYWNjZXNzVG9rZW4sIG9wZXJhdGlvbklkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LmdldChgL3YxL3VzZXJfb3BlcmF0aW9ucy8ke29wZXJhdGlvbklkfWAsIGF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIGxvYWQgb3BlcmF0aW9uIHN0YXR1c1wiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRVc2VyT3BlcmF0aW9uR3JvdXAoY2xpZW50LCBhY2Nlc3NUb2tlbiwgb3BlcmF0aW9uR3JvdXBJZCkge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5nZXQoYC92MS91c2VyX29wZXJhdGlvbnMvZ3JvdXBzLyR7b3BlcmF0aW9uR3JvdXBJZH1gLCBhdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikpO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byBsb2FkIGdyb3VwZWQgb3BlcmF0aW9uIHN0YXR1c1wiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjYW5jZWxVc2VyT3BlcmF0aW9uKGNsaWVudCwgYWNjZXNzVG9rZW4sIG9wZXJhdGlvbklkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LmRlbGV0ZShgL3YxL3VzZXJfb3BlcmF0aW9ucy8ke29wZXJhdGlvbklkfWAsIGF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIGNhbmNlbCB0aGUgcGVuZGluZyB0cmFuc2FjdGlvblwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IGF1dGhIZWFkZXJzLCBnZXRBeGlvc0Vycm9yTWVzc2FnZSwgd2l0aEVycm9yQ2F1c2UgfSBmcm9tIFwiLi9jbGllbnQuanNcIjtcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRBZGRyZXNzQm9vayhjbGllbnQsIGFjY2Vzc1Rva2VuKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LmdldChcIi92MS9hZGRyZXNzX2Jvb2tcIiwgYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pKTtcbiAgICAgICAgcmV0dXJuIHJlcy5kYXRhLmRhdGE7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gbG9hZCBhZGRyZXNzIGJvb2tcIiksIGVycm9yKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBzZXJ0QWRkcmVzc0Jvb2tFbnRyeShjbGllbnQsIGFjY2Vzc1Rva2VuLCBwYXlsb2FkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LnBvc3QoXCIvdjEvYWRkcmVzc19ib29rXCIsIHBheWxvYWQsIGF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIHNhdmUgZW50cnlcIiksIGVycm9yKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZGVsZXRlQWRkcmVzc0Jvb2tFbnRyeShjbGllbnQsIGFjY2Vzc1Rva2VuLCBwYXlsb2FkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LmRlbGV0ZShcIi92MS9hZGRyZXNzX2Jvb2tcIiwge1xuICAgICAgICAgICAgLi4uYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pLFxuICAgICAgICAgICAgZGF0YTogcGF5bG9hZCxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIGRlbGV0ZSBlbnRyeVwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbiIsImltcG9ydCB7IGFwaUNsaWVudCB9IGZyb20gXCJAL2xpYi9hcGkvY2xpZW50XCI7XG5pbXBvcnQgeyBidWlsZEFjY2Vzc0V4cGlyeSB9IGZyb20gXCJAL2xpYi9hdXRoL3Rva2VuLXV0aWxzXCI7XG5pbXBvcnQgeyByZWZyZXNoV2l0aFRva2VuIH0gZnJvbSBcIkByZXBvL2FwaS1jbGllbnQvYXV0aFwiO1xuaW1wb3J0IHsgZ2V0TWUsIHR5cGUgTWVQb2NrZXQgfSBmcm9tIFwiQHJlcG8vYXBpLWNsaWVudC91c2Vyc1wiO1xuaW1wb3J0IHtcbiAgY29uZmlybURhcHBDb25uZWN0aW9uLFxuICBkaXNjb25uZWN0RGFwcENvbm5lY3Rpb24sXG4gIGxpc3REYXBwQ29ubmVjdGlvbnMsXG4gIHByZXBhcmVEYXBwQ29ubmVjdGlvbixcbiAgcmVjb3JkRGFwcENvbm5lY3Rpb25TaWduRXZlbnQsXG4gIHJlamVjdERhcHBDb25uZWN0aW9uLFxufSBmcm9tIFwiQHJlcG8vYXBpLWNsaWVudC9kYXBwc1wiO1xuaW1wb3J0IHtcbiAgcHJlcGFyZVBvY2tldCxcbiAgc3VibWl0UG9ja2V0LFxuICBwcmVwYXJlUG9ja2V0VHhTZW5kLFxuICBzdWJtaXRQb2NrZXRUeFNlbmQsXG4gIHByZXBhcmVQb2NrZXRUeEN1c3RvbSxcbiAgc3VibWl0UG9ja2V0VHhDdXN0b20sXG4gIHByZXBhcmVQb2NrZXRQZXJzb25hbFNpZ24sXG4gIHN1Ym1pdFBvY2tldFBlcnNvbmFsU2lnbixcbiAgZ2V0UG9ja2V0QmFsYW5jZXMsXG4gIGdldFBvY2tldEFjdGl2aXRpZXMsXG59IGZyb20gXCJAcmVwby9hcGktY2xpZW50L3BvY2tldHNcIjtcbmltcG9ydCB7XG4gIGdldFVzZXJPcGVyYXRpb24sXG4gIGNhbmNlbFVzZXJPcGVyYXRpb24sXG59IGZyb20gXCJAcmVwby9hcGktY2xpZW50L3VzZXItb3BlcmF0aW9uc1wiO1xuaW1wb3J0IHtcbiAgZ2V0QWRkcmVzc0Jvb2ssXG4gIHVwc2VydEFkZHJlc3NCb29rRW50cnksXG4gIGRlbGV0ZUFkZHJlc3NCb29rRW50cnksXG59IGZyb20gXCJAcmVwby9hcGktY2xpZW50L2FkZHJlc3MtYm9va1wiO1xuaW1wb3J0IHR5cGUgeyBBcGlTZXNzaW9uIH0gZnJvbSBcIkAvc2hhcmVkL3R5cGVzXCI7XG5pbXBvcnQgdHlwZSB7IFN0b3JhZ2VNYW5hZ2VyIH0gZnJvbSBcIi4uL3N0b3JhZ2UtbWFuYWdlclwiO1xuaW1wb3J0IHR5cGUge1xuICBQb2NrZXREZXBsb3lTdWJtaXRSZXF1ZXN0LFxuICBQb2NrZXRNZXRhVHJhbnNhY3Rpb24sXG4gIFBvY2tldFBlcnNvbmFsU2lnblByZXBhcmVSZXF1ZXN0LFxuICBQb2NrZXRQZXJzb25hbFNpZ25TdWJtaXRSZXF1ZXN0LFxuICBQb2NrZXRUeFNlbmRQcmVwYXJlUmVxdWVzdCxcbiAgUG9ja2V0U3VibWl0UmVxdWVzdCxcbn0gZnJvbSBcIkByZXBvL2FwaS1jbGllbnQvcG9ja2V0c1wiO1xuaW1wb3J0IHR5cGUge1xuICBBZGRyZXNzQm9va0RlbGV0ZVJlcXVlc3QsXG4gIEFkZHJlc3NCb29rVXBzZXJ0UmVxdWVzdCxcbn0gZnJvbSBcIkByZXBvL2FwaS1jbGllbnQvYWRkcmVzcy1ib29rXCI7XG5pbXBvcnQgdHlwZSB7XG4gIERhcHBDb25uZWN0aW9uTGlzdFBhcmFtcyxcbiAgRGFwcENvbm5lY3Rpb25QcmVwYXJlUmVxdWVzdCxcbiAgRGFwcENvbm5lY3Rpb25TaWduRXZlbnRSZXF1ZXN0LFxufSBmcm9tIFwiQHJlcG8vYXBpLWNsaWVudC9kYXBwc1wiO1xuXG5jb25zdCBBQ0NFU1NfVE9LRU5fQlVGRkVSX01TID0gNjBfMDAwO1xuXG5leHBvcnQgY2xhc3MgQXBpQ29udHJvbGxlciB7XG4gIGNvbnN0cnVjdG9yKHByaXZhdGUgc3RvcmFnZTogU3RvcmFnZU1hbmFnZXIpIHt9XG5cbiAgcHJpdmF0ZSBzZWxlY3RQcmVmZXJyZWRQb2NrZXQoXG4gICAgcG9ja2V0czogTWVQb2NrZXRbXSxcbiAgICBzZWxlY3RlZFBvY2tldElkOiBzdHJpbmcgfCBudWxsLFxuICApOiBNZVBvY2tldCB8IG51bGwge1xuICAgIGlmIChwb2NrZXRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgY29uc3Qgc2VsZWN0ZWRQb2NrZXQgPVxuICAgICAgcG9ja2V0cy5maW5kKChwb2NrZXQpID0+IHBvY2tldC5wb2NrZXRJZCA9PT0gc2VsZWN0ZWRQb2NrZXRJZCkgPz8gbnVsbDtcbiAgICBpZiAoc2VsZWN0ZWRQb2NrZXQ/LmRlcGxveVN0YXRlID09PSBcIkRFUExPWUVEXCIpIHtcbiAgICAgIHJldHVybiBzZWxlY3RlZFBvY2tldDtcbiAgICB9XG5cbiAgICBjb25zdCBmaXJzdERlcGxveWVkID1cbiAgICAgIHBvY2tldHMuZmluZCgocG9ja2V0KSA9PiBwb2NrZXQuZGVwbG95U3RhdGUgPT09IFwiREVQTE9ZRURcIikgPz8gbnVsbDtcbiAgICBpZiAoZmlyc3REZXBsb3llZCkge1xuICAgICAgcmV0dXJuIGZpcnN0RGVwbG95ZWQ7XG4gICAgfVxuXG4gICAgcmV0dXJuIHNlbGVjdGVkUG9ja2V0ID8/IHBvY2tldHNbMF0gPz8gbnVsbDtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgc3luY1NlbGVjdGVkUG9ja2V0U3RhdGUoXG4gICAgcG9ja2V0czogTWVQb2NrZXRbXSxcbiAgICBzZWxlY3RlZFBvY2tldElkPzogc3RyaW5nIHwgbnVsbCxcbiAgKTogUHJvbWlzZTxNZVBvY2tldCB8IG51bGw+IHtcbiAgICBjb25zdCBjdXJyZW50U2VsZWN0ZWRQb2NrZXRJZCA9XG4gICAgICBzZWxlY3RlZFBvY2tldElkID8/IChhd2FpdCB0aGlzLnN0b3JhZ2UuZ2V0QXBpU2VsZWN0ZWRQb2NrZXRJZCgpKTtcbiAgICBjb25zdCBzZWxlY3RlZFBvY2tldCA9IHRoaXMuc2VsZWN0UHJlZmVycmVkUG9ja2V0KFxuICAgICAgcG9ja2V0cyxcbiAgICAgIGN1cnJlbnRTZWxlY3RlZFBvY2tldElkLFxuICAgICk7XG5cbiAgICBhd2FpdCB0aGlzLnN0b3JhZ2Uuc2V0QXBpU2VsZWN0ZWRQb2NrZXRJZChzZWxlY3RlZFBvY2tldD8ucG9ja2V0SWQgPz8gbnVsbCk7XG4gICAgYXdhaXQgdGhpcy5zdG9yYWdlLnNldEFwaUNoYWluSWQoc2VsZWN0ZWRQb2NrZXQ/LmNoYWluSWQgPz8gbnVsbCk7XG5cbiAgICByZXR1cm4gc2VsZWN0ZWRQb2NrZXQ7XG4gIH1cblxuICBhc3luYyBnZXRTZXNzaW9uKCk6IFByb21pc2U8QXBpU2Vzc2lvbj4ge1xuICAgIHJldHVybiB0aGlzLnN0b3JhZ2UuZ2V0QXBpU2Vzc2lvbigpO1xuICB9XG5cbiAgYXN5bmMgc2V0U2Vzc2lvbihwYXlsb2FkOiBBcGlTZXNzaW9uKTogUHJvbWlzZTxBcGlTZXNzaW9uPiB7XG4gICAgY29uc3QgYWNjZXNzVG9rZW5FeHBpcmVzQXQgPSBwYXlsb2FkLmFjY2Vzc1Rva2VuXG4gICAgICA/IChwYXlsb2FkLmFjY2Vzc1Rva2VuRXhwaXJlc0F0ID8/IGJ1aWxkQWNjZXNzRXhwaXJ5KHBheWxvYWQuYWNjZXNzVG9rZW4pKVxuICAgICAgOiBudWxsO1xuICAgIGNvbnN0IHNlc3Npb246IEFwaVNlc3Npb24gPSB7XG4gICAgICAuLi5wYXlsb2FkLFxuICAgICAgYWNjZXNzVG9rZW5FeHBpcmVzQXQsXG4gICAgfTtcbiAgICBhd2FpdCB0aGlzLnN0b3JhZ2Uuc2V0QXBpU2Vzc2lvbihzZXNzaW9uKTtcbiAgICByZXR1cm4gc2Vzc2lvbjtcbiAgfVxuXG4gIGFzeW5jIGNsZWFyU2Vzc2lvbigpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCB0aGlzLnN0b3JhZ2UuY2xlYXJBcGlTZXNzaW9uKCk7XG4gICAgYXdhaXQgdGhpcy5zdG9yYWdlLnNldEFwaVNlbGVjdGVkUG9ja2V0SWQobnVsbCk7XG4gICAgYXdhaXQgdGhpcy5zdG9yYWdlLnNldEFwaUNoYWluSWQobnVsbCk7XG4gIH1cblxuICBhc3luYyBnZXRDaGFpbklkKCk6IFByb21pc2U8bnVtYmVyIHwgbnVsbD4ge1xuICAgIGNvbnN0IHBvY2tldHMgPSBhd2FpdCB0aGlzLnN0b3JhZ2UuZ2V0QXBpUG9ja2V0cygpO1xuICAgIGNvbnN0IHNlbGVjdGVkUG9ja2V0SWQgPSBhd2FpdCB0aGlzLnN0b3JhZ2UuZ2V0QXBpU2VsZWN0ZWRQb2NrZXRJZCgpO1xuICAgIGNvbnN0IHNlbGVjdGVkUG9ja2V0ID0gdGhpcy5zZWxlY3RQcmVmZXJyZWRQb2NrZXQoXG4gICAgICBwb2NrZXRzLFxuICAgICAgc2VsZWN0ZWRQb2NrZXRJZCxcbiAgICApO1xuICAgIGNvbnN0IGNoYWluSWQgPSBzZWxlY3RlZFBvY2tldD8uY2hhaW5JZCA/PyBudWxsO1xuXG4gICAgaWYgKGNoYWluSWQgIT09IChhd2FpdCB0aGlzLnN0b3JhZ2UuZ2V0QXBpQ2hhaW5JZCgpKSkge1xuICAgICAgYXdhaXQgdGhpcy5zdG9yYWdlLnNldEFwaUNoYWluSWQoY2hhaW5JZCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGNoYWluSWQ7XG4gIH1cblxuICBhc3luYyBzZXRTZWxlY3RlZFBvY2tldElkKHBvY2tldElkOiBzdHJpbmcgfCBudWxsKTogUHJvbWlzZTxNZVBvY2tldCB8IG51bGw+IHtcbiAgICBjb25zdCBwb2NrZXRzID0gYXdhaXQgdGhpcy5zdG9yYWdlLmdldEFwaVBvY2tldHMoKTtcbiAgICByZXR1cm4gdGhpcy5zeW5jU2VsZWN0ZWRQb2NrZXRTdGF0ZShwb2NrZXRzLCBwb2NrZXRJZCk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGdldFZhbGlkQWNjZXNzVG9rZW4oKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBzZXNzaW9uID0gYXdhaXQgdGhpcy5zdG9yYWdlLmdldEFwaVNlc3Npb24oKTtcbiAgICBpZiAoIXNlc3Npb24ucmVmcmVzaFRva2VuKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJTRVNTSU9OX0VYUElSRURcIik7XG4gICAgfVxuXG4gICAgY29uc3QgaGFzVmFsaWRUb2tlbiA9XG4gICAgICBzZXNzaW9uLmFjY2Vzc1Rva2VuICYmXG4gICAgICBzZXNzaW9uLmFjY2Vzc1Rva2VuRXhwaXJlc0F0ICYmXG4gICAgICBzZXNzaW9uLmFjY2Vzc1Rva2VuRXhwaXJlc0F0ID4gRGF0ZS5ub3coKSArIEFDQ0VTU19UT0tFTl9CVUZGRVJfTVM7XG5cbiAgICBpZiAoaGFzVmFsaWRUb2tlbikge1xuICAgICAgcmV0dXJuIHNlc3Npb24uYWNjZXNzVG9rZW4gYXMgc3RyaW5nO1xuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZWZyZXNoZWQgPSBhd2FpdCByZWZyZXNoV2l0aFRva2VuKGFwaUNsaWVudCwgc2Vzc2lvbi5yZWZyZXNoVG9rZW4pO1xuICAgICAgY29uc3QgYWNjZXNzVG9rZW5FeHBpcmVzQXQgPSBidWlsZEFjY2Vzc0V4cGlyeShyZWZyZXNoZWQuYWNjZXNzVG9rZW4pO1xuICAgICAgY29uc3QgbmV4dFNlc3Npb246IEFwaVNlc3Npb24gPSB7XG4gICAgICAgIC4uLnNlc3Npb24sXG4gICAgICAgIGFjY2Vzc1Rva2VuOiByZWZyZXNoZWQuYWNjZXNzVG9rZW4sXG4gICAgICAgIHJlZnJlc2hUb2tlbjogcmVmcmVzaGVkLnJlZnJlc2hUb2tlbixcbiAgICAgICAgYWNjZXNzVG9rZW5FeHBpcmVzQXQsXG4gICAgICB9O1xuICAgICAgYXdhaXQgdGhpcy5zdG9yYWdlLnNldEFwaVNlc3Npb24obmV4dFNlc3Npb24pO1xuICAgICAgcmV0dXJuIHJlZnJlc2hlZC5hY2Nlc3NUb2tlbjtcbiAgICB9IGNhdGNoIHtcbiAgICAgIGF3YWl0IHRoaXMuc3RvcmFnZS5jbGVhckFwaVNlc3Npb24oKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlNFU1NJT05fRVhQSVJFRFwiKTtcbiAgICB9XG4gIH1cblxuICBhc3luYyBnZXRNZSgpIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIGNvbnN0IG1lID0gYXdhaXQgZ2V0TWUoYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbik7XG4gICAgYXdhaXQgdGhpcy5zdG9yYWdlLnNldEFwaVBvY2tldHMobWUucG9ja2V0cyk7XG4gICAgYXdhaXQgdGhpcy5zdG9yYWdlLnNldEFwaVBlbmRpbmdVc2VyT3BlcmF0aW9ucyhtZS5wZW5kaW5nVXNlck9wZXJhdGlvbnMpO1xuICAgIGF3YWl0IHRoaXMuc3RvcmFnZS5zZXRBcGlEYXBwQ29ubmVjdGlvbnMobWUuZGFwcENvbm5lY3Rpb25zKTtcbiAgICBhd2FpdCB0aGlzLnN5bmNTZWxlY3RlZFBvY2tldFN0YXRlKG1lLnBvY2tldHMpO1xuXG4gICAgcmV0dXJuIG1lO1xuICB9XG5cbiAgYXN5bmMgcHJlcGFyZVBvY2tldCgpIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBwcmVwYXJlUG9ja2V0KGFwaUNsaWVudCwgYWNjZXNzVG9rZW4pO1xuICB9XG5cbiAgYXN5bmMgc3VibWl0UG9ja2V0KHJlcXVlc3Q6IFBvY2tldERlcGxveVN1Ym1pdFJlcXVlc3QpIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBzdWJtaXRQb2NrZXQoYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbiwgcmVxdWVzdCk7XG4gIH1cblxuICBhc3luYyBwcmVwYXJlUG9ja2V0U2VuZChcbiAgICBwb2NrZXRJZDogc3RyaW5nLFxuICAgIHJlcXVlc3Q6IFBvY2tldFR4U2VuZFByZXBhcmVSZXF1ZXN0LFxuICApIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBwcmVwYXJlUG9ja2V0VHhTZW5kKGFwaUNsaWVudCwgYWNjZXNzVG9rZW4sIHBvY2tldElkLCByZXF1ZXN0KTtcbiAgfVxuXG4gIGFzeW5jIHN1Ym1pdFBvY2tldFNlbmQocG9ja2V0SWQ6IHN0cmluZywgcmVxdWVzdDogUG9ja2V0U3VibWl0UmVxdWVzdCkge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIHN1Ym1pdFBvY2tldFR4U2VuZChhcGlDbGllbnQsIGFjY2Vzc1Rva2VuLCBwb2NrZXRJZCwgcmVxdWVzdCk7XG4gIH1cblxuICBhc3luYyBwcmVwYXJlUG9ja2V0Q3VzdG9tKFxuICAgIHBvY2tldElkOiBzdHJpbmcsXG4gICAgcmVxdWVzdDogeyBtZXRhVHJhbnNhY3Rpb25zOiBQb2NrZXRNZXRhVHJhbnNhY3Rpb25bXSB9LFxuICApIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBwcmVwYXJlUG9ja2V0VHhDdXN0b20oYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQsIHJlcXVlc3QpO1xuICB9XG5cbiAgYXN5bmMgc3VibWl0UG9ja2V0Q3VzdG9tKHBvY2tldElkOiBzdHJpbmcsIHJlcXVlc3Q6IFBvY2tldFN1Ym1pdFJlcXVlc3QpIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBzdWJtaXRQb2NrZXRUeEN1c3RvbShhcGlDbGllbnQsIGFjY2Vzc1Rva2VuLCBwb2NrZXRJZCwgcmVxdWVzdCk7XG4gIH1cblxuICBhc3luYyBwcmVwYXJlUG9ja2V0UGVyc29uYWxTaWduKFxuICAgIHBvY2tldElkOiBzdHJpbmcsXG4gICAgcmVxdWVzdDogUG9ja2V0UGVyc29uYWxTaWduUHJlcGFyZVJlcXVlc3QsXG4gICkge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIHByZXBhcmVQb2NrZXRQZXJzb25hbFNpZ24oYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQsIHJlcXVlc3QpO1xuICB9XG5cbiAgYXN5bmMgc3VibWl0UG9ja2V0UGVyc29uYWxTaWduKFxuICAgIHBvY2tldElkOiBzdHJpbmcsXG4gICAgcmVxdWVzdDogUG9ja2V0UGVyc29uYWxTaWduU3VibWl0UmVxdWVzdCxcbiAgKSB7XG4gICAgY29uc3QgYWNjZXNzVG9rZW4gPSBhd2FpdCB0aGlzLmdldFZhbGlkQWNjZXNzVG9rZW4oKTtcbiAgICByZXR1cm4gc3VibWl0UG9ja2V0UGVyc29uYWxTaWduKGFwaUNsaWVudCwgYWNjZXNzVG9rZW4sIHBvY2tldElkLCByZXF1ZXN0KTtcbiAgfVxuXG4gIGFzeW5jIGdldFBvY2tldEJhbGFuY2VzKHBvY2tldElkOiBzdHJpbmcpIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBnZXRQb2NrZXRCYWxhbmNlcyhhcGlDbGllbnQsIGFjY2Vzc1Rva2VuLCBwb2NrZXRJZCk7XG4gIH1cblxuICBhc3luYyBnZXRQb2NrZXRBY3Rpdml0aWVzKFxuICAgIHBvY2tldElkOiBzdHJpbmcsXG4gICAgcGFyYW1zPzogeyBjdXJzb3I/OiBzdHJpbmc7IGxpbWl0PzogbnVtYmVyIH0sXG4gICkge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIGdldFBvY2tldEFjdGl2aXRpZXMoYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQsIHBhcmFtcyk7XG4gIH1cblxuICBhc3luYyBnZXRVc2VyT3BlcmF0aW9uKG9wZXJhdGlvbklkOiBzdHJpbmcpIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBnZXRVc2VyT3BlcmF0aW9uKGFwaUNsaWVudCwgYWNjZXNzVG9rZW4sIG9wZXJhdGlvbklkKTtcbiAgfVxuXG4gIGFzeW5jIGNhbmNlbFVzZXJPcGVyYXRpb24ob3BlcmF0aW9uSWQ6IHN0cmluZykge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIGNhbmNlbFVzZXJPcGVyYXRpb24oYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbiwgb3BlcmF0aW9uSWQpO1xuICB9XG5cbiAgYXN5bmMgbGlzdEFkZHJlc3NCb29rKCkge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIGdldEFkZHJlc3NCb29rKGFwaUNsaWVudCwgYWNjZXNzVG9rZW4pO1xuICB9XG5cbiAgYXN5bmMgdXBzZXJ0QWRkcmVzc0Jvb2socGF5bG9hZDogQWRkcmVzc0Jvb2tVcHNlcnRSZXF1ZXN0KSB7XG4gICAgY29uc3QgYWNjZXNzVG9rZW4gPSBhd2FpdCB0aGlzLmdldFZhbGlkQWNjZXNzVG9rZW4oKTtcbiAgICByZXR1cm4gdXBzZXJ0QWRkcmVzc0Jvb2tFbnRyeShhcGlDbGllbnQsIGFjY2Vzc1Rva2VuLCBwYXlsb2FkKTtcbiAgfVxuXG4gIGFzeW5jIGRlbGV0ZUFkZHJlc3NCb29rKHBheWxvYWQ6IEFkZHJlc3NCb29rRGVsZXRlUmVxdWVzdCkge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIGRlbGV0ZUFkZHJlc3NCb29rRW50cnkoYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbiwgcGF5bG9hZCk7XG4gIH1cblxuICBhc3luYyBwcmVwYXJlRGFwcENvbm5lY3Rpb24ocGF5bG9hZDogRGFwcENvbm5lY3Rpb25QcmVwYXJlUmVxdWVzdCkge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIHByZXBhcmVEYXBwQ29ubmVjdGlvbihhcGlDbGllbnQsIGFjY2Vzc1Rva2VuLCBwYXlsb2FkKTtcbiAgfVxuXG4gIGFzeW5jIGNvbmZpcm1EYXBwQ29ubmVjdGlvbihjb25uZWN0aW9uSWQ6IHN0cmluZykge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIGNvbmZpcm1EYXBwQ29ubmVjdGlvbihhcGlDbGllbnQsIGFjY2Vzc1Rva2VuLCBjb25uZWN0aW9uSWQpO1xuICB9XG5cbiAgYXN5bmMgcmVqZWN0RGFwcENvbm5lY3Rpb24oY29ubmVjdGlvbklkOiBzdHJpbmcpIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiByZWplY3REYXBwQ29ubmVjdGlvbihhcGlDbGllbnQsIGFjY2Vzc1Rva2VuLCBjb25uZWN0aW9uSWQpO1xuICB9XG5cbiAgYXN5bmMgZGlzY29ubmVjdERhcHBDb25uZWN0aW9uKGNvbm5lY3Rpb25JZDogc3RyaW5nKSB7XG4gICAgY29uc3QgYWNjZXNzVG9rZW4gPSBhd2FpdCB0aGlzLmdldFZhbGlkQWNjZXNzVG9rZW4oKTtcbiAgICByZXR1cm4gZGlzY29ubmVjdERhcHBDb25uZWN0aW9uKGFwaUNsaWVudCwgYWNjZXNzVG9rZW4sIGNvbm5lY3Rpb25JZCk7XG4gIH1cblxuICBhc3luYyBsaXN0RGFwcENvbm5lY3Rpb25zKHBhcmFtcz86IERhcHBDb25uZWN0aW9uTGlzdFBhcmFtcykge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIGxpc3REYXBwQ29ubmVjdGlvbnMoYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbiwgcGFyYW1zKTtcbiAgfVxuXG4gIGFzeW5jIHJlY29yZERhcHBDb25uZWN0aW9uU2lnbkV2ZW50KFxuICAgIGNvbm5lY3Rpb25JZDogc3RyaW5nLFxuICAgIHBheWxvYWQ6IERhcHBDb25uZWN0aW9uU2lnbkV2ZW50UmVxdWVzdCxcbiAgKSB7XG4gICAgY29uc3QgYWNjZXNzVG9rZW4gPSBhd2FpdCB0aGlzLmdldFZhbGlkQWNjZXNzVG9rZW4oKTtcbiAgICByZXR1cm4gcmVjb3JkRGFwcENvbm5lY3Rpb25TaWduRXZlbnQoXG4gICAgICBhcGlDbGllbnQsXG4gICAgICBhY2Nlc3NUb2tlbixcbiAgICAgIGNvbm5lY3Rpb25JZCxcbiAgICAgIHBheWxvYWQsXG4gICAgKTtcbiAgfVxufVxuIiwiLy8gQmFja2dyb3VuZCBTZXJ2aWNlIFdvcmtlciAtIE1haW4gZW50cnkgcG9pbnQgKEFQSS1maXJzdClcblxuaW1wb3J0IHsgU3RvcmFnZU1hbmFnZXIgfSBmcm9tIFwiLi9zdG9yYWdlLW1hbmFnZXJcIjtcbmltcG9ydCB7IE1lc3NhZ2VIYW5kbGVyIH0gZnJvbSBcIi4vbWVzc2FnZS1oYW5kbGVyXCI7XG5pbXBvcnQgeyBBcGlDb250cm9sbGVyIH0gZnJvbSBcIi4vY29udHJvbGxlcnMvYXBpLWNvbnRyb2xsZXJcIjtcbmltcG9ydCB0eXBlIHsgTWVzc2FnZSB9IGZyb20gXCJAL3NoYXJlZC90eXBlc1wiO1xuaW1wb3J0IHsgaW5pdGlhbGl6ZUFwaUNsaWVudCB9IGZyb20gXCJAL2xpYi9hcGkvY2xpZW50XCI7XG5cbmNvbnNvbGUubG9nKFwiW0JhY2tncm91bmRdIEdyYW5kcGEgRGVGaSBFeHRlbnNpb24gbG9hZGVkXCIpO1xuY29uc29sZS5sb2coXG4gIFwiW0JhY2tncm91bmRdIFNlcnZpY2UgV29ya2VyIElEOlwiLFxuICBzZWxmLnJlZ2lzdHJhdGlvbj8uYWN0aXZlPy5zY3JpcHRVUkwsXG4pO1xuXG4vLyBLZWVwIHNlcnZpY2Ugd29ya2VyIGFsaXZlXG5sZXQga2VlcEFsaXZlSW50ZXJ2YWw6IG51bWJlciB8IHVuZGVmaW5lZDtcblxuZnVuY3Rpb24ga2VlcFNlcnZpY2VXb3JrZXJBbGl2ZSgpIHtcbiAgaWYgKGtlZXBBbGl2ZUludGVydmFsKSB7XG4gICAgY2xlYXJJbnRlcnZhbChrZWVwQWxpdmVJbnRlcnZhbCk7XG4gIH1cbiAga2VlcEFsaXZlSW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgY29uc29sZS5sb2coXCJbQmFja2dyb3VuZF0gS2VlcC1hbGl2ZSBwaW5nXCIpO1xuICB9LCAyMDAwMCkgYXMgdW5rbm93biBhcyBudW1iZXI7XG59XG5cbmtlZXBTZXJ2aWNlV29ya2VyQWxpdmUoKTtcblxuc2VsZi5hZGRFdmVudExpc3RlbmVyKFwiZXJyb3JcIiwgKGV2ZW50KSA9PiB7XG4gIGNvbnNvbGUuZXJyb3IoXCJbQmFja2dyb3VuZF0gVW5jYXVnaHQgZXJyb3I6XCIsIGV2ZW50LmVycm9yKTtcbiAgY29uc29sZS5lcnJvcihcIltCYWNrZ3JvdW5kXSBFcnJvciBtZXNzYWdlOlwiLCBldmVudC5tZXNzYWdlKTtcbiAgY29uc29sZS5lcnJvcihcIltCYWNrZ3JvdW5kXSBFcnJvciBzdGFjazpcIiwgZXZlbnQuZXJyb3I/LnN0YWNrKTtcbiAgY29uc29sZS5lcnJvcihcbiAgICBcIltCYWNrZ3JvdW5kXSBFcnJvciBhdDpcIixcbiAgICBldmVudC5maWxlbmFtZSxcbiAgICBldmVudC5saW5lbm8sXG4gICAgZXZlbnQuY29sbm8sXG4gICk7XG59KTtcblxuc2VsZi5hZGRFdmVudExpc3RlbmVyKFwidW5oYW5kbGVkcmVqZWN0aW9uXCIsIChldmVudCkgPT4ge1xuICBjb25zb2xlLmVycm9yKFwiW0JhY2tncm91bmRdIFVuaGFuZGxlZCBwcm9taXNlIHJlamVjdGlvbjpcIiwgZXZlbnQucmVhc29uKTtcbiAgY29uc29sZS5lcnJvcihcIltCYWNrZ3JvdW5kXSBSZWplY3Rpb24gc3RhY2s6XCIsIGV2ZW50LnJlYXNvbj8uc3RhY2spO1xuICBjb25zb2xlLmVycm9yKFwiW0JhY2tncm91bmRdIFByb21pc2U6XCIsIGV2ZW50LnByb21pc2UpO1xufSk7XG5cbi8vIEluaXRpYWxpemUgbWFuYWdlcnNcbmNvbnN0IHN0b3JhZ2UgPSBuZXcgU3RvcmFnZU1hbmFnZXIoKTtcbmNvbnN0IGFwaUNvbnRyb2xsZXIgPSBuZXcgQXBpQ29udHJvbGxlcihzdG9yYWdlKTtcbmNvbnN0IG1lc3NhZ2VIYW5kbGVyID0gbmV3IE1lc3NhZ2VIYW5kbGVyKHN0b3JhZ2UsIGFwaUNvbnRyb2xsZXIpO1xuXG5hc3luYyBmdW5jdGlvbiBpbml0aWFsaXplRXh0ZW5zaW9uKCkge1xuICBjb25zb2xlLmxvZyhcIltCYWNrZ3JvdW5kXSBJbml0aWFsaXppbmcgZXh0ZW5zaW9uLi4uXCIpO1xuICBhd2FpdCBQcm9taXNlLmFsbChbc3RvcmFnZS5pbml0aWFsaXplKCksIGluaXRpYWxpemVBcGlDbGllbnQoKV0pO1xuICBjb25zb2xlLmxvZyhcIltCYWNrZ3JvdW5kXSBFeHRlbnNpb24gaW5pdGlhbGl6ZWRcIik7XG59XG5cbmNocm9tZS5ydW50aW1lLm9uSW5zdGFsbGVkLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcbiAgY29uc29sZS5sb2coXCJbQmFja2dyb3VuZF0gRXh0ZW5zaW9uIGluc3RhbGxlZFwiKTtcbiAgYXdhaXQgaW5pdGlhbGl6ZUV4dGVuc2lvbigpO1xufSk7XG5cbnR5cGUgQmFja2dyb3VuZFJlc3BvbnNlID1cbiAgfCB7IHN1Y2Nlc3M6IHRydWU7IGRhdGE6IHVua25vd24gfVxuICB8IHsgc3VjY2VzczogZmFsc2U7IGVycm9yOiBzdHJpbmcgfTtcblxuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKFxuICAoXG4gICAgbWVzc2FnZTogTWVzc2FnZSxcbiAgICBzZW5kZXI6IGNocm9tZS5ydW50aW1lLk1lc3NhZ2VTZW5kZXIsXG4gICAgc2VuZFJlc3BvbnNlOiAocmVzcG9uc2U6IEJhY2tncm91bmRSZXNwb25zZSkgPT4gdm9pZCxcbiAgKSA9PiB7XG4gICAgY29uc29sZS5sb2coXCJbQmFja2dyb3VuZF0gUmVjZWl2ZWQgbWVzc2FnZTpcIiwgbWVzc2FnZS50eXBlKTtcbiAgICBjb25zb2xlLmxvZyhcbiAgICAgIFwiW0JhY2tncm91bmRdIE1lc3NhZ2UgcGF5bG9hZDpcIixcbiAgICAgIFwicGF5bG9hZFwiIGluIG1lc3NhZ2UgPyBtZXNzYWdlLnBheWxvYWQgOiBcIm5vIHBheWxvYWRcIixcbiAgICApO1xuICAgIGNvbnNvbGUubG9nKFwiW0JhY2tncm91bmRdIFNlbmRlcjpcIiwgc2VuZGVyLnRhYj8uaWQgfHwgXCJwb3B1cFwiLCBzZW5kZXIudXJsKTtcblxuICAgIHRyeSB7XG4gICAgICBtZXNzYWdlSGFuZGxlclxuICAgICAgICAuaGFuZGxlTWVzc2FnZShtZXNzYWdlLCBzZW5kZXIpXG4gICAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgXCJbQmFja2dyb3VuZF0gTWVzc2FnZSBoYW5kbGVkIHN1Y2Nlc3NmdWxseTpcIixcbiAgICAgICAgICAgIG1lc3NhZ2UudHlwZSxcbiAgICAgICAgICApO1xuICAgICAgICAgIHNlbmRSZXNwb25zZSh7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IHJlc3BvbnNlIH0pO1xuICAgICAgICB9KVxuICAgICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIltCYWNrZ3JvdW5kXSBNZXNzYWdlIGhhbmRsZXIgZXJyb3I6XCIsIGVycm9yKTtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiW0JhY2tncm91bmRdIEVycm9yIHR5cGU6XCIsIGVycm9yLmNvbnN0cnVjdG9yLm5hbWUpO1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJbQmFja2dyb3VuZF0gRXJyb3IgbWVzc2FnZTpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIltCYWNrZ3JvdW5kXSBFcnJvciBzdGFjazpcIiwgZXJyb3Iuc3RhY2spO1xuXG4gICAgICAgICAgc2VuZFJlc3BvbnNlKHtcbiAgICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgICAgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfHwgXCJVbmtub3duIGVycm9yXCIsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBcIltCYWNrZ3JvdW5kXSBTeW5jaHJvbm91cyBlcnJvciBpbiBtZXNzYWdlIGhhbmRsZXI6XCIsXG4gICAgICAgIGVycm9yLFxuICAgICAgKTtcbiAgICAgIHNlbmRSZXNwb25zZSh7XG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICBlcnJvcjogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIixcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHJldHVybiB0cnVlO1xuICB9LFxuKTtcblxuY2hyb21lLnJ1bnRpbWUub25TdGFydHVwLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcbiAgY29uc29sZS5sb2coXCJbQmFja2dyb3VuZF0gRXh0ZW5zaW9uIHN0YXJ0ZWQgb24gYnJvd3NlciBzdGFydHVwXCIpO1xuICBhd2FpdCBpbml0aWFsaXplRXh0ZW5zaW9uKCk7XG59KTtcblxuLy8gRXhwb3J0IGZvciB0ZXN0aW5nXG5leHBvcnQgeyBzdG9yYWdlLCBtZXNzYWdlSGFuZGxlciB9O1xuIl0sIm5hbWVzIjpbInN0b3JhZ2UiLCJyZWNvcmQiXSwibWFwcGluZ3MiOiI7QUFhQSxNQUFNLHNCQUFrQztBQUFBLEVBQ3RDLGFBQWE7QUFBQSxFQUNiLGNBQWM7QUFBQSxFQUNkLHNCQUFzQjtBQUFBLEVBQ3RCLGNBQWM7QUFBQSxFQUNkLE1BQU07QUFDUjtBQUVBLFNBQVMsZUFDUCxRQUNBLEtBQ0EsVUFDRztBQUNILFFBQU0sUUFBUSxPQUFPLEdBQUc7QUFDeEIsU0FBUSxTQUFlO0FBQ3pCO0FBRUEsU0FBUyxnQkFBZ0IsT0FBdUI7QUFDOUMsTUFBSTtBQUNGLFVBQU0sTUFBTSxJQUFJLElBQUksS0FBSztBQUN6QixVQUFNLFdBQVcsSUFBSSxTQUFTLFlBQUE7QUFDOUIsVUFBTSxXQUFXLElBQUksU0FBUyxZQUFBO0FBQzlCLFVBQU0sT0FBTyxJQUFJO0FBQ2pCLFVBQU0sY0FDSixLQUFLLFNBQVMsS0FDZCxFQUNHLGFBQWEsWUFBWSxTQUFTLFNBQ2xDLGFBQWEsV0FBVyxTQUFTO0FBRXRDLFVBQU0sT0FBTyxjQUFjLEdBQUcsUUFBUSxJQUFJLElBQUksS0FBSztBQUNuRCxXQUFPLEdBQUcsUUFBUSxLQUFLLElBQUk7QUFBQSxFQUM3QixRQUFRO0FBQ04sV0FBTyxNQUFNLEtBQUEsRUFBTyxZQUFBO0FBQUEsRUFDdEI7QUFDRjtBQUVPLE1BQU0sZUFBZTtBQUFBLEVBQ2xCLHNCQUFzQixPQUtuQjtBQUNULFdBQU87QUFBQSxNQUNMLE1BQU07QUFBQSxNQUNOLE1BQU0sY0FBYyxZQUFBO0FBQUEsTUFDcEIsT0FBTyxNQUFNLE9BQU87QUFBQSxNQUNwQixNQUFNO0FBQUEsSUFBQSxFQUNOLEtBQUssR0FBRztBQUFBLEVBQ1o7QUFBQSxFQUVRLHNCQUFzQixPQUE4QztBQUMxRSxRQUFJLENBQUMsU0FBUyxPQUFPLFVBQVUsU0FBVSxRQUFPO0FBQ2hELFVBQU0sU0FBUztBQUNmLFdBQ0UsT0FBTyxPQUFPLGlCQUFpQixZQUMvQixPQUFPLE9BQU8sV0FBVyxZQUN6QixPQUFPLE9BQU8scUJBQXFCLFlBQ25DLE9BQU8sT0FBTyxTQUFTLGFBQ3RCLE9BQU8sZ0JBQWdCLFlBQVksT0FBTyxnQkFBZ0IsWUFDM0QsT0FBTyxPQUFPLGtCQUFrQixZQUNoQyxPQUFPLE9BQU8sWUFBWTtBQUFBLEVBRTlCO0FBQUEsRUFFQSxNQUFNLGFBQTRCO0FBQ2hDLFVBQU0sV0FBVyxNQUFNLEtBQUssT0FBQTtBQUU1QixRQUFJLENBQUMsU0FBUyxVQUFVO0FBQ3RCLFlBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSTtBQUFBLFFBQzdCLENBQUMsYUFBYSxRQUFRLEdBQUc7QUFBQSxRQUN6QixDQUFDLGFBQWEsZUFBZSxHQUFHLENBQUE7QUFBQSxRQUNoQyxDQUFDLGFBQWEsV0FBVyxHQUFHO0FBQUEsUUFDNUIsQ0FBQyxhQUFhLFdBQVcsR0FBRyxDQUFBO0FBQUEsUUFDNUIsQ0FBQyxhQUFhLHNCQUFzQixHQUFHO0FBQUEsUUFDdkMsQ0FBQyxhQUFhLDJCQUEyQixHQUFHLENBQUE7QUFBQSxRQUM1QyxDQUFDLGFBQWEsb0JBQW9CLEdBQUcsQ0FBQTtBQUFBLFFBQ3JDLENBQUMsYUFBYSxZQUFZLEdBQUc7QUFBQSxRQUM3QixDQUFDLGFBQWEsU0FBUyxHQUFHO0FBQUEsTUFBQSxDQUMzQjtBQUNELGNBQVEsSUFBSSxxQ0FBcUM7QUFBQSxJQUNuRDtBQUFBLEVBQ0Y7QUFBQSxFQUVBLE1BQU0sU0FBMEM7QUFDOUMsV0FBTyxPQUFPLFFBQVEsTUFBTSxJQUFJLElBQUk7QUFBQSxFQUN0QztBQUFBLEVBRUEsTUFBTSxXQUEwQjtBQUM5QixVQUFNLE9BQU8sUUFBUSxNQUFNLE1BQUE7QUFBQSxFQUM3QjtBQUFBLEVBRUEsTUFBTSxjQUFpQztBQUNyQyxVQUFNLFNBQVUsTUFBTSxPQUFPLFFBQVEsTUFBTTtBQUFBLE1BQ3pDLGFBQWE7QUFBQSxJQUFBO0FBRWYsV0FBTyxlQUFlLFFBQVEsYUFBYSxVQUFVLGdCQUFnQjtBQUFBLEVBQ3ZFO0FBQUEsRUFFQSxNQUFNLFlBQVksVUFBbUM7QUFDbkQsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxhQUFhLFFBQVEsR0FBRyxVQUFVO0FBQUEsRUFDdEU7QUFBQSxFQUVBLE1BQU0sZUFBZSxTQUEyQztBQUM5RCxVQUFNLFdBQVcsTUFBTSxLQUFLLFlBQUE7QUFDNUIsVUFBTSxLQUFLLFlBQVksRUFBRSxHQUFHLFVBQVUsR0FBRyxTQUFTO0FBQUEsRUFDcEQ7QUFBQTtBQUFBLEVBR0EsTUFBTSxvQkFBa0U7QUFDdEUsVUFBTSxTQUFVLE1BQU0sT0FBTyxRQUFRLE1BQU07QUFBQSxNQUN6QyxhQUFhO0FBQUEsSUFBQTtBQUVmLFVBQU0sTUFBTSxlQUFlLFFBQVEsYUFBYSxpQkFBaUIsQ0FBQSxDQUFFO0FBQ25FLFVBQU0sVUFBVSxPQUFPLFFBQVEsR0FBOEI7QUFDN0QsVUFBTSxPQUE0QyxDQUFBO0FBQ2xELGVBQVcsQ0FBQyxLQUFLLEtBQUssS0FBSyxTQUFTO0FBQ2xDLFVBQUksQ0FBQyxLQUFLLHNCQUFzQixLQUFLLEVBQUc7QUFDeEMsV0FBSyxHQUFHLElBQUk7QUFBQSxJQUNkO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVBLE1BQU0saUJBQWlCLE1BQTBDO0FBQy9ELFVBQU0sUUFBUSxNQUFNLEtBQUssa0JBQUE7QUFDekIsVUFBTSxtQkFBbUI7QUFBQSxNQUN2QixLQUFLLG9CQUFvQixLQUFLO0FBQUEsSUFBQTtBQUVoQyxVQUFNLE1BQU0sS0FBSyxJQUFBO0FBQ2pCLFVBQU0sTUFBTSxLQUFLLHNCQUFzQjtBQUFBLE1BQ3JDO0FBQUEsTUFDQSxhQUFhLEtBQUs7QUFBQSxNQUNsQixlQUFlLEtBQUs7QUFBQSxNQUNwQixTQUFTLEtBQUs7QUFBQSxJQUFBLENBQ2Y7QUFDRCxVQUFNLEdBQUcsSUFBSTtBQUFBLE1BQ1gsR0FBRztBQUFBLE1BQ0gsUUFBUSxnQkFBZ0IsS0FBSyxNQUFNO0FBQUEsTUFDbkM7QUFBQSxNQUNBLGFBQWEsS0FBSyxlQUFlO0FBQUEsTUFDakMsWUFBWSxLQUFLLGNBQWM7QUFBQSxJQUFBO0FBRWpDLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsYUFBYSxlQUFlLEdBQUcsT0FBTztBQUFBLEVBQzFFO0FBQUEsRUFFQSxNQUFNLG9CQUFvQixjQUFxQztBQUM3RCxVQUFNLFFBQVEsTUFBTSxLQUFLLGtCQUFBO0FBQ3pCLGVBQVcsQ0FBQyxLQUFLLEtBQUssS0FBSyxPQUFPLFFBQVEsS0FBSyxHQUFHO0FBQ2hELFVBQUksTUFBTSxpQkFBaUIsYUFBYztBQUN6QyxhQUFPLE1BQU0sR0FBRztBQUFBLElBQ2xCO0FBQ0EsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxhQUFhLGVBQWUsR0FBRyxPQUFPO0FBQUEsRUFDMUU7QUFBQSxFQUVBLE1BQU0sOEJBQ0osUUFDQSxlQUNlO0FBQ2YsVUFBTSxRQUFRLE1BQU0sS0FBSyxrQkFBQTtBQUN6QixVQUFNLG1CQUFtQixnQkFBZ0IsTUFBTTtBQUMvQyxVQUFNLDBCQUEwQixlQUFlLFlBQUEsS0FBaUI7QUFDaEUsZUFBVyxDQUFDLEtBQUssS0FBSyxLQUFLLE9BQU8sUUFBUSxLQUFLLEdBQUc7QUFDaEQsVUFBSSxNQUFNLHFCQUFxQixpQkFBa0I7QUFDakQsVUFDRSwyQkFDQSxNQUFNLGNBQWMsWUFBQSxNQUFrQix5QkFDdEM7QUFDQTtBQUFBLE1BQ0Y7QUFDQSxhQUFPLE1BQU0sR0FBRztBQUFBLElBQ2xCO0FBQ0EsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxhQUFhLGVBQWUsR0FBRyxPQUFPO0FBQUEsRUFDMUU7QUFBQSxFQUVBLE1BQU0sa0JBQWtCLFFBS2dCO0FBQ3RDLFVBQU0sUUFBUSxNQUFNLEtBQUssa0JBQUE7QUFDekIsVUFBTSxtQkFBbUIsZ0JBQWdCLE9BQU8sTUFBTTtBQUN0RCxVQUFNLDBCQUEwQixPQUFPLGNBQWMsWUFBQTtBQUNyRCxVQUFNLFFBQVEsT0FBTyxPQUFPLEtBQUssRUFBRTtBQUFBLE1BQ2pDLENBQUMsU0FDQyxLQUFLLHFCQUFxQixvQkFDMUIsS0FBSyxnQkFBZ0IsT0FBTyxlQUM1QixLQUFLLFlBQVksT0FBTyxXQUN4QixLQUFLLGNBQWMsa0JBQWtCO0FBQUEsSUFBQTtBQUV6QyxXQUFPLFNBQVM7QUFBQSxFQUNsQjtBQUFBLEVBRUEsTUFBTSxnQkFBZ0IsUUFLRDtBQUNuQixXQUFRLE1BQU0sS0FBSyxrQkFBa0IsTUFBTSxNQUFPO0FBQUEsRUFDcEQ7QUFBQSxFQUVBLE1BQU0sbUJBQW1CLGNBQXFDO0FBQzVELFVBQU0sUUFBUSxNQUFNLEtBQUssa0JBQUE7QUFDekIsUUFBSSxZQUFZO0FBQ2hCLGVBQVcsQ0FBQyxLQUFLLElBQUksS0FBSyxPQUFPLFFBQVEsS0FBSyxHQUFHO0FBQy9DLFVBQUksS0FBSyxpQkFBaUIsYUFBYztBQUN4QyxZQUFNLEdBQUcsSUFBSTtBQUFBLFFBQ1gsR0FBRztBQUFBLFFBQ0gsWUFBWSxLQUFLLElBQUE7QUFBQSxNQUFJO0FBRXZCLGtCQUFZO0FBQUEsSUFDZDtBQUVBLFFBQUksV0FBVztBQUNiLFlBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsYUFBYSxlQUFlLEdBQUcsT0FBTztBQUFBLElBQzFFO0FBQUEsRUFDRjtBQUFBO0FBQUEsRUFHQSxNQUFNLGdCQUFxQztBQUN6QyxVQUFNLFNBQVUsTUFBTSxPQUFPLFFBQVEsTUFBTTtBQUFBLE1BQ3pDLGFBQWE7QUFBQSxJQUFBO0FBRWYsV0FBTztBQUFBLE1BQ0w7QUFBQSxNQUNBLGFBQWE7QUFBQSxNQUNiO0FBQUEsSUFBQTtBQUFBLEVBRUo7QUFBQSxFQUVBLE1BQU0sY0FBYyxTQUFvQztBQUN0RCxVQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLGFBQWEsV0FBVyxHQUFHLFNBQVM7QUFBQSxFQUN4RTtBQUFBLEVBRUEsTUFBTSxrQkFBaUM7QUFDckMsVUFBTSxLQUFLLGNBQWMsbUJBQW1CO0FBQUEsRUFDOUM7QUFBQSxFQUVBLE1BQU0sZ0JBQXFDO0FBQ3pDLFVBQU0sU0FBVSxNQUFNLE9BQU8sUUFBUSxNQUFNO0FBQUEsTUFDekMsYUFBYTtBQUFBLElBQUE7QUFFZixXQUFPLGVBQWUsUUFBUSxhQUFhLGFBQWEsQ0FBQSxDQUFnQjtBQUFBLEVBQzFFO0FBQUEsRUFFQSxNQUFNLGNBQWMsU0FBb0M7QUFDdEQsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxhQUFhLFdBQVcsR0FBRyxTQUFTO0FBQUEsRUFDeEU7QUFBQSxFQUVBLE1BQU0seUJBQWlEO0FBQ3JELFVBQU0sU0FBVSxNQUFNLE9BQU8sUUFBUSxNQUFNO0FBQUEsTUFDekMsYUFBYTtBQUFBLElBQUE7QUFFZixXQUFPLGVBQWUsUUFBUSxhQUFhLHdCQUF3QixJQUFJO0FBQUEsRUFDekU7QUFBQSxFQUVBLE1BQU0sdUJBQXVCLFVBQXdDO0FBQ25FLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSTtBQUFBLE1BQzdCLENBQUMsYUFBYSxzQkFBc0IsR0FBRztBQUFBLElBQUEsQ0FDeEM7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFNLDhCQUFpRTtBQUNyRSxVQUFNLFNBQVUsTUFBTSxPQUFPLFFBQVEsTUFBTTtBQUFBLE1BQ3pDLGFBQWE7QUFBQSxJQUFBO0FBRWYsV0FBTztBQUFBLE1BQ0w7QUFBQSxNQUNBLGFBQWE7QUFBQSxNQUNiLENBQUE7QUFBQSxJQUFDO0FBQUEsRUFFTDtBQUFBLEVBRUEsTUFBTSw0QkFDSixZQUNlO0FBQ2YsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJO0FBQUEsTUFDN0IsQ0FBQyxhQUFhLDJCQUEyQixHQUFHO0FBQUEsSUFBQSxDQUM3QztBQUFBLEVBQ0g7QUFBQSxFQUVBLE1BQU0sd0JBQXNEO0FBQzFELFVBQU0sU0FBVSxNQUFNLE9BQU8sUUFBUSxNQUFNO0FBQUEsTUFDekMsYUFBYTtBQUFBLElBQUE7QUFFZixXQUFPO0FBQUEsTUFDTDtBQUFBLE1BQ0EsYUFBYTtBQUFBLE1BQ2IsQ0FBQTtBQUFBLElBQUM7QUFBQSxFQUVMO0FBQUEsRUFFQSxNQUFNLHNCQUFzQixhQUFpRDtBQUMzRSxVQUFNLE9BQU8sUUFBUSxNQUFNLElBQUk7QUFBQSxNQUM3QixDQUFDLGFBQWEsb0JBQW9CLEdBQUc7QUFBQSxJQUFBLENBQ3RDO0FBQUEsRUFDSDtBQUFBLEVBRUEsTUFBTSxnQkFBd0M7QUFDNUMsVUFBTSxTQUFVLE1BQU0sT0FBTyxRQUFRLE1BQU07QUFBQSxNQUN6QyxhQUFhO0FBQUEsSUFBQTtBQUVmLFdBQU8sZUFBZSxRQUFRLGFBQWEsY0FBYyxJQUFJO0FBQUEsRUFDL0Q7QUFBQSxFQUVBLE1BQU0sY0FBYyxTQUF1QztBQUN6RCxVQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLGFBQWEsWUFBWSxHQUFHLFNBQVM7QUFBQSxFQUN6RTtBQUFBLEVBRUEsTUFBTSxjQUF3QztBQUM1QyxVQUFNLFNBQVUsTUFBTSxPQUFPLFFBQVEsTUFBTTtBQUFBLE1BQ3pDLGFBQWE7QUFBQSxJQUFBO0FBRWYsV0FBTyxlQUFlLFFBQVEsYUFBYSxXQUFXLElBQUk7QUFBQSxFQUM1RDtBQUFBLEVBRUEsTUFBTSxZQUFZLE9BQXVDO0FBQ3ZELFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsYUFBYSxTQUFTLEdBQUcsT0FBTztBQUFBLEVBQ3BFO0FBQ0Y7QUNqVEEsTUFBTSwwQkFBMEIsSUFBSTtBQUNwQyxNQUFNLHFCQUFxQixJQUFJO0FBQy9CLE1BQU0sMkJBQTJCO0FBb0MxQixNQUFNLGVBQWU7QUFBQSxFQUsxQixZQUNVQSxVQUNBLEtBQ1I7QUFGUSxTQUFBLFVBQUFBO0FBQ0EsU0FBQSxNQUFBO0FBRVIsV0FBTyxRQUFRLFVBQVUsWUFBWSxDQUFDLGFBQWE7QUFDakQsaUJBQVcsQ0FBQyxXQUFXLEtBQUssS0FBSyxLQUFLLHFCQUFxQjtBQUN6RCxZQUFJLE1BQU0sYUFBYSxTQUFVO0FBQ2pDLHFCQUFhLE1BQU0sU0FBUztBQUM1QixhQUFLLG9CQUFvQixPQUFPLFNBQVM7QUFDekMsY0FBTSxPQUFPLElBQUksTUFBTSxvQ0FBb0MsQ0FBQztBQUFBLE1BQzlEO0FBRUEsaUJBQVcsQ0FBQyxhQUFhLEtBQUssS0FBSyxLQUFLLHlCQUF5QjtBQUMvRCxZQUFJLE1BQU0sYUFBYSxTQUFVO0FBQ2pDLHFCQUFhLE1BQU0sU0FBUztBQUM1QixhQUFLLHdCQUF3QixPQUFPLFdBQVc7QUFDL0MsY0FBTSxPQUFPLElBQUksTUFBTSxxQ0FBcUMsQ0FBQztBQUFBLE1BQy9EO0FBRUEsaUJBQVcsQ0FBQyxXQUFXLEtBQUssS0FBSyxLQUFLLHVCQUF1QjtBQUMzRCxZQUFJLE1BQU0sYUFBYSxTQUFVO0FBQ2pDLHFCQUFhLE1BQU0sU0FBUztBQUM1QixhQUFLLHNCQUFzQixPQUFPLFNBQVM7QUFDM0MsY0FBTSxPQUFPLElBQUksTUFBTSxtQ0FBbUMsQ0FBQztBQUFBLE1BQzdEO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBOUJRLDBDQUEwQixJQUFBO0FBQUEsRUFDMUIsOENBQThCLElBQUE7QUFBQSxFQUM5Qiw0Q0FBNEIsSUFBQTtBQUFBLEVBOEJwQyxNQUFNLGNBQ0osU0FDQSxRQUNrQjtBQUNsQixZQUFRLElBQUksOEJBQThCLFFBQVEsSUFBSTtBQUV0RCxZQUFRLFFBQVEsTUFBQTtBQUFBLE1BQ2QsS0FBSztBQUNILGVBQU8sS0FBSyxrQkFBa0IsUUFBUSxTQUFTLE1BQU07QUFBQSxNQUV2RCxLQUFLO0FBQ0gsZUFBTyxLQUFLLHFCQUFxQixRQUFRLE9BQU87QUFBQSxNQUVsRCxLQUFLO0FBQ0gsZUFBTyxLQUFLLHNCQUFzQixRQUFRLFNBQVMsTUFBTTtBQUFBLE1BRTNELEtBQUs7QUFDSCxlQUFPLEtBQUssa0JBQWtCLFFBQVEsU0FBUyxNQUFNO0FBQUEsTUFFdkQsS0FBSztBQUNILGVBQU8sS0FBSyxtQkFBQTtBQUFBLE1BRWQsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJLFdBQUE7QUFBQSxNQUVsQixLQUFLO0FBQ0gsZUFBTyxLQUFLLElBQUksV0FBVyxRQUFRLE9BQU87QUFBQSxNQUU1QyxLQUFLO0FBQ0gsZUFBTyxLQUFLLG1CQUFBO0FBQUEsTUFFZCxLQUFLO0FBQ0gsZUFBTyxLQUFLLElBQUksV0FBQTtBQUFBLE1BRWxCLEtBQUs7QUFDSCxlQUFPLEtBQUssSUFBSSxNQUFBO0FBQUEsTUFFbEIsS0FBSztBQUNILGVBQU8sS0FBSyxtQkFBbUIsUUFBUSxPQUFPO0FBQUEsTUFFaEQsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJLGNBQUE7QUFBQSxNQUVsQixLQUFLO0FBQ0gsZUFBTyxLQUFLLElBQUk7QUFBQSxVQUNkLFFBQVE7QUFBQSxRQUFBO0FBQUEsTUFHWixLQUFLO0FBQ0gsZUFBTyxLQUFLLGtCQUFrQixRQUFRLFNBQVMsTUFBTTtBQUFBLE1BRXZELEtBQUs7QUFDSCxlQUFPLEtBQUssSUFBSTtBQUFBLFVBQ2QsUUFBUSxRQUFRO0FBQUEsVUFDaEIsUUFBUSxRQUFRO0FBQUEsUUFBQTtBQUFBLE1BR3BCLEtBQUs7QUFDSCxlQUFPLEtBQUssSUFBSTtBQUFBLFVBQ2QsUUFBUSxRQUFRO0FBQUEsVUFDaEIsUUFBUSxRQUFRO0FBQUEsUUFBQTtBQUFBLE1BR3BCLEtBQUs7QUFDSCxlQUFPLEtBQUssSUFBSTtBQUFBLFVBQ2QsUUFBUSxRQUFRO0FBQUEsVUFDaEIsUUFBUSxRQUFRO0FBQUEsUUFBQTtBQUFBLE1BS3BCLEtBQUs7QUFDSCxlQUFPLEtBQUssSUFBSTtBQUFBLFVBQ2QsUUFBUSxRQUFRO0FBQUEsVUFDaEIsUUFBUSxRQUFRO0FBQUEsUUFBQTtBQUFBLE1BR3BCLEtBQUs7QUFDSCxlQUFPLEtBQUssSUFBSTtBQUFBLFVBQ2QsUUFBUSxRQUFRO0FBQUEsVUFDaEIsUUFBUSxRQUFRO0FBQUEsUUFBQTtBQUFBLE1BR3BCLEtBQUs7QUFDSCxlQUFPLEtBQUssSUFBSTtBQUFBLFVBQ2QsUUFBUSxRQUFRO0FBQUEsVUFDaEIsUUFBUSxRQUFRO0FBQUEsUUFBQTtBQUFBLE1BR3BCLEtBQUs7QUFDSCxlQUFPLEtBQUssSUFBSSxrQkFBa0IsUUFBUSxRQUFRLFFBQVE7QUFBQSxNQUU1RCxLQUFLO0FBQ0gsZUFBTyxLQUFLLElBQUksb0JBQW9CLFFBQVEsUUFBUSxVQUFVO0FBQUEsVUFDNUQsUUFBUSxRQUFRLFFBQVE7QUFBQSxVQUN4QixPQUFPLFFBQVEsUUFBUTtBQUFBLFFBQUEsQ0FDeEI7QUFBQSxNQUVILEtBQUs7QUFDSCxlQUFPLEtBQUssSUFBSSxpQkFBaUIsUUFBUSxRQUFRLFdBQVc7QUFBQSxNQUU5RCxLQUFLO0FBQ0gsZUFBTyxLQUFLLElBQUksb0JBQW9CLFFBQVEsUUFBUSxXQUFXO0FBQUEsTUFFakUsS0FBSztBQUNILGVBQU8sS0FBSyw0QkFBNEIsUUFBUSxPQUFPO0FBQUEsTUFFekQsS0FBSztBQUNILGVBQU8sS0FBSywyQkFBMkIsUUFBUSxPQUFPO0FBQUEsTUFFeEQsS0FBSztBQUNILGVBQU8sS0FBSyx1QkFBdUIsUUFBUSxPQUFPO0FBQUEsTUFFcEQsS0FBSztBQUNILGVBQU8sS0FBSyxzQkFBc0IsUUFBUSxPQUFPO0FBQUEsTUFFbkQsS0FBSztBQUNILGVBQU8sS0FBSyx5QkFBeUIsUUFBUSxPQUFPO0FBQUEsTUFFdEQsS0FBSztBQUNILGVBQU8sS0FBSyx3QkFBd0IsUUFBUSxPQUFPO0FBQUEsTUFFckQsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJLGdCQUFBO0FBQUEsTUFFbEIsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJO0FBQUEsVUFDZCxRQUFRO0FBQUEsUUFBQTtBQUFBLE1BR1osS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJO0FBQUEsVUFDZCxRQUFRO0FBQUEsUUFBQTtBQUFBLE1BR1o7QUFDRSxjQUFNLElBQUk7QUFBQSxVQUNSLHlCQUNHLFFBQThCLFFBQVEsU0FDekM7QUFBQSxRQUFBO0FBQUEsSUFDRjtBQUFBLEVBRU47QUFBQSxFQUVRLGdCQUFnQixPQUF1QjtBQUM3QyxRQUFJO0FBQ0YsWUFBTSxNQUFNLElBQUksSUFBSSxLQUFLO0FBQ3pCLFlBQU0sV0FBVyxJQUFJLFNBQVMsWUFBQTtBQUM5QixZQUFNLFdBQVcsSUFBSSxTQUFTLFlBQUE7QUFDOUIsWUFBTSxPQUFPLElBQUk7QUFDakIsWUFBTSxjQUNKLEtBQUssU0FBUyxLQUNkLEVBQ0csYUFBYSxZQUFZLFNBQVMsU0FDbEMsYUFBYSxXQUFXLFNBQVM7QUFFdEMsWUFBTSxPQUFPLGNBQWMsR0FBRyxRQUFRLElBQUksSUFBSSxLQUFLO0FBQ25ELGFBQU8sR0FBRyxRQUFRLEtBQUssSUFBSTtBQUFBLElBQzdCLFFBQVE7QUFDTixhQUFPLE1BQU0sS0FBQSxFQUFPLFlBQUE7QUFBQSxJQUN0QjtBQUFBLEVBQ0Y7QUFBQSxFQUVRLHNCQUNOLFlBQ3FCO0FBQ3JCLFVBQU0sTUFBTSxLQUFLLElBQUE7QUFDakIsV0FBTztBQUFBLE1BQ0wsY0FBYyxXQUFXO0FBQUEsTUFDekIsUUFBUSxXQUFXO0FBQUEsTUFDbkIsa0JBQWtCLFdBQVc7QUFBQSxNQUM3QixNQUFNLFdBQVc7QUFBQSxNQUNqQixhQUFhLFdBQVc7QUFBQSxNQUN4QixVQUFVLFdBQVc7QUFBQSxNQUNyQixlQUFlLFdBQVc7QUFBQSxNQUMxQixTQUFTLFdBQVc7QUFBQSxNQUNwQixZQUFZLFdBQVc7QUFBQSxNQUN2QixhQUFhLFdBQVcsY0FDcEIsS0FBSyxNQUFNLFdBQVcsV0FBVyxLQUFLLE1BQ3RDO0FBQUEsTUFDSixZQUFZO0FBQUEsSUFBQTtBQUFBLEVBRWhCO0FBQUEsRUFFUSwyQkFBMkIsTUFBa0M7QUFDbkUsV0FBTztBQUFBLE1BQ0wsTUFBTTtBQUFBLE1BQ04sT0FBTztBQUFBLE1BQ1AsU0FBUyxHQUFHLElBQUk7QUFBQSxJQUFBO0FBQUEsRUFFcEI7QUFBQSxFQUVBLE1BQWMsZ0JBQ1osY0FDQSxNQUNBLFNBQ2U7QUFDZixRQUFJO0FBQ0YsWUFBTSxLQUFLLElBQUksOEJBQThCLGNBQWM7QUFBQSxRQUN6RDtBQUFBLFFBQ0E7QUFBQSxNQUFBLENBQ0Q7QUFBQSxJQUNILFNBQVMsT0FBTztBQUNkLGNBQVEsS0FBSyxzREFBc0QsS0FBSztBQUFBLElBQzFFO0FBQUEsRUFDRjtBQUFBLEVBRVEsYUFDTixTQUNBLGtCQUNBLGlCQUNpQjtBQUNqQixRQUFJLFFBQVEsV0FBVyxHQUFHO0FBQ3hCLGFBQU87QUFBQSxJQUNUO0FBRUEsVUFBTSxpQkFDSixRQUFRLEtBQUssQ0FBQyxXQUFXLE9BQU8sYUFBYSxnQkFBZ0IsS0FBSztBQUNwRSxRQUNFLG1CQUNDLENBQUMsbUJBQW1CLGVBQWUsZ0JBQWdCLGFBQ3BEO0FBQ0EsYUFBTztBQUFBLElBQ1Q7QUFFQSxRQUFJLGlCQUFpQjtBQUNuQixhQUNFLFFBQVEsS0FBSyxDQUFDLFdBQVcsT0FBTyxnQkFBZ0IsVUFBVSxLQUFLO0FBQUEsSUFFbkU7QUFFQSxXQUFPLGtCQUFrQixRQUFRLENBQUMsS0FBSztBQUFBLEVBQ3pDO0FBQUEsRUFFQSxNQUFjLG1CQUF3QztBQUNwRCxRQUFJLFVBQVUsTUFBTSxLQUFLLFFBQVEsY0FBQTtBQUNqQyxRQUFJLFFBQVEsU0FBUyxHQUFHO0FBQ3RCLGFBQU87QUFBQSxJQUNUO0FBRUEsUUFBSTtBQUNGLFlBQU0sS0FBSyxJQUFJLE1BQUE7QUFBQSxJQUNqQixTQUFTLE9BQU87QUFDZCxjQUFRLEtBQUssK0NBQStDLEtBQUs7QUFBQSxJQUNuRTtBQUVBLGNBQVUsTUFBTSxLQUFLLFFBQVEsY0FBQTtBQUM3QixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRUEsTUFBYyxpQkFBaUIsU0FFRjtBQUMzQixVQUFNLFVBQVUsTUFBTSxLQUFLLGlCQUFBO0FBQzNCLFVBQU0sbUJBQW1CLE1BQU0sS0FBSyxRQUFRLHVCQUFBO0FBQzVDLFdBQU8sS0FBSztBQUFBLE1BQ1Y7QUFBQSxNQUNBO0FBQUEsTUFDQSxTQUFTLG1CQUFtQjtBQUFBLElBQUE7QUFBQSxFQUVoQztBQUFBLEVBRUEsTUFBYyw0QkFDWixTQUNBLFNBQ0EsU0FDMEI7QUFDMUIsVUFBTSxVQUFVLE1BQU0sS0FBSyxpQkFBQTtBQUMzQixXQUNFLFFBQVE7QUFBQSxNQUNOLENBQUMsV0FDQyxPQUFPLFFBQVEsWUFBQSxNQUFrQixRQUFRLFlBQUEsS0FDekMsT0FBTyxZQUFZLFlBQ2xCLENBQUMsU0FBUyxtQkFBbUIsT0FBTyxnQkFBZ0I7QUFBQSxJQUFBLEtBQ3BEO0FBQUEsRUFFVDtBQUFBLEVBRUEsTUFBYyx3QkFBd0IsU0FHcEI7QUFDaEIsVUFBTSxPQUFPLE1BQU0sT0FBTyxLQUFLLE1BQU0sQ0FBQSxDQUFFO0FBQ3ZDLFVBQU0sUUFBUTtBQUFBLE1BQ1osS0FBSyxJQUFJLE9BQU8sUUFBUTtBQUN0QixZQUFJLE9BQU8sSUFBSSxPQUFPLFVBQVU7QUFDOUI7QUFBQSxRQUNGO0FBRUEsWUFBSTtBQUNGLGdCQUFNLE9BQU8sS0FBSyxZQUFZLElBQUksSUFBSSxPQUFPO0FBQUEsUUFDL0MsUUFBUTtBQUFBLFFBRVI7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUFBO0FBQUEsRUFFTDtBQUFBLEVBRUEsTUFBYyw2QkFDWixRQUNlO0FBQ2YsVUFBTSxLQUFLLHdCQUF3QjtBQUFBLE1BQ2pDLE1BQU07QUFBQSxNQUNOLFNBQVM7QUFBQSxRQUNQLFNBQVMsUUFBUSxXQUFXO0FBQUEsUUFDNUIsVUFBVSxTQUFTLENBQUMsT0FBTyxPQUFPLElBQUksQ0FBQTtBQUFBLE1BQUM7QUFBQSxJQUN6QyxDQUNEO0FBQUEsRUFDSDtBQUFBLEVBRUEsTUFBYyxzQkFBcUM7QUFDakQsVUFBTSxLQUFLLHdCQUF3QixFQUFFLE1BQU0scUJBQXFCO0FBQUEsRUFDbEU7QUFBQSxFQUVBLE1BQWMsOEJBQ1osUUFDQSxlQUNxQztBQUNyQyxVQUFNLG1CQUFtQixLQUFLLGdCQUFnQixNQUFNO0FBQ3BELFVBQU0sYUFBYSxNQUFNLEtBQUssUUFBUSxrQkFBQTtBQUN0QyxVQUFNLGFBQ0osT0FBTyxPQUFPLFVBQVUsRUFBRTtBQUFBLE1BQ3hCLENBQUMsU0FDQyxLQUFLLGdCQUFnQixZQUNyQixLQUFLLHFCQUFxQixvQkFDMUIsS0FBSyxjQUFjLFlBQUEsTUFBa0IsY0FBYyxZQUFBO0FBQUEsSUFBWSxLQUM5RDtBQUNQLFFBQUksWUFBWTtBQUNkLGFBQU87QUFBQSxJQUNUO0FBRUEsUUFBSTtBQUNGLFlBQU0sU0FBUyxNQUFNLEtBQUssSUFBSSxvQkFBb0I7QUFBQSxRQUNoRCxhQUFhO0FBQUEsUUFDYixRQUFRO0FBQUEsTUFBQSxDQUNUO0FBQ0QsWUFBTSxjQUNKLE9BQU8sWUFBWTtBQUFBLFFBQ2pCLENBQUMsZUFDQyxXQUFXLHFCQUFxQixvQkFDaEMsV0FBVyxjQUFjLGtCQUN2QixjQUFjLFlBQUE7QUFBQSxNQUFZLEtBQzNCO0FBQ1AsVUFBSSxDQUFDLGFBQWE7QUFDaEIsZUFBTztBQUFBLE1BQ1Q7QUFFQSxZQUFNLFNBQVMsS0FBSyxzQkFBc0IsV0FBVztBQUNyRCxZQUFNLEtBQUssUUFBUSxpQkFBaUIsTUFBTTtBQUMxQyxhQUFPO0FBQUEsSUFDVCxTQUFTLE9BQU87QUFDZCxjQUFRO0FBQUEsUUFDTjtBQUFBLFFBQ0E7QUFBQSxNQUFBO0FBRUYsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFjLDZCQUNaLFFBQ0EsUUFDcUM7QUFDckMsVUFBTSxXQUFXLE1BQU0sS0FBSyw4QkFBOEIsUUFBUSxNQUFNO0FBQ3hFLFFBQUksVUFBVTtBQUNaLGFBQU87QUFBQSxJQUNUO0FBRUEsVUFBTSxnQkFBZ0IsTUFBTSxLQUFLO0FBQUEsTUFDL0I7QUFBQSxNQUNBLE9BQU87QUFBQSxJQUFBO0FBRVQsUUFBSSxDQUFDLGVBQWU7QUFDbEIsYUFBTztBQUFBLElBQ1Q7QUFFQSxVQUFNLFdBQVcsTUFBTSxLQUFLLElBQUksc0JBQXNCO0FBQUEsTUFDcEQsUUFBUSxLQUFLLGdCQUFnQixNQUFNO0FBQUEsTUFDbkMsYUFBYTtBQUFBLE1BQ2IsZUFBZSxPQUFPO0FBQUEsTUFDdEIsU0FBUyxPQUFPO0FBQUEsTUFDaEIsVUFBVSxPQUFPO0FBQUEsSUFBQSxDQUNsQjtBQUVELFFBQUksU0FBUyxXQUFXLGVBQWUsV0FBVztBQUNoRCxZQUFNLElBQUksTUFBTSxTQUFTLGtCQUFrQixzQkFBc0I7QUFBQSxJQUNuRTtBQUVBLFFBQ0UsU0FBUyxvQkFDVCxTQUFTLFdBQVcsV0FBVyxhQUMvQjtBQUNBLFlBQU1DLFVBQVMsS0FBSyxzQkFBc0IsU0FBUyxVQUFVO0FBQzdELFlBQU0sS0FBSyxRQUFRLGlCQUFpQkEsT0FBTTtBQUMxQyxhQUFPQTtBQUFBQSxJQUNUO0FBRUEsVUFBTSxZQUFZLE1BQU0sS0FBSyxJQUFJO0FBQUEsTUFDL0IsU0FBUyxXQUFXO0FBQUEsSUFBQTtBQUV0QixVQUFNLFNBQVMsS0FBSyxzQkFBc0IsVUFBVSxVQUFVO0FBQzlELFVBQU0sS0FBSyxRQUFRLGlCQUFpQixNQUFNO0FBQzFDLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFjLDhCQUNaLFFBQ0EsUUFDcUM7QUFDckMsVUFBTSxRQUFRLE1BQU0sS0FBSyxRQUFRLGtCQUFrQjtBQUFBLE1BQ2pEO0FBQUEsTUFDQSxlQUFlLE9BQU87QUFBQSxNQUN0QixTQUFTLE9BQU87QUFBQSxNQUNoQixhQUFhO0FBQUEsSUFBQSxDQUNkO0FBQ0QsUUFBSSxPQUFPO0FBQ1QsYUFBTztBQUFBLElBQ1Q7QUFFQSxRQUFJO0FBQ0YsWUFBTSxtQkFBbUIsS0FBSyxnQkFBZ0IsTUFBTTtBQUNwRCxZQUFNLFNBQVMsTUFBTSxLQUFLLElBQUksb0JBQW9CO0FBQUEsUUFDaEQsYUFBYTtBQUFBLFFBQ2IsVUFBVSxPQUFPO0FBQUEsUUFDakIsUUFBUTtBQUFBLE1BQUEsQ0FDVDtBQUNELFlBQU0sUUFBUSxPQUFPLFlBQVk7QUFBQSxRQUMvQixDQUFDLGVBQWUsV0FBVyxxQkFBcUI7QUFBQSxNQUFBO0FBRWxELFVBQUksQ0FBQyxPQUFPO0FBQ1YsZUFBTztBQUFBLE1BQ1Q7QUFFQSxZQUFNLFNBQVMsS0FBSyxzQkFBc0IsS0FBSztBQUMvQyxZQUFNLEtBQUssUUFBUSxpQkFBaUIsTUFBTTtBQUMxQyxhQUFPO0FBQUEsSUFDVCxTQUFTLE9BQU87QUFDZCxjQUFRLEtBQUssc0RBQXNELEtBQUs7QUFDeEUsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFjLGtCQUNaLFNBQ0EsUUFDQTtBQUNBLFVBQU0sWUFBWSxRQUFRLFVBQVUsT0FBTyxVQUFVLE9BQU87QUFDNUQsUUFBSSxDQUFDLFdBQVc7QUFDZCxZQUFNLElBQUksTUFBTSxvQkFBb0I7QUFBQSxJQUN0QztBQUNBLFVBQU0sU0FBUyxLQUFLLGdCQUFnQixTQUFTO0FBRTdDLFVBQU0sU0FBUyxNQUFNLEtBQUsseUJBQXlCO0FBQUEsTUFDakQsaUJBQWlCO0FBQUEsSUFBQSxDQUNsQjtBQUNELFFBQUksQ0FBQyxRQUFRO0FBQ1gsWUFBTSxJQUFJO0FBQUEsUUFDUjtBQUFBLE1BQUE7QUFBQSxJQUVKO0FBRUEsVUFBTSxnQkFBZ0IsTUFBTSxLQUFLO0FBQUEsTUFDL0I7QUFBQSxNQUNBO0FBQUEsSUFBQTtBQUVGLFFBQUksZUFBZTtBQUNqQixhQUFPO0FBQUEsUUFDTCxXQUFXO0FBQUEsUUFDWCxVQUFVLENBQUMsT0FBTyxPQUFPO0FBQUEsTUFBQTtBQUFBLElBRTdCO0FBRUEsVUFBTSxXQUFXLE1BQU0sS0FBSyxJQUFJLHNCQUFzQjtBQUFBLE1BQ3BEO0FBQUEsTUFDQSxhQUFhO0FBQUEsTUFDYixlQUFlLE9BQU87QUFBQSxNQUN0QixTQUFTLE9BQU87QUFBQSxNQUNoQixVQUFVLE9BQU87QUFBQSxJQUFBLENBQ2xCO0FBRUQsUUFBSSxTQUFTLFdBQVcsZUFBZSxXQUFXO0FBQ2hELFlBQU0sSUFBSSxNQUFNLFNBQVMsa0JBQWtCLHNCQUFzQjtBQUFBLElBQ25FO0FBRUEsUUFDRSxTQUFTLG9CQUNULFNBQVMsV0FBVyxXQUFXLGFBQy9CO0FBQ0EsWUFBTSxLQUFLLFFBQVE7QUFBQSxRQUNqQixLQUFLLHNCQUFzQixTQUFTLFVBQVU7QUFBQSxNQUFBO0FBRWhELGFBQU87QUFBQSxRQUNMLFdBQVc7QUFBQSxRQUNYLFVBQVUsQ0FBQyxPQUFPLE9BQU87QUFBQSxNQUFBO0FBQUEsSUFFN0I7QUFFQSxVQUFNLFlBQVksT0FBTyxXQUFBO0FBQ3pCLFVBQU0sV0FBVyxNQUFNLEtBQUsseUJBQXlCLFNBQVM7QUFFOUQsUUFBSSxXQUFXO0FBQ2YsUUFBSTtBQUNGLGlCQUFXLE1BQU0sS0FBSyw2QkFBNkIsV0FBVztBQUFBLFFBQzVEO0FBQUEsUUFDQTtBQUFBLFFBQ0EsZUFBZSxPQUFPO0FBQUEsUUFDdEIsWUFBWSxTQUFTO0FBQUEsUUFDckIsU0FBUztBQUFBLFVBQ1AsTUFBTSxTQUFTO0FBQUEsVUFDZixPQUFPLFNBQVM7QUFBQSxVQUNoQixTQUFTLFNBQVM7QUFBQSxRQUFBO0FBQUEsTUFDcEIsQ0FDRDtBQUFBLElBQ0gsU0FBUyxPQUFPO0FBQ2QsWUFBTSxLQUFLLElBQ1IscUJBQXFCLFNBQVMsV0FBVyxZQUFZLEVBQ3JELE1BQU0sTUFBTSxNQUFTO0FBQ3hCLFlBQU07QUFBQSxJQUNSO0FBRUEsUUFBSSxDQUFDLFVBQVU7QUFDYixZQUFNLEtBQUssSUFDUixxQkFBcUIsU0FBUyxXQUFXLFlBQVksRUFDckQsTUFBTSxNQUFNLE1BQVM7QUFDeEIsWUFBTSxJQUFJLE1BQU0sMEJBQTBCO0FBQUEsSUFDNUM7QUFFQSxVQUFNLFlBQVksTUFBTSxLQUFLLElBQUk7QUFBQSxNQUMvQixTQUFTLFdBQVc7QUFBQSxJQUFBO0FBRXRCLFVBQU0sS0FBSyxRQUFRO0FBQUEsTUFDakIsS0FBSyxzQkFBc0IsVUFBVSxVQUFVO0FBQUEsSUFBQTtBQUdqRCxXQUFPO0FBQUEsTUFDTCxXQUFXO0FBQUEsTUFDWCxVQUFVLENBQUMsT0FBTyxPQUFPO0FBQUEsSUFBQTtBQUFBLEVBRTdCO0FBQUEsRUFFQSxNQUFjLHFCQUFxQixTQUE2QjtBQUM5RCxVQUFNLFNBQVMsTUFBTSxLQUFLLGlCQUFBO0FBQzFCLFFBQUksQ0FBQyxRQUFRO0FBQ1gsWUFBTSxLQUFLLFFBQVEsOEJBQThCLFFBQVEsTUFBTTtBQUMvRCxhQUFPLEVBQUUsU0FBUyxLQUFBO0FBQUEsSUFDcEI7QUFFQSxVQUFNLE9BQU8sTUFBTSxLQUFLLFFBQVEsa0JBQWtCO0FBQUEsTUFDaEQsUUFBUSxRQUFRO0FBQUEsTUFDaEIsZUFBZSxPQUFPO0FBQUEsTUFDdEIsU0FBUyxPQUFPO0FBQUEsTUFDaEIsYUFBYTtBQUFBLElBQUEsQ0FDZDtBQUVELFFBQUksTUFBTTtBQUNSLFlBQU0sS0FBSyxJQUNSLHlCQUF5QixLQUFLLFlBQVksRUFDMUMsTUFBTSxDQUFDLFVBQVU7QUFDaEIsZ0JBQVEsS0FBSywrQ0FBK0MsS0FBSztBQUFBLE1BQ25FLENBQUM7QUFDSCxZQUFNLEtBQUssUUFBUSxvQkFBb0IsS0FBSyxZQUFZO0FBQUEsSUFDMUQ7QUFFQSxVQUFNLEtBQUssUUFBUTtBQUFBLE1BQ2pCLFFBQVE7QUFBQSxNQUNSLE9BQU87QUFBQSxJQUFBO0FBRVQsV0FBTyxFQUFFLFNBQVMsS0FBQTtBQUFBLEVBQ3BCO0FBQUEsRUFFQSxNQUFjLHNCQUNaLFNBQ0EsUUFDd0I7QUFDeEIsVUFBTSxTQUFTLE9BQU8sVUFBVSxPQUFPO0FBQ3ZDLFFBQUksQ0FBQyxRQUFRO0FBQ1gsWUFBTSxJQUFJLE1BQU0sb0JBQW9CO0FBQUEsSUFDdEM7QUFFQSxRQUFJLENBQUMsUUFBUSxJQUFJO0FBQ2YsWUFBTSxJQUFJLE1BQU0sZ0NBQWdDO0FBQUEsSUFDbEQ7QUFFQSxVQUFNLFNBQVMsTUFBTSxLQUFLLGlCQUFpQixFQUFFLGlCQUFpQixNQUFNO0FBQ3BFLFFBQUksQ0FBQyxRQUFRO0FBQ1gsWUFBTSxJQUFJLE1BQU0scUJBQXFCO0FBQUEsSUFDdkM7QUFFQSxVQUFNLGFBQWEsTUFBTSxLQUFLLDZCQUE2QixRQUFRLE1BQU07QUFDekUsUUFBSSxDQUFDLFlBQVk7QUFDZixZQUFNLElBQUksTUFBTSxvQkFBb0I7QUFBQSxJQUN0QztBQUNBLFFBQUksV0FBVyxlQUFlLFdBQVc7QUFDdkMsWUFBTSxJQUFJLE1BQU0sc0JBQXNCO0FBQUEsSUFDeEM7QUFFQSxVQUFNLEtBQUssUUFBUSxtQkFBbUIsV0FBVyxZQUFZO0FBQzdELFNBQUssS0FBSztBQUFBLE1BQ1IsV0FBVztBQUFBLE1BQ1g7QUFBQSxNQUNBO0FBQUEsSUFBQTtBQUdGLFVBQU0sVUFDSixXQUFXLGVBQWUsWUFDdEIsS0FBSywyQkFBMkIsV0FBVyxJQUFJLElBQy9DO0FBRU4sVUFBTSxXQUFXLE1BQU0sS0FBSyxJQUFJLG9CQUFvQixPQUFPLFVBQVU7QUFBQSxNQUNuRSxrQkFBa0I7QUFBQSxRQUNoQjtBQUFBLFVBQ0UsSUFBSSxRQUFRO0FBQUEsVUFDWixPQUFRLFFBQVEsU0FBUztBQUFBLFVBQ3pCLE1BQU8sUUFBUSxRQUFRO0FBQUEsUUFBQTtBQUFBLE1BQ3pCO0FBQUEsSUFDRixDQUNEO0FBRUQsVUFBTSxXQUFXLE1BQU0sS0FBSyxrQkFBa0IsU0FBUyxXQUFXO0FBQ2xFLFdBQU8sS0FBSyxzQkFBc0IsU0FBUyxhQUFhO0FBQUEsTUFDdEQ7QUFBQSxNQUNBLFFBQVEsV0FBVztBQUFBLE1BQ25CO0FBQUEsTUFDQTtBQUFBLElBQUEsQ0FDRDtBQUFBLEVBQ0g7QUFBQSxFQUVBLE1BQWMsa0JBQ1osU0FDQSxRQUN3QjtBQUN4QixVQUFNLFNBQVMsT0FBTyxVQUFVLE9BQU87QUFDdkMsUUFBSSxDQUFDLFFBQVE7QUFDWCxZQUFNLElBQUksTUFBTSxvQkFBb0I7QUFBQSxJQUN0QztBQUVBLFFBQUksT0FBTyxRQUFRLFlBQVksVUFBVTtBQUN2QyxZQUFNLElBQUksTUFBTSxpQ0FBaUM7QUFBQSxJQUNuRDtBQUVBLFVBQU0sU0FBUyxNQUFNLEtBQUssaUJBQWlCLEVBQUUsaUJBQWlCLE1BQU07QUFDcEUsUUFBSSxDQUFDLFFBQVE7QUFDWCxZQUFNLElBQUksTUFBTSxxQkFBcUI7QUFBQSxJQUN2QztBQUVBLFVBQU0sYUFBYSxNQUFNLEtBQUssNkJBQTZCLFFBQVEsTUFBTTtBQUN6RSxRQUFJLENBQUMsWUFBWTtBQUNmLFlBQU0sSUFBSSxNQUFNLG9CQUFvQjtBQUFBLElBQ3RDO0FBQ0EsUUFBSSxXQUFXLGVBQWUsV0FBVztBQUN2QyxZQUFNLElBQUksTUFBTSxzQkFBc0I7QUFBQSxJQUN4QztBQUVBLFVBQU0sbUJBQW1CLFFBQVEsU0FBUyxZQUFBO0FBQzFDLFFBQUksb0JBQW9CLHFCQUFxQixPQUFPLFFBQVEsZUFBZTtBQUN6RSxZQUFNLElBQUksTUFBTSxrREFBa0Q7QUFBQSxJQUNwRTtBQUVBLFVBQU0sS0FBSyxRQUFRLG1CQUFtQixXQUFXLFlBQVk7QUFDN0QsU0FBSyxLQUFLLGdCQUFnQixXQUFXLGNBQWMsV0FBVyxXQUFXO0FBRXpFLFVBQU0sVUFDSixXQUFXLGVBQWUsWUFDdEIsS0FBSywyQkFBMkIsV0FBVyxJQUFJLElBQy9DO0FBRU4sVUFBTSxZQUFZLE9BQU8sV0FBQTtBQUN6QixVQUFNLFdBQVcsTUFBTSxLQUFLLHNCQUFzQixTQUFTO0FBQzNELFdBQU8sS0FBSywwQkFBMEIsV0FBVztBQUFBLE1BQy9DO0FBQUEsTUFDQSxTQUFTLFFBQVE7QUFBQSxNQUNqQixTQUFTLE9BQU87QUFBQSxNQUNoQixRQUFRLFdBQVc7QUFBQSxNQUNuQixVQUFVLE9BQU87QUFBQSxNQUNqQjtBQUFBLE1BQ0E7QUFBQSxJQUFBLENBQ0Q7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFjLHFCQUFxQjtBQUNqQyxVQUFNLEtBQUssUUFBUSxTQUFBO0FBQ25CLFVBQU0sS0FBSyxvQkFBQTtBQUNYLFdBQU8sRUFBRSxTQUFTLEtBQUE7QUFBQSxFQUNwQjtBQUFBLEVBRUEsTUFBYyxxQkFBcUI7QUFDakMsVUFBTSxLQUFLLElBQUksYUFBQTtBQUNmLFVBQU0sS0FBSyxvQkFBQTtBQUNYLFdBQU8sRUFBRSxTQUFTLEtBQUE7QUFBQSxFQUNwQjtBQUFBLEVBRUEsTUFBYyxtQkFBbUIsU0FBc0M7QUFDckUsVUFBTSxpQkFBaUIsTUFBTSxLQUFLLElBQUksb0JBQW9CLFFBQVEsUUFBUTtBQUMxRSxVQUFNLEtBQUssNkJBQTZCLGNBQWM7QUFDdEQsV0FBTztBQUFBLE1BQ0wsVUFBVSxnQkFBZ0IsWUFBWTtBQUFBLE1BQ3RDLFNBQVMsZ0JBQWdCLFdBQVc7QUFBQSxJQUFBO0FBQUEsRUFFeEM7QUFBQSxFQUVBLE1BQWMsa0JBQ1osU0FDQSxRQUNBO0FBQ0EsVUFBTSxZQUFZLE9BQU8sVUFBVSxPQUFPO0FBQzFDLFFBQUksQ0FBQyxXQUFXO0FBQ2QsWUFBTSxJQUFJLE1BQU0sb0JBQW9CO0FBQUEsSUFDdEM7QUFFQSxRQUFJLENBQUMsb0JBQW9CLFFBQVEsT0FBTyxHQUFHO0FBQ3pDLFlBQU0sSUFBSSxNQUFNLFNBQVMsUUFBUSxPQUFPLG9CQUFvQjtBQUFBLElBQzlEO0FBRUEsVUFBTSxnQkFBZ0IsTUFBTSxLQUFLLGlCQUFpQjtBQUFBLE1BQ2hELGlCQUFpQjtBQUFBLElBQUEsQ0FDbEI7QUFDRCxRQUFJLENBQUMsZUFBZTtBQUNsQixZQUFNLElBQUksTUFBTSw4QkFBOEI7QUFBQSxJQUNoRDtBQUVBLFFBQUksY0FBYyxZQUFZLFFBQVEsU0FBUztBQUM3QyxhQUFPO0FBQUEsUUFDTCxTQUFTLGNBQWM7QUFBQSxRQUN2QixVQUFVLENBQUMsY0FBYyxPQUFPO0FBQUEsUUFDaEMsZUFBZSxjQUFjO0FBQUEsUUFDN0IsZ0JBQWdCO0FBQUEsTUFBQTtBQUFBLElBRXBCO0FBRUEsVUFBTSxnQkFBZ0IsTUFBTSxLQUFLO0FBQUEsTUFDL0I7QUFBQSxNQUNBLGNBQWM7QUFBQSxJQUFBO0FBRWhCLFFBQUksQ0FBQyxlQUFlO0FBQ2xCLFlBQU0sSUFBSSxNQUFNLG9CQUFvQjtBQUFBLElBQ3RDO0FBRUEsVUFBTSxlQUFlLE1BQU0sS0FBSztBQUFBLE1BQzlCLGNBQWM7QUFBQSxNQUNkLFFBQVE7QUFBQSxNQUNSLEVBQUUsaUJBQWlCLEtBQUE7QUFBQSxJQUFLO0FBRTFCLFFBQUksQ0FBQyxjQUFjO0FBQ2pCLFlBQU0sSUFBSTtBQUFBLFFBQ1I7QUFBQSxNQUFBO0FBQUEsSUFFSjtBQUVBLFVBQU0saUJBQ0osYUFBYSxRQUFRLGtCQUNyQixjQUFjLFFBQVEsWUFBQTtBQUV4QixVQUFNLEtBQUssSUFBSSxvQkFBb0IsYUFBYSxRQUFRO0FBQ3hELFVBQU0sYUFBYSxNQUFNLEtBQUs7QUFBQSxNQUM1QjtBQUFBLE1BQ0E7QUFBQSxJQUFBO0FBRUYsUUFBSSxDQUFDLFlBQVk7QUFDZixZQUFNLElBQUksTUFBTSxvREFBb0Q7QUFBQSxJQUN0RTtBQUVBLFVBQU0sS0FBSyw2QkFBNkIsWUFBWTtBQUVwRCxXQUFPO0FBQUEsTUFDTCxTQUFTLGFBQWE7QUFBQSxNQUN0QixVQUFVLENBQUMsYUFBYSxPQUFPO0FBQUEsTUFDL0IsZUFBZSxhQUFhO0FBQUEsTUFDNUI7QUFBQSxJQUFBO0FBQUEsRUFFSjtBQUFBLEVBRUEsTUFBYyx5QkFBeUIsU0FFVjtBQUMzQixVQUFNLFdBQVcsTUFBTSxLQUFLLGlCQUFpQixPQUFPO0FBQ3BELFFBQUksVUFBVTtBQUNaLGFBQU87QUFBQSxJQUNUO0FBRUEsVUFBTSxXQUFXLE1BQU0sS0FBSyxvQkFBQTtBQUM1QixRQUFJO0FBQ0YsYUFBTyxLQUFLLG1CQUFtQixvQkFBb0IsT0FBTztBQUFBLElBQzVELFVBQUE7QUFDRSxVQUFJLFVBQVU7QUFDWixlQUFPLFFBQVEsT0FBTyxVQUFVLE1BQU0sTUFBUztBQUFBLE1BQ2pEO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLE1BQWMsbUJBQ1osV0FDQSxTQUMwQjtBQUMxQixVQUFNLFFBQVEsS0FBSyxJQUFBO0FBQ25CLFdBQU8sS0FBSyxRQUFRLFFBQVEsV0FBVztBQUNyQyxZQUFNLFNBQVMsTUFBTSxLQUFLLGlCQUFpQixPQUFPO0FBQ2xELFVBQUksUUFBUTtBQUNWLGVBQU87QUFBQSxNQUNUO0FBQ0EsWUFBTSxNQUFNLHdCQUF3QjtBQUFBLElBQ3RDO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVBLE1BQWMsa0JBQ1osYUFDNkI7QUFDN0IsVUFBTSxNQUFNLE9BQU8sUUFBUTtBQUFBLE1BQ3pCLDRDQUE0QztBQUFBLFFBQzFDO0FBQUEsTUFBQSxDQUNEO0FBQUEsSUFBQTtBQUdILFdBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM5QixhQUFPLFFBQVE7QUFBQSxRQUNiO0FBQUEsVUFDRTtBQUFBLFVBQ0EsTUFBTTtBQUFBLFVBQ04sT0FBTztBQUFBLFVBQ1AsUUFBUTtBQUFBLFVBQ1IsU0FBUztBQUFBLFFBQUE7QUFBQSxRQUVYLENBQUMsV0FBVztBQUNWLGtCQUFRLFFBQVEsRUFBRTtBQUFBLFFBQ3BCO0FBQUEsTUFBQTtBQUFBLElBRUosQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVBLE1BQWMseUJBQ1osV0FDNkI7QUFDN0IsVUFBTSxNQUFNLE9BQU8sUUFBUTtBQUFBLE1BQ3pCLCtDQUErQztBQUFBLFFBQzdDO0FBQUEsTUFBQSxDQUNEO0FBQUEsSUFBQTtBQUdILFdBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM5QixhQUFPLFFBQVE7QUFBQSxRQUNiO0FBQUEsVUFDRTtBQUFBLFVBQ0EsTUFBTTtBQUFBLFVBQ04sT0FBTztBQUFBLFVBQ1AsUUFBUTtBQUFBLFVBQ1IsU0FBUztBQUFBLFFBQUE7QUFBQSxRQUVYLENBQUMsV0FBVztBQUNWLGtCQUFRLFFBQVEsRUFBRTtBQUFBLFFBQ3BCO0FBQUEsTUFBQTtBQUFBLElBRUosQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVBLE1BQWMsc0JBQ1osV0FDNkI7QUFDN0IsVUFBTSxNQUFNLE9BQU8sUUFBUTtBQUFBLE1BQ3pCLDRDQUE0QztBQUFBLFFBQzFDO0FBQUEsTUFBQSxDQUNEO0FBQUEsSUFBQTtBQUdILFdBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM5QixhQUFPLFFBQVE7QUFBQSxRQUNiO0FBQUEsVUFDRTtBQUFBLFVBQ0EsTUFBTTtBQUFBLFVBQ04sT0FBTztBQUFBLFVBQ1AsUUFBUTtBQUFBLFVBQ1IsU0FBUztBQUFBLFFBQUE7QUFBQSxRQUVYLENBQUMsV0FBVztBQUNWLGtCQUFRLFFBQVEsRUFBRTtBQUFBLFFBQ3BCO0FBQUEsTUFBQTtBQUFBLElBRUosQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVBLE1BQWMsc0JBQW1EO0FBQy9ELFVBQU0sTUFBTSxPQUFPLFFBQVEsT0FBTyxvQkFBb0I7QUFDdEQsV0FBTyxJQUFJLFFBQVEsQ0FBQyxZQUFZO0FBQzlCLGFBQU8sUUFBUTtBQUFBLFFBQ2I7QUFBQSxVQUNFO0FBQUEsVUFDQSxNQUFNO0FBQUEsVUFDTixPQUFPO0FBQUEsVUFDUCxRQUFRO0FBQUEsVUFDUixTQUFTO0FBQUEsUUFBQTtBQUFBLFFBRVgsQ0FBQyxXQUFXO0FBQ1Ysa0JBQVEsUUFBUSxFQUFFO0FBQUEsUUFDcEI7QUFBQSxNQUFBO0FBQUEsSUFFSixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRVEsNkJBQ04sV0FDQSxTQUNrQjtBQUNsQixRQUFJLEtBQUssb0JBQW9CLElBQUksU0FBUyxHQUFHO0FBQzNDLFdBQUssb0JBQ0YsSUFBSSxTQUFTLEdBQ1osT0FBTyxJQUFJLE1BQU0sMkJBQTJCLENBQUM7QUFDakQsV0FBSyxvQkFBb0IsT0FBTyxTQUFTO0FBQUEsSUFDM0M7QUFFQSxXQUFPLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVztBQUN0QyxZQUFNLFlBQVksV0FBVyxNQUFNO0FBQ2pDLGFBQUssb0JBQW9CLE9BQU8sU0FBUztBQUN6QyxlQUFPLElBQUksTUFBTSxtQ0FBbUMsQ0FBQztBQUFBLE1BQ3ZELEdBQUcsdUJBQXVCO0FBRTFCLFdBQUssb0JBQW9CLElBQUksV0FBVztBQUFBLFFBQ3RDO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLEdBQUc7QUFBQSxNQUFBLENBQ0o7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFUSxzQkFDTixhQUNBLFNBQ3dCO0FBQ3hCLFFBQUksS0FBSyx3QkFBd0IsSUFBSSxXQUFXLEdBQUc7QUFDakQsV0FBSyx3QkFDRixJQUFJLFdBQVcsR0FDZCxPQUFPLElBQUksTUFBTSwrQkFBK0IsQ0FBQztBQUNyRCxXQUFLLHdCQUF3QixPQUFPLFdBQVc7QUFBQSxJQUNqRDtBQUVBLFdBQU8sSUFBSSxRQUFRLENBQUMsU0FBUyxXQUFXO0FBQ3RDLFlBQU0sWUFBWSxXQUFXLE1BQU07QUFDakMsYUFBSyx3QkFBd0IsT0FBTyxXQUFXO0FBQy9DLGVBQU8sSUFBSSxNQUFNLG9DQUFvQyxDQUFDO0FBQUEsTUFDeEQsR0FBRyx1QkFBdUI7QUFFMUIsV0FBSyx3QkFBd0IsSUFBSSxhQUFhO0FBQUEsUUFDNUM7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsR0FBRztBQUFBLE1BQUEsQ0FDSjtBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVRLDBCQUNOLFdBQ0EsU0FDd0I7QUFDeEIsUUFBSSxLQUFLLHNCQUFzQixJQUFJLFNBQVMsR0FBRztBQUM3QyxXQUFLLHNCQUNGLElBQUksU0FBUyxHQUNaLE9BQU8sSUFBSSxNQUFNLHdCQUF3QixDQUFDO0FBQzlDLFdBQUssc0JBQXNCLE9BQU8sU0FBUztBQUFBLElBQzdDO0FBRUEsV0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDdEMsWUFBTSxZQUFZLFdBQVcsTUFBTTtBQUNqQyxhQUFLLHNCQUFzQixPQUFPLFNBQVM7QUFDM0MsZUFBTyxJQUFJLE1BQU0sa0NBQWtDLENBQUM7QUFBQSxNQUN0RCxHQUFHLHVCQUF1QjtBQUUxQixXQUFLLHNCQUFzQixJQUFJLFdBQVc7QUFBQSxRQUN4QztBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxHQUFHO0FBQUEsTUFBQSxDQUNKO0FBQUEsSUFDSCxDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsTUFBYyw0QkFBNEIsU0FBZ0M7QUFDeEUsVUFBTSxRQUFRLEtBQUssb0JBQW9CLElBQUksUUFBUSxTQUFTO0FBQzVELFFBQUksQ0FBQyxPQUFPO0FBQ1YsWUFBTSxJQUFJLE1BQU0sMkJBQTJCO0FBQUEsSUFDN0M7QUFFQSxXQUFPO0FBQUEsTUFDTCxXQUFXLFFBQVE7QUFBQSxNQUNuQixRQUFRLE1BQU07QUFBQSxNQUNkLGVBQWUsTUFBTTtBQUFBLE1BQ3JCLFNBQVMsTUFBTSxXQUFXO0FBQUEsTUFDMUIsY0FBYyxNQUFNLFdBQVc7QUFBQSxNQUMvQixNQUFNLE1BQU0sV0FBVztBQUFBLE1BQ3ZCLFlBQVksTUFBTSxXQUFXO0FBQUEsTUFDN0IsYUFBYSxNQUFNLFFBQVE7QUFBQSxNQUMzQixjQUFjLE1BQU0sUUFBUTtBQUFBLE1BQzVCLGdCQUFnQixNQUFNLFFBQVE7QUFBQSxJQUFBO0FBQUEsRUFFbEM7QUFBQSxFQUVBLE1BQWMsMkJBQTJCLFNBSXRDO0FBQ0QsVUFBTSxRQUFRLEtBQUssb0JBQW9CLElBQUksUUFBUSxTQUFTO0FBQzVELFFBQUksQ0FBQyxPQUFPO0FBQ1YsYUFBTyxFQUFFLFNBQVMsS0FBQTtBQUFBLElBQ3BCO0FBRUEsaUJBQWEsTUFBTSxTQUFTO0FBQzVCLFNBQUssb0JBQW9CLE9BQU8sUUFBUSxTQUFTO0FBRWpELFFBQUksUUFBUSxXQUFXLFlBQVk7QUFDakMsWUFBTSxRQUFRLElBQUk7QUFDbEIsYUFBTyxFQUFFLFNBQVMsS0FBQTtBQUFBLElBQ3BCO0FBQ0EsUUFBSSxRQUFRLFdBQVcsWUFBWTtBQUNqQyxZQUFNLFFBQVEsS0FBSztBQUNuQixhQUFPLEVBQUUsU0FBUyxLQUFBO0FBQUEsSUFDcEI7QUFFQSxVQUFNLE9BQU8sSUFBSSxNQUFNLFFBQVEsU0FBUyx5QkFBeUIsQ0FBQztBQUNsRSxXQUFPLEVBQUUsU0FBUyxLQUFBO0FBQUEsRUFDcEI7QUFBQSxFQUVBLE1BQWMsdUJBQXVCLFNBQWtDO0FBQ3JFLFVBQU0sUUFBUSxLQUFLLHdCQUF3QixJQUFJLFFBQVEsV0FBVztBQUNsRSxRQUFJLENBQUMsT0FBTztBQUNWLFlBQU0sSUFBSSxNQUFNLCtCQUErQjtBQUFBLElBQ2pEO0FBRUEsV0FBTztBQUFBLE1BQ0wsYUFBYSxRQUFRO0FBQUEsTUFDckIsUUFBUSxNQUFNO0FBQUEsTUFDZCxTQUFTLE1BQU0sWUFBWSxXQUFXO0FBQUEsTUFDdEMsY0FBYyxNQUFNLFlBQVksZ0JBQWdCO0FBQUEsTUFDaEQsTUFBTSxNQUFNLFlBQVksUUFBUTtBQUFBLE1BQ2hDLFlBQVksTUFBTSxZQUFZLGNBQWM7QUFBQSxNQUM1QyxTQUFTLE1BQU07QUFBQSxJQUFBO0FBQUEsRUFFbkI7QUFBQSxFQUVBLE1BQWMsc0JBQXNCLFNBS2pDO0FBQ0QsVUFBTSxRQUFRLEtBQUssd0JBQXdCLElBQUksUUFBUSxXQUFXO0FBQ2xFLFFBQUksQ0FBQyxPQUFPO0FBQ1YsYUFBTyxFQUFFLFNBQVMsS0FBQTtBQUFBLElBQ3BCO0FBRUEsaUJBQWEsTUFBTSxTQUFTO0FBQzVCLFNBQUssd0JBQXdCLE9BQU8sUUFBUSxXQUFXO0FBRXZELFFBQUksTUFBTSxZQUFZO0FBQ3BCLFlBQU0sVUFDSixRQUFRLFdBQVcsY0FDZixhQUNBLFFBQVEsV0FBVyxhQUNqQixhQUNBO0FBQ1IsV0FBSyxLQUFLO0FBQUEsUUFDUixNQUFNLFdBQVc7QUFBQSxRQUNqQjtBQUFBLFFBQ0E7QUFBQSxNQUFBO0FBQUEsSUFFSjtBQUVBLFFBQUksUUFBUSxXQUFXLGFBQWE7QUFDbEMsVUFBSSxDQUFDLFFBQVEsUUFBUTtBQUNuQixjQUFNO0FBQUEsVUFDSixJQUFJLE1BQU0sK0NBQStDO0FBQUEsUUFBQTtBQUUzRCxlQUFPLEVBQUUsU0FBUyxLQUFBO0FBQUEsTUFDcEI7QUFDQSxZQUFNLFFBQVEsUUFBUSxNQUFNO0FBQzVCLGFBQU8sRUFBRSxTQUFTLEtBQUE7QUFBQSxJQUNwQjtBQUVBLFVBQU0sZUFDSixRQUFRLFNBQVM7QUFDbkIsVUFBTSxPQUFPLElBQUksTUFBTSxZQUFZLENBQUM7QUFDcEMsV0FBTyxFQUFFLFNBQVMsS0FBQTtBQUFBLEVBQ3BCO0FBQUEsRUFFQSxNQUFjLHlCQUF5QixTQUFnQztBQUNyRSxVQUFNLFFBQVEsS0FBSyxzQkFBc0IsSUFBSSxRQUFRLFNBQVM7QUFDOUQsUUFBSSxDQUFDLE9BQU87QUFDVixZQUFNLElBQUksTUFBTSx3QkFBd0I7QUFBQSxJQUMxQztBQUVBLFdBQU87QUFBQSxNQUNMLFdBQVcsUUFBUTtBQUFBLE1BQ25CLFNBQVMsTUFBTTtBQUFBLE1BQ2YsU0FBUyxNQUFNO0FBQUEsTUFDZixRQUFRLE1BQU07QUFBQSxNQUNkLFVBQVUsTUFBTTtBQUFBLE1BQ2hCLFNBQVMsTUFBTSxZQUFZLFdBQVc7QUFBQSxNQUN0QyxjQUFjLE1BQU0sWUFBWSxnQkFBZ0I7QUFBQSxNQUNoRCxNQUFNLE1BQU0sWUFBWSxRQUFRO0FBQUEsTUFDaEMsWUFBWSxNQUFNLFlBQVksY0FBYztBQUFBLE1BQzVDLFNBQVMsTUFBTTtBQUFBLElBQUE7QUFBQSxFQUVuQjtBQUFBLEVBRUEsTUFBYyx3QkFBd0IsU0FLbkM7QUFDRCxVQUFNLFFBQVEsS0FBSyxzQkFBc0IsSUFBSSxRQUFRLFNBQVM7QUFDOUQsUUFBSSxDQUFDLE9BQU87QUFDVixhQUFPLEVBQUUsU0FBUyxLQUFBO0FBQUEsSUFDcEI7QUFFQSxpQkFBYSxNQUFNLFNBQVM7QUFDNUIsU0FBSyxzQkFBc0IsT0FBTyxRQUFRLFNBQVM7QUFFbkQsUUFBSSxNQUFNLFlBQVk7QUFDcEIsWUFBTSxVQUNKLFFBQVEsV0FBVyxXQUNmLGFBQ0EsUUFBUSxXQUFXLGFBQ2pCLGFBQ0E7QUFDUixXQUFLLEtBQUs7QUFBQSxRQUNSLE1BQU0sV0FBVztBQUFBLFFBQ2pCO0FBQUEsUUFDQTtBQUFBLE1BQUE7QUFBQSxJQUVKO0FBRUEsUUFBSSxRQUFRLFdBQVcsVUFBVTtBQUMvQixVQUFJLENBQUMsUUFBUSxXQUFXO0FBQ3RCLGNBQU0sT0FBTyxJQUFJLE1BQU0sMEJBQTBCLENBQUM7QUFDbEQsZUFBTyxFQUFFLFNBQVMsS0FBQTtBQUFBLE1BQ3BCO0FBQ0EsWUFBTSxRQUFRLFFBQVEsU0FBUztBQUMvQixhQUFPLEVBQUUsU0FBUyxLQUFBO0FBQUEsSUFDcEI7QUFFQSxVQUFNLGVBQ0osUUFBUSxTQUFTO0FBQ25CLFVBQU0sT0FBTyxJQUFJLE1BQU0sWUFBWSxDQUFDO0FBQ3BDLFdBQU8sRUFBRSxTQUFTLEtBQUE7QUFBQSxFQUNwQjtBQUNGO0FDNXRDQSxNQUFNLHFCQUFxQixLQUFLLEtBQUs7QUFFckMsU0FBUyxtQkFBbUIsT0FBZTtBQUN6QyxNQUFJLGFBQWEsTUFBTSxRQUFRLE1BQU0sR0FBRyxFQUFFLFFBQVEsTUFBTSxHQUFHO0FBQzNELFFBQU0sZ0JBQWdCLFdBQVcsU0FBUztBQUMxQyxNQUFJLGtCQUFrQixFQUFHLGVBQWM7QUFBQSxXQUM5QixrQkFBa0IsRUFBRyxlQUFjO0FBQUEsV0FDbkMsa0JBQWtCLEVBQUcsZUFBYztBQUM1QyxTQUFPO0FBQ1Q7QUFFTyxTQUFTLG9CQUFvQixPQUE4QjtBQUNoRSxNQUFJO0FBQ0YsVUFBTSxXQUFXLE1BQU0sTUFBTSxHQUFHO0FBQ2hDLFFBQUksU0FBUyxTQUFTLEVBQUcsUUFBTztBQUNoQyxVQUFNLGlCQUFpQixTQUFTLENBQUM7QUFDakMsUUFBSSxDQUFDLGVBQWdCLFFBQU87QUFDNUIsVUFBTSxhQUFhLG1CQUFtQixjQUFjO0FBQ3BELFFBQUksT0FBTyxXQUFXLFNBQVMsV0FBWSxRQUFPO0FBQ2xELFVBQU0sT0FBTyxXQUFXLEtBQUssVUFBVTtBQUN2QyxVQUFNLFVBQVUsS0FBSyxNQUFNLElBQUk7QUFDL0IsUUFBSSxPQUFPLFFBQVEsUUFBUSxTQUFVLFFBQU87QUFDNUMsV0FBTyxRQUFRLE1BQU07QUFBQSxFQUN2QixRQUFRO0FBQ04sV0FBTztBQUFBLEVBQ1Q7QUFDRjtBQUVPLFNBQVMsa0JBQWtCLE9BQWU7QUFDL0MsU0FBTyxvQkFBb0IsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUNwRDtBQ3RCTyxlQUFlLE1BQU0sUUFBUSxhQUFhO0FBQzdDLE1BQUk7QUFDQSxVQUFNLE1BQU0sTUFBTSxPQUFPLElBQUksZ0JBQWdCLFlBQVksV0FBVyxDQUFDO0FBQ3JFLFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDcEIsU0FDTyxPQUFPO0FBQ1YsVUFBTSxlQUFlLHFCQUFxQixPQUFPLDZCQUE2QixHQUFHLEtBQUs7QUFBQSxFQUMxRjtBQUNKO0FDZk8sZUFBZSxzQkFBc0IsUUFBUSxhQUFhLFNBQVM7QUFDdEUsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sS0FBSyxpQ0FBaUMsU0FBUyxZQUFZLFdBQVcsQ0FBQztBQUNoRyxXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTyxtQ0FBbUMsR0FBRyxLQUFLO0FBQUEsRUFDaEc7QUFDSjtBQUNPLGVBQWUsc0JBQXNCLFFBQVEsYUFBYSxjQUFjO0FBQzNFLE1BQUk7QUFDQSxVQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUsseUJBQXlCLFlBQVksWUFBWSxDQUFBLEdBQUksWUFBWSxXQUFXLENBQUM7QUFDM0csV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8sbUNBQW1DLEdBQUcsS0FBSztBQUFBLEVBQ2hHO0FBQ0o7QUFDTyxlQUFlLHFCQUFxQixRQUFRLGFBQWEsY0FBYztBQUMxRSxNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxLQUFLLHlCQUF5QixZQUFZLFdBQVcsQ0FBQSxHQUFJLFlBQVksV0FBVyxDQUFDO0FBQzFHLFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDcEIsU0FDTyxPQUFPO0FBQ1YsVUFBTSxlQUFlLHFCQUFxQixPQUFPLGtDQUFrQyxHQUFHLEtBQUs7QUFBQSxFQUMvRjtBQUNKO0FBQ08sZUFBZSx5QkFBeUIsUUFBUSxhQUFhLGNBQWM7QUFDOUUsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sS0FBSyx5QkFBeUIsWUFBWSxlQUFlLENBQUEsR0FBSSxZQUFZLFdBQVcsQ0FBQztBQUM5RyxXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTywyQkFBMkIsR0FBRyxLQUFLO0FBQUEsRUFDeEY7QUFDSjtBQUNPLGVBQWUsb0JBQW9CLFFBQVEsYUFBYSxRQUFRO0FBQ25FLE1BQUk7QUFDQSxVQUFNLE1BQU0sTUFBTSxPQUFPLElBQUkseUJBQXlCO0FBQUEsTUFDbEQsR0FBRyxZQUFZLFdBQVc7QUFBQSxNQUMxQjtBQUFBLElBQ1osQ0FBUztBQUNELFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDcEIsU0FDTyxPQUFPO0FBQ1YsVUFBTSxlQUFlLHFCQUFxQixPQUFPLGlDQUFpQyxHQUFHLEtBQUs7QUFBQSxFQUM5RjtBQUNKO0FBQ08sZUFBZSw4QkFBOEIsUUFBUSxhQUFhLGNBQWMsU0FBUztBQUM1RixNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxLQUFLLHlCQUF5QixZQUFZLGdCQUFnQixTQUFTLFlBQVksV0FBVyxDQUFDO0FBQ3BILFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDcEIsU0FDTyxPQUFPO0FBQ1YsVUFBTSxlQUFlLHFCQUFxQixPQUFPLGtDQUFrQyxHQUFHLEtBQUs7QUFBQSxFQUMvRjtBQUNKO0FDeERPLGVBQWUsY0FBYyxRQUFRLGFBQWEsTUFBTTtBQUMzRCxRQUFNLGlCQUF5QyxxQkFBb0I7QUFDbkUsUUFBTSxVQUFVLENBQUE7QUFDaEIsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sS0FBSywyQkFBMkIsU0FBUztBQUFBLE1BQzlELEdBQUcsWUFBWSxXQUFXO0FBQUEsTUFDMUIsU0FBUztBQUFBLFFBQ0wsR0FBRyxZQUFZLFdBQVcsRUFBRTtBQUFBLFFBQzVCLG1CQUFtQjtBQUFBLE1BQ25DO0FBQUEsSUFDQSxDQUFTO0FBQ0QsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8sMEJBQTBCLEdBQUcsS0FBSztBQUFBLEVBQ3ZGO0FBQ0o7QUFDTyxlQUFlLGFBQWEsUUFBUSxhQUFhLFNBQVMsTUFBTTtBQUNuRSxRQUFNLGlCQUF5QyxxQkFBb0I7QUFDbkUsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sS0FBSywwQkFBMEIsU0FBUztBQUFBLE1BQzdELEdBQUcsWUFBWSxXQUFXO0FBQUEsTUFDMUIsU0FBUztBQUFBLFFBQ0wsR0FBRyxZQUFZLFdBQVcsRUFBRTtBQUFBLFFBQzVCLG1CQUFtQjtBQUFBLE1BQ25DO0FBQUEsSUFDQSxDQUFTO0FBQ0QsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8seUJBQXlCLEdBQUcsS0FBSztBQUFBLEVBQ3RGO0FBQ0o7QUFDTyxlQUFlLG9CQUFvQixRQUFRLGFBQWEsVUFBVSxTQUFTLE1BQU07QUFDcEYsUUFBTSxpQkFBeUMscUJBQW9CO0FBQ25FLE1BQUk7QUFDQSxVQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUssZUFBZSxRQUFRLG9CQUFvQixTQUFTO0FBQUEsTUFDOUUsR0FBRyxZQUFZLFdBQVc7QUFBQSxNQUMxQixTQUFTO0FBQUEsUUFDTCxHQUFHLFlBQVksV0FBVyxFQUFFO0FBQUEsUUFDNUIsbUJBQW1CO0FBQUEsTUFDbkM7QUFBQSxJQUNBLENBQVM7QUFDRCxXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTyw0QkFBNEIsR0FBRyxLQUFLO0FBQUEsRUFDekY7QUFDSjtBQUNPLGVBQWUsbUJBQW1CLFFBQVEsYUFBYSxVQUFVLFNBQVMsTUFBTTtBQUNuRixRQUFNLGlCQUF5QyxxQkFBb0I7QUFDbkUsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sS0FBSyxlQUFlLFFBQVEsbUJBQW1CLFNBQVM7QUFBQSxNQUM3RSxHQUFHLFlBQVksV0FBVztBQUFBLE1BQzFCLFNBQVM7QUFBQSxRQUNMLEdBQUcsWUFBWSxXQUFXLEVBQUU7QUFBQSxRQUM1QixtQkFBbUI7QUFBQSxNQUNuQztBQUFBLElBQ0EsQ0FBUztBQUNELFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDcEIsU0FDTyxPQUFPO0FBQ1YsVUFBTSxlQUFlLHFCQUFxQixPQUFPLDJCQUEyQixHQUFHLEtBQUs7QUFBQSxFQUN4RjtBQUNKO0FBQ08sZUFBZSxzQkFBc0IsUUFBUSxhQUFhLFVBQVUsU0FBUyxNQUFNO0FBQ3RGLFFBQU0saUJBQXlDLHFCQUFvQjtBQUNuRSxNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxLQUFLLGVBQWUsUUFBUSxzQkFBc0IsU0FBUztBQUFBLE1BQ2hGLEdBQUcsWUFBWSxXQUFXO0FBQUEsTUFDMUIsU0FBUztBQUFBLFFBQ0wsR0FBRyxZQUFZLFdBQVcsRUFBRTtBQUFBLFFBQzVCLG1CQUFtQjtBQUFBLE1BQ25DO0FBQUEsSUFDQSxDQUFTO0FBQ0QsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8sK0JBQStCLEdBQUcsS0FBSztBQUFBLEVBQzVGO0FBQ0o7QUFDTyxlQUFlLHFCQUFxQixRQUFRLGFBQWEsVUFBVSxTQUFTLE1BQU07QUFDckYsUUFBTSxpQkFBeUMscUJBQW9CO0FBQ25FLE1BQUk7QUFDQSxVQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUssZUFBZSxRQUFRLHFCQUFxQixTQUFTO0FBQUEsTUFDL0UsR0FBRyxZQUFZLFdBQVc7QUFBQSxNQUMxQixTQUFTO0FBQUEsUUFDTCxHQUFHLFlBQVksV0FBVyxFQUFFO0FBQUEsUUFDNUIsbUJBQW1CO0FBQUEsTUFDbkM7QUFBQSxJQUNBLENBQVM7QUFDRCxXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTyw4QkFBOEIsR0FBRyxLQUFLO0FBQUEsRUFDM0Y7QUFDSjtBQUNPLGVBQWUsMEJBQTBCLFFBQVEsYUFBYSxVQUFVLFNBQVM7QUFDcEYsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sS0FBSyxlQUFlLFFBQVEsMEJBQTBCLFNBQVMsWUFBWSxXQUFXLENBQUM7QUFDaEgsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8saUNBQWlDLEdBQUcsS0FBSztBQUFBLEVBQzlGO0FBQ0o7QUFDTyxlQUFlLHlCQUF5QixRQUFRLGFBQWEsVUFBVSxTQUFTO0FBQ25GLE1BQUk7QUFDQSxVQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUssZUFBZSxRQUFRLHlCQUF5QixTQUFTLFlBQVksV0FBVyxDQUFDO0FBQy9HLFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDcEIsU0FDTyxPQUFPO0FBQ1YsVUFBTSxlQUFlLHFCQUFxQixPQUFPLGdDQUFnQyxHQUFHLEtBQUs7QUFBQSxFQUM3RjtBQUNKO0FBd0NPLGVBQWUsa0JBQWtCLFFBQVEsYUFBYSxVQUFVO0FBQ25FLE1BQUk7QUFDQSxVQUFNLE1BQU0sTUFBTSxPQUFPLElBQUksZUFBZSxRQUFRLGFBQWEsWUFBWSxXQUFXLENBQUM7QUFDekYsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8sZ0NBQWdDLEdBQUcsS0FBSztBQUFBLEVBQzdGO0FBQ0o7QUFDTyxlQUFlLG9CQUFvQixRQUFRLGFBQWEsVUFBVSxRQUFRO0FBQzdFLE1BQUk7QUFDQSxVQUFNLE1BQU0sTUFBTSxPQUFPLElBQUksZUFBZSxRQUFRLGVBQWU7QUFBQSxNQUMvRCxHQUFHLFlBQVksV0FBVztBQUFBLE1BQzFCLFFBQVE7QUFBQSxRQUNKLFFBQVEsUUFBUTtBQUFBLFFBQ2hCLE9BQU8sUUFBUTtBQUFBLE1BQy9CO0FBQUEsSUFDQSxDQUFTO0FBQ0QsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8sZ0NBQWdDLEdBQUcsS0FBSztBQUFBLEVBQzdGO0FBQ0o7QUNqTE8sZUFBZSxpQkFBaUIsUUFBUSxhQUFhLGFBQWE7QUFDckUsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sSUFBSSx1QkFBdUIsV0FBVyxJQUFJLFlBQVksV0FBVyxDQUFDO0FBQzNGLFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDcEIsU0FDTyxPQUFPO0FBQ1YsVUFBTSxlQUFlLHFCQUFxQixPQUFPLGlDQUFpQyxHQUFHLEtBQUs7QUFBQSxFQUM5RjtBQUNKO0FBVU8sZUFBZSxvQkFBb0IsUUFBUSxhQUFhLGFBQWE7QUFDeEUsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sT0FBTyx1QkFBdUIsV0FBVyxJQUFJLFlBQVksV0FBVyxDQUFDO0FBQzlGLFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDcEIsU0FDTyxPQUFPO0FBQ1YsVUFBTSxlQUFlLHFCQUFxQixPQUFPLDBDQUEwQyxHQUFHLEtBQUs7QUFBQSxFQUN2RztBQUNKO0FDMUJPLGVBQWUsZUFBZSxRQUFRLGFBQWE7QUFDdEQsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sSUFBSSxvQkFBb0IsWUFBWSxXQUFXLENBQUM7QUFDekUsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8sNkJBQTZCLEdBQUcsS0FBSztBQUFBLEVBQzFGO0FBQ0o7QUFDTyxlQUFlLHVCQUF1QixRQUFRLGFBQWEsU0FBUztBQUN2RSxNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxLQUFLLG9CQUFvQixTQUFTLFlBQVksV0FBVyxDQUFDO0FBQ25GLFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDcEIsU0FDTyxPQUFPO0FBQ1YsVUFBTSxlQUFlLHFCQUFxQixPQUFPLHNCQUFzQixHQUFHLEtBQUs7QUFBQSxFQUNuRjtBQUNKO0FBQ08sZUFBZSx1QkFBdUIsUUFBUSxhQUFhLFNBQVM7QUFDdkUsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sT0FBTyxvQkFBb0I7QUFBQSxNQUNoRCxHQUFHLFlBQVksV0FBVztBQUFBLE1BQzFCLE1BQU07QUFBQSxJQUNsQixDQUFTO0FBQ0QsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8sd0JBQXdCLEdBQUcsS0FBSztBQUFBLEVBQ3JGO0FBQ0o7QUN1QkEsTUFBTSx5QkFBeUI7QUFFeEIsTUFBTSxjQUFjO0FBQUEsRUFDekIsWUFBb0JELFVBQXlCO0FBQXpCLFNBQUEsVUFBQUE7QUFBQSxFQUEwQjtBQUFBLEVBRXRDLHNCQUNOLFNBQ0Esa0JBQ2lCO0FBQ2pCLFFBQUksUUFBUSxXQUFXLEdBQUc7QUFDeEIsYUFBTztBQUFBLElBQ1Q7QUFFQSxVQUFNLGlCQUNKLFFBQVEsS0FBSyxDQUFDLFdBQVcsT0FBTyxhQUFhLGdCQUFnQixLQUFLO0FBQ3BFLFFBQUksZ0JBQWdCLGdCQUFnQixZQUFZO0FBQzlDLGFBQU87QUFBQSxJQUNUO0FBRUEsVUFBTSxnQkFDSixRQUFRLEtBQUssQ0FBQyxXQUFXLE9BQU8sZ0JBQWdCLFVBQVUsS0FBSztBQUNqRSxRQUFJLGVBQWU7QUFDakIsYUFBTztBQUFBLElBQ1Q7QUFFQSxXQUFPLGtCQUFrQixRQUFRLENBQUMsS0FBSztBQUFBLEVBQ3pDO0FBQUEsRUFFQSxNQUFjLHdCQUNaLFNBQ0Esa0JBQzBCO0FBQzFCLFVBQU0sMEJBQ0osb0JBQXFCLE1BQU0sS0FBSyxRQUFRLHVCQUFBO0FBQzFDLFVBQU0saUJBQWlCLEtBQUs7QUFBQSxNQUMxQjtBQUFBLE1BQ0E7QUFBQSxJQUFBO0FBR0YsVUFBTSxLQUFLLFFBQVEsdUJBQXVCLGdCQUFnQixZQUFZLElBQUk7QUFDMUUsVUFBTSxLQUFLLFFBQVEsY0FBYyxnQkFBZ0IsV0FBVyxJQUFJO0FBRWhFLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFNLGFBQWtDO0FBQ3RDLFdBQU8sS0FBSyxRQUFRLGNBQUE7QUFBQSxFQUN0QjtBQUFBLEVBRUEsTUFBTSxXQUFXLFNBQTBDO0FBQ3pELFVBQU0sdUJBQXVCLFFBQVEsY0FDaEMsUUFBUSx3QkFBd0Isa0JBQWtCLFFBQVEsV0FBVyxJQUN0RTtBQUNKLFVBQU0sVUFBc0I7QUFBQSxNQUMxQixHQUFHO0FBQUEsTUFDSDtBQUFBLElBQUE7QUFFRixVQUFNLEtBQUssUUFBUSxjQUFjLE9BQU87QUFDeEMsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVBLE1BQU0sZUFBOEI7QUFDbEMsVUFBTSxLQUFLLFFBQVEsZ0JBQUE7QUFDbkIsVUFBTSxLQUFLLFFBQVEsdUJBQXVCLElBQUk7QUFDOUMsVUFBTSxLQUFLLFFBQVEsY0FBYyxJQUFJO0FBQUEsRUFDdkM7QUFBQSxFQUVBLE1BQU0sYUFBcUM7QUFDekMsVUFBTSxVQUFVLE1BQU0sS0FBSyxRQUFRLGNBQUE7QUFDbkMsVUFBTSxtQkFBbUIsTUFBTSxLQUFLLFFBQVEsdUJBQUE7QUFDNUMsVUFBTSxpQkFBaUIsS0FBSztBQUFBLE1BQzFCO0FBQUEsTUFDQTtBQUFBLElBQUE7QUFFRixVQUFNLFVBQVUsZ0JBQWdCLFdBQVc7QUFFM0MsUUFBSSxZQUFhLE1BQU0sS0FBSyxRQUFRLGlCQUFrQjtBQUNwRCxZQUFNLEtBQUssUUFBUSxjQUFjLE9BQU87QUFBQSxJQUMxQztBQUVBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFNLG9CQUFvQixVQUFtRDtBQUMzRSxVQUFNLFVBQVUsTUFBTSxLQUFLLFFBQVEsY0FBQTtBQUNuQyxXQUFPLEtBQUssd0JBQXdCLFNBQVMsUUFBUTtBQUFBLEVBQ3ZEO0FBQUEsRUFFQSxNQUFjLHNCQUF1QztBQUNuRCxVQUFNLFVBQVUsTUFBTSxLQUFLLFFBQVEsY0FBQTtBQUNuQyxRQUFJLENBQUMsUUFBUSxjQUFjO0FBQ3pCLFlBQU0sSUFBSSxNQUFNLGlCQUFpQjtBQUFBLElBQ25DO0FBRUEsVUFBTSxnQkFDSixRQUFRLGVBQ1IsUUFBUSx3QkFDUixRQUFRLHVCQUF1QixLQUFLLElBQUEsSUFBUTtBQUU5QyxRQUFJLGVBQWU7QUFDakIsYUFBTyxRQUFRO0FBQUEsSUFDakI7QUFFQSxRQUFJO0FBQ0YsWUFBTSxZQUFZLE1BQU0saUJBQWlCLFdBQVcsUUFBUSxZQUFZO0FBQ3hFLFlBQU0sdUJBQXVCLGtCQUFrQixVQUFVLFdBQVc7QUFDcEUsWUFBTSxjQUEwQjtBQUFBLFFBQzlCLEdBQUc7QUFBQSxRQUNILGFBQWEsVUFBVTtBQUFBLFFBQ3ZCLGNBQWMsVUFBVTtBQUFBLFFBQ3hCO0FBQUEsTUFBQTtBQUVGLFlBQU0sS0FBSyxRQUFRLGNBQWMsV0FBVztBQUM1QyxhQUFPLFVBQVU7QUFBQSxJQUNuQixRQUFRO0FBQ04sWUFBTSxLQUFLLFFBQVEsZ0JBQUE7QUFDbkIsWUFBTSxJQUFJLE1BQU0saUJBQWlCO0FBQUEsSUFDbkM7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFNLFFBQVE7QUFDWixVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFVBQU0sS0FBSyxNQUFNLE1BQU0sV0FBVyxXQUFXO0FBQzdDLFVBQU0sS0FBSyxRQUFRLGNBQWMsR0FBRyxPQUFPO0FBQzNDLFVBQU0sS0FBSyxRQUFRLDRCQUE0QixHQUFHLHFCQUFxQjtBQUN2RSxVQUFNLEtBQUssUUFBUSxzQkFBc0IsR0FBRyxlQUFlO0FBQzNELFVBQU0sS0FBSyx3QkFBd0IsR0FBRyxPQUFPO0FBRTdDLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFNLGdCQUFnQjtBQUNwQixVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU8sY0FBYyxXQUFXLFdBQVc7QUFBQSxFQUM3QztBQUFBLEVBRUEsTUFBTSxhQUFhLFNBQW9DO0FBQ3JELFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyxhQUFhLFdBQVcsYUFBYSxPQUFPO0FBQUEsRUFDckQ7QUFBQSxFQUVBLE1BQU0sa0JBQ0osVUFDQSxTQUNBO0FBQ0EsVUFBTSxjQUFjLE1BQU0sS0FBSyxvQkFBQTtBQUMvQixXQUFPLG9CQUFvQixXQUFXLGFBQWEsVUFBVSxPQUFPO0FBQUEsRUFDdEU7QUFBQSxFQUVBLE1BQU0saUJBQWlCLFVBQWtCLFNBQThCO0FBQ3JFLFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyxtQkFBbUIsV0FBVyxhQUFhLFVBQVUsT0FBTztBQUFBLEVBQ3JFO0FBQUEsRUFFQSxNQUFNLG9CQUNKLFVBQ0EsU0FDQTtBQUNBLFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyxzQkFBc0IsV0FBVyxhQUFhLFVBQVUsT0FBTztBQUFBLEVBQ3hFO0FBQUEsRUFFQSxNQUFNLG1CQUFtQixVQUFrQixTQUE4QjtBQUN2RSxVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU8scUJBQXFCLFdBQVcsYUFBYSxVQUFVLE9BQU87QUFBQSxFQUN2RTtBQUFBLEVBRUEsTUFBTSwwQkFDSixVQUNBLFNBQ0E7QUFDQSxVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU8sMEJBQTBCLFdBQVcsYUFBYSxVQUFVLE9BQU87QUFBQSxFQUM1RTtBQUFBLEVBRUEsTUFBTSx5QkFDSixVQUNBLFNBQ0E7QUFDQSxVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU8seUJBQXlCLFdBQVcsYUFBYSxVQUFVLE9BQU87QUFBQSxFQUMzRTtBQUFBLEVBRUEsTUFBTSxrQkFBa0IsVUFBa0I7QUFDeEMsVUFBTSxjQUFjLE1BQU0sS0FBSyxvQkFBQTtBQUMvQixXQUFPLGtCQUFrQixXQUFXLGFBQWEsUUFBUTtBQUFBLEVBQzNEO0FBQUEsRUFFQSxNQUFNLG9CQUNKLFVBQ0EsUUFDQTtBQUNBLFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyxvQkFBb0IsV0FBVyxhQUFhLFVBQVUsTUFBTTtBQUFBLEVBQ3JFO0FBQUEsRUFFQSxNQUFNLGlCQUFpQixhQUFxQjtBQUMxQyxVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU8saUJBQWlCLFdBQVcsYUFBYSxXQUFXO0FBQUEsRUFDN0Q7QUFBQSxFQUVBLE1BQU0sb0JBQW9CLGFBQXFCO0FBQzdDLFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyxvQkFBb0IsV0FBVyxhQUFhLFdBQVc7QUFBQSxFQUNoRTtBQUFBLEVBRUEsTUFBTSxrQkFBa0I7QUFDdEIsVUFBTSxjQUFjLE1BQU0sS0FBSyxvQkFBQTtBQUMvQixXQUFPLGVBQWUsV0FBVyxXQUFXO0FBQUEsRUFDOUM7QUFBQSxFQUVBLE1BQU0sa0JBQWtCLFNBQW1DO0FBQ3pELFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyx1QkFBdUIsV0FBVyxhQUFhLE9BQU87QUFBQSxFQUMvRDtBQUFBLEVBRUEsTUFBTSxrQkFBa0IsU0FBbUM7QUFDekQsVUFBTSxjQUFjLE1BQU0sS0FBSyxvQkFBQTtBQUMvQixXQUFPLHVCQUF1QixXQUFXLGFBQWEsT0FBTztBQUFBLEVBQy9EO0FBQUEsRUFFQSxNQUFNLHNCQUFzQixTQUF1QztBQUNqRSxVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU8sc0JBQXNCLFdBQVcsYUFBYSxPQUFPO0FBQUEsRUFDOUQ7QUFBQSxFQUVBLE1BQU0sc0JBQXNCLGNBQXNCO0FBQ2hELFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyxzQkFBc0IsV0FBVyxhQUFhLFlBQVk7QUFBQSxFQUNuRTtBQUFBLEVBRUEsTUFBTSxxQkFBcUIsY0FBc0I7QUFDL0MsVUFBTSxjQUFjLE1BQU0sS0FBSyxvQkFBQTtBQUMvQixXQUFPLHFCQUFxQixXQUFXLGFBQWEsWUFBWTtBQUFBLEVBQ2xFO0FBQUEsRUFFQSxNQUFNLHlCQUF5QixjQUFzQjtBQUNuRCxVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU8seUJBQXlCLFdBQVcsYUFBYSxZQUFZO0FBQUEsRUFDdEU7QUFBQSxFQUVBLE1BQU0sb0JBQW9CLFFBQW1DO0FBQzNELFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyxvQkFBb0IsV0FBVyxhQUFhLE1BQU07QUFBQSxFQUMzRDtBQUFBLEVBRUEsTUFBTSw4QkFDSixjQUNBLFNBQ0E7QUFDQSxVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU87QUFBQSxNQUNMO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFBQTtBQUFBLEVBRUo7QUFDRjtBQy9TQSxRQUFRLElBQUksNENBQTRDO0FBQ3hELFFBQVE7QUFBQSxFQUNOO0FBQUEsRUFDQSxLQUFLLGNBQWMsUUFBUTtBQUM3QjtBQUdBLElBQUk7QUFFSixTQUFTLHlCQUF5QjtBQUNoQyxNQUFJLG1CQUFtQjtBQUNyQixrQkFBYyxpQkFBaUI7QUFBQSxFQUNqQztBQUNBLHNCQUFvQixZQUFZLE1BQU07QUFDcEMsWUFBUSxJQUFJLDhCQUE4QjtBQUFBLEVBQzVDLEdBQUcsR0FBSztBQUNWO0FBRUEsdUJBQUE7QUFFQSxLQUFLLGlCQUFpQixTQUFTLENBQUMsVUFBVTtBQUN4QyxVQUFRLE1BQU0sZ0NBQWdDLE1BQU0sS0FBSztBQUN6RCxVQUFRLE1BQU0sK0JBQStCLE1BQU0sT0FBTztBQUMxRCxVQUFRLE1BQU0sNkJBQTZCLE1BQU0sT0FBTyxLQUFLO0FBQzdELFVBQVE7QUFBQSxJQUNOO0FBQUEsSUFDQSxNQUFNO0FBQUEsSUFDTixNQUFNO0FBQUEsSUFDTixNQUFNO0FBQUEsRUFBQTtBQUVWLENBQUM7QUFFRCxLQUFLLGlCQUFpQixzQkFBc0IsQ0FBQyxVQUFVO0FBQ3JELFVBQVEsTUFBTSw2Q0FBNkMsTUFBTSxNQUFNO0FBQ3ZFLFVBQVEsTUFBTSxpQ0FBaUMsTUFBTSxRQUFRLEtBQUs7QUFDbEUsVUFBUSxNQUFNLHlCQUF5QixNQUFNLE9BQU87QUFDdEQsQ0FBQztBQUdELE1BQU0sVUFBVSxJQUFJLGVBQUE7QUFDcEIsTUFBTSxnQkFBZ0IsSUFBSSxjQUFjLE9BQU87QUFDL0MsTUFBTSxpQkFBaUIsSUFBSSxlQUFlLFNBQVMsYUFBYTtBQUVoRSxlQUFlLHNCQUFzQjtBQUNuQyxVQUFRLElBQUksd0NBQXdDO0FBQ3BELFFBQU0sUUFBUSxJQUFJLENBQUMsUUFBUSxjQUFjLG9CQUFBLENBQXFCLENBQUM7QUFDL0QsVUFBUSxJQUFJLG9DQUFvQztBQUNsRDtBQUVBLE9BQU8sUUFBUSxZQUFZLFlBQVksWUFBWTtBQUNqRCxVQUFRLElBQUksa0NBQWtDO0FBQzlDLFFBQU0sb0JBQUE7QUFDUixDQUFDO0FBTUQsT0FBTyxRQUFRLFVBQVU7QUFBQSxFQUN2QixDQUNFLFNBQ0EsUUFDQSxpQkFDRztBQUNILFlBQVEsSUFBSSxrQ0FBa0MsUUFBUSxJQUFJO0FBQzFELFlBQVE7QUFBQSxNQUNOO0FBQUEsTUFDQSxhQUFhLFVBQVUsUUFBUSxVQUFVO0FBQUEsSUFBQTtBQUUzQyxZQUFRLElBQUksd0JBQXdCLE9BQU8sS0FBSyxNQUFNLFNBQVMsT0FBTyxHQUFHO0FBRXpFLFFBQUk7QUFDRixxQkFDRyxjQUFjLFNBQVMsTUFBTSxFQUM3QixLQUFLLENBQUMsYUFBYTtBQUNsQixnQkFBUTtBQUFBLFVBQ047QUFBQSxVQUNBLFFBQVE7QUFBQSxRQUFBO0FBRVYscUJBQWEsRUFBRSxTQUFTLE1BQU0sTUFBTSxVQUFVO0FBQUEsTUFDaEQsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxVQUFVO0FBQ2hCLGdCQUFRLE1BQU0sdUNBQXVDLEtBQUs7QUFDMUQsZ0JBQVEsTUFBTSw0QkFBNEIsTUFBTSxZQUFZLElBQUk7QUFDaEUsZ0JBQVEsTUFBTSwrQkFBK0IsTUFBTSxPQUFPO0FBQzFELGdCQUFRLE1BQU0sNkJBQTZCLE1BQU0sS0FBSztBQUV0RCxxQkFBYTtBQUFBLFVBQ1gsU0FBUztBQUFBLFVBQ1QsT0FBTyxNQUFNLFdBQVc7QUFBQSxRQUFBLENBQ3pCO0FBQUEsTUFDSCxDQUFDO0FBQUEsSUFDTCxTQUFTLE9BQU87QUFDZCxjQUFRO0FBQUEsUUFDTjtBQUFBLFFBQ0E7QUFBQSxNQUFBO0FBRUYsbUJBQWE7QUFBQSxRQUNYLFNBQVM7QUFBQSxRQUNULE9BQU8saUJBQWlCLFFBQVEsTUFBTSxVQUFVO0FBQUEsTUFBQSxDQUNqRDtBQUFBLElBQ0g7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsT0FBTyxRQUFRLFVBQVUsWUFBWSxZQUFZO0FBQy9DLFVBQVEsSUFBSSxtREFBbUQ7QUFDL0QsUUFBTSxvQkFBQTtBQUNSLENBQUM7In0=
