import { D as DEFAULT_SETTINGS, S as STORAGE_KEYS, s as sleep, k as authHeaders, w as withErrorCause, l as getAxiosErrorMessage, m as createIdempotencyKey, n as refreshWithToken, c as apiClient, o as initializeApiClient } from "../chunks/utils.uTfVa1nz.js";
const DEFAULT_API_SESSION = {
  accessToken: null,
  refreshToken: null,
  accessTokenExpiresAt: null,
  credentialId: null,
  rpId: null
};
function readStorageKey(result, key, fallback) {
  const value = result[key];
  return value ?? fallback;
}
function normalizeOrigin(value) {
  try {
    const url = new URL(value);
    const protocol = url.protocol.toLowerCase();
    const hostname = url.hostname.toLowerCase();
    const port = url.port;
    const includePort = port.length > 0 && !(protocol === "https:" && port === "443" || protocol === "http:" && port === "80");
    const host = includePort ? `${hostname}:${port}` : hostname;
    return `${protocol}//${host}`;
  } catch {
    return value.trim().toLowerCase();
  }
}
class StorageManager {
  buildConnectedSiteKey(entry) {
    return [
      entry.walletScope,
      entry.walletAddress.toLowerCase(),
      String(entry.chainId),
      entry.normalizedOrigin
    ].join("|");
  }
  isConnectedSiteRecord(value) {
    if (!value || typeof value !== "object") return false;
    const record = value;
    return typeof record.connectionId === "string" && typeof record.origin === "string" && typeof record.normalizedOrigin === "string" && typeof record.host === "string" && (record.walletScope === "pocket" || record.walletScope === "vault") && typeof record.walletAddress === "string" && typeof record.chainId === "number";
  }
  async initialize() {
    const existing = await this.getAll();
    if (!existing.settings) {
      await chrome.storage.local.set({
        [STORAGE_KEYS.SETTINGS]: DEFAULT_SETTINGS,
        [STORAGE_KEYS.CONNECTED_SITES]: {},
        [STORAGE_KEYS.API_SESSION]: DEFAULT_API_SESSION,
        [STORAGE_KEYS.API_POCKETS]: [],
        [STORAGE_KEYS.API_SELECTED_POCKET_ID]: null,
        [STORAGE_KEYS.API_PENDING_USER_OPERATIONS]: [],
        [STORAGE_KEYS.API_DAPP_CONNECTIONS]: [],
        [STORAGE_KEYS.API_CHAIN_ID]: null,
        [STORAGE_KEYS.API_VAULT]: null
      });
      console.log("[Storage] Initialized with defaults");
    }
  }
  async getAll() {
    return chrome.storage.local.get(null);
  }
  async clearAll() {
    await chrome.storage.local.clear();
  }
  async getSettings() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.SETTINGS
    );
    return readStorageKey(result, STORAGE_KEYS.SETTINGS, DEFAULT_SETTINGS);
  }
  async setSettings(settings) {
    await chrome.storage.local.set({ [STORAGE_KEYS.SETTINGS]: settings });
  }
  async updateSettings(updates) {
    const settings = await this.getSettings();
    await this.setSettings({ ...settings, ...updates });
  }
  // Connected sites management
  async getConnectedSites() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.CONNECTED_SITES
    );
    const raw = readStorageKey(result, STORAGE_KEYS.CONNECTED_SITES, {});
    const entries = Object.entries(raw);
    const next = {};
    for (const [key, value] of entries) {
      if (!this.isConnectedSiteRecord(value)) continue;
      next[key] = value;
    }
    return next;
  }
  async addConnectedSite(site) {
    const sites = await this.getConnectedSites();
    const normalizedOrigin = normalizeOrigin(
      site.normalizedOrigin || site.origin
    );
    const now = Date.now();
    const key = this.buildConnectedSiteKey({
      normalizedOrigin,
      walletScope: site.walletScope,
      walletAddress: site.walletAddress,
      chainId: site.chainId
    });
    sites[key] = {
      ...site,
      origin: normalizeOrigin(site.origin),
      normalizedOrigin,
      connectedAt: site.connectedAt || now,
      lastUsedAt: site.lastUsedAt || now
    };
    await chrome.storage.local.set({ [STORAGE_KEYS.CONNECTED_SITES]: sites });
  }
  async removeConnectedSite(connectionId) {
    const sites = await this.getConnectedSites();
    for (const [key, entry] of Object.entries(sites)) {
      if (entry.connectionId !== connectionId) continue;
      delete sites[key];
    }
    await chrome.storage.local.set({ [STORAGE_KEYS.CONNECTED_SITES]: sites });
  }
  async removeConnectedSitesForOrigin(origin, walletAddress) {
    const sites = await this.getConnectedSites();
    const normalizedOrigin = normalizeOrigin(origin);
    const normalizedWalletAddress = walletAddress?.toLowerCase() ?? null;
    for (const [key, entry] of Object.entries(sites)) {
      if (entry.normalizedOrigin !== normalizedOrigin) continue;
      if (normalizedWalletAddress && entry.walletAddress.toLowerCase() !== normalizedWalletAddress) {
        continue;
      }
      delete sites[key];
    }
    await chrome.storage.local.set({ [STORAGE_KEYS.CONNECTED_SITES]: sites });
  }
  async findConnectedSite(params) {
    const sites = await this.getConnectedSites();
    const normalizedOrigin = normalizeOrigin(params.origin);
    const normalizedWalletAddress = params.walletAddress.toLowerCase();
    const match = Object.values(sites).find(
      (site) => site.normalizedOrigin === normalizedOrigin && site.walletScope === params.walletScope && site.chainId === params.chainId && site.walletAddress.toLowerCase() === normalizedWalletAddress
    );
    return match ?? null;
  }
  async isConnectedSite(params) {
    return await this.findConnectedSite(params) !== null;
  }
  async touchConnectedSite(connectionId) {
    const sites = await this.getConnectedSites();
    let didUpdate = false;
    for (const [key, site] of Object.entries(sites)) {
      if (site.connectionId !== connectionId) continue;
      sites[key] = {
        ...site,
        lastUsedAt: Date.now()
      };
      didUpdate = true;
    }
    if (didUpdate) {
      await chrome.storage.local.set({ [STORAGE_KEYS.CONNECTED_SITES]: sites });
    }
  }
  // API session management (new backend)
  async getApiSession() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.API_SESSION
    );
    return readStorageKey(
      result,
      STORAGE_KEYS.API_SESSION,
      DEFAULT_API_SESSION
    );
  }
  async setApiSession(session) {
    await chrome.storage.local.set({ [STORAGE_KEYS.API_SESSION]: session });
  }
  async clearApiSession() {
    await this.setApiSession(DEFAULT_API_SESSION);
  }
  async getApiPockets() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.API_POCKETS
    );
    return readStorageKey(result, STORAGE_KEYS.API_POCKETS, []);
  }
  async setApiPockets(pockets) {
    await chrome.storage.local.set({ [STORAGE_KEYS.API_POCKETS]: pockets });
  }
  async getApiSelectedPocketId() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.API_SELECTED_POCKET_ID
    );
    return readStorageKey(result, STORAGE_KEYS.API_SELECTED_POCKET_ID, null);
  }
  async setApiSelectedPocketId(pocketId) {
    await chrome.storage.local.set({
      [STORAGE_KEYS.API_SELECTED_POCKET_ID]: pocketId
    });
  }
  async getApiPendingUserOperations() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.API_PENDING_USER_OPERATIONS
    );
    return readStorageKey(
      result,
      STORAGE_KEYS.API_PENDING_USER_OPERATIONS,
      []
    );
  }
  async setApiPendingUserOperations(operations) {
    await chrome.storage.local.set({
      [STORAGE_KEYS.API_PENDING_USER_OPERATIONS]: operations
    });
  }
  async getApiDappConnections() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.API_DAPP_CONNECTIONS
    );
    return readStorageKey(
      result,
      STORAGE_KEYS.API_DAPP_CONNECTIONS,
      []
    );
  }
  async setApiDappConnections(connections) {
    await chrome.storage.local.set({
      [STORAGE_KEYS.API_DAPP_CONNECTIONS]: connections
    });
  }
  async getApiChainId() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.API_CHAIN_ID
    );
    return readStorageKey(result, STORAGE_KEYS.API_CHAIN_ID, null);
  }
  async setApiChainId(chainId) {
    await chrome.storage.local.set({ [STORAGE_KEYS.API_CHAIN_ID]: chainId });
  }
  async getApiVault() {
    const result = await chrome.storage.local.get(
      STORAGE_KEYS.API_VAULT
    );
    return readStorageKey(result, STORAGE_KEYS.API_VAULT, null);
  }
  async setApiVault(vault) {
    await chrome.storage.local.set({ [STORAGE_KEYS.API_VAULT]: vault });
  }
}
const DAPP_CONFIRM_TIMEOUT_MS = 5 * 6e4;
const CONNECT_TIMEOUT_MS = 2 * 6e4;
const CONNECT_POLL_INTERVAL_MS = 500;
class MessageHandler {
  constructor(storage2, api) {
    this.storage = storage2;
    this.api = api;
    chrome.windows.onRemoved.addListener((windowId) => {
      for (const [requestId, entry] of this.pendingDappConnects) {
        if (entry.windowId !== windowId) continue;
        clearTimeout(entry.timeoutId);
        this.pendingDappConnects.delete(requestId);
        entry.reject(new Error("Connection confirmation was closed"));
      }
      for (const [operationId, entry] of this.pendingDappTransactions) {
        if (entry.windowId !== windowId) continue;
        clearTimeout(entry.timeoutId);
        this.pendingDappTransactions.delete(operationId);
        entry.reject(new Error("Transaction confirmation was closed"));
      }
      for (const [requestId, entry] of this.pendingDappSignatures) {
        if (entry.windowId !== windowId) continue;
        clearTimeout(entry.timeoutId);
        this.pendingDappSignatures.delete(requestId);
        entry.reject(new Error("Signature confirmation was closed"));
      }
    });
  }
  pendingDappConnects = /* @__PURE__ */ new Map();
  pendingDappTransactions = /* @__PURE__ */ new Map();
  pendingDappSignatures = /* @__PURE__ */ new Map();
  async handleMessage(message, sender) {
    console.log("[MessageHandler] Handling:", message.type);
    switch (message.type) {
      case "CONNECT_SITE":
        return this.handleConnectSite(message.payload, sender);
      case "DISCONNECT_SITE":
        return this.handleDisconnectSite(message.payload);
      case "SEND_TRANSACTION":
        return this.handleSendTransaction(message.payload, sender);
      case "SIGN_MESSAGE":
        return this.handleSignMessage(message.payload, sender);
      case "CLEAR_ALL_DATA":
        return this.handleClearAllData();
      case "API_GET_SESSION":
        return this.api.getSession();
      case "API_SET_SESSION":
        return this.api.setSession(message.payload);
      case "API_CLEAR_SESSION":
        return this.api.clearSession();
      case "API_GET_CHAIN_ID":
        return this.api.getChainId();
      case "API_USERS_ME":
        return this.api.getMe();
      case "API_POCKET_SELECT":
        await this.api.setSelectedPocketId(message.payload.pocketId);
        return { pocketId: message.payload.pocketId };
      case "API_POCKET_PREPARE":
        return this.api.preparePocket();
      case "API_POCKET_SUBMIT":
        return this.api.submitPocket(message.payload);
      case "API_POCKET_SEND_PREPARE":
        return this.api.preparePocketSend(
          message.payload.pocketId,
          message.payload.request
        );
      case "API_POCKET_SEND_SUBMIT":
        return this.api.submitPocketSend(
          message.payload.pocketId,
          message.payload.request
        );
      case "API_POCKET_CUSTOM_PREPARE":
        return this.api.preparePocketCustom(
          message.payload.pocketId,
          message.payload.request
        );
      case "API_POCKET_CUSTOM_SUBMIT":
        return this.api.submitPocketCustom(
          message.payload.pocketId,
          message.payload.request
        );
      case "API_POCKET_PERSONAL_SIGN_PREPARE":
        return this.api.preparePocketPersonalSign(
          message.payload.pocketId,
          message.payload.request
        );
      case "API_POCKET_PERSONAL_SIGN_SUBMIT":
        return this.api.submitPocketPersonalSign(
          message.payload.pocketId,
          message.payload.request
        );
      case "API_POCKET_BALANCES":
        return this.api.getPocketBalances(message.payload.pocketId);
      case "API_POCKET_ACTIVITIES":
        return this.api.getPocketActivities(message.payload.pocketId, {
          cursor: message.payload.cursor,
          limit: message.payload.limit
        });
      case "API_USEROP_GET":
        return this.api.getUserOperation(message.payload.operationId);
      case "API_USEROP_CANCEL":
        return this.api.cancelUserOperation(message.payload.operationId);
      case "API_DAPP_CONNECT_CONTEXT":
        return this.handleApiDappConnectContext(message.payload);
      case "API_DAPP_CONNECT_RESULT":
        return this.handleApiDappConnectResult(message.payload);
      case "API_DAPP_TX_CONTEXT":
        return this.handleApiDappTxContext(message.payload);
      case "API_DAPP_TX_RESULT":
        return this.handleApiDappTxResult(message.payload);
      case "API_DAPP_SIGN_CONTEXT":
        return this.handleApiDappSignContext(message.payload);
      case "API_DAPP_SIGN_RESULT":
        return this.handleApiDappSignResult(message.payload);
      case "API_ADDRESS_BOOK_LIST":
        return this.api.listAddressBook();
      case "API_ADDRESS_BOOK_UPSERT":
        return this.api.upsertAddressBook(
          message.payload
        );
      case "API_ADDRESS_BOOK_DELETE":
        return this.api.deleteAddressBook(
          message.payload
        );
      default:
        throw new Error(
          `Unknown message type: ${message.type ?? "unknown"}`
        );
    }
  }
  normalizeOrigin(value) {
    try {
      const url = new URL(value);
      const protocol = url.protocol.toLowerCase();
      const hostname = url.hostname.toLowerCase();
      const port = url.port;
      const includePort = port.length > 0 && !(protocol === "https:" && port === "443" || protocol === "http:" && port === "80");
      const host = includePort ? `${hostname}:${port}` : hostname;
      return `${protocol}//${host}`;
    } catch {
      return value.trim().toLowerCase();
    }
  }
  toConnectedSiteRecord(connection) {
    const now = Date.now();
    return {
      connectionId: connection.connectionId,
      origin: connection.origin,
      normalizedOrigin: connection.normalizedOrigin,
      host: connection.host,
      walletScope: connection.walletScope,
      walletId: connection.walletId,
      walletAddress: connection.walletAddress,
      chainId: connection.chainId,
      trustLevel: connection.trustLevel,
      connectedAt: connection.connectedAt ? Date.parse(connection.connectedAt) || now : now,
      lastUsedAt: now
    };
  }
  buildUnknownSigningWarning(host) {
    return {
      tone: "soft",
      title: "Unknown dApp",
      message: `${host} is not in the trusted list. Review details carefully before signing.`
    };
  }
  async recordSignEvent(connectionId, kind, outcome) {
    try {
      await this.api.recordDappConnectionSignEvent(connectionId, {
        kind,
        outcome
      });
    } catch (error) {
      console.warn("[MessageHandler] Failed to record dApp sign event:", error);
    }
  }
  async resolveConnectedSiteForPocket(origin, pocket) {
    const local = await this.storage.findConnectedSite({
      origin,
      walletAddress: pocket.address,
      chainId: pocket.chainId,
      walletScope: "pocket"
    });
    if (local) {
      return local;
    }
    try {
      const normalizedOrigin = this.normalizeOrigin(origin);
      const remote = await this.api.listDappConnections({
        walletScope: "pocket",
        walletId: pocket.pocketId,
        status: "connected"
      });
      const match = remote.connections.find(
        (connection) => connection.normalizedOrigin === normalizedOrigin
      );
      if (!match) {
        return null;
      }
      const record = this.toConnectedSiteRecord(match);
      await this.storage.addConnectedSite(record);
      return record;
    } catch (error) {
      console.warn("[MessageHandler] Failed to resolve connected dApp:", error);
      return null;
    }
  }
  async handleConnectSite(payload, sender) {
    const rawOrigin = payload.origin || sender.origin || sender.url;
    if (!rawOrigin) {
      throw new Error("No origin provided");
    }
    const origin = this.normalizeOrigin(rawOrigin);
    const pocket = await this.ensurePrimaryPocketReady();
    if (!pocket) {
      throw new Error(
        "Wallet not ready. Sign in to the extension and create a pocket."
      );
    }
    const prepared = await this.api.prepareDappConnection({
      origin,
      walletScope: "pocket",
      walletAddress: pocket.address,
      chainId: pocket.chainId,
      pocketId: pocket.pocketId
    });
    if (prepared.connection.trustLevel === "blocked") {
      throw new Error(prepared.warningMessage || "This dApp is blocked");
    }
    if (prepared.alreadyConnected && prepared.connection.status === "connected") {
      await this.storage.addConnectedSite(
        this.toConnectedSiteRecord(prepared.connection)
      );
      return {
        connected: true,
        accounts: [pocket.address]
      };
    }
    const requestId = crypto.randomUUID();
    const windowId = await this.openConnectConfirmWindow(requestId);
    let approved = false;
    try {
      approved = await this.awaitDappConnectConfirmation(requestId, {
        windowId,
        origin,
        walletAddress: pocket.address,
        connection: prepared.connection,
        warning: {
          tone: prepared.warningTone,
          title: prepared.warningTitle,
          message: prepared.warningMessage
        }
      });
    } catch (error) {
      await this.api.rejectDappConnection(prepared.connection.connectionId).catch(() => void 0);
      throw error;
    }
    if (!approved) {
      await this.api.rejectDappConnection(prepared.connection.connectionId).catch(() => void 0);
      throw new Error("User rejected connection");
    }
    const confirmed = await this.api.confirmDappConnection(
      prepared.connection.connectionId
    );
    await this.storage.addConnectedSite(
      this.toConnectedSiteRecord(confirmed.connection)
    );
    return {
      connected: true,
      accounts: [pocket.address]
    };
  }
  async handleDisconnectSite(payload) {
    const pocket = await this.getPrimaryPocket();
    if (!pocket) {
      await this.storage.removeConnectedSitesForOrigin(payload.origin);
      return { success: true };
    }
    const site = await this.storage.findConnectedSite({
      origin: payload.origin,
      walletAddress: pocket.address,
      chainId: pocket.chainId,
      walletScope: "pocket"
    });
    if (site) {
      await this.api.disconnectDappConnection(site.connectionId).catch((error) => {
        console.warn("[MessageHandler] Failed to disconnect dApp:", error);
      });
      await this.storage.removeConnectedSite(site.connectionId);
    }
    await this.storage.removeConnectedSitesForOrigin(
      payload.origin,
      pocket.address
    );
    return { success: true };
  }
  async handleSendTransaction(payload, sender) {
    const origin = sender.origin || sender.url;
    if (!origin) {
      throw new Error("No origin provided");
    }
    if (!payload.to) {
      throw new Error("Invalid transaction parameters");
    }
    const pocket = await this.getPrimaryPocket();
    if (!pocket) {
      throw new Error("No pocket available");
    }
    const connection = await this.resolveConnectedSiteForPocket(origin, pocket);
    if (!connection) {
      throw new Error("Site not connected");
    }
    if (connection.trustLevel === "blocked") {
      throw new Error("This dApp is blocked");
    }
    await this.storage.touchConnectedSite(connection.connectionId);
    void this.recordSignEvent(
      connection.connectionId,
      "transaction",
      "requested"
    );
    const warning = connection.trustLevel === "unknown" ? this.buildUnknownSigningWarning(connection.host) : null;
    const prepared = await this.api.preparePocketCustom(pocket.pocketId, {
      metaTransactions: [
        {
          to: payload.to,
          value: payload.value || "0x0",
          data: payload.data || "0x"
        }
      ]
    });
    const windowId = await this.openConfirmWindow(prepared.operationId);
    return this.awaitDappConfirmation(prepared.operationId, {
      windowId,
      origin: connection.origin,
      connection,
      warning
    });
  }
  async handleSignMessage(payload, sender) {
    const origin = sender.origin || sender.url;
    if (!origin) {
      throw new Error("No origin provided");
    }
    if (typeof payload.message !== "string") {
      throw new Error("Invalid sign message parameters");
    }
    const pocket = await this.getPrimaryPocket();
    if (!pocket) {
      throw new Error("No pocket available");
    }
    const connection = await this.resolveConnectedSiteForPocket(origin, pocket);
    if (!connection) {
      throw new Error("Site not connected");
    }
    if (connection.trustLevel === "blocked") {
      throw new Error("This dApp is blocked");
    }
    const requestedAddress = payload.address?.toLowerCase();
    if (requestedAddress && requestedAddress !== pocket.address.toLowerCase()) {
      throw new Error("Requested account does not match selected pocket");
    }
    await this.storage.touchConnectedSite(connection.connectionId);
    void this.recordSignEvent(connection.connectionId, "message", "requested");
    const warning = connection.trustLevel === "unknown" ? this.buildUnknownSigningWarning(connection.host) : null;
    const requestId = crypto.randomUUID();
    const windowId = await this.openSignConfirmWindow(requestId);
    return this.awaitDappSignConfirmation(requestId, {
      windowId,
      message: payload.message,
      address: pocket.address,
      origin: connection.origin,
      pocketId: pocket.pocketId,
      connection,
      warning
    });
  }
  async handleClearAllData() {
    await this.storage.clearAll();
    return { success: true };
  }
  async getPrimaryPocket() {
    const session = await this.storage.getApiSession();
    if (!session.refreshToken) {
      return null;
    }
    let pockets = await this.storage.getApiPockets();
    if (pockets.length === 0) {
      try {
        await this.api.getMe();
      } catch (error) {
        console.warn("[MessageHandler] Failed to refresh pockets:", error);
      }
      pockets = await this.storage.getApiPockets();
    }
    const selectedId = await this.storage.getApiSelectedPocketId();
    return pockets.find((entry) => entry.pocketId === selectedId) ?? pockets[0] ?? null;
  }
  async ensurePrimaryPocketReady() {
    const existing = await this.getPrimaryPocket();
    if (existing) {
      return existing;
    }
    const windowId = await this.openExtensionWindow();
    try {
      return this.awaitPrimaryPocket(CONNECT_TIMEOUT_MS);
    } finally {
      if (windowId) {
        chrome.windows.remove(windowId, () => void 0);
      }
    }
  }
  async awaitPrimaryPocket(timeoutMs) {
    const start = Date.now();
    while (Date.now() - start < timeoutMs) {
      const pocket = await this.getPrimaryPocket();
      if (pocket) {
        return pocket;
      }
      await sleep(CONNECT_POLL_INTERVAL_MS);
    }
    return null;
  }
  async openConfirmWindow(operationId) {
    const url = chrome.runtime.getURL(
      `popup/index.html#/confirm-tx?operationId=${encodeURIComponent(
        operationId
      )}`
    );
    return new Promise((resolve) => {
      chrome.windows.create(
        {
          url,
          type: "popup",
          width: 420,
          height: 720,
          focused: true
        },
        (window) => {
          resolve(window?.id);
        }
      );
    });
  }
  async openConnectConfirmWindow(requestId) {
    const url = chrome.runtime.getURL(
      `popup/index.html#/confirm-connect?requestId=${encodeURIComponent(
        requestId
      )}`
    );
    return new Promise((resolve) => {
      chrome.windows.create(
        {
          url,
          type: "popup",
          width: 420,
          height: 720,
          focused: true
        },
        (window) => {
          resolve(window?.id);
        }
      );
    });
  }
  async openSignConfirmWindow(requestId) {
    const url = chrome.runtime.getURL(
      `popup/index.html#/confirm-sign?requestId=${encodeURIComponent(
        requestId
      )}`
    );
    return new Promise((resolve) => {
      chrome.windows.create(
        {
          url,
          type: "popup",
          width: 420,
          height: 720,
          focused: true
        },
        (window) => {
          resolve(window?.id);
        }
      );
    });
  }
  async openExtensionWindow() {
    const url = chrome.runtime.getURL("popup/index.html#/");
    return new Promise((resolve) => {
      chrome.windows.create(
        {
          url,
          type: "popup",
          width: 420,
          height: 720,
          focused: true
        },
        (window) => {
          resolve(window?.id);
        }
      );
    });
  }
  awaitDappConnectConfirmation(requestId, payload) {
    if (this.pendingDappConnects.has(requestId)) {
      this.pendingDappConnects.get(requestId)?.reject(new Error("Duplicate connect request"));
      this.pendingDappConnects.delete(requestId);
    }
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        this.pendingDappConnects.delete(requestId);
        reject(new Error("Connection confirmation timed out"));
      }, DAPP_CONFIRM_TIMEOUT_MS);
      this.pendingDappConnects.set(requestId, {
        resolve,
        reject,
        timeoutId,
        ...payload
      });
    });
  }
  awaitDappConfirmation(operationId, payload) {
    if (this.pendingDappTransactions.has(operationId)) {
      this.pendingDappTransactions.get(operationId)?.reject(new Error("Duplicate transaction request"));
      this.pendingDappTransactions.delete(operationId);
    }
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        this.pendingDappTransactions.delete(operationId);
        reject(new Error("Transaction confirmation timed out"));
      }, DAPP_CONFIRM_TIMEOUT_MS);
      this.pendingDappTransactions.set(operationId, {
        resolve,
        reject,
        timeoutId,
        ...payload
      });
    });
  }
  awaitDappSignConfirmation(requestId, payload) {
    if (this.pendingDappSignatures.has(requestId)) {
      this.pendingDappSignatures.get(requestId)?.reject(new Error("Duplicate sign request"));
      this.pendingDappSignatures.delete(requestId);
    }
    return new Promise((resolve, reject) => {
      const timeoutId = setTimeout(() => {
        this.pendingDappSignatures.delete(requestId);
        reject(new Error("Signature confirmation timed out"));
      }, DAPP_CONFIRM_TIMEOUT_MS);
      this.pendingDappSignatures.set(requestId, {
        resolve,
        reject,
        timeoutId,
        ...payload
      });
    });
  }
  async handleApiDappConnectContext(payload) {
    const entry = this.pendingDappConnects.get(payload.requestId);
    if (!entry) {
      throw new Error("Connect request not found");
    }
    return {
      requestId: payload.requestId,
      origin: entry.origin,
      walletAddress: entry.walletAddress,
      connectionId: entry.connection.connectionId,
      host: entry.connection.host,
      trustLevel: entry.connection.trustLevel,
      warningTone: entry.warning.tone,
      warningTitle: entry.warning.title,
      warningMessage: entry.warning.message
    };
  }
  async handleApiDappConnectResult(payload) {
    const entry = this.pendingDappConnects.get(payload.requestId);
    if (!entry) {
      return { success: true };
    }
    clearTimeout(entry.timeoutId);
    this.pendingDappConnects.delete(payload.requestId);
    if (payload.status === "approved") {
      entry.resolve(true);
      return { success: true };
    }
    if (payload.status === "rejected") {
      entry.resolve(false);
      return { success: true };
    }
    entry.reject(new Error(payload.error || "Connection was rejected"));
    return { success: true };
  }
  async handleApiDappTxContext(payload) {
    const entry = this.pendingDappTransactions.get(payload.operationId);
    if (!entry) {
      throw new Error("Transaction request not found");
    }
    return {
      operationId: payload.operationId,
      origin: entry.origin,
      connectionId: entry.connection?.connectionId ?? null,
      host: entry.connection?.host ?? null,
      trustLevel: entry.connection?.trustLevel ?? null,
      warning: entry.warning
    };
  }
  async handleApiDappTxResult(payload) {
    const entry = this.pendingDappTransactions.get(payload.operationId);
    if (!entry) {
      return { success: true };
    }
    clearTimeout(entry.timeoutId);
    this.pendingDappTransactions.delete(payload.operationId);
    if (entry.connection) {
      const outcome = payload.status === "confirmed" ? "approved" : payload.status === "rejected" ? "rejected" : "failed";
      void this.recordSignEvent(
        entry.connection.connectionId,
        "transaction",
        outcome
      );
    }
    if (payload.status === "confirmed") {
      if (!payload.txHash) {
        entry.reject(
          new Error("Transaction confirmed but tx hash unavailable")
        );
        return { success: true };
      }
      entry.resolve(payload.txHash);
      return { success: true };
    }
    const errorMessage = payload.error || "Transaction was rejected by the user";
    entry.reject(new Error(errorMessage));
    return { success: true };
  }
  async handleApiDappSignContext(payload) {
    const entry = this.pendingDappSignatures.get(payload.requestId);
    if (!entry) {
      throw new Error("Sign request not found");
    }
    return {
      requestId: payload.requestId,
      message: entry.message,
      address: entry.address,
      origin: entry.origin,
      pocketId: entry.pocketId,
      connectionId: entry.connection?.connectionId ?? null,
      host: entry.connection?.host ?? null,
      trustLevel: entry.connection?.trustLevel ?? null,
      warning: entry.warning
    };
  }
  async handleApiDappSignResult(payload) {
    const entry = this.pendingDappSignatures.get(payload.requestId);
    if (!entry) {
      return { success: true };
    }
    clearTimeout(entry.timeoutId);
    this.pendingDappSignatures.delete(payload.requestId);
    if (entry.connection) {
      const outcome = payload.status === "signed" ? "approved" : payload.status === "rejected" ? "rejected" : "failed";
      void this.recordSignEvent(
        entry.connection.connectionId,
        "message",
        outcome
      );
    }
    if (payload.status === "signed") {
      if (!payload.signature) {
        entry.reject(new Error("Missing signature result"));
        return { success: true };
      }
      entry.resolve(payload.signature);
      return { success: true };
    }
    const errorMessage = payload.error || "Message signing was rejected by the user";
    entry.reject(new Error(errorMessage));
    return { success: true };
  }
}
const FALLBACK_EXPIRY_MS = 60 * 60 * 1e3;
function normalizeBase64Url(value) {
  let normalized = value.replace(/-/g, "+").replace(/_/g, "/");
  const paddingNeeded = normalized.length % 4;
  if (paddingNeeded === 2) normalized += "==";
  else if (paddingNeeded === 3) normalized += "=";
  else if (paddingNeeded !== 0) normalized += "==";
  return normalized;
}
function decodeJwtExpiration(token) {
  try {
    const segments = token.split(".");
    if (segments.length < 2) return null;
    const payloadSegment = segments[1];
    if (!payloadSegment) return null;
    const normalized = normalizeBase64Url(payloadSegment);
    if (typeof globalThis.atob !== "function") return null;
    const json = globalThis.atob(normalized);
    const payload = JSON.parse(json);
    if (typeof payload.exp !== "number") return null;
    return payload.exp * 1e3;
  } catch {
    return null;
  }
}
function buildAccessExpiry(token) {
  return decodeJwtExpiration(token) ?? Date.now() + FALLBACK_EXPIRY_MS;
}
async function getMe(client, accessToken) {
  try {
    const res = await client.get("/v1/users/me", authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to load user profile"), error);
  }
}
async function prepareDappConnection(client, accessToken, payload) {
  try {
    const res = await client.post("/v1/dapps/connections/prepare", payload, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to prepare dApp connection"), error);
  }
}
async function confirmDappConnection(client, accessToken, connectionId) {
  try {
    const res = await client.post(`/v1/dapps/connections/${connectionId}/confirm`, {}, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to confirm dApp connection"), error);
  }
}
async function rejectDappConnection(client, accessToken, connectionId) {
  try {
    const res = await client.post(`/v1/dapps/connections/${connectionId}/reject`, {}, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to reject dApp connection"), error);
  }
}
async function disconnectDappConnection(client, accessToken, connectionId) {
  try {
    const res = await client.post(`/v1/dapps/connections/${connectionId}/disconnect`, {}, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to disconnect dApp"), error);
  }
}
async function listDappConnections(client, accessToken, params) {
  try {
    const res = await client.get("/v1/dapps/connections", {
      ...authHeaders(accessToken),
      params
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to load dApp connections"), error);
  }
}
async function recordDappConnectionSignEvent(client, accessToken, connectionId, payload) {
  try {
    const res = await client.post(`/v1/dapps/connections/${connectionId}/sign-events`, payload, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to record dApp sign event"), error);
  }
}
async function preparePocket(client, accessToken) {
  const idempotencyKey = createIdempotencyKey();
  try {
    const res = await client.post("/v1/pockets/new/prepare", {}, {
      ...authHeaders(accessToken),
      headers: {
        ...authHeaders(accessToken).headers,
        "Idempotency-Key": idempotencyKey
      }
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to prepare pocket"), error);
  }
}
async function submitPocket(client, accessToken, payload) {
  const idempotencyKey = createIdempotencyKey();
  try {
    const res = await client.post("/v1/pockets/new/submit", payload, {
      ...authHeaders(accessToken),
      headers: {
        ...authHeaders(accessToken).headers,
        "Idempotency-Key": idempotencyKey
      }
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to submit pocket"), error);
  }
}
async function preparePocketTxSend(client, accessToken, pocketId, payload, opts) {
  const idempotencyKey = createIdempotencyKey();
  try {
    const res = await client.post(`/v1/pockets/${pocketId}/tx/send/prepare`, payload, {
      ...authHeaders(accessToken),
      headers: {
        ...authHeaders(accessToken).headers,
        "Idempotency-Key": idempotencyKey
      }
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to prepare transfer"), error);
  }
}
async function submitPocketTxSend(client, accessToken, pocketId, payload, opts) {
  const idempotencyKey = createIdempotencyKey();
  try {
    const res = await client.post(`/v1/pockets/${pocketId}/tx/send/submit`, payload, {
      ...authHeaders(accessToken),
      headers: {
        ...authHeaders(accessToken).headers,
        "Idempotency-Key": idempotencyKey
      }
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to submit transfer"), error);
  }
}
async function preparePocketTxCustom(client, accessToken, pocketId, payload, opts) {
  const idempotencyKey = createIdempotencyKey();
  try {
    const res = await client.post(`/v1/pockets/${pocketId}/tx/custom/prepare`, payload, {
      ...authHeaders(accessToken),
      headers: {
        ...authHeaders(accessToken).headers,
        "Idempotency-Key": idempotencyKey
      }
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to prepare transaction"), error);
  }
}
async function submitPocketTxCustom(client, accessToken, pocketId, payload, opts) {
  const idempotencyKey = createIdempotencyKey();
  try {
    const res = await client.post(`/v1/pockets/${pocketId}/tx/custom/submit`, payload, {
      ...authHeaders(accessToken),
      headers: {
        ...authHeaders(accessToken).headers,
        "Idempotency-Key": idempotencyKey
      }
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to submit transaction"), error);
  }
}
async function preparePocketPersonalSign(client, accessToken, pocketId, payload) {
  try {
    const res = await client.post(`/v1/pockets/${pocketId}/sign/personal/prepare`, payload, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to prepare personal sign"), error);
  }
}
async function submitPocketPersonalSign(client, accessToken, pocketId, payload) {
  try {
    const res = await client.post(`/v1/pockets/${pocketId}/sign/personal/submit`, payload, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to submit personal sign"), error);
  }
}
async function getPocketBalances(client, accessToken, pocketId) {
  try {
    const res = await client.get(`/v1/pockets/${pocketId}/balances`, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to load pocket balances"), error);
  }
}
async function getPocketActivities(client, accessToken, pocketId, params) {
  try {
    const res = await client.get(`/v1/pockets/${pocketId}/activities`, {
      ...authHeaders(accessToken),
      params: {
        cursor: params?.cursor,
        limit: params?.limit
      }
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to load pocket activity"), error);
  }
}
async function getUserOperation(client, accessToken, operationId) {
  try {
    const res = await client.get(`/v1/user_operations/${operationId}`, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to load operation status"), error);
  }
}
async function cancelUserOperation(client, accessToken, operationId) {
  try {
    const res = await client.delete(`/v1/user_operations/${operationId}`, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to cancel the pending transaction"), error);
  }
}
async function getAddressBook(client, accessToken) {
  try {
    const res = await client.get("/v1/address_book", authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to load address book"), error);
  }
}
async function upsertAddressBookEntry(client, accessToken, payload) {
  try {
    const res = await client.post("/v1/address_book", payload, authHeaders(accessToken));
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to save entry"), error);
  }
}
async function deleteAddressBookEntry(client, accessToken, payload) {
  try {
    const res = await client.delete("/v1/address_book", {
      ...authHeaders(accessToken),
      data: payload
    });
    return res.data.data;
  } catch (error) {
    throw withErrorCause(getAxiosErrorMessage(error, "Unable to delete entry"), error);
  }
}
const ACCESS_TOKEN_BUFFER_MS = 6e4;
class ApiController {
  constructor(storage2) {
    this.storage = storage2;
  }
  async getSession() {
    return this.storage.getApiSession();
  }
  async setSession(payload) {
    const accessTokenExpiresAt = payload.accessToken ? payload.accessTokenExpiresAt ?? buildAccessExpiry(payload.accessToken) : null;
    const session = {
      ...payload,
      accessTokenExpiresAt
    };
    await this.storage.setApiSession(session);
    return session;
  }
  async clearSession() {
    await this.storage.clearApiSession();
    await this.storage.setApiChainId(null);
  }
  async getChainId() {
    return this.storage.getApiChainId();
  }
  async setSelectedPocketId(pocketId) {
    await this.storage.setApiSelectedPocketId(pocketId);
  }
  async getValidAccessToken() {
    const session = await this.storage.getApiSession();
    if (!session.refreshToken) {
      throw new Error("SESSION_EXPIRED");
    }
    const hasValidToken = session.accessToken && session.accessTokenExpiresAt && session.accessTokenExpiresAt > Date.now() + ACCESS_TOKEN_BUFFER_MS;
    if (hasValidToken) {
      return session.accessToken;
    }
    try {
      const refreshed = await refreshWithToken(apiClient, session.refreshToken);
      const accessTokenExpiresAt = buildAccessExpiry(refreshed.accessToken);
      const nextSession = {
        ...session,
        accessToken: refreshed.accessToken,
        refreshToken: refreshed.refreshToken,
        accessTokenExpiresAt
      };
      await this.storage.setApiSession(nextSession);
      return refreshed.accessToken;
    } catch {
      await this.storage.clearApiSession();
      throw new Error("SESSION_EXPIRED");
    }
  }
  async getMe() {
    const accessToken = await this.getValidAccessToken();
    const me = await getMe(apiClient, accessToken);
    await this.storage.setApiPockets(me.pockets);
    await this.storage.setApiPendingUserOperations(me.pendingUserOperations);
    await this.storage.setApiDappConnections(me.dappConnections);
    await this.storage.setApiChainId(me.chainId);
    const selected = await this.storage.getApiSelectedPocketId();
    if (!selected && me.pockets.length > 0) {
      await this.storage.setApiSelectedPocketId(
        me.pockets[0]?.pocketId ?? null
      );
    }
    return me;
  }
  async preparePocket() {
    const accessToken = await this.getValidAccessToken();
    return preparePocket(apiClient, accessToken);
  }
  async submitPocket(request) {
    const accessToken = await this.getValidAccessToken();
    return submitPocket(apiClient, accessToken, request);
  }
  async preparePocketSend(pocketId, request) {
    const accessToken = await this.getValidAccessToken();
    return preparePocketTxSend(apiClient, accessToken, pocketId, request);
  }
  async submitPocketSend(pocketId, request) {
    const accessToken = await this.getValidAccessToken();
    return submitPocketTxSend(apiClient, accessToken, pocketId, request);
  }
  async preparePocketCustom(pocketId, request) {
    const accessToken = await this.getValidAccessToken();
    return preparePocketTxCustom(apiClient, accessToken, pocketId, request);
  }
  async submitPocketCustom(pocketId, request) {
    const accessToken = await this.getValidAccessToken();
    return submitPocketTxCustom(apiClient, accessToken, pocketId, request);
  }
  async preparePocketPersonalSign(pocketId, request) {
    const accessToken = await this.getValidAccessToken();
    return preparePocketPersonalSign(apiClient, accessToken, pocketId, request);
  }
  async submitPocketPersonalSign(pocketId, request) {
    const accessToken = await this.getValidAccessToken();
    return submitPocketPersonalSign(apiClient, accessToken, pocketId, request);
  }
  async getPocketBalances(pocketId) {
    const accessToken = await this.getValidAccessToken();
    return getPocketBalances(apiClient, accessToken, pocketId);
  }
  async getPocketActivities(pocketId, params) {
    const accessToken = await this.getValidAccessToken();
    return getPocketActivities(apiClient, accessToken, pocketId, params);
  }
  async getUserOperation(operationId) {
    const accessToken = await this.getValidAccessToken();
    return getUserOperation(apiClient, accessToken, operationId);
  }
  async cancelUserOperation(operationId) {
    const accessToken = await this.getValidAccessToken();
    return cancelUserOperation(apiClient, accessToken, operationId);
  }
  async listAddressBook() {
    const accessToken = await this.getValidAccessToken();
    return getAddressBook(apiClient, accessToken);
  }
  async upsertAddressBook(payload) {
    const accessToken = await this.getValidAccessToken();
    return upsertAddressBookEntry(apiClient, accessToken, payload);
  }
  async deleteAddressBook(payload) {
    const accessToken = await this.getValidAccessToken();
    return deleteAddressBookEntry(apiClient, accessToken, payload);
  }
  async prepareDappConnection(payload) {
    const accessToken = await this.getValidAccessToken();
    return prepareDappConnection(apiClient, accessToken, payload);
  }
  async confirmDappConnection(connectionId) {
    const accessToken = await this.getValidAccessToken();
    return confirmDappConnection(apiClient, accessToken, connectionId);
  }
  async rejectDappConnection(connectionId) {
    const accessToken = await this.getValidAccessToken();
    return rejectDappConnection(apiClient, accessToken, connectionId);
  }
  async disconnectDappConnection(connectionId) {
    const accessToken = await this.getValidAccessToken();
    return disconnectDappConnection(apiClient, accessToken, connectionId);
  }
  async listDappConnections(params) {
    const accessToken = await this.getValidAccessToken();
    return listDappConnections(apiClient, accessToken, params);
  }
  async recordDappConnectionSignEvent(connectionId, payload) {
    const accessToken = await this.getValidAccessToken();
    return recordDappConnectionSignEvent(
      apiClient,
      accessToken,
      connectionId,
      payload
    );
  }
}
console.log("[Background] Grandpa DeFi Extension loaded");
console.log(
  "[Background] Service Worker ID:",
  self.registration?.active?.scriptURL
);
let keepAliveInterval;
function keepServiceWorkerAlive() {
  if (keepAliveInterval) {
    clearInterval(keepAliveInterval);
  }
  keepAliveInterval = setInterval(() => {
    console.log("[Background] Keep-alive ping");
  }, 2e4);
}
keepServiceWorkerAlive();
self.addEventListener("error", (event) => {
  console.error("[Background] Uncaught error:", event.error);
  console.error("[Background] Error message:", event.message);
  console.error("[Background] Error stack:", event.error?.stack);
  console.error(
    "[Background] Error at:",
    event.filename,
    event.lineno,
    event.colno
  );
});
self.addEventListener("unhandledrejection", (event) => {
  console.error("[Background] Unhandled promise rejection:", event.reason);
  console.error("[Background] Rejection stack:", event.reason?.stack);
  console.error("[Background] Promise:", event.promise);
});
const storage = new StorageManager();
const apiController = new ApiController(storage);
const messageHandler = new MessageHandler(storage, apiController);
async function initializeExtension() {
  console.log("[Background] Initializing extension...");
  await Promise.all([storage.initialize(), initializeApiClient()]);
  console.log("[Background] Extension initialized");
}
chrome.runtime.onInstalled.addListener(async () => {
  console.log("[Background] Extension installed");
  await initializeExtension();
});
chrome.runtime.onMessage.addListener(
  (message, sender, sendResponse) => {
    console.log("[Background] Received message:", message.type);
    console.log(
      "[Background] Message payload:",
      "payload" in message ? message.payload : "no payload"
    );
    console.log("[Background] Sender:", sender.tab?.id || "popup", sender.url);
    try {
      messageHandler.handleMessage(message, sender).then((response) => {
        console.log(
          "[Background] Message handled successfully:",
          message.type
        );
        sendResponse({ success: true, data: response });
      }).catch((error) => {
        console.error("[Background] Message handler error:", error);
        console.error("[Background] Error type:", error.constructor.name);
        console.error("[Background] Error message:", error.message);
        console.error("[Background] Error stack:", error.stack);
        sendResponse({
          success: false,
          error: error.message || "Unknown error"
        });
      });
    } catch (error) {
      console.error(
        "[Background] Synchronous error in message handler:",
        error
      );
      sendResponse({
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
    return true;
  }
);
chrome.runtime.onStartup.addListener(async () => {
  console.log("[Background] Extension started on browser startup");
  await initializeExtension();
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9iYWNrZ3JvdW5kL3N0b3JhZ2UtbWFuYWdlci50cyIsIi4uLy4uL3NyYy9iYWNrZ3JvdW5kL21lc3NhZ2UtaGFuZGxlci50cyIsIi4uLy4uL3NyYy9saWIvYXV0aC90b2tlbi11dGlscy50cyIsIi4uLy4uLy4uLy4uL3BhY2thZ2VzL2FwaS1jbGllbnQvZGlzdC91c2Vycy5qcyIsIi4uLy4uLy4uLy4uL3BhY2thZ2VzL2FwaS1jbGllbnQvZGlzdC9kYXBwcy5qcyIsIi4uLy4uLy4uLy4uL3BhY2thZ2VzL2FwaS1jbGllbnQvZGlzdC9wb2NrZXRzLmpzIiwiLi4vLi4vLi4vLi4vcGFja2FnZXMvYXBpLWNsaWVudC9kaXN0L3VzZXItb3BlcmF0aW9ucy5qcyIsIi4uLy4uLy4uLy4uL3BhY2thZ2VzL2FwaS1jbGllbnQvZGlzdC9hZGRyZXNzLWJvb2suanMiLCIuLi8uLi9zcmMvYmFja2dyb3VuZC9jb250cm9sbGVycy9hcGktY29udHJvbGxlci50cyIsIi4uLy4uL3NyYy9iYWNrZ3JvdW5kL2luZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIFN0b3JhZ2UgTWFuYWdlciAtIEhhbmRsZXMgY2hyb21lLnN0b3JhZ2Ugb3BlcmF0aW9ucyAoQVBJLWZpcnN0KVxuXG5pbXBvcnQgdHlwZSB7XG4gIEFwaURhcHBDb25uZWN0aW9uLFxuICBBcGlTZXNzaW9uLFxuICBBcGlWYXVsdCxcbiAgQ29ubmVjdGVkU2l0ZVJlY29yZCxcbiAgU2V0dGluZ3MsXG4gIFN0b3JhZ2VTY2hlbWEsXG59IGZyb20gXCJAL3NoYXJlZC90eXBlc1wiO1xuaW1wb3J0IHR5cGUgeyBNZVBvY2tldCwgTWVQZW5kaW5nVXNlck9wZXJhdGlvbiB9IGZyb20gXCJAcmVwby9hcGktY2xpZW50L3VzZXJzXCI7XG5pbXBvcnQgeyBTVE9SQUdFX0tFWVMsIERFRkFVTFRfU0VUVElOR1MgfSBmcm9tIFwiQC9zaGFyZWQvY29uc3RhbnRzXCI7XG5cbmNvbnN0IERFRkFVTFRfQVBJX1NFU1NJT046IEFwaVNlc3Npb24gPSB7XG4gIGFjY2Vzc1Rva2VuOiBudWxsLFxuICByZWZyZXNoVG9rZW46IG51bGwsXG4gIGFjY2Vzc1Rva2VuRXhwaXJlc0F0OiBudWxsLFxuICBjcmVkZW50aWFsSWQ6IG51bGwsXG4gIHJwSWQ6IG51bGwsXG59O1xuXG5mdW5jdGlvbiByZWFkU3RvcmFnZUtleTxUPihcbiAgcmVzdWx0OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbiAga2V5OiBzdHJpbmcsXG4gIGZhbGxiYWNrOiBULFxuKTogVCB7XG4gIGNvbnN0IHZhbHVlID0gcmVzdWx0W2tleV07XG4gIHJldHVybiAodmFsdWUgYXMgVCkgPz8gZmFsbGJhY2s7XG59XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZU9yaWdpbih2YWx1ZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgdHJ5IHtcbiAgICBjb25zdCB1cmwgPSBuZXcgVVJMKHZhbHVlKTtcbiAgICBjb25zdCBwcm90b2NvbCA9IHVybC5wcm90b2NvbC50b0xvd2VyQ2FzZSgpO1xuICAgIGNvbnN0IGhvc3RuYW1lID0gdXJsLmhvc3RuYW1lLnRvTG93ZXJDYXNlKCk7XG4gICAgY29uc3QgcG9ydCA9IHVybC5wb3J0O1xuICAgIGNvbnN0IGluY2x1ZGVQb3J0ID1cbiAgICAgIHBvcnQubGVuZ3RoID4gMCAmJlxuICAgICAgIShcbiAgICAgICAgKHByb3RvY29sID09PSBcImh0dHBzOlwiICYmIHBvcnQgPT09IFwiNDQzXCIpIHx8XG4gICAgICAgIChwcm90b2NvbCA9PT0gXCJodHRwOlwiICYmIHBvcnQgPT09IFwiODBcIilcbiAgICAgICk7XG4gICAgY29uc3QgaG9zdCA9IGluY2x1ZGVQb3J0ID8gYCR7aG9zdG5hbWV9OiR7cG9ydH1gIDogaG9zdG5hbWU7XG4gICAgcmV0dXJuIGAke3Byb3RvY29sfS8vJHtob3N0fWA7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiB2YWx1ZS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgU3RvcmFnZU1hbmFnZXIge1xuICBwcml2YXRlIGJ1aWxkQ29ubmVjdGVkU2l0ZUtleShlbnRyeToge1xuICAgIG5vcm1hbGl6ZWRPcmlnaW46IHN0cmluZztcbiAgICB3YWxsZXRTY29wZTogQ29ubmVjdGVkU2l0ZVJlY29yZFtcIndhbGxldFNjb3BlXCJdO1xuICAgIHdhbGxldEFkZHJlc3M6IGAweCR7c3RyaW5nfWA7XG4gICAgY2hhaW5JZDogbnVtYmVyO1xuICB9KTogc3RyaW5nIHtcbiAgICByZXR1cm4gW1xuICAgICAgZW50cnkud2FsbGV0U2NvcGUsXG4gICAgICBlbnRyeS53YWxsZXRBZGRyZXNzLnRvTG93ZXJDYXNlKCksXG4gICAgICBTdHJpbmcoZW50cnkuY2hhaW5JZCksXG4gICAgICBlbnRyeS5ub3JtYWxpemVkT3JpZ2luLFxuICAgIF0uam9pbihcInxcIik7XG4gIH1cblxuICBwcml2YXRlIGlzQ29ubmVjdGVkU2l0ZVJlY29yZCh2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIENvbm5lY3RlZFNpdGVSZWNvcmQge1xuICAgIGlmICghdmFsdWUgfHwgdHlwZW9mIHZhbHVlICE9PSBcIm9iamVjdFwiKSByZXR1cm4gZmFsc2U7XG4gICAgY29uc3QgcmVjb3JkID0gdmFsdWUgYXMgUGFydGlhbDxDb25uZWN0ZWRTaXRlUmVjb3JkPjtcbiAgICByZXR1cm4gKFxuICAgICAgdHlwZW9mIHJlY29yZC5jb25uZWN0aW9uSWQgPT09IFwic3RyaW5nXCIgJiZcbiAgICAgIHR5cGVvZiByZWNvcmQub3JpZ2luID09PSBcInN0cmluZ1wiICYmXG4gICAgICB0eXBlb2YgcmVjb3JkLm5vcm1hbGl6ZWRPcmlnaW4gPT09IFwic3RyaW5nXCIgJiZcbiAgICAgIHR5cGVvZiByZWNvcmQuaG9zdCA9PT0gXCJzdHJpbmdcIiAmJlxuICAgICAgKHJlY29yZC53YWxsZXRTY29wZSA9PT0gXCJwb2NrZXRcIiB8fCByZWNvcmQud2FsbGV0U2NvcGUgPT09IFwidmF1bHRcIikgJiZcbiAgICAgIHR5cGVvZiByZWNvcmQud2FsbGV0QWRkcmVzcyA9PT0gXCJzdHJpbmdcIiAmJlxuICAgICAgdHlwZW9mIHJlY29yZC5jaGFpbklkID09PSBcIm51bWJlclwiXG4gICAgKTtcbiAgfVxuXG4gIGFzeW5jIGluaXRpYWxpemUoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgZXhpc3RpbmcgPSBhd2FpdCB0aGlzLmdldEFsbCgpO1xuXG4gICAgaWYgKCFleGlzdGluZy5zZXR0aW5ncykge1xuICAgICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHtcbiAgICAgICAgW1NUT1JBR0VfS0VZUy5TRVRUSU5HU106IERFRkFVTFRfU0VUVElOR1MsXG4gICAgICAgIFtTVE9SQUdFX0tFWVMuQ09OTkVDVEVEX1NJVEVTXToge30sXG4gICAgICAgIFtTVE9SQUdFX0tFWVMuQVBJX1NFU1NJT05dOiBERUZBVUxUX0FQSV9TRVNTSU9OLFxuICAgICAgICBbU1RPUkFHRV9LRVlTLkFQSV9QT0NLRVRTXTogW10sXG4gICAgICAgIFtTVE9SQUdFX0tFWVMuQVBJX1NFTEVDVEVEX1BPQ0tFVF9JRF06IG51bGwsXG4gICAgICAgIFtTVE9SQUdFX0tFWVMuQVBJX1BFTkRJTkdfVVNFUl9PUEVSQVRJT05TXTogW10sXG4gICAgICAgIFtTVE9SQUdFX0tFWVMuQVBJX0RBUFBfQ09OTkVDVElPTlNdOiBbXSxcbiAgICAgICAgW1NUT1JBR0VfS0VZUy5BUElfQ0hBSU5fSURdOiBudWxsLFxuICAgICAgICBbU1RPUkFHRV9LRVlTLkFQSV9WQVVMVF06IG51bGwsXG4gICAgICB9KTtcbiAgICAgIGNvbnNvbGUubG9nKFwiW1N0b3JhZ2VdIEluaXRpYWxpemVkIHdpdGggZGVmYXVsdHNcIik7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgZ2V0QWxsKCk6IFByb21pc2U8UGFydGlhbDxTdG9yYWdlU2NoZW1hPj4ge1xuICAgIHJldHVybiBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQobnVsbCkgYXMgUHJvbWlzZTxQYXJ0aWFsPFN0b3JhZ2VTY2hlbWE+PjtcbiAgfVxuXG4gIGFzeW5jIGNsZWFyQWxsKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmNsZWFyKCk7XG4gIH1cblxuICBhc3luYyBnZXRTZXR0aW5ncygpOiBQcm9taXNlPFNldHRpbmdzPiB7XG4gICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChcbiAgICAgIFNUT1JBR0VfS0VZUy5TRVRUSU5HUyxcbiAgICApKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICByZXR1cm4gcmVhZFN0b3JhZ2VLZXkocmVzdWx0LCBTVE9SQUdFX0tFWVMuU0VUVElOR1MsIERFRkFVTFRfU0VUVElOR1MpO1xuICB9XG5cbiAgYXN5bmMgc2V0U2V0dGluZ3Moc2V0dGluZ3M6IFNldHRpbmdzKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NUT1JBR0VfS0VZUy5TRVRUSU5HU106IHNldHRpbmdzIH0pO1xuICB9XG5cbiAgYXN5bmMgdXBkYXRlU2V0dGluZ3ModXBkYXRlczogUGFydGlhbDxTZXR0aW5ncz4pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBzZXR0aW5ncyA9IGF3YWl0IHRoaXMuZ2V0U2V0dGluZ3MoKTtcbiAgICBhd2FpdCB0aGlzLnNldFNldHRpbmdzKHsgLi4uc2V0dGluZ3MsIC4uLnVwZGF0ZXMgfSk7XG4gIH1cblxuICAvLyBDb25uZWN0ZWQgc2l0ZXMgbWFuYWdlbWVudFxuICBhc3luYyBnZXRDb25uZWN0ZWRTaXRlcygpOiBQcm9taXNlPFJlY29yZDxzdHJpbmcsIENvbm5lY3RlZFNpdGVSZWNvcmQ+PiB7XG4gICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChcbiAgICAgIFNUT1JBR0VfS0VZUy5DT05ORUNURURfU0lURVMsXG4gICAgKSkgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgY29uc3QgcmF3ID0gcmVhZFN0b3JhZ2VLZXkocmVzdWx0LCBTVE9SQUdFX0tFWVMuQ09OTkVDVEVEX1NJVEVTLCB7fSk7XG4gICAgY29uc3QgZW50cmllcyA9IE9iamVjdC5lbnRyaWVzKHJhdyBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik7XG4gICAgY29uc3QgbmV4dDogUmVjb3JkPHN0cmluZywgQ29ubmVjdGVkU2l0ZVJlY29yZD4gPSB7fTtcbiAgICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBlbnRyaWVzKSB7XG4gICAgICBpZiAoIXRoaXMuaXNDb25uZWN0ZWRTaXRlUmVjb3JkKHZhbHVlKSkgY29udGludWU7XG4gICAgICBuZXh0W2tleV0gPSB2YWx1ZTtcbiAgICB9XG4gICAgcmV0dXJuIG5leHQ7XG4gIH1cblxuICBhc3luYyBhZGRDb25uZWN0ZWRTaXRlKHNpdGU6IENvbm5lY3RlZFNpdGVSZWNvcmQpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBzaXRlcyA9IGF3YWl0IHRoaXMuZ2V0Q29ubmVjdGVkU2l0ZXMoKTtcbiAgICBjb25zdCBub3JtYWxpemVkT3JpZ2luID0gbm9ybWFsaXplT3JpZ2luKFxuICAgICAgc2l0ZS5ub3JtYWxpemVkT3JpZ2luIHx8IHNpdGUub3JpZ2luLFxuICAgICk7XG4gICAgY29uc3Qgbm93ID0gRGF0ZS5ub3coKTtcbiAgICBjb25zdCBrZXkgPSB0aGlzLmJ1aWxkQ29ubmVjdGVkU2l0ZUtleSh7XG4gICAgICBub3JtYWxpemVkT3JpZ2luLFxuICAgICAgd2FsbGV0U2NvcGU6IHNpdGUud2FsbGV0U2NvcGUsXG4gICAgICB3YWxsZXRBZGRyZXNzOiBzaXRlLndhbGxldEFkZHJlc3MsXG4gICAgICBjaGFpbklkOiBzaXRlLmNoYWluSWQsXG4gICAgfSk7XG4gICAgc2l0ZXNba2V5XSA9IHtcbiAgICAgIC4uLnNpdGUsXG4gICAgICBvcmlnaW46IG5vcm1hbGl6ZU9yaWdpbihzaXRlLm9yaWdpbiksXG4gICAgICBub3JtYWxpemVkT3JpZ2luLFxuICAgICAgY29ubmVjdGVkQXQ6IHNpdGUuY29ubmVjdGVkQXQgfHwgbm93LFxuICAgICAgbGFzdFVzZWRBdDogc2l0ZS5sYXN0VXNlZEF0IHx8IG5vdyxcbiAgICB9O1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTVE9SQUdFX0tFWVMuQ09OTkVDVEVEX1NJVEVTXTogc2l0ZXMgfSk7XG4gIH1cblxuICBhc3luYyByZW1vdmVDb25uZWN0ZWRTaXRlKGNvbm5lY3Rpb25JZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3Qgc2l0ZXMgPSBhd2FpdCB0aGlzLmdldENvbm5lY3RlZFNpdGVzKCk7XG4gICAgZm9yIChjb25zdCBba2V5LCBlbnRyeV0gb2YgT2JqZWN0LmVudHJpZXMoc2l0ZXMpKSB7XG4gICAgICBpZiAoZW50cnkuY29ubmVjdGlvbklkICE9PSBjb25uZWN0aW9uSWQpIGNvbnRpbnVlO1xuICAgICAgZGVsZXRlIHNpdGVzW2tleV07XG4gICAgfVxuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTVE9SQUdFX0tFWVMuQ09OTkVDVEVEX1NJVEVTXTogc2l0ZXMgfSk7XG4gIH1cblxuICBhc3luYyByZW1vdmVDb25uZWN0ZWRTaXRlc0Zvck9yaWdpbihcbiAgICBvcmlnaW46IHN0cmluZyxcbiAgICB3YWxsZXRBZGRyZXNzPzogYDB4JHtzdHJpbmd9YCB8IG51bGwsXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IHNpdGVzID0gYXdhaXQgdGhpcy5nZXRDb25uZWN0ZWRTaXRlcygpO1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRPcmlnaW4gPSBub3JtYWxpemVPcmlnaW4ob3JpZ2luKTtcbiAgICBjb25zdCBub3JtYWxpemVkV2FsbGV0QWRkcmVzcyA9IHdhbGxldEFkZHJlc3M/LnRvTG93ZXJDYXNlKCkgPz8gbnVsbDtcbiAgICBmb3IgKGNvbnN0IFtrZXksIGVudHJ5XSBvZiBPYmplY3QuZW50cmllcyhzaXRlcykpIHtcbiAgICAgIGlmIChlbnRyeS5ub3JtYWxpemVkT3JpZ2luICE9PSBub3JtYWxpemVkT3JpZ2luKSBjb250aW51ZTtcbiAgICAgIGlmIChcbiAgICAgICAgbm9ybWFsaXplZFdhbGxldEFkZHJlc3MgJiZcbiAgICAgICAgZW50cnkud2FsbGV0QWRkcmVzcy50b0xvd2VyQ2FzZSgpICE9PSBub3JtYWxpemVkV2FsbGV0QWRkcmVzc1xuICAgICAgKSB7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuICAgICAgZGVsZXRlIHNpdGVzW2tleV07XG4gICAgfVxuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTVE9SQUdFX0tFWVMuQ09OTkVDVEVEX1NJVEVTXTogc2l0ZXMgfSk7XG4gIH1cblxuICBhc3luYyBmaW5kQ29ubmVjdGVkU2l0ZShwYXJhbXM6IHtcbiAgICBvcmlnaW46IHN0cmluZztcbiAgICB3YWxsZXRBZGRyZXNzOiBgMHgke3N0cmluZ31gO1xuICAgIGNoYWluSWQ6IG51bWJlcjtcbiAgICB3YWxsZXRTY29wZTogQ29ubmVjdGVkU2l0ZVJlY29yZFtcIndhbGxldFNjb3BlXCJdO1xuICB9KTogUHJvbWlzZTxDb25uZWN0ZWRTaXRlUmVjb3JkIHwgbnVsbD4ge1xuICAgIGNvbnN0IHNpdGVzID0gYXdhaXQgdGhpcy5nZXRDb25uZWN0ZWRTaXRlcygpO1xuICAgIGNvbnN0IG5vcm1hbGl6ZWRPcmlnaW4gPSBub3JtYWxpemVPcmlnaW4ocGFyYW1zLm9yaWdpbik7XG4gICAgY29uc3Qgbm9ybWFsaXplZFdhbGxldEFkZHJlc3MgPSBwYXJhbXMud2FsbGV0QWRkcmVzcy50b0xvd2VyQ2FzZSgpO1xuICAgIGNvbnN0IG1hdGNoID0gT2JqZWN0LnZhbHVlcyhzaXRlcykuZmluZChcbiAgICAgIChzaXRlKSA9PlxuICAgICAgICBzaXRlLm5vcm1hbGl6ZWRPcmlnaW4gPT09IG5vcm1hbGl6ZWRPcmlnaW4gJiZcbiAgICAgICAgc2l0ZS53YWxsZXRTY29wZSA9PT0gcGFyYW1zLndhbGxldFNjb3BlICYmXG4gICAgICAgIHNpdGUuY2hhaW5JZCA9PT0gcGFyYW1zLmNoYWluSWQgJiZcbiAgICAgICAgc2l0ZS53YWxsZXRBZGRyZXNzLnRvTG93ZXJDYXNlKCkgPT09IG5vcm1hbGl6ZWRXYWxsZXRBZGRyZXNzLFxuICAgICk7XG4gICAgcmV0dXJuIG1hdGNoID8/IG51bGw7XG4gIH1cblxuICBhc3luYyBpc0Nvbm5lY3RlZFNpdGUocGFyYW1zOiB7XG4gICAgb3JpZ2luOiBzdHJpbmc7XG4gICAgd2FsbGV0QWRkcmVzczogYDB4JHtzdHJpbmd9YDtcbiAgICBjaGFpbklkOiBudW1iZXI7XG4gICAgd2FsbGV0U2NvcGU6IENvbm5lY3RlZFNpdGVSZWNvcmRbXCJ3YWxsZXRTY29wZVwiXTtcbiAgfSk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHJldHVybiAoYXdhaXQgdGhpcy5maW5kQ29ubmVjdGVkU2l0ZShwYXJhbXMpKSAhPT0gbnVsbDtcbiAgfVxuXG4gIGFzeW5jIHRvdWNoQ29ubmVjdGVkU2l0ZShjb25uZWN0aW9uSWQ6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IHNpdGVzID0gYXdhaXQgdGhpcy5nZXRDb25uZWN0ZWRTaXRlcygpO1xuICAgIGxldCBkaWRVcGRhdGUgPSBmYWxzZTtcbiAgICBmb3IgKGNvbnN0IFtrZXksIHNpdGVdIG9mIE9iamVjdC5lbnRyaWVzKHNpdGVzKSkge1xuICAgICAgaWYgKHNpdGUuY29ubmVjdGlvbklkICE9PSBjb25uZWN0aW9uSWQpIGNvbnRpbnVlO1xuICAgICAgc2l0ZXNba2V5XSA9IHtcbiAgICAgICAgLi4uc2l0ZSxcbiAgICAgICAgbGFzdFVzZWRBdDogRGF0ZS5ub3coKSxcbiAgICAgIH07XG4gICAgICBkaWRVcGRhdGUgPSB0cnVlO1xuICAgIH1cblxuICAgIGlmIChkaWRVcGRhdGUpIHtcbiAgICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTVE9SQUdFX0tFWVMuQ09OTkVDVEVEX1NJVEVTXTogc2l0ZXMgfSk7XG4gICAgfVxuICB9XG5cbiAgLy8gQVBJIHNlc3Npb24gbWFuYWdlbWVudCAobmV3IGJhY2tlbmQpXG4gIGFzeW5jIGdldEFwaVNlc3Npb24oKTogUHJvbWlzZTxBcGlTZXNzaW9uPiB7XG4gICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChcbiAgICAgIFNUT1JBR0VfS0VZUy5BUElfU0VTU0lPTixcbiAgICApKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICByZXR1cm4gcmVhZFN0b3JhZ2VLZXkoXG4gICAgICByZXN1bHQsXG4gICAgICBTVE9SQUdFX0tFWVMuQVBJX1NFU1NJT04sXG4gICAgICBERUZBVUxUX0FQSV9TRVNTSU9OLFxuICAgICk7XG4gIH1cblxuICBhc3luYyBzZXRBcGlTZXNzaW9uKHNlc3Npb246IEFwaVNlc3Npb24pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbU1RPUkFHRV9LRVlTLkFQSV9TRVNTSU9OXTogc2Vzc2lvbiB9KTtcbiAgfVxuXG4gIGFzeW5jIGNsZWFyQXBpU2Vzc2lvbigpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCB0aGlzLnNldEFwaVNlc3Npb24oREVGQVVMVF9BUElfU0VTU0lPTik7XG4gIH1cblxuICBhc3luYyBnZXRBcGlQb2NrZXRzKCk6IFByb21pc2U8TWVQb2NrZXRbXT4ge1xuICAgIGNvbnN0IHJlc3VsdCA9IChhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoXG4gICAgICBTVE9SQUdFX0tFWVMuQVBJX1BPQ0tFVFMsXG4gICAgKSkgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgcmV0dXJuIHJlYWRTdG9yYWdlS2V5KHJlc3VsdCwgU1RPUkFHRV9LRVlTLkFQSV9QT0NLRVRTLCBbXSBhcyBNZVBvY2tldFtdKTtcbiAgfVxuXG4gIGFzeW5jIHNldEFwaVBvY2tldHMocG9ja2V0czogTWVQb2NrZXRbXSk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTVE9SQUdFX0tFWVMuQVBJX1BPQ0tFVFNdOiBwb2NrZXRzIH0pO1xuICB9XG5cbiAgYXN5bmMgZ2V0QXBpU2VsZWN0ZWRQb2NrZXRJZCgpOiBQcm9taXNlPHN0cmluZyB8IG51bGw+IHtcbiAgICBjb25zdCByZXN1bHQgPSAoYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFxuICAgICAgU1RPUkFHRV9LRVlTLkFQSV9TRUxFQ1RFRF9QT0NLRVRfSUQsXG4gICAgKSkgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgcmV0dXJuIHJlYWRTdG9yYWdlS2V5KHJlc3VsdCwgU1RPUkFHRV9LRVlTLkFQSV9TRUxFQ1RFRF9QT0NLRVRfSUQsIG51bGwpO1xuICB9XG5cbiAgYXN5bmMgc2V0QXBpU2VsZWN0ZWRQb2NrZXRJZChwb2NrZXRJZDogc3RyaW5nIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgICBbU1RPUkFHRV9LRVlTLkFQSV9TRUxFQ1RFRF9QT0NLRVRfSURdOiBwb2NrZXRJZCxcbiAgICB9KTtcbiAgfVxuXG4gIGFzeW5jIGdldEFwaVBlbmRpbmdVc2VyT3BlcmF0aW9ucygpOiBQcm9taXNlPE1lUGVuZGluZ1VzZXJPcGVyYXRpb25bXT4ge1xuICAgIGNvbnN0IHJlc3VsdCA9IChhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQoXG4gICAgICBTVE9SQUdFX0tFWVMuQVBJX1BFTkRJTkdfVVNFUl9PUEVSQVRJT05TLFxuICAgICkpIGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xuICAgIHJldHVybiByZWFkU3RvcmFnZUtleShcbiAgICAgIHJlc3VsdCxcbiAgICAgIFNUT1JBR0VfS0VZUy5BUElfUEVORElOR19VU0VSX09QRVJBVElPTlMsXG4gICAgICBbXSBhcyBNZVBlbmRpbmdVc2VyT3BlcmF0aW9uW10sXG4gICAgKTtcbiAgfVxuXG4gIGFzeW5jIHNldEFwaVBlbmRpbmdVc2VyT3BlcmF0aW9ucyhcbiAgICBvcGVyYXRpb25zOiBNZVBlbmRpbmdVc2VyT3BlcmF0aW9uW10sXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7XG4gICAgICBbU1RPUkFHRV9LRVlTLkFQSV9QRU5ESU5HX1VTRVJfT1BFUkFUSU9OU106IG9wZXJhdGlvbnMsXG4gICAgfSk7XG4gIH1cblxuICBhc3luYyBnZXRBcGlEYXBwQ29ubmVjdGlvbnMoKTogUHJvbWlzZTxBcGlEYXBwQ29ubmVjdGlvbltdPiB7XG4gICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChcbiAgICAgIFNUT1JBR0VfS0VZUy5BUElfREFQUF9DT05ORUNUSU9OUyxcbiAgICApKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICByZXR1cm4gcmVhZFN0b3JhZ2VLZXkoXG4gICAgICByZXN1bHQsXG4gICAgICBTVE9SQUdFX0tFWVMuQVBJX0RBUFBfQ09OTkVDVElPTlMsXG4gICAgICBbXSBhcyBBcGlEYXBwQ29ubmVjdGlvbltdLFxuICAgICk7XG4gIH1cblxuICBhc3luYyBzZXRBcGlEYXBwQ29ubmVjdGlvbnMoY29ubmVjdGlvbnM6IEFwaURhcHBDb25uZWN0aW9uW10pOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoe1xuICAgICAgW1NUT1JBR0VfS0VZUy5BUElfREFQUF9DT05ORUNUSU9OU106IGNvbm5lY3Rpb25zLFxuICAgIH0pO1xuICB9XG5cbiAgYXN5bmMgZ2V0QXBpQ2hhaW5JZCgpOiBQcm9taXNlPG51bWJlciB8IG51bGw+IHtcbiAgICBjb25zdCByZXN1bHQgPSAoYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0KFxuICAgICAgU1RPUkFHRV9LRVlTLkFQSV9DSEFJTl9JRCxcbiAgICApKSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPjtcbiAgICByZXR1cm4gcmVhZFN0b3JhZ2VLZXkocmVzdWx0LCBTVE9SQUdFX0tFWVMuQVBJX0NIQUlOX0lELCBudWxsKTtcbiAgfVxuXG4gIGFzeW5jIHNldEFwaUNoYWluSWQoY2hhaW5JZDogbnVtYmVyIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTVE9SQUdFX0tFWVMuQVBJX0NIQUlOX0lEXTogY2hhaW5JZCB9KTtcbiAgfVxuXG4gIGFzeW5jIGdldEFwaVZhdWx0KCk6IFByb21pc2U8QXBpVmF1bHQgfCBudWxsPiB7XG4gICAgY29uc3QgcmVzdWx0ID0gKGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldChcbiAgICAgIFNUT1JBR0VfS0VZUy5BUElfVkFVTFQsXG4gICAgKSkgYXMgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG4gICAgcmV0dXJuIHJlYWRTdG9yYWdlS2V5KHJlc3VsdCwgU1RPUkFHRV9LRVlTLkFQSV9WQVVMVCwgbnVsbCk7XG4gIH1cblxuICBhc3luYyBzZXRBcGlWYXVsdCh2YXVsdDogQXBpVmF1bHQgfCBudWxsKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NUT1JBR0VfS0VZUy5BUElfVkFVTFRdOiB2YXVsdCB9KTtcbiAgfVxufVxuIiwiLy8gTWVzc2FnZSBIYW5kbGVyIC0gUm91dGVzIG1lc3NhZ2VzIHRvIGFwcHJvcHJpYXRlIGhhbmRsZXJzIChBUEktZmlyc3QpXG5cbmltcG9ydCB0eXBlIHsgU3RvcmFnZU1hbmFnZXIgfSBmcm9tIFwiLi9zdG9yYWdlLW1hbmFnZXJcIjtcbmltcG9ydCB0eXBlIHtcbiAgQ29ubmVjdGVkU2l0ZVJlY29yZCxcbiAgRGFwcFdhcm5pbmdDb250ZXh0LFxuICBNZXNzYWdlLFxuICBTaWduTWVzc2FnZVJlcXVlc3QsXG4gIFRyYW5zYWN0aW9uUmVxdWVzdCxcbn0gZnJvbSBcIkAvc2hhcmVkL3R5cGVzXCI7XG5pbXBvcnQgdHlwZSB7IEFwaUNvbnRyb2xsZXIgfSBmcm9tIFwiLi9jb250cm9sbGVycy9hcGktY29udHJvbGxlclwiO1xuaW1wb3J0IHR5cGUgeyBNZVBvY2tldCB9IGZyb20gXCJAcmVwby9hcGktY2xpZW50L3VzZXJzXCI7XG5pbXBvcnQgdHlwZSB7IERhcHBDb25uZWN0aW9uU3VtbWFyeSB9IGZyb20gXCJAcmVwby9hcGktY2xpZW50L2RhcHBzXCI7XG5pbXBvcnQgdHlwZSB7XG4gIFBvY2tldE1ldGFUcmFuc2FjdGlvbixcbiAgUG9ja2V0UGVyc29uYWxTaWduUHJlcGFyZVJlcXVlc3QsXG4gIFBvY2tldFBlcnNvbmFsU2lnblN1Ym1pdFJlcXVlc3QsXG4gIFBvY2tldFN1Ym1pdFJlcXVlc3QsXG4gIFBvY2tldFR4U2VuZFByZXBhcmVSZXF1ZXN0LFxufSBmcm9tIFwiQHJlcG8vYXBpLWNsaWVudC9wb2NrZXRzXCI7XG5pbXBvcnQgdHlwZSB7XG4gIEFkZHJlc3NCb29rRGVsZXRlUmVxdWVzdCxcbiAgQWRkcmVzc0Jvb2tVcHNlcnRSZXF1ZXN0LFxufSBmcm9tIFwiQHJlcG8vYXBpLWNsaWVudC9hZGRyZXNzLWJvb2tcIjtcbmltcG9ydCB7IHNsZWVwIH0gZnJvbSBcIkAvc2hhcmVkL3V0aWxzXCI7XG5cbmNvbnN0IERBUFBfQ09ORklSTV9USU1FT1VUX01TID0gNSAqIDYwXzAwMDtcbmNvbnN0IENPTk5FQ1RfVElNRU9VVF9NUyA9IDIgKiA2MF8wMDA7XG5jb25zdCBDT05ORUNUX1BPTExfSU5URVJWQUxfTVMgPSA1MDA7XG5cbnR5cGUgUGVuZGluZ0RhcHBDb25uZWN0ID0ge1xuICByZXNvbHZlOiAoYXBwcm92ZWQ6IGJvb2xlYW4pID0+IHZvaWQ7XG4gIHJlamVjdDogKGVycm9yOiBFcnJvcikgPT4gdm9pZDtcbiAgdGltZW91dElkOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRUaW1lb3V0PjtcbiAgd2luZG93SWQ/OiBudW1iZXI7XG4gIG9yaWdpbjogc3RyaW5nO1xuICB3YWxsZXRBZGRyZXNzOiBgMHgke3N0cmluZ31gO1xuICBjb25uZWN0aW9uOiBEYXBwQ29ubmVjdGlvblN1bW1hcnk7XG4gIHdhcm5pbmc6IERhcHBXYXJuaW5nQ29udGV4dDtcbn07XG5cbnR5cGUgUGVuZGluZ0RhcHBUcmFuc2FjdGlvbiA9IHtcbiAgcmVzb2x2ZTogKHR4SGFzaDogYDB4JHtzdHJpbmd9YCkgPT4gdm9pZDtcbiAgcmVqZWN0OiAoZXJyb3I6IEVycm9yKSA9PiB2b2lkO1xuICB0aW1lb3V0SWQ6IFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+O1xuICB3aW5kb3dJZD86IG51bWJlcjtcbiAgb3JpZ2luOiBzdHJpbmc7XG4gIGNvbm5lY3Rpb246IENvbm5lY3RlZFNpdGVSZWNvcmQgfCBudWxsO1xuICB3YXJuaW5nOiBEYXBwV2FybmluZ0NvbnRleHQgfCBudWxsO1xufTtcblxudHlwZSBQZW5kaW5nRGFwcFNpZ25hdHVyZSA9IHtcbiAgcmVzb2x2ZTogKHNpZ25hdHVyZTogYDB4JHtzdHJpbmd9YCkgPT4gdm9pZDtcbiAgcmVqZWN0OiAoZXJyb3I6IEVycm9yKSA9PiB2b2lkO1xuICB0aW1lb3V0SWQ6IFJldHVyblR5cGU8dHlwZW9mIHNldFRpbWVvdXQ+O1xuICB3aW5kb3dJZD86IG51bWJlcjtcbiAgbWVzc2FnZTogc3RyaW5nO1xuICBhZGRyZXNzOiBgMHgke3N0cmluZ31gO1xuICBvcmlnaW46IHN0cmluZztcbiAgcG9ja2V0SWQ6IHN0cmluZztcbiAgY29ubmVjdGlvbjogQ29ubmVjdGVkU2l0ZVJlY29yZCB8IG51bGw7XG4gIHdhcm5pbmc6IERhcHBXYXJuaW5nQ29udGV4dCB8IG51bGw7XG59O1xuXG5leHBvcnQgY2xhc3MgTWVzc2FnZUhhbmRsZXIge1xuICBwcml2YXRlIHBlbmRpbmdEYXBwQ29ubmVjdHMgPSBuZXcgTWFwPHN0cmluZywgUGVuZGluZ0RhcHBDb25uZWN0PigpO1xuICBwcml2YXRlIHBlbmRpbmdEYXBwVHJhbnNhY3Rpb25zID0gbmV3IE1hcDxzdHJpbmcsIFBlbmRpbmdEYXBwVHJhbnNhY3Rpb24+KCk7XG4gIHByaXZhdGUgcGVuZGluZ0RhcHBTaWduYXR1cmVzID0gbmV3IE1hcDxzdHJpbmcsIFBlbmRpbmdEYXBwU2lnbmF0dXJlPigpO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgc3RvcmFnZTogU3RvcmFnZU1hbmFnZXIsXG4gICAgcHJpdmF0ZSBhcGk6IEFwaUNvbnRyb2xsZXIsXG4gICkge1xuICAgIGNocm9tZS53aW5kb3dzLm9uUmVtb3ZlZC5hZGRMaXN0ZW5lcigod2luZG93SWQpID0+IHtcbiAgICAgIGZvciAoY29uc3QgW3JlcXVlc3RJZCwgZW50cnldIG9mIHRoaXMucGVuZGluZ0RhcHBDb25uZWN0cykge1xuICAgICAgICBpZiAoZW50cnkud2luZG93SWQgIT09IHdpbmRvd0lkKSBjb250aW51ZTtcbiAgICAgICAgY2xlYXJUaW1lb3V0KGVudHJ5LnRpbWVvdXRJZCk7XG4gICAgICAgIHRoaXMucGVuZGluZ0RhcHBDb25uZWN0cy5kZWxldGUocmVxdWVzdElkKTtcbiAgICAgICAgZW50cnkucmVqZWN0KG5ldyBFcnJvcihcIkNvbm5lY3Rpb24gY29uZmlybWF0aW9uIHdhcyBjbG9zZWRcIikpO1xuICAgICAgfVxuXG4gICAgICBmb3IgKGNvbnN0IFtvcGVyYXRpb25JZCwgZW50cnldIG9mIHRoaXMucGVuZGluZ0RhcHBUcmFuc2FjdGlvbnMpIHtcbiAgICAgICAgaWYgKGVudHJ5LndpbmRvd0lkICE9PSB3aW5kb3dJZCkgY29udGludWU7XG4gICAgICAgIGNsZWFyVGltZW91dChlbnRyeS50aW1lb3V0SWQpO1xuICAgICAgICB0aGlzLnBlbmRpbmdEYXBwVHJhbnNhY3Rpb25zLmRlbGV0ZShvcGVyYXRpb25JZCk7XG4gICAgICAgIGVudHJ5LnJlamVjdChuZXcgRXJyb3IoXCJUcmFuc2FjdGlvbiBjb25maXJtYXRpb24gd2FzIGNsb3NlZFwiKSk7XG4gICAgICB9XG5cbiAgICAgIGZvciAoY29uc3QgW3JlcXVlc3RJZCwgZW50cnldIG9mIHRoaXMucGVuZGluZ0RhcHBTaWduYXR1cmVzKSB7XG4gICAgICAgIGlmIChlbnRyeS53aW5kb3dJZCAhPT0gd2luZG93SWQpIGNvbnRpbnVlO1xuICAgICAgICBjbGVhclRpbWVvdXQoZW50cnkudGltZW91dElkKTtcbiAgICAgICAgdGhpcy5wZW5kaW5nRGFwcFNpZ25hdHVyZXMuZGVsZXRlKHJlcXVlc3RJZCk7XG4gICAgICAgIGVudHJ5LnJlamVjdChuZXcgRXJyb3IoXCJTaWduYXR1cmUgY29uZmlybWF0aW9uIHdhcyBjbG9zZWRcIikpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG5cbiAgYXN5bmMgaGFuZGxlTWVzc2FnZShcbiAgICBtZXNzYWdlOiBNZXNzYWdlLFxuICAgIHNlbmRlcjogY2hyb21lLnJ1bnRpbWUuTWVzc2FnZVNlbmRlcixcbiAgKTogUHJvbWlzZTx1bmtub3duPiB7XG4gICAgY29uc29sZS5sb2coXCJbTWVzc2FnZUhhbmRsZXJdIEhhbmRsaW5nOlwiLCBtZXNzYWdlLnR5cGUpO1xuXG4gICAgc3dpdGNoIChtZXNzYWdlLnR5cGUpIHtcbiAgICAgIGNhc2UgXCJDT05ORUNUX1NJVEVcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlQ29ubmVjdFNpdGUobWVzc2FnZS5wYXlsb2FkLCBzZW5kZXIpO1xuXG4gICAgICBjYXNlIFwiRElTQ09OTkVDVF9TSVRFXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmhhbmRsZURpc2Nvbm5lY3RTaXRlKG1lc3NhZ2UucGF5bG9hZCk7XG5cbiAgICAgIGNhc2UgXCJTRU5EX1RSQU5TQUNUSU9OXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmhhbmRsZVNlbmRUcmFuc2FjdGlvbihtZXNzYWdlLnBheWxvYWQsIHNlbmRlcik7XG5cbiAgICAgIGNhc2UgXCJTSUdOX01FU1NBR0VcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlU2lnbk1lc3NhZ2UobWVzc2FnZS5wYXlsb2FkLCBzZW5kZXIpO1xuXG4gICAgICBjYXNlIFwiQ0xFQVJfQUxMX0RBVEFcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlQ2xlYXJBbGxEYXRhKCk7XG5cbiAgICAgIGNhc2UgXCJBUElfR0VUX1NFU1NJT05cIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuYXBpLmdldFNlc3Npb24oKTtcblxuICAgICAgY2FzZSBcIkFQSV9TRVRfU0VTU0lPTlwiOlxuICAgICAgICByZXR1cm4gdGhpcy5hcGkuc2V0U2Vzc2lvbihtZXNzYWdlLnBheWxvYWQpO1xuXG4gICAgICBjYXNlIFwiQVBJX0NMRUFSX1NFU1NJT05cIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuYXBpLmNsZWFyU2Vzc2lvbigpO1xuXG4gICAgICBjYXNlIFwiQVBJX0dFVF9DSEFJTl9JRFwiOlxuICAgICAgICByZXR1cm4gdGhpcy5hcGkuZ2V0Q2hhaW5JZCgpO1xuXG4gICAgICBjYXNlIFwiQVBJX1VTRVJTX01FXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmFwaS5nZXRNZSgpO1xuXG4gICAgICBjYXNlIFwiQVBJX1BPQ0tFVF9TRUxFQ1RcIjpcbiAgICAgICAgYXdhaXQgdGhpcy5hcGkuc2V0U2VsZWN0ZWRQb2NrZXRJZChtZXNzYWdlLnBheWxvYWQucG9ja2V0SWQpO1xuICAgICAgICByZXR1cm4geyBwb2NrZXRJZDogbWVzc2FnZS5wYXlsb2FkLnBvY2tldElkIH07XG5cbiAgICAgIGNhc2UgXCJBUElfUE9DS0VUX1BSRVBBUkVcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuYXBpLnByZXBhcmVQb2NrZXQoKTtcblxuICAgICAgY2FzZSBcIkFQSV9QT0NLRVRfU1VCTUlUXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmFwaS5zdWJtaXRQb2NrZXQobWVzc2FnZS5wYXlsb2FkIGFzIFBvY2tldFN1Ym1pdFJlcXVlc3QpO1xuXG4gICAgICBjYXNlIFwiQVBJX1BPQ0tFVF9TRU5EX1BSRVBBUkVcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuYXBpLnByZXBhcmVQb2NrZXRTZW5kKFxuICAgICAgICAgIG1lc3NhZ2UucGF5bG9hZC5wb2NrZXRJZCxcbiAgICAgICAgICBtZXNzYWdlLnBheWxvYWQucmVxdWVzdCBhcyBQb2NrZXRUeFNlbmRQcmVwYXJlUmVxdWVzdCxcbiAgICAgICAgKTtcblxuICAgICAgY2FzZSBcIkFQSV9QT0NLRVRfU0VORF9TVUJNSVRcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuYXBpLnN1Ym1pdFBvY2tldFNlbmQoXG4gICAgICAgICAgbWVzc2FnZS5wYXlsb2FkLnBvY2tldElkLFxuICAgICAgICAgIG1lc3NhZ2UucGF5bG9hZC5yZXF1ZXN0IGFzIFBvY2tldFN1Ym1pdFJlcXVlc3QsXG4gICAgICAgICk7XG5cbiAgICAgIGNhc2UgXCJBUElfUE9DS0VUX0NVU1RPTV9QUkVQQVJFXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmFwaS5wcmVwYXJlUG9ja2V0Q3VzdG9tKFxuICAgICAgICAgIG1lc3NhZ2UucGF5bG9hZC5wb2NrZXRJZCxcbiAgICAgICAgICBtZXNzYWdlLnBheWxvYWQucmVxdWVzdCBhcyB7XG4gICAgICAgICAgICBtZXRhVHJhbnNhY3Rpb25zOiBQb2NrZXRNZXRhVHJhbnNhY3Rpb25bXTtcbiAgICAgICAgICB9LFxuICAgICAgICApO1xuXG4gICAgICBjYXNlIFwiQVBJX1BPQ0tFVF9DVVNUT01fU1VCTUlUXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmFwaS5zdWJtaXRQb2NrZXRDdXN0b20oXG4gICAgICAgICAgbWVzc2FnZS5wYXlsb2FkLnBvY2tldElkLFxuICAgICAgICAgIG1lc3NhZ2UucGF5bG9hZC5yZXF1ZXN0IGFzIFBvY2tldFN1Ym1pdFJlcXVlc3QsXG4gICAgICAgICk7XG5cbiAgICAgIGNhc2UgXCJBUElfUE9DS0VUX1BFUlNPTkFMX1NJR05fUFJFUEFSRVwiOlxuICAgICAgICByZXR1cm4gdGhpcy5hcGkucHJlcGFyZVBvY2tldFBlcnNvbmFsU2lnbihcbiAgICAgICAgICBtZXNzYWdlLnBheWxvYWQucG9ja2V0SWQsXG4gICAgICAgICAgbWVzc2FnZS5wYXlsb2FkLnJlcXVlc3QgYXMgUG9ja2V0UGVyc29uYWxTaWduUHJlcGFyZVJlcXVlc3QsXG4gICAgICAgICk7XG5cbiAgICAgIGNhc2UgXCJBUElfUE9DS0VUX1BFUlNPTkFMX1NJR05fU1VCTUlUXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmFwaS5zdWJtaXRQb2NrZXRQZXJzb25hbFNpZ24oXG4gICAgICAgICAgbWVzc2FnZS5wYXlsb2FkLnBvY2tldElkLFxuICAgICAgICAgIG1lc3NhZ2UucGF5bG9hZC5yZXF1ZXN0IGFzIFBvY2tldFBlcnNvbmFsU2lnblN1Ym1pdFJlcXVlc3QsXG4gICAgICAgICk7XG5cbiAgICAgIGNhc2UgXCJBUElfUE9DS0VUX0JBTEFOQ0VTXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmFwaS5nZXRQb2NrZXRCYWxhbmNlcyhtZXNzYWdlLnBheWxvYWQucG9ja2V0SWQpO1xuXG4gICAgICBjYXNlIFwiQVBJX1BPQ0tFVF9BQ1RJVklUSUVTXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmFwaS5nZXRQb2NrZXRBY3Rpdml0aWVzKG1lc3NhZ2UucGF5bG9hZC5wb2NrZXRJZCwge1xuICAgICAgICAgIGN1cnNvcjogbWVzc2FnZS5wYXlsb2FkLmN1cnNvcixcbiAgICAgICAgICBsaW1pdDogbWVzc2FnZS5wYXlsb2FkLmxpbWl0LFxuICAgICAgICB9KTtcblxuICAgICAgY2FzZSBcIkFQSV9VU0VST1BfR0VUXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmFwaS5nZXRVc2VyT3BlcmF0aW9uKG1lc3NhZ2UucGF5bG9hZC5vcGVyYXRpb25JZCk7XG5cbiAgICAgIGNhc2UgXCJBUElfVVNFUk9QX0NBTkNFTFwiOlxuICAgICAgICByZXR1cm4gdGhpcy5hcGkuY2FuY2VsVXNlck9wZXJhdGlvbihtZXNzYWdlLnBheWxvYWQub3BlcmF0aW9uSWQpO1xuXG4gICAgICBjYXNlIFwiQVBJX0RBUFBfQ09OTkVDVF9DT05URVhUXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmhhbmRsZUFwaURhcHBDb25uZWN0Q29udGV4dChtZXNzYWdlLnBheWxvYWQpO1xuXG4gICAgICBjYXNlIFwiQVBJX0RBUFBfQ09OTkVDVF9SRVNVTFRcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlQXBpRGFwcENvbm5lY3RSZXN1bHQobWVzc2FnZS5wYXlsb2FkKTtcblxuICAgICAgY2FzZSBcIkFQSV9EQVBQX1RYX0NPTlRFWFRcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlQXBpRGFwcFR4Q29udGV4dChtZXNzYWdlLnBheWxvYWQpO1xuXG4gICAgICBjYXNlIFwiQVBJX0RBUFBfVFhfUkVTVUxUXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmhhbmRsZUFwaURhcHBUeFJlc3VsdChtZXNzYWdlLnBheWxvYWQpO1xuXG4gICAgICBjYXNlIFwiQVBJX0RBUFBfU0lHTl9DT05URVhUXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmhhbmRsZUFwaURhcHBTaWduQ29udGV4dChtZXNzYWdlLnBheWxvYWQpO1xuXG4gICAgICBjYXNlIFwiQVBJX0RBUFBfU0lHTl9SRVNVTFRcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuaGFuZGxlQXBpRGFwcFNpZ25SZXN1bHQobWVzc2FnZS5wYXlsb2FkKTtcblxuICAgICAgY2FzZSBcIkFQSV9BRERSRVNTX0JPT0tfTElTVFwiOlxuICAgICAgICByZXR1cm4gdGhpcy5hcGkubGlzdEFkZHJlc3NCb29rKCk7XG5cbiAgICAgIGNhc2UgXCJBUElfQUREUkVTU19CT09LX1VQU0VSVFwiOlxuICAgICAgICByZXR1cm4gdGhpcy5hcGkudXBzZXJ0QWRkcmVzc0Jvb2soXG4gICAgICAgICAgbWVzc2FnZS5wYXlsb2FkIGFzIEFkZHJlc3NCb29rVXBzZXJ0UmVxdWVzdCxcbiAgICAgICAgKTtcblxuICAgICAgY2FzZSBcIkFQSV9BRERSRVNTX0JPT0tfREVMRVRFXCI6XG4gICAgICAgIHJldHVybiB0aGlzLmFwaS5kZWxldGVBZGRyZXNzQm9vayhcbiAgICAgICAgICBtZXNzYWdlLnBheWxvYWQgYXMgQWRkcmVzc0Jvb2tEZWxldGVSZXF1ZXN0LFxuICAgICAgICApO1xuXG4gICAgICBkZWZhdWx0OlxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgYFVua25vd24gbWVzc2FnZSB0eXBlOiAke1xuICAgICAgICAgICAgKG1lc3NhZ2UgYXMgeyB0eXBlPzogc3RyaW5nIH0pLnR5cGUgPz8gXCJ1bmtub3duXCJcbiAgICAgICAgICB9YCxcbiAgICAgICAgKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIG5vcm1hbGl6ZU9yaWdpbih2YWx1ZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdXJsID0gbmV3IFVSTCh2YWx1ZSk7XG4gICAgICBjb25zdCBwcm90b2NvbCA9IHVybC5wcm90b2NvbC50b0xvd2VyQ2FzZSgpO1xuICAgICAgY29uc3QgaG9zdG5hbWUgPSB1cmwuaG9zdG5hbWUudG9Mb3dlckNhc2UoKTtcbiAgICAgIGNvbnN0IHBvcnQgPSB1cmwucG9ydDtcbiAgICAgIGNvbnN0IGluY2x1ZGVQb3J0ID1cbiAgICAgICAgcG9ydC5sZW5ndGggPiAwICYmXG4gICAgICAgICEoXG4gICAgICAgICAgKHByb3RvY29sID09PSBcImh0dHBzOlwiICYmIHBvcnQgPT09IFwiNDQzXCIpIHx8XG4gICAgICAgICAgKHByb3RvY29sID09PSBcImh0dHA6XCIgJiYgcG9ydCA9PT0gXCI4MFwiKVxuICAgICAgICApO1xuICAgICAgY29uc3QgaG9zdCA9IGluY2x1ZGVQb3J0ID8gYCR7aG9zdG5hbWV9OiR7cG9ydH1gIDogaG9zdG5hbWU7XG4gICAgICByZXR1cm4gYCR7cHJvdG9jb2x9Ly8ke2hvc3R9YDtcbiAgICB9IGNhdGNoIHtcbiAgICAgIHJldHVybiB2YWx1ZS50cmltKCkudG9Mb3dlckNhc2UoKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIHRvQ29ubmVjdGVkU2l0ZVJlY29yZChcbiAgICBjb25uZWN0aW9uOiBEYXBwQ29ubmVjdGlvblN1bW1hcnksXG4gICk6IENvbm5lY3RlZFNpdGVSZWNvcmQge1xuICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gICAgcmV0dXJuIHtcbiAgICAgIGNvbm5lY3Rpb25JZDogY29ubmVjdGlvbi5jb25uZWN0aW9uSWQsXG4gICAgICBvcmlnaW46IGNvbm5lY3Rpb24ub3JpZ2luLFxuICAgICAgbm9ybWFsaXplZE9yaWdpbjogY29ubmVjdGlvbi5ub3JtYWxpemVkT3JpZ2luLFxuICAgICAgaG9zdDogY29ubmVjdGlvbi5ob3N0LFxuICAgICAgd2FsbGV0U2NvcGU6IGNvbm5lY3Rpb24ud2FsbGV0U2NvcGUsXG4gICAgICB3YWxsZXRJZDogY29ubmVjdGlvbi53YWxsZXRJZCxcbiAgICAgIHdhbGxldEFkZHJlc3M6IGNvbm5lY3Rpb24ud2FsbGV0QWRkcmVzcyxcbiAgICAgIGNoYWluSWQ6IGNvbm5lY3Rpb24uY2hhaW5JZCxcbiAgICAgIHRydXN0TGV2ZWw6IGNvbm5lY3Rpb24udHJ1c3RMZXZlbCxcbiAgICAgIGNvbm5lY3RlZEF0OiBjb25uZWN0aW9uLmNvbm5lY3RlZEF0XG4gICAgICAgID8gRGF0ZS5wYXJzZShjb25uZWN0aW9uLmNvbm5lY3RlZEF0KSB8fCBub3dcbiAgICAgICAgOiBub3csXG4gICAgICBsYXN0VXNlZEF0OiBub3csXG4gICAgfTtcbiAgfVxuXG4gIHByaXZhdGUgYnVpbGRVbmtub3duU2lnbmluZ1dhcm5pbmcoaG9zdDogc3RyaW5nKTogRGFwcFdhcm5pbmdDb250ZXh0IHtcbiAgICByZXR1cm4ge1xuICAgICAgdG9uZTogXCJzb2Z0XCIsXG4gICAgICB0aXRsZTogXCJVbmtub3duIGRBcHBcIixcbiAgICAgIG1lc3NhZ2U6IGAke2hvc3R9IGlzIG5vdCBpbiB0aGUgdHJ1c3RlZCBsaXN0LiBSZXZpZXcgZGV0YWlscyBjYXJlZnVsbHkgYmVmb3JlIHNpZ25pbmcuYCxcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyByZWNvcmRTaWduRXZlbnQoXG4gICAgY29ubmVjdGlvbklkOiBzdHJpbmcsXG4gICAga2luZDogXCJ0cmFuc2FjdGlvblwiIHwgXCJtZXNzYWdlXCIsXG4gICAgb3V0Y29tZTogXCJyZXF1ZXN0ZWRcIiB8IFwiYXBwcm92ZWRcIiB8IFwicmVqZWN0ZWRcIiB8IFwiZmFpbGVkXCIsXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmFwaS5yZWNvcmREYXBwQ29ubmVjdGlvblNpZ25FdmVudChjb25uZWN0aW9uSWQsIHtcbiAgICAgICAga2luZCxcbiAgICAgICAgb3V0Y29tZSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLndhcm4oXCJbTWVzc2FnZUhhbmRsZXJdIEZhaWxlZCB0byByZWNvcmQgZEFwcCBzaWduIGV2ZW50OlwiLCBlcnJvcik7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyByZXNvbHZlQ29ubmVjdGVkU2l0ZUZvclBvY2tldChcbiAgICBvcmlnaW46IHN0cmluZyxcbiAgICBwb2NrZXQ6IE1lUG9ja2V0LFxuICApOiBQcm9taXNlPENvbm5lY3RlZFNpdGVSZWNvcmQgfCBudWxsPiB7XG4gICAgY29uc3QgbG9jYWwgPSBhd2FpdCB0aGlzLnN0b3JhZ2UuZmluZENvbm5lY3RlZFNpdGUoe1xuICAgICAgb3JpZ2luLFxuICAgICAgd2FsbGV0QWRkcmVzczogcG9ja2V0LmFkZHJlc3MsXG4gICAgICBjaGFpbklkOiBwb2NrZXQuY2hhaW5JZCxcbiAgICAgIHdhbGxldFNjb3BlOiBcInBvY2tldFwiLFxuICAgIH0pO1xuICAgIGlmIChsb2NhbCkge1xuICAgICAgcmV0dXJuIGxvY2FsO1xuICAgIH1cblxuICAgIHRyeSB7XG4gICAgICBjb25zdCBub3JtYWxpemVkT3JpZ2luID0gdGhpcy5ub3JtYWxpemVPcmlnaW4ob3JpZ2luKTtcbiAgICAgIGNvbnN0IHJlbW90ZSA9IGF3YWl0IHRoaXMuYXBpLmxpc3REYXBwQ29ubmVjdGlvbnMoe1xuICAgICAgICB3YWxsZXRTY29wZTogXCJwb2NrZXRcIixcbiAgICAgICAgd2FsbGV0SWQ6IHBvY2tldC5wb2NrZXRJZCxcbiAgICAgICAgc3RhdHVzOiBcImNvbm5lY3RlZFwiLFxuICAgICAgfSk7XG4gICAgICBjb25zdCBtYXRjaCA9IHJlbW90ZS5jb25uZWN0aW9ucy5maW5kKFxuICAgICAgICAoY29ubmVjdGlvbikgPT4gY29ubmVjdGlvbi5ub3JtYWxpemVkT3JpZ2luID09PSBub3JtYWxpemVkT3JpZ2luLFxuICAgICAgKTtcbiAgICAgIGlmICghbWF0Y2gpIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHJlY29yZCA9IHRoaXMudG9Db25uZWN0ZWRTaXRlUmVjb3JkKG1hdGNoKTtcbiAgICAgIGF3YWl0IHRoaXMuc3RvcmFnZS5hZGRDb25uZWN0ZWRTaXRlKHJlY29yZCk7XG4gICAgICByZXR1cm4gcmVjb3JkO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLndhcm4oXCJbTWVzc2FnZUhhbmRsZXJdIEZhaWxlZCB0byByZXNvbHZlIGNvbm5lY3RlZCBkQXBwOlwiLCBlcnJvcik7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGhhbmRsZUNvbm5lY3RTaXRlKFxuICAgIHBheWxvYWQ6IHsgb3JpZ2luOiBzdHJpbmcgfSxcbiAgICBzZW5kZXI6IGNocm9tZS5ydW50aW1lLk1lc3NhZ2VTZW5kZXIsXG4gICkge1xuICAgIGNvbnN0IHJhd09yaWdpbiA9IHBheWxvYWQub3JpZ2luIHx8IHNlbmRlci5vcmlnaW4gfHwgc2VuZGVyLnVybDtcbiAgICBpZiAoIXJhd09yaWdpbikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm8gb3JpZ2luIHByb3ZpZGVkXCIpO1xuICAgIH1cbiAgICBjb25zdCBvcmlnaW4gPSB0aGlzLm5vcm1hbGl6ZU9yaWdpbihyYXdPcmlnaW4pO1xuXG4gICAgY29uc3QgcG9ja2V0ID0gYXdhaXQgdGhpcy5lbnN1cmVQcmltYXJ5UG9ja2V0UmVhZHkoKTtcbiAgICBpZiAoIXBvY2tldCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBcIldhbGxldCBub3QgcmVhZHkuIFNpZ24gaW4gdG8gdGhlIGV4dGVuc2lvbiBhbmQgY3JlYXRlIGEgcG9ja2V0LlwiLFxuICAgICAgKTtcbiAgICB9XG5cbiAgICBjb25zdCBwcmVwYXJlZCA9IGF3YWl0IHRoaXMuYXBpLnByZXBhcmVEYXBwQ29ubmVjdGlvbih7XG4gICAgICBvcmlnaW4sXG4gICAgICB3YWxsZXRTY29wZTogXCJwb2NrZXRcIixcbiAgICAgIHdhbGxldEFkZHJlc3M6IHBvY2tldC5hZGRyZXNzLFxuICAgICAgY2hhaW5JZDogcG9ja2V0LmNoYWluSWQsXG4gICAgICBwb2NrZXRJZDogcG9ja2V0LnBvY2tldElkLFxuICAgIH0pO1xuXG4gICAgaWYgKHByZXBhcmVkLmNvbm5lY3Rpb24udHJ1c3RMZXZlbCA9PT0gXCJibG9ja2VkXCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihwcmVwYXJlZC53YXJuaW5nTWVzc2FnZSB8fCBcIlRoaXMgZEFwcCBpcyBibG9ja2VkXCIpO1xuICAgIH1cblxuICAgIGlmIChcbiAgICAgIHByZXBhcmVkLmFscmVhZHlDb25uZWN0ZWQgJiZcbiAgICAgIHByZXBhcmVkLmNvbm5lY3Rpb24uc3RhdHVzID09PSBcImNvbm5lY3RlZFwiXG4gICAgKSB7XG4gICAgICBhd2FpdCB0aGlzLnN0b3JhZ2UuYWRkQ29ubmVjdGVkU2l0ZShcbiAgICAgICAgdGhpcy50b0Nvbm5lY3RlZFNpdGVSZWNvcmQocHJlcGFyZWQuY29ubmVjdGlvbiksXG4gICAgICApO1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgY29ubmVjdGVkOiB0cnVlLFxuICAgICAgICBhY2NvdW50czogW3BvY2tldC5hZGRyZXNzXSxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgY29uc3QgcmVxdWVzdElkID0gY3J5cHRvLnJhbmRvbVVVSUQoKTtcbiAgICBjb25zdCB3aW5kb3dJZCA9IGF3YWl0IHRoaXMub3BlbkNvbm5lY3RDb25maXJtV2luZG93KHJlcXVlc3RJZCk7XG5cbiAgICBsZXQgYXBwcm92ZWQgPSBmYWxzZTtcbiAgICB0cnkge1xuICAgICAgYXBwcm92ZWQgPSBhd2FpdCB0aGlzLmF3YWl0RGFwcENvbm5lY3RDb25maXJtYXRpb24ocmVxdWVzdElkLCB7XG4gICAgICAgIHdpbmRvd0lkLFxuICAgICAgICBvcmlnaW4sXG4gICAgICAgIHdhbGxldEFkZHJlc3M6IHBvY2tldC5hZGRyZXNzLFxuICAgICAgICBjb25uZWN0aW9uOiBwcmVwYXJlZC5jb25uZWN0aW9uLFxuICAgICAgICB3YXJuaW5nOiB7XG4gICAgICAgICAgdG9uZTogcHJlcGFyZWQud2FybmluZ1RvbmUsXG4gICAgICAgICAgdGl0bGU6IHByZXBhcmVkLndhcm5pbmdUaXRsZSxcbiAgICAgICAgICBtZXNzYWdlOiBwcmVwYXJlZC53YXJuaW5nTWVzc2FnZSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBhd2FpdCB0aGlzLmFwaVxuICAgICAgICAucmVqZWN0RGFwcENvbm5lY3Rpb24ocHJlcGFyZWQuY29ubmVjdGlvbi5jb25uZWN0aW9uSWQpXG4gICAgICAgIC5jYXRjaCgoKSA9PiB1bmRlZmluZWQpO1xuICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxuXG4gICAgaWYgKCFhcHByb3ZlZCkge1xuICAgICAgYXdhaXQgdGhpcy5hcGlcbiAgICAgICAgLnJlamVjdERhcHBDb25uZWN0aW9uKHByZXBhcmVkLmNvbm5lY3Rpb24uY29ubmVjdGlvbklkKVxuICAgICAgICAuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlVzZXIgcmVqZWN0ZWQgY29ubmVjdGlvblwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBjb25maXJtZWQgPSBhd2FpdCB0aGlzLmFwaS5jb25maXJtRGFwcENvbm5lY3Rpb24oXG4gICAgICBwcmVwYXJlZC5jb25uZWN0aW9uLmNvbm5lY3Rpb25JZCxcbiAgICApO1xuICAgIGF3YWl0IHRoaXMuc3RvcmFnZS5hZGRDb25uZWN0ZWRTaXRlKFxuICAgICAgdGhpcy50b0Nvbm5lY3RlZFNpdGVSZWNvcmQoY29uZmlybWVkLmNvbm5lY3Rpb24pLFxuICAgICk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgY29ubmVjdGVkOiB0cnVlLFxuICAgICAgYWNjb3VudHM6IFtwb2NrZXQuYWRkcmVzc10sXG4gICAgfTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgaGFuZGxlRGlzY29ubmVjdFNpdGUocGF5bG9hZDogeyBvcmlnaW46IHN0cmluZyB9KSB7XG4gICAgY29uc3QgcG9ja2V0ID0gYXdhaXQgdGhpcy5nZXRQcmltYXJ5UG9ja2V0KCk7XG4gICAgaWYgKCFwb2NrZXQpIHtcbiAgICAgIGF3YWl0IHRoaXMuc3RvcmFnZS5yZW1vdmVDb25uZWN0ZWRTaXRlc0Zvck9yaWdpbihwYXlsb2FkLm9yaWdpbik7XG4gICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gICAgfVxuXG4gICAgY29uc3Qgc2l0ZSA9IGF3YWl0IHRoaXMuc3RvcmFnZS5maW5kQ29ubmVjdGVkU2l0ZSh7XG4gICAgICBvcmlnaW46IHBheWxvYWQub3JpZ2luLFxuICAgICAgd2FsbGV0QWRkcmVzczogcG9ja2V0LmFkZHJlc3MsXG4gICAgICBjaGFpbklkOiBwb2NrZXQuY2hhaW5JZCxcbiAgICAgIHdhbGxldFNjb3BlOiBcInBvY2tldFwiLFxuICAgIH0pO1xuXG4gICAgaWYgKHNpdGUpIHtcbiAgICAgIGF3YWl0IHRoaXMuYXBpXG4gICAgICAgIC5kaXNjb25uZWN0RGFwcENvbm5lY3Rpb24oc2l0ZS5jb25uZWN0aW9uSWQpXG4gICAgICAgIC5jYXRjaCgoZXJyb3IpID0+IHtcbiAgICAgICAgICBjb25zb2xlLndhcm4oXCJbTWVzc2FnZUhhbmRsZXJdIEZhaWxlZCB0byBkaXNjb25uZWN0IGRBcHA6XCIsIGVycm9yKTtcbiAgICAgICAgfSk7XG4gICAgICBhd2FpdCB0aGlzLnN0b3JhZ2UucmVtb3ZlQ29ubmVjdGVkU2l0ZShzaXRlLmNvbm5lY3Rpb25JZCk7XG4gICAgfVxuXG4gICAgYXdhaXQgdGhpcy5zdG9yYWdlLnJlbW92ZUNvbm5lY3RlZFNpdGVzRm9yT3JpZ2luKFxuICAgICAgcGF5bG9hZC5vcmlnaW4sXG4gICAgICBwb2NrZXQuYWRkcmVzcyxcbiAgICApO1xuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgaGFuZGxlU2VuZFRyYW5zYWN0aW9uKFxuICAgIHBheWxvYWQ6IFRyYW5zYWN0aW9uUmVxdWVzdCxcbiAgICBzZW5kZXI6IGNocm9tZS5ydW50aW1lLk1lc3NhZ2VTZW5kZXIsXG4gICk6IFByb21pc2U8YDB4JHtzdHJpbmd9YD4ge1xuICAgIGNvbnN0IG9yaWdpbiA9IHNlbmRlci5vcmlnaW4gfHwgc2VuZGVyLnVybDtcbiAgICBpZiAoIW9yaWdpbikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm8gb3JpZ2luIHByb3ZpZGVkXCIpO1xuICAgIH1cblxuICAgIGlmICghcGF5bG9hZC50bykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiSW52YWxpZCB0cmFuc2FjdGlvbiBwYXJhbWV0ZXJzXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IHBvY2tldCA9IGF3YWl0IHRoaXMuZ2V0UHJpbWFyeVBvY2tldCgpO1xuICAgIGlmICghcG9ja2V0KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBwb2NrZXQgYXZhaWxhYmxlXCIpO1xuICAgIH1cblxuICAgIGNvbnN0IGNvbm5lY3Rpb24gPSBhd2FpdCB0aGlzLnJlc29sdmVDb25uZWN0ZWRTaXRlRm9yUG9ja2V0KG9yaWdpbiwgcG9ja2V0KTtcbiAgICBpZiAoIWNvbm5lY3Rpb24pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlNpdGUgbm90IGNvbm5lY3RlZFwiKTtcbiAgICB9XG4gICAgaWYgKGNvbm5lY3Rpb24udHJ1c3RMZXZlbCA9PT0gXCJibG9ja2VkXCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRoaXMgZEFwcCBpcyBibG9ja2VkXCIpO1xuICAgIH1cblxuICAgIGF3YWl0IHRoaXMuc3RvcmFnZS50b3VjaENvbm5lY3RlZFNpdGUoY29ubmVjdGlvbi5jb25uZWN0aW9uSWQpO1xuICAgIHZvaWQgdGhpcy5yZWNvcmRTaWduRXZlbnQoXG4gICAgICBjb25uZWN0aW9uLmNvbm5lY3Rpb25JZCxcbiAgICAgIFwidHJhbnNhY3Rpb25cIixcbiAgICAgIFwicmVxdWVzdGVkXCIsXG4gICAgKTtcblxuICAgIGNvbnN0IHdhcm5pbmcgPVxuICAgICAgY29ubmVjdGlvbi50cnVzdExldmVsID09PSBcInVua25vd25cIlxuICAgICAgICA/IHRoaXMuYnVpbGRVbmtub3duU2lnbmluZ1dhcm5pbmcoY29ubmVjdGlvbi5ob3N0KVxuICAgICAgICA6IG51bGw7XG5cbiAgICBjb25zdCBwcmVwYXJlZCA9IGF3YWl0IHRoaXMuYXBpLnByZXBhcmVQb2NrZXRDdXN0b20ocG9ja2V0LnBvY2tldElkLCB7XG4gICAgICBtZXRhVHJhbnNhY3Rpb25zOiBbXG4gICAgICAgIHtcbiAgICAgICAgICB0bzogcGF5bG9hZC50byBhcyBgMHgke3N0cmluZ31gLFxuICAgICAgICAgIHZhbHVlOiAocGF5bG9hZC52YWx1ZSB8fCBcIjB4MFwiKSBhcyBgMHgke3N0cmluZ31gLFxuICAgICAgICAgIGRhdGE6IChwYXlsb2FkLmRhdGEgfHwgXCIweFwiKSBhcyBgMHgke3N0cmluZ31gLFxuICAgICAgICB9LFxuICAgICAgXSxcbiAgICB9KTtcblxuICAgIGNvbnN0IHdpbmRvd0lkID0gYXdhaXQgdGhpcy5vcGVuQ29uZmlybVdpbmRvdyhwcmVwYXJlZC5vcGVyYXRpb25JZCk7XG4gICAgcmV0dXJuIHRoaXMuYXdhaXREYXBwQ29uZmlybWF0aW9uKHByZXBhcmVkLm9wZXJhdGlvbklkLCB7XG4gICAgICB3aW5kb3dJZCxcbiAgICAgIG9yaWdpbjogY29ubmVjdGlvbi5vcmlnaW4sXG4gICAgICBjb25uZWN0aW9uLFxuICAgICAgd2FybmluZyxcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgaGFuZGxlU2lnbk1lc3NhZ2UoXG4gICAgcGF5bG9hZDogU2lnbk1lc3NhZ2VSZXF1ZXN0LFxuICAgIHNlbmRlcjogY2hyb21lLnJ1bnRpbWUuTWVzc2FnZVNlbmRlcixcbiAgKTogUHJvbWlzZTxgMHgke3N0cmluZ31gPiB7XG4gICAgY29uc3Qgb3JpZ2luID0gc2VuZGVyLm9yaWdpbiB8fCBzZW5kZXIudXJsO1xuICAgIGlmICghb3JpZ2luKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBvcmlnaW4gcHJvdmlkZWRcIik7XG4gICAgfVxuXG4gICAgaWYgKHR5cGVvZiBwYXlsb2FkLm1lc3NhZ2UgIT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgc2lnbiBtZXNzYWdlIHBhcmFtZXRlcnNcIik7XG4gICAgfVxuXG4gICAgY29uc3QgcG9ja2V0ID0gYXdhaXQgdGhpcy5nZXRQcmltYXJ5UG9ja2V0KCk7XG4gICAgaWYgKCFwb2NrZXQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIk5vIHBvY2tldCBhdmFpbGFibGVcIik7XG4gICAgfVxuXG4gICAgY29uc3QgY29ubmVjdGlvbiA9IGF3YWl0IHRoaXMucmVzb2x2ZUNvbm5lY3RlZFNpdGVGb3JQb2NrZXQob3JpZ2luLCBwb2NrZXQpO1xuICAgIGlmICghY29ubmVjdGlvbikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiU2l0ZSBub3QgY29ubmVjdGVkXCIpO1xuICAgIH1cbiAgICBpZiAoY29ubmVjdGlvbi50cnVzdExldmVsID09PSBcImJsb2NrZWRcIikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiVGhpcyBkQXBwIGlzIGJsb2NrZWRcIik7XG4gICAgfVxuXG4gICAgY29uc3QgcmVxdWVzdGVkQWRkcmVzcyA9IHBheWxvYWQuYWRkcmVzcz8udG9Mb3dlckNhc2UoKTtcbiAgICBpZiAocmVxdWVzdGVkQWRkcmVzcyAmJiByZXF1ZXN0ZWRBZGRyZXNzICE9PSBwb2NrZXQuYWRkcmVzcy50b0xvd2VyQ2FzZSgpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJSZXF1ZXN0ZWQgYWNjb3VudCBkb2VzIG5vdCBtYXRjaCBzZWxlY3RlZCBwb2NrZXRcIik7XG4gICAgfVxuXG4gICAgYXdhaXQgdGhpcy5zdG9yYWdlLnRvdWNoQ29ubmVjdGVkU2l0ZShjb25uZWN0aW9uLmNvbm5lY3Rpb25JZCk7XG4gICAgdm9pZCB0aGlzLnJlY29yZFNpZ25FdmVudChjb25uZWN0aW9uLmNvbm5lY3Rpb25JZCwgXCJtZXNzYWdlXCIsIFwicmVxdWVzdGVkXCIpO1xuXG4gICAgY29uc3Qgd2FybmluZyA9XG4gICAgICBjb25uZWN0aW9uLnRydXN0TGV2ZWwgPT09IFwidW5rbm93blwiXG4gICAgICAgID8gdGhpcy5idWlsZFVua25vd25TaWduaW5nV2FybmluZyhjb25uZWN0aW9uLmhvc3QpXG4gICAgICAgIDogbnVsbDtcblxuICAgIGNvbnN0IHJlcXVlc3RJZCA9IGNyeXB0by5yYW5kb21VVUlEKCk7XG4gICAgY29uc3Qgd2luZG93SWQgPSBhd2FpdCB0aGlzLm9wZW5TaWduQ29uZmlybVdpbmRvdyhyZXF1ZXN0SWQpO1xuICAgIHJldHVybiB0aGlzLmF3YWl0RGFwcFNpZ25Db25maXJtYXRpb24ocmVxdWVzdElkLCB7XG4gICAgICB3aW5kb3dJZCxcbiAgICAgIG1lc3NhZ2U6IHBheWxvYWQubWVzc2FnZSxcbiAgICAgIGFkZHJlc3M6IHBvY2tldC5hZGRyZXNzLFxuICAgICAgb3JpZ2luOiBjb25uZWN0aW9uLm9yaWdpbixcbiAgICAgIHBvY2tldElkOiBwb2NrZXQucG9ja2V0SWQsXG4gICAgICBjb25uZWN0aW9uLFxuICAgICAgd2FybmluZyxcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgaGFuZGxlQ2xlYXJBbGxEYXRhKCkge1xuICAgIGF3YWl0IHRoaXMuc3RvcmFnZS5jbGVhckFsbCgpO1xuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZ2V0UHJpbWFyeVBvY2tldCgpOiBQcm9taXNlPE1lUG9ja2V0IHwgbnVsbD4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCB0aGlzLnN0b3JhZ2UuZ2V0QXBpU2Vzc2lvbigpO1xuICAgIGlmICghc2Vzc2lvbi5yZWZyZXNoVG9rZW4pIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIGxldCBwb2NrZXRzID0gYXdhaXQgdGhpcy5zdG9yYWdlLmdldEFwaVBvY2tldHMoKTtcbiAgICBpZiAocG9ja2V0cy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGF3YWl0IHRoaXMuYXBpLmdldE1lKCk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLndhcm4oXCJbTWVzc2FnZUhhbmRsZXJdIEZhaWxlZCB0byByZWZyZXNoIHBvY2tldHM6XCIsIGVycm9yKTtcbiAgICAgIH1cbiAgICAgIHBvY2tldHMgPSBhd2FpdCB0aGlzLnN0b3JhZ2UuZ2V0QXBpUG9ja2V0cygpO1xuICAgIH1cblxuICAgIGNvbnN0IHNlbGVjdGVkSWQgPSBhd2FpdCB0aGlzLnN0b3JhZ2UuZ2V0QXBpU2VsZWN0ZWRQb2NrZXRJZCgpO1xuICAgIHJldHVybiAoXG4gICAgICBwb2NrZXRzLmZpbmQoKGVudHJ5KSA9PiBlbnRyeS5wb2NrZXRJZCA9PT0gc2VsZWN0ZWRJZCkgPz9cbiAgICAgIHBvY2tldHNbMF0gPz9cbiAgICAgIG51bGxcbiAgICApO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBlbnN1cmVQcmltYXJ5UG9ja2V0UmVhZHkoKTogUHJvbWlzZTxNZVBvY2tldCB8IG51bGw+IHtcbiAgICBjb25zdCBleGlzdGluZyA9IGF3YWl0IHRoaXMuZ2V0UHJpbWFyeVBvY2tldCgpO1xuICAgIGlmIChleGlzdGluZykge1xuICAgICAgcmV0dXJuIGV4aXN0aW5nO1xuICAgIH1cblxuICAgIGNvbnN0IHdpbmRvd0lkID0gYXdhaXQgdGhpcy5vcGVuRXh0ZW5zaW9uV2luZG93KCk7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiB0aGlzLmF3YWl0UHJpbWFyeVBvY2tldChDT05ORUNUX1RJTUVPVVRfTVMpO1xuICAgIH0gZmluYWxseSB7XG4gICAgICBpZiAod2luZG93SWQpIHtcbiAgICAgICAgY2hyb21lLndpbmRvd3MucmVtb3ZlKHdpbmRvd0lkLCAoKSA9PiB1bmRlZmluZWQpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgYXdhaXRQcmltYXJ5UG9ja2V0KFxuICAgIHRpbWVvdXRNczogbnVtYmVyLFxuICApOiBQcm9taXNlPE1lUG9ja2V0IHwgbnVsbD4ge1xuICAgIGNvbnN0IHN0YXJ0ID0gRGF0ZS5ub3coKTtcbiAgICB3aGlsZSAoRGF0ZS5ub3coKSAtIHN0YXJ0IDwgdGltZW91dE1zKSB7XG4gICAgICBjb25zdCBwb2NrZXQgPSBhd2FpdCB0aGlzLmdldFByaW1hcnlQb2NrZXQoKTtcbiAgICAgIGlmIChwb2NrZXQpIHtcbiAgICAgICAgcmV0dXJuIHBvY2tldDtcbiAgICAgIH1cbiAgICAgIGF3YWl0IHNsZWVwKENPTk5FQ1RfUE9MTF9JTlRFUlZBTF9NUyk7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBvcGVuQ29uZmlybVdpbmRvdyhcbiAgICBvcGVyYXRpb25JZDogc3RyaW5nLFxuICApOiBQcm9taXNlPG51bWJlciB8IHVuZGVmaW5lZD4ge1xuICAgIGNvbnN0IHVybCA9IGNocm9tZS5ydW50aW1lLmdldFVSTChcbiAgICAgIGBwb3B1cC9pbmRleC5odG1sIy9jb25maXJtLXR4P29wZXJhdGlvbklkPSR7ZW5jb2RlVVJJQ29tcG9uZW50KFxuICAgICAgICBvcGVyYXRpb25JZCxcbiAgICAgICl9YCxcbiAgICApO1xuXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICBjaHJvbWUud2luZG93cy5jcmVhdGUoXG4gICAgICAgIHtcbiAgICAgICAgICB1cmwsXG4gICAgICAgICAgdHlwZTogXCJwb3B1cFwiLFxuICAgICAgICAgIHdpZHRoOiA0MjAsXG4gICAgICAgICAgaGVpZ2h0OiA3MjAsXG4gICAgICAgICAgZm9jdXNlZDogdHJ1ZSxcbiAgICAgICAgfSxcbiAgICAgICAgKHdpbmRvdykgPT4ge1xuICAgICAgICAgIHJlc29sdmUod2luZG93Py5pZCk7XG4gICAgICAgIH0sXG4gICAgICApO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBvcGVuQ29ubmVjdENvbmZpcm1XaW5kb3coXG4gICAgcmVxdWVzdElkOiBzdHJpbmcsXG4gICk6IFByb21pc2U8bnVtYmVyIHwgdW5kZWZpbmVkPiB7XG4gICAgY29uc3QgdXJsID0gY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKFxuICAgICAgYHBvcHVwL2luZGV4Lmh0bWwjL2NvbmZpcm0tY29ubmVjdD9yZXF1ZXN0SWQ9JHtlbmNvZGVVUklDb21wb25lbnQoXG4gICAgICAgIHJlcXVlc3RJZCxcbiAgICAgICl9YCxcbiAgICApO1xuXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICBjaHJvbWUud2luZG93cy5jcmVhdGUoXG4gICAgICAgIHtcbiAgICAgICAgICB1cmwsXG4gICAgICAgICAgdHlwZTogXCJwb3B1cFwiLFxuICAgICAgICAgIHdpZHRoOiA0MjAsXG4gICAgICAgICAgaGVpZ2h0OiA3MjAsXG4gICAgICAgICAgZm9jdXNlZDogdHJ1ZSxcbiAgICAgICAgfSxcbiAgICAgICAgKHdpbmRvdykgPT4ge1xuICAgICAgICAgIHJlc29sdmUod2luZG93Py5pZCk7XG4gICAgICAgIH0sXG4gICAgICApO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBvcGVuU2lnbkNvbmZpcm1XaW5kb3coXG4gICAgcmVxdWVzdElkOiBzdHJpbmcsXG4gICk6IFByb21pc2U8bnVtYmVyIHwgdW5kZWZpbmVkPiB7XG4gICAgY29uc3QgdXJsID0gY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKFxuICAgICAgYHBvcHVwL2luZGV4Lmh0bWwjL2NvbmZpcm0tc2lnbj9yZXF1ZXN0SWQ9JHtlbmNvZGVVUklDb21wb25lbnQoXG4gICAgICAgIHJlcXVlc3RJZCxcbiAgICAgICl9YCxcbiAgICApO1xuXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICBjaHJvbWUud2luZG93cy5jcmVhdGUoXG4gICAgICAgIHtcbiAgICAgICAgICB1cmwsXG4gICAgICAgICAgdHlwZTogXCJwb3B1cFwiLFxuICAgICAgICAgIHdpZHRoOiA0MjAsXG4gICAgICAgICAgaGVpZ2h0OiA3MjAsXG4gICAgICAgICAgZm9jdXNlZDogdHJ1ZSxcbiAgICAgICAgfSxcbiAgICAgICAgKHdpbmRvdykgPT4ge1xuICAgICAgICAgIHJlc29sdmUod2luZG93Py5pZCk7XG4gICAgICAgIH0sXG4gICAgICApO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBvcGVuRXh0ZW5zaW9uV2luZG93KCk6IFByb21pc2U8bnVtYmVyIHwgdW5kZWZpbmVkPiB7XG4gICAgY29uc3QgdXJsID0gY2hyb21lLnJ1bnRpbWUuZ2V0VVJMKFwicG9wdXAvaW5kZXguaHRtbCMvXCIpO1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgY2hyb21lLndpbmRvd3MuY3JlYXRlKFxuICAgICAgICB7XG4gICAgICAgICAgdXJsLFxuICAgICAgICAgIHR5cGU6IFwicG9wdXBcIixcbiAgICAgICAgICB3aWR0aDogNDIwLFxuICAgICAgICAgIGhlaWdodDogNzIwLFxuICAgICAgICAgIGZvY3VzZWQ6IHRydWUsXG4gICAgICAgIH0sXG4gICAgICAgICh3aW5kb3cpID0+IHtcbiAgICAgICAgICByZXNvbHZlKHdpbmRvdz8uaWQpO1xuICAgICAgICB9LFxuICAgICAgKTtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgYXdhaXREYXBwQ29ubmVjdENvbmZpcm1hdGlvbihcbiAgICByZXF1ZXN0SWQ6IHN0cmluZyxcbiAgICBwYXlsb2FkOiBPbWl0PFBlbmRpbmdEYXBwQ29ubmVjdCwgXCJyZXNvbHZlXCIgfCBcInJlamVjdFwiIHwgXCJ0aW1lb3V0SWRcIj4sXG4gICk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIGlmICh0aGlzLnBlbmRpbmdEYXBwQ29ubmVjdHMuaGFzKHJlcXVlc3RJZCkpIHtcbiAgICAgIHRoaXMucGVuZGluZ0RhcHBDb25uZWN0c1xuICAgICAgICAuZ2V0KHJlcXVlc3RJZClcbiAgICAgICAgPy5yZWplY3QobmV3IEVycm9yKFwiRHVwbGljYXRlIGNvbm5lY3QgcmVxdWVzdFwiKSk7XG4gICAgICB0aGlzLnBlbmRpbmdEYXBwQ29ubmVjdHMuZGVsZXRlKHJlcXVlc3RJZCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIGNvbnN0IHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0aGlzLnBlbmRpbmdEYXBwQ29ubmVjdHMuZGVsZXRlKHJlcXVlc3RJZCk7XG4gICAgICAgIHJlamVjdChuZXcgRXJyb3IoXCJDb25uZWN0aW9uIGNvbmZpcm1hdGlvbiB0aW1lZCBvdXRcIikpO1xuICAgICAgfSwgREFQUF9DT05GSVJNX1RJTUVPVVRfTVMpO1xuXG4gICAgICB0aGlzLnBlbmRpbmdEYXBwQ29ubmVjdHMuc2V0KHJlcXVlc3RJZCwge1xuICAgICAgICByZXNvbHZlLFxuICAgICAgICByZWplY3QsXG4gICAgICAgIHRpbWVvdXRJZCxcbiAgICAgICAgLi4ucGF5bG9hZCxcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBhd2FpdERhcHBDb25maXJtYXRpb24oXG4gICAgb3BlcmF0aW9uSWQ6IHN0cmluZyxcbiAgICBwYXlsb2FkOiBPbWl0PFBlbmRpbmdEYXBwVHJhbnNhY3Rpb24sIFwicmVzb2x2ZVwiIHwgXCJyZWplY3RcIiB8IFwidGltZW91dElkXCI+LFxuICApOiBQcm9taXNlPGAweCR7c3RyaW5nfWA+IHtcbiAgICBpZiAodGhpcy5wZW5kaW5nRGFwcFRyYW5zYWN0aW9ucy5oYXMob3BlcmF0aW9uSWQpKSB7XG4gICAgICB0aGlzLnBlbmRpbmdEYXBwVHJhbnNhY3Rpb25zXG4gICAgICAgIC5nZXQob3BlcmF0aW9uSWQpXG4gICAgICAgID8ucmVqZWN0KG5ldyBFcnJvcihcIkR1cGxpY2F0ZSB0cmFuc2FjdGlvbiByZXF1ZXN0XCIpKTtcbiAgICAgIHRoaXMucGVuZGluZ0RhcHBUcmFuc2FjdGlvbnMuZGVsZXRlKG9wZXJhdGlvbklkKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgY29uc3QgdGltZW91dElkID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHRoaXMucGVuZGluZ0RhcHBUcmFuc2FjdGlvbnMuZGVsZXRlKG9wZXJhdGlvbklkKTtcbiAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihcIlRyYW5zYWN0aW9uIGNvbmZpcm1hdGlvbiB0aW1lZCBvdXRcIikpO1xuICAgICAgfSwgREFQUF9DT05GSVJNX1RJTUVPVVRfTVMpO1xuXG4gICAgICB0aGlzLnBlbmRpbmdEYXBwVHJhbnNhY3Rpb25zLnNldChvcGVyYXRpb25JZCwge1xuICAgICAgICByZXNvbHZlLFxuICAgICAgICByZWplY3QsXG4gICAgICAgIHRpbWVvdXRJZCxcbiAgICAgICAgLi4ucGF5bG9hZCxcbiAgICAgIH0pO1xuICAgIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBhd2FpdERhcHBTaWduQ29uZmlybWF0aW9uKFxuICAgIHJlcXVlc3RJZDogc3RyaW5nLFxuICAgIHBheWxvYWQ6IE9taXQ8UGVuZGluZ0RhcHBTaWduYXR1cmUsIFwicmVzb2x2ZVwiIHwgXCJyZWplY3RcIiB8IFwidGltZW91dElkXCI+LFxuICApOiBQcm9taXNlPGAweCR7c3RyaW5nfWA+IHtcbiAgICBpZiAodGhpcy5wZW5kaW5nRGFwcFNpZ25hdHVyZXMuaGFzKHJlcXVlc3RJZCkpIHtcbiAgICAgIHRoaXMucGVuZGluZ0RhcHBTaWduYXR1cmVzXG4gICAgICAgIC5nZXQocmVxdWVzdElkKVxuICAgICAgICA/LnJlamVjdChuZXcgRXJyb3IoXCJEdXBsaWNhdGUgc2lnbiByZXF1ZXN0XCIpKTtcbiAgICAgIHRoaXMucGVuZGluZ0RhcHBTaWduYXR1cmVzLmRlbGV0ZShyZXF1ZXN0SWQpO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBjb25zdCB0aW1lb3V0SWQgPSBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgdGhpcy5wZW5kaW5nRGFwcFNpZ25hdHVyZXMuZGVsZXRlKHJlcXVlc3RJZCk7XG4gICAgICAgIHJlamVjdChuZXcgRXJyb3IoXCJTaWduYXR1cmUgY29uZmlybWF0aW9uIHRpbWVkIG91dFwiKSk7XG4gICAgICB9LCBEQVBQX0NPTkZJUk1fVElNRU9VVF9NUyk7XG5cbiAgICAgIHRoaXMucGVuZGluZ0RhcHBTaWduYXR1cmVzLnNldChyZXF1ZXN0SWQsIHtcbiAgICAgICAgcmVzb2x2ZSxcbiAgICAgICAgcmVqZWN0LFxuICAgICAgICB0aW1lb3V0SWQsXG4gICAgICAgIC4uLnBheWxvYWQsXG4gICAgICB9KTtcbiAgICB9KTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgaGFuZGxlQXBpRGFwcENvbm5lY3RDb250ZXh0KHBheWxvYWQ6IHsgcmVxdWVzdElkOiBzdHJpbmcgfSkge1xuICAgIGNvbnN0IGVudHJ5ID0gdGhpcy5wZW5kaW5nRGFwcENvbm5lY3RzLmdldChwYXlsb2FkLnJlcXVlc3RJZCk7XG4gICAgaWYgKCFlbnRyeSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiQ29ubmVjdCByZXF1ZXN0IG5vdCBmb3VuZFwiKTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgcmVxdWVzdElkOiBwYXlsb2FkLnJlcXVlc3RJZCxcbiAgICAgIG9yaWdpbjogZW50cnkub3JpZ2luLFxuICAgICAgd2FsbGV0QWRkcmVzczogZW50cnkud2FsbGV0QWRkcmVzcyxcbiAgICAgIGNvbm5lY3Rpb25JZDogZW50cnkuY29ubmVjdGlvbi5jb25uZWN0aW9uSWQsXG4gICAgICBob3N0OiBlbnRyeS5jb25uZWN0aW9uLmhvc3QsXG4gICAgICB0cnVzdExldmVsOiBlbnRyeS5jb25uZWN0aW9uLnRydXN0TGV2ZWwsXG4gICAgICB3YXJuaW5nVG9uZTogZW50cnkud2FybmluZy50b25lLFxuICAgICAgd2FybmluZ1RpdGxlOiBlbnRyeS53YXJuaW5nLnRpdGxlLFxuICAgICAgd2FybmluZ01lc3NhZ2U6IGVudHJ5Lndhcm5pbmcubWVzc2FnZSxcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBoYW5kbGVBcGlEYXBwQ29ubmVjdFJlc3VsdChwYXlsb2FkOiB7XG4gICAgcmVxdWVzdElkOiBzdHJpbmc7XG4gICAgc3RhdHVzOiBcImFwcHJvdmVkXCIgfCBcInJlamVjdGVkXCIgfCBcImZhaWxlZFwiO1xuICAgIGVycm9yPzogc3RyaW5nO1xuICB9KSB7XG4gICAgY29uc3QgZW50cnkgPSB0aGlzLnBlbmRpbmdEYXBwQ29ubmVjdHMuZ2V0KHBheWxvYWQucmVxdWVzdElkKTtcbiAgICBpZiAoIWVudHJ5KSB7XG4gICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gICAgfVxuXG4gICAgY2xlYXJUaW1lb3V0KGVudHJ5LnRpbWVvdXRJZCk7XG4gICAgdGhpcy5wZW5kaW5nRGFwcENvbm5lY3RzLmRlbGV0ZShwYXlsb2FkLnJlcXVlc3RJZCk7XG5cbiAgICBpZiAocGF5bG9hZC5zdGF0dXMgPT09IFwiYXBwcm92ZWRcIikge1xuICAgICAgZW50cnkucmVzb2x2ZSh0cnVlKTtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbiAgICB9XG4gICAgaWYgKHBheWxvYWQuc3RhdHVzID09PSBcInJlamVjdGVkXCIpIHtcbiAgICAgIGVudHJ5LnJlc29sdmUoZmFsc2UpO1xuICAgICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xuICAgIH1cblxuICAgIGVudHJ5LnJlamVjdChuZXcgRXJyb3IocGF5bG9hZC5lcnJvciB8fCBcIkNvbm5lY3Rpb24gd2FzIHJlamVjdGVkXCIpKTtcbiAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGhhbmRsZUFwaURhcHBUeENvbnRleHQocGF5bG9hZDogeyBvcGVyYXRpb25JZDogc3RyaW5nIH0pIHtcbiAgICBjb25zdCBlbnRyeSA9IHRoaXMucGVuZGluZ0RhcHBUcmFuc2FjdGlvbnMuZ2V0KHBheWxvYWQub3BlcmF0aW9uSWQpO1xuICAgIGlmICghZW50cnkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlRyYW5zYWN0aW9uIHJlcXVlc3Qgbm90IGZvdW5kXCIpO1xuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICBvcGVyYXRpb25JZDogcGF5bG9hZC5vcGVyYXRpb25JZCxcbiAgICAgIG9yaWdpbjogZW50cnkub3JpZ2luLFxuICAgICAgY29ubmVjdGlvbklkOiBlbnRyeS5jb25uZWN0aW9uPy5jb25uZWN0aW9uSWQgPz8gbnVsbCxcbiAgICAgIGhvc3Q6IGVudHJ5LmNvbm5lY3Rpb24/Lmhvc3QgPz8gbnVsbCxcbiAgICAgIHRydXN0TGV2ZWw6IGVudHJ5LmNvbm5lY3Rpb24/LnRydXN0TGV2ZWwgPz8gbnVsbCxcbiAgICAgIHdhcm5pbmc6IGVudHJ5Lndhcm5pbmcsXG4gICAgfTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgaGFuZGxlQXBpRGFwcFR4UmVzdWx0KHBheWxvYWQ6IHtcbiAgICBvcGVyYXRpb25JZDogc3RyaW5nO1xuICAgIHN0YXR1czogXCJjb25maXJtZWRcIiB8IFwicmVqZWN0ZWRcIiB8IFwiZmFpbGVkXCI7XG4gICAgdHhIYXNoPzogYDB4JHtzdHJpbmd9YCB8IG51bGw7XG4gICAgZXJyb3I/OiBzdHJpbmc7XG4gIH0pIHtcbiAgICBjb25zdCBlbnRyeSA9IHRoaXMucGVuZGluZ0RhcHBUcmFuc2FjdGlvbnMuZ2V0KHBheWxvYWQub3BlcmF0aW9uSWQpO1xuICAgIGlmICghZW50cnkpIHtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbiAgICB9XG5cbiAgICBjbGVhclRpbWVvdXQoZW50cnkudGltZW91dElkKTtcbiAgICB0aGlzLnBlbmRpbmdEYXBwVHJhbnNhY3Rpb25zLmRlbGV0ZShwYXlsb2FkLm9wZXJhdGlvbklkKTtcblxuICAgIGlmIChlbnRyeS5jb25uZWN0aW9uKSB7XG4gICAgICBjb25zdCBvdXRjb21lID1cbiAgICAgICAgcGF5bG9hZC5zdGF0dXMgPT09IFwiY29uZmlybWVkXCJcbiAgICAgICAgICA/IFwiYXBwcm92ZWRcIlxuICAgICAgICAgIDogcGF5bG9hZC5zdGF0dXMgPT09IFwicmVqZWN0ZWRcIlxuICAgICAgICAgICAgPyBcInJlamVjdGVkXCJcbiAgICAgICAgICAgIDogXCJmYWlsZWRcIjtcbiAgICAgIHZvaWQgdGhpcy5yZWNvcmRTaWduRXZlbnQoXG4gICAgICAgIGVudHJ5LmNvbm5lY3Rpb24uY29ubmVjdGlvbklkLFxuICAgICAgICBcInRyYW5zYWN0aW9uXCIsXG4gICAgICAgIG91dGNvbWUsXG4gICAgICApO1xuICAgIH1cblxuICAgIGlmIChwYXlsb2FkLnN0YXR1cyA9PT0gXCJjb25maXJtZWRcIikge1xuICAgICAgaWYgKCFwYXlsb2FkLnR4SGFzaCkge1xuICAgICAgICBlbnRyeS5yZWplY3QoXG4gICAgICAgICAgbmV3IEVycm9yKFwiVHJhbnNhY3Rpb24gY29uZmlybWVkIGJ1dCB0eCBoYXNoIHVuYXZhaWxhYmxlXCIpLFxuICAgICAgICApO1xuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gICAgICB9XG4gICAgICBlbnRyeS5yZXNvbHZlKHBheWxvYWQudHhIYXNoKTtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbiAgICB9XG5cbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPVxuICAgICAgcGF5bG9hZC5lcnJvciB8fCBcIlRyYW5zYWN0aW9uIHdhcyByZWplY3RlZCBieSB0aGUgdXNlclwiO1xuICAgIGVudHJ5LnJlamVjdChuZXcgRXJyb3IoZXJyb3JNZXNzYWdlKSk7XG4gICAgcmV0dXJuIHsgc3VjY2VzczogdHJ1ZSB9O1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBoYW5kbGVBcGlEYXBwU2lnbkNvbnRleHQocGF5bG9hZDogeyByZXF1ZXN0SWQ6IHN0cmluZyB9KSB7XG4gICAgY29uc3QgZW50cnkgPSB0aGlzLnBlbmRpbmdEYXBwU2lnbmF0dXJlcy5nZXQocGF5bG9hZC5yZXF1ZXN0SWQpO1xuICAgIGlmICghZW50cnkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlNpZ24gcmVxdWVzdCBub3QgZm91bmRcIik7XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIHJlcXVlc3RJZDogcGF5bG9hZC5yZXF1ZXN0SWQsXG4gICAgICBtZXNzYWdlOiBlbnRyeS5tZXNzYWdlLFxuICAgICAgYWRkcmVzczogZW50cnkuYWRkcmVzcyxcbiAgICAgIG9yaWdpbjogZW50cnkub3JpZ2luLFxuICAgICAgcG9ja2V0SWQ6IGVudHJ5LnBvY2tldElkLFxuICAgICAgY29ubmVjdGlvbklkOiBlbnRyeS5jb25uZWN0aW9uPy5jb25uZWN0aW9uSWQgPz8gbnVsbCxcbiAgICAgIGhvc3Q6IGVudHJ5LmNvbm5lY3Rpb24/Lmhvc3QgPz8gbnVsbCxcbiAgICAgIHRydXN0TGV2ZWw6IGVudHJ5LmNvbm5lY3Rpb24/LnRydXN0TGV2ZWwgPz8gbnVsbCxcbiAgICAgIHdhcm5pbmc6IGVudHJ5Lndhcm5pbmcsXG4gICAgfTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgaGFuZGxlQXBpRGFwcFNpZ25SZXN1bHQocGF5bG9hZDoge1xuICAgIHJlcXVlc3RJZDogc3RyaW5nO1xuICAgIHN0YXR1czogXCJzaWduZWRcIiB8IFwicmVqZWN0ZWRcIiB8IFwiZmFpbGVkXCI7XG4gICAgc2lnbmF0dXJlPzogYDB4JHtzdHJpbmd9YDtcbiAgICBlcnJvcj86IHN0cmluZztcbiAgfSkge1xuICAgIGNvbnN0IGVudHJ5ID0gdGhpcy5wZW5kaW5nRGFwcFNpZ25hdHVyZXMuZ2V0KHBheWxvYWQucmVxdWVzdElkKTtcbiAgICBpZiAoIWVudHJ5KSB7XG4gICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gICAgfVxuXG4gICAgY2xlYXJUaW1lb3V0KGVudHJ5LnRpbWVvdXRJZCk7XG4gICAgdGhpcy5wZW5kaW5nRGFwcFNpZ25hdHVyZXMuZGVsZXRlKHBheWxvYWQucmVxdWVzdElkKTtcblxuICAgIGlmIChlbnRyeS5jb25uZWN0aW9uKSB7XG4gICAgICBjb25zdCBvdXRjb21lID1cbiAgICAgICAgcGF5bG9hZC5zdGF0dXMgPT09IFwic2lnbmVkXCJcbiAgICAgICAgICA/IFwiYXBwcm92ZWRcIlxuICAgICAgICAgIDogcGF5bG9hZC5zdGF0dXMgPT09IFwicmVqZWN0ZWRcIlxuICAgICAgICAgICAgPyBcInJlamVjdGVkXCJcbiAgICAgICAgICAgIDogXCJmYWlsZWRcIjtcbiAgICAgIHZvaWQgdGhpcy5yZWNvcmRTaWduRXZlbnQoXG4gICAgICAgIGVudHJ5LmNvbm5lY3Rpb24uY29ubmVjdGlvbklkLFxuICAgICAgICBcIm1lc3NhZ2VcIixcbiAgICAgICAgb3V0Y29tZSxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgaWYgKHBheWxvYWQuc3RhdHVzID09PSBcInNpZ25lZFwiKSB7XG4gICAgICBpZiAoIXBheWxvYWQuc2lnbmF0dXJlKSB7XG4gICAgICAgIGVudHJ5LnJlamVjdChuZXcgRXJyb3IoXCJNaXNzaW5nIHNpZ25hdHVyZSByZXN1bHRcIikpO1xuICAgICAgICByZXR1cm4geyBzdWNjZXNzOiB0cnVlIH07XG4gICAgICB9XG4gICAgICBlbnRyeS5yZXNvbHZlKHBheWxvYWQuc2lnbmF0dXJlKTtcbiAgICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbiAgICB9XG5cbiAgICBjb25zdCBlcnJvck1lc3NhZ2UgPVxuICAgICAgcGF5bG9hZC5lcnJvciB8fCBcIk1lc3NhZ2Ugc2lnbmluZyB3YXMgcmVqZWN0ZWQgYnkgdGhlIHVzZXJcIjtcbiAgICBlbnRyeS5yZWplY3QobmV3IEVycm9yKGVycm9yTWVzc2FnZSkpO1xuICAgIHJldHVybiB7IHN1Y2Nlc3M6IHRydWUgfTtcbiAgfVxufVxuIiwiY29uc3QgRkFMTEJBQ0tfRVhQSVJZX01TID0gNjAgKiA2MCAqIDEwMDA7XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZUJhc2U2NFVybCh2YWx1ZTogc3RyaW5nKSB7XG4gIGxldCBub3JtYWxpemVkID0gdmFsdWUucmVwbGFjZSgvLS9nLCBcIitcIikucmVwbGFjZSgvXy9nLCBcIi9cIik7XG4gIGNvbnN0IHBhZGRpbmdOZWVkZWQgPSBub3JtYWxpemVkLmxlbmd0aCAlIDQ7XG4gIGlmIChwYWRkaW5nTmVlZGVkID09PSAyKSBub3JtYWxpemVkICs9IFwiPT1cIjtcbiAgZWxzZSBpZiAocGFkZGluZ05lZWRlZCA9PT0gMykgbm9ybWFsaXplZCArPSBcIj1cIjtcbiAgZWxzZSBpZiAocGFkZGluZ05lZWRlZCAhPT0gMCkgbm9ybWFsaXplZCArPSBcIj09XCI7XG4gIHJldHVybiBub3JtYWxpemVkO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gZGVjb2RlSnd0RXhwaXJhdGlvbih0b2tlbjogc3RyaW5nKTogbnVtYmVyIHwgbnVsbCB7XG4gIHRyeSB7XG4gICAgY29uc3Qgc2VnbWVudHMgPSB0b2tlbi5zcGxpdChcIi5cIik7XG4gICAgaWYgKHNlZ21lbnRzLmxlbmd0aCA8IDIpIHJldHVybiBudWxsO1xuICAgIGNvbnN0IHBheWxvYWRTZWdtZW50ID0gc2VnbWVudHNbMV07XG4gICAgaWYgKCFwYXlsb2FkU2VnbWVudCkgcmV0dXJuIG51bGw7XG4gICAgY29uc3Qgbm9ybWFsaXplZCA9IG5vcm1hbGl6ZUJhc2U2NFVybChwYXlsb2FkU2VnbWVudCk7XG4gICAgaWYgKHR5cGVvZiBnbG9iYWxUaGlzLmF0b2IgIT09IFwiZnVuY3Rpb25cIikgcmV0dXJuIG51bGw7XG4gICAgY29uc3QganNvbiA9IGdsb2JhbFRoaXMuYXRvYihub3JtYWxpemVkKTtcbiAgICBjb25zdCBwYXlsb2FkID0gSlNPTi5wYXJzZShqc29uKSBhcyB7IGV4cD86IG51bWJlciB9O1xuICAgIGlmICh0eXBlb2YgcGF5bG9hZC5leHAgIT09IFwibnVtYmVyXCIpIHJldHVybiBudWxsO1xuICAgIHJldHVybiBwYXlsb2FkLmV4cCAqIDEwMDA7XG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBudWxsO1xuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBidWlsZEFjY2Vzc0V4cGlyeSh0b2tlbjogc3RyaW5nKSB7XG4gIHJldHVybiBkZWNvZGVKd3RFeHBpcmF0aW9uKHRva2VuKSA/PyBEYXRlLm5vdygpICsgRkFMTEJBQ0tfRVhQSVJZX01TO1xufVxuIiwiaW1wb3J0IHsgYXV0aEhlYWRlcnMsIGdldEF4aW9zRXJyb3JNZXNzYWdlLCB3aXRoRXJyb3JDYXVzZSB9IGZyb20gXCIuL2NsaWVudC5qc1wiO1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldE1lKGNsaWVudCwgYWNjZXNzVG9rZW4pIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQuZ2V0KFwiL3YxL3VzZXJzL21lXCIsIGF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIGxvYWQgdXNlciBwcm9maWxlXCIpLCBlcnJvcik7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgYXV0aEhlYWRlcnMsIGdldEF4aW9zRXJyb3JNZXNzYWdlLCB3aXRoRXJyb3JDYXVzZSB9IGZyb20gXCIuL2NsaWVudC5qc1wiO1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHByZXBhcmVEYXBwQ29ubmVjdGlvbihjbGllbnQsIGFjY2Vzc1Rva2VuLCBwYXlsb2FkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LnBvc3QoXCIvdjEvZGFwcHMvY29ubmVjdGlvbnMvcHJlcGFyZVwiLCBwYXlsb2FkLCBhdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikpO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byBwcmVwYXJlIGRBcHAgY29ubmVjdGlvblwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjb25maXJtRGFwcENvbm5lY3Rpb24oY2xpZW50LCBhY2Nlc3NUb2tlbiwgY29ubmVjdGlvbklkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LnBvc3QoYC92MS9kYXBwcy9jb25uZWN0aW9ucy8ke2Nvbm5lY3Rpb25JZH0vY29uZmlybWAsIHt9LCBhdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikpO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byBjb25maXJtIGRBcHAgY29ubmVjdGlvblwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWplY3REYXBwQ29ubmVjdGlvbihjbGllbnQsIGFjY2Vzc1Rva2VuLCBjb25uZWN0aW9uSWQpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQucG9zdChgL3YxL2RhcHBzL2Nvbm5lY3Rpb25zLyR7Y29ubmVjdGlvbklkfS9yZWplY3RgLCB7fSwgYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pKTtcbiAgICAgICAgcmV0dXJuIHJlcy5kYXRhLmRhdGE7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gcmVqZWN0IGRBcHAgY29ubmVjdGlvblwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkaXNjb25uZWN0RGFwcENvbm5lY3Rpb24oY2xpZW50LCBhY2Nlc3NUb2tlbiwgY29ubmVjdGlvbklkKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LnBvc3QoYC92MS9kYXBwcy9jb25uZWN0aW9ucy8ke2Nvbm5lY3Rpb25JZH0vZGlzY29ubmVjdGAsIHt9LCBhdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikpO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byBkaXNjb25uZWN0IGRBcHBcIiksIGVycm9yKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbGlzdERhcHBDb25uZWN0aW9ucyhjbGllbnQsIGFjY2Vzc1Rva2VuLCBwYXJhbXMpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQuZ2V0KFwiL3YxL2RhcHBzL2Nvbm5lY3Rpb25zXCIsIHtcbiAgICAgICAgICAgIC4uLmF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSxcbiAgICAgICAgICAgIHBhcmFtcyxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIGxvYWQgZEFwcCBjb25uZWN0aW9uc1wiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWNvcmREYXBwQ29ubmVjdGlvblNpZ25FdmVudChjbGllbnQsIGFjY2Vzc1Rva2VuLCBjb25uZWN0aW9uSWQsIHBheWxvYWQpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQucG9zdChgL3YxL2RhcHBzL2Nvbm5lY3Rpb25zLyR7Y29ubmVjdGlvbklkfS9zaWduLWV2ZW50c2AsIHBheWxvYWQsIGF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIHJlY29yZCBkQXBwIHNpZ24gZXZlbnRcIiksIGVycm9yKTtcbiAgICB9XG59XG4iLCJpbXBvcnQgeyBhdXRoSGVhZGVycywgY3JlYXRlSWRlbXBvdGVuY3lLZXksIGdldEF4aW9zRXJyb3JNZXNzYWdlLCB3aXRoRXJyb3JDYXVzZSwgfSBmcm9tIFwiLi9jbGllbnQuanNcIjtcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcmVwYXJlUG9ja2V0KGNsaWVudCwgYWNjZXNzVG9rZW4pIHtcbiAgICBjb25zdCBpZGVtcG90ZW5jeUtleSA9IGNyZWF0ZUlkZW1wb3RlbmN5S2V5KCk7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LnBvc3QoXCIvdjEvcG9ja2V0cy9uZXcvcHJlcGFyZVwiLCB7fSwge1xuICAgICAgICAgICAgLi4uYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pLFxuICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAgIC4uLmF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKS5oZWFkZXJzLFxuICAgICAgICAgICAgICAgIFwiSWRlbXBvdGVuY3ktS2V5XCI6IGlkZW1wb3RlbmN5S2V5LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIHByZXBhcmUgcG9ja2V0XCIpLCBlcnJvcik7XG4gICAgfVxufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdFBvY2tldChjbGllbnQsIGFjY2Vzc1Rva2VuLCBwYXlsb2FkKSB7XG4gICAgY29uc3QgaWRlbXBvdGVuY3lLZXkgPSBjcmVhdGVJZGVtcG90ZW5jeUtleSgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5wb3N0KFwiL3YxL3BvY2tldHMvbmV3L3N1Ym1pdFwiLCBwYXlsb2FkLCB7XG4gICAgICAgICAgICAuLi5hdXRoSGVhZGVycyhhY2Nlc3NUb2tlbiksXG4gICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgICAgLi4uYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pLmhlYWRlcnMsXG4gICAgICAgICAgICAgICAgXCJJZGVtcG90ZW5jeS1LZXlcIjogaWRlbXBvdGVuY3lLZXksXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5kYXRhLmRhdGE7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gc3VibWl0IHBvY2tldFwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcmVwYXJlUG9ja2V0VHhTZW5kKGNsaWVudCwgYWNjZXNzVG9rZW4sIHBvY2tldElkLCBwYXlsb2FkLCBvcHRzKSB7XG4gICAgY29uc3QgaWRlbXBvdGVuY3lLZXkgPSBvcHRzPy5pZGVtcG90ZW5jeUtleSA/PyBjcmVhdGVJZGVtcG90ZW5jeUtleSgpO1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5wb3N0KGAvdjEvcG9ja2V0cy8ke3BvY2tldElkfS90eC9zZW5kL3ByZXBhcmVgLCBwYXlsb2FkLCB7XG4gICAgICAgICAgICAuLi5hdXRoSGVhZGVycyhhY2Nlc3NUb2tlbiksXG4gICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgICAgLi4uYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pLmhlYWRlcnMsXG4gICAgICAgICAgICAgICAgXCJJZGVtcG90ZW5jeS1LZXlcIjogaWRlbXBvdGVuY3lLZXksXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5kYXRhLmRhdGE7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gcHJlcGFyZSB0cmFuc2ZlclwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzdWJtaXRQb2NrZXRUeFNlbmQoY2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQsIHBheWxvYWQsIG9wdHMpIHtcbiAgICBjb25zdCBpZGVtcG90ZW5jeUtleSA9IG9wdHM/LmlkZW1wb3RlbmN5S2V5ID8/IGNyZWF0ZUlkZW1wb3RlbmN5S2V5KCk7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LnBvc3QoYC92MS9wb2NrZXRzLyR7cG9ja2V0SWR9L3R4L3NlbmQvc3VibWl0YCwgcGF5bG9hZCwge1xuICAgICAgICAgICAgLi4uYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pLFxuICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAgIC4uLmF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKS5oZWFkZXJzLFxuICAgICAgICAgICAgICAgIFwiSWRlbXBvdGVuY3ktS2V5XCI6IGlkZW1wb3RlbmN5S2V5LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIHN1Ym1pdCB0cmFuc2ZlclwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBwcmVwYXJlUG9ja2V0VHhDdXN0b20oY2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQsIHBheWxvYWQsIG9wdHMpIHtcbiAgICBjb25zdCBpZGVtcG90ZW5jeUtleSA9IG9wdHM/LmlkZW1wb3RlbmN5S2V5ID8/IGNyZWF0ZUlkZW1wb3RlbmN5S2V5KCk7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LnBvc3QoYC92MS9wb2NrZXRzLyR7cG9ja2V0SWR9L3R4L2N1c3RvbS9wcmVwYXJlYCwgcGF5bG9hZCwge1xuICAgICAgICAgICAgLi4uYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pLFxuICAgICAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgICAgIC4uLmF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKS5oZWFkZXJzLFxuICAgICAgICAgICAgICAgIFwiSWRlbXBvdGVuY3ktS2V5XCI6IGlkZW1wb3RlbmN5S2V5LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIHByZXBhcmUgdHJhbnNhY3Rpb25cIiksIGVycm9yKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3VibWl0UG9ja2V0VHhDdXN0b20oY2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQsIHBheWxvYWQsIG9wdHMpIHtcbiAgICBjb25zdCBpZGVtcG90ZW5jeUtleSA9IG9wdHM/LmlkZW1wb3RlbmN5S2V5ID8/IGNyZWF0ZUlkZW1wb3RlbmN5S2V5KCk7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LnBvc3QoYC92MS9wb2NrZXRzLyR7cG9ja2V0SWR9L3R4L2N1c3RvbS9zdWJtaXRgLCBwYXlsb2FkLCB7XG4gICAgICAgICAgICAuLi5hdXRoSGVhZGVycyhhY2Nlc3NUb2tlbiksXG4gICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgICAgLi4uYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pLmhlYWRlcnMsXG4gICAgICAgICAgICAgICAgXCJJZGVtcG90ZW5jeS1LZXlcIjogaWRlbXBvdGVuY3lLZXksXG4gICAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5kYXRhLmRhdGE7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gc3VibWl0IHRyYW5zYWN0aW9uXCIpLCBlcnJvcik7XG4gICAgfVxufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHByZXBhcmVQb2NrZXRQZXJzb25hbFNpZ24oY2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQsIHBheWxvYWQpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQucG9zdChgL3YxL3BvY2tldHMvJHtwb2NrZXRJZH0vc2lnbi9wZXJzb25hbC9wcmVwYXJlYCwgcGF5bG9hZCwgYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pKTtcbiAgICAgICAgcmV0dXJuIHJlcy5kYXRhLmRhdGE7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gcHJlcGFyZSBwZXJzb25hbCBzaWduXCIpLCBlcnJvcik7XG4gICAgfVxufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHN1Ym1pdFBvY2tldFBlcnNvbmFsU2lnbihjbGllbnQsIGFjY2Vzc1Rva2VuLCBwb2NrZXRJZCwgcGF5bG9hZCkge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5wb3N0KGAvdjEvcG9ja2V0cy8ke3BvY2tldElkfS9zaWduL3BlcnNvbmFsL3N1Ym1pdGAsIHBheWxvYWQsIGF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIHN1Ym1pdCBwZXJzb25hbCBzaWduXCIpLCBlcnJvcik7XG4gICAgfVxufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVBvY2tldExhYmVsKGNsaWVudCwgYWNjZXNzVG9rZW4sIHBvY2tldElkLCBsYWJlbCkge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5wYXRjaChgL3YxL3BvY2tldHMvJHtwb2NrZXRJZH1gLCB7IGxhYmVsIH0sIGF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIHVwZGF0ZSB3YWxsZXQgbmFtZVwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBsaXN0UG9ja2V0cyhjbGllbnQsIGFjY2Vzc1Rva2VuLCBvcHRzKSB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgY2xpZW50LmdldChcIi92MS9wb2NrZXRzXCIsIHtcbiAgICAgICAgICAgIC4uLmF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSxcbiAgICAgICAgICAgIHBhcmFtczogeyBzdGF0ZTogb3B0cz8uc3RhdGUgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhLnBvY2tldHM7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gbG9hZCBwb2NrZXRzXCIpLCBlcnJvcik7XG4gICAgfVxufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFyY2hpdmVQb2NrZXQoY2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQucG9zdChgL3YxL3BvY2tldHMvJHtwb2NrZXRJZH0vYXJjaGl2ZWAsIHt9LCBhdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikpO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byBhcmNoaXZlIHdhbGxldFwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1bmFyY2hpdmVQb2NrZXQoY2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQucG9zdChgL3YxL3BvY2tldHMvJHtwb2NrZXRJZH0vdW5hcmNoaXZlYCwge30sIGF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIHVuYXJjaGl2ZSB3YWxsZXRcIiksIGVycm9yKTtcbiAgICB9XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UG9ja2V0QmFsYW5jZXMoY2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQuZ2V0KGAvdjEvcG9ja2V0cy8ke3BvY2tldElkfS9iYWxhbmNlc2AsIGF1dGhIZWFkZXJzKGFjY2Vzc1Rva2VuKSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIGxvYWQgcG9ja2V0IGJhbGFuY2VzXCIpLCBlcnJvcik7XG4gICAgfVxufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFBvY2tldEFjdGl2aXRpZXMoY2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQsIHBhcmFtcykge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGNsaWVudC5nZXQoYC92MS9wb2NrZXRzLyR7cG9ja2V0SWR9L2FjdGl2aXRpZXNgLCB7XG4gICAgICAgICAgICAuLi5hdXRoSGVhZGVycyhhY2Nlc3NUb2tlbiksXG4gICAgICAgICAgICBwYXJhbXM6IHtcbiAgICAgICAgICAgICAgICBjdXJzb3I6IHBhcmFtcz8uY3Vyc29yLFxuICAgICAgICAgICAgICAgIGxpbWl0OiBwYXJhbXM/LmxpbWl0LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXMuZGF0YS5kYXRhO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgd2l0aEVycm9yQ2F1c2UoZ2V0QXhpb3NFcnJvck1lc3NhZ2UoZXJyb3IsIFwiVW5hYmxlIHRvIGxvYWQgcG9ja2V0IGFjdGl2aXR5XCIpLCBlcnJvcik7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgYXV0aEhlYWRlcnMsIGdldEF4aW9zRXJyb3JNZXNzYWdlLCB3aXRoRXJyb3JDYXVzZSB9IGZyb20gXCIuL2NsaWVudC5qc1wiO1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFVzZXJPcGVyYXRpb24oY2xpZW50LCBhY2Nlc3NUb2tlbiwgb3BlcmF0aW9uSWQpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQuZ2V0KGAvdjEvdXNlcl9vcGVyYXRpb25zLyR7b3BlcmF0aW9uSWR9YCwgYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pKTtcbiAgICAgICAgcmV0dXJuIHJlcy5kYXRhLmRhdGE7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gbG9hZCBvcGVyYXRpb24gc3RhdHVzXCIpLCBlcnJvcik7XG4gICAgfVxufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNhbmNlbFVzZXJPcGVyYXRpb24oY2xpZW50LCBhY2Nlc3NUb2tlbiwgb3BlcmF0aW9uSWQpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQuZGVsZXRlKGAvdjEvdXNlcl9vcGVyYXRpb25zLyR7b3BlcmF0aW9uSWR9YCwgYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pKTtcbiAgICAgICAgcmV0dXJuIHJlcy5kYXRhLmRhdGE7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gY2FuY2VsIHRoZSBwZW5kaW5nIHRyYW5zYWN0aW9uXCIpLCBlcnJvcik7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgYXV0aEhlYWRlcnMsIGdldEF4aW9zRXJyb3JNZXNzYWdlLCB3aXRoRXJyb3JDYXVzZSB9IGZyb20gXCIuL2NsaWVudC5qc1wiO1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldEFkZHJlc3NCb29rKGNsaWVudCwgYWNjZXNzVG9rZW4pIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQuZ2V0KFwiL3YxL2FkZHJlc3NfYm9va1wiLCBhdXRoSGVhZGVycyhhY2Nlc3NUb2tlbikpO1xuICAgICAgICByZXR1cm4gcmVzLmRhdGEuZGF0YTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHRocm93IHdpdGhFcnJvckNhdXNlKGdldEF4aW9zRXJyb3JNZXNzYWdlKGVycm9yLCBcIlVuYWJsZSB0byBsb2FkIGFkZHJlc3MgYm9va1wiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cHNlcnRBZGRyZXNzQm9va0VudHJ5KGNsaWVudCwgYWNjZXNzVG9rZW4sIHBheWxvYWQpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQucG9zdChcIi92MS9hZGRyZXNzX2Jvb2tcIiwgcGF5bG9hZCwgYXV0aEhlYWRlcnMoYWNjZXNzVG9rZW4pKTtcbiAgICAgICAgcmV0dXJuIHJlcy5kYXRhLmRhdGE7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gc2F2ZSBlbnRyeVwiKSwgZXJyb3IpO1xuICAgIH1cbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZWxldGVBZGRyZXNzQm9va0VudHJ5KGNsaWVudCwgYWNjZXNzVG9rZW4sIHBheWxvYWQpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBjbGllbnQuZGVsZXRlKFwiL3YxL2FkZHJlc3NfYm9va1wiLCB7XG4gICAgICAgICAgICAuLi5hdXRoSGVhZGVycyhhY2Nlc3NUb2tlbiksXG4gICAgICAgICAgICBkYXRhOiBwYXlsb2FkLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlcy5kYXRhLmRhdGE7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICB0aHJvdyB3aXRoRXJyb3JDYXVzZShnZXRBeGlvc0Vycm9yTWVzc2FnZShlcnJvciwgXCJVbmFibGUgdG8gZGVsZXRlIGVudHJ5XCIpLCBlcnJvcik7XG4gICAgfVxufVxuIiwiaW1wb3J0IHsgYXBpQ2xpZW50IH0gZnJvbSBcIkAvbGliL2FwaS9jbGllbnRcIjtcbmltcG9ydCB7IGJ1aWxkQWNjZXNzRXhwaXJ5IH0gZnJvbSBcIkAvbGliL2F1dGgvdG9rZW4tdXRpbHNcIjtcbmltcG9ydCB7IHJlZnJlc2hXaXRoVG9rZW4gfSBmcm9tIFwiQHJlcG8vYXBpLWNsaWVudC9hdXRoXCI7XG5pbXBvcnQgeyBnZXRNZSB9IGZyb20gXCJAcmVwby9hcGktY2xpZW50L3VzZXJzXCI7XG5pbXBvcnQge1xuICBjb25maXJtRGFwcENvbm5lY3Rpb24sXG4gIGRpc2Nvbm5lY3REYXBwQ29ubmVjdGlvbixcbiAgbGlzdERhcHBDb25uZWN0aW9ucyxcbiAgcHJlcGFyZURhcHBDb25uZWN0aW9uLFxuICByZWNvcmREYXBwQ29ubmVjdGlvblNpZ25FdmVudCxcbiAgcmVqZWN0RGFwcENvbm5lY3Rpb24sXG59IGZyb20gXCJAcmVwby9hcGktY2xpZW50L2RhcHBzXCI7XG5pbXBvcnQge1xuICBwcmVwYXJlUG9ja2V0LFxuICBzdWJtaXRQb2NrZXQsXG4gIHByZXBhcmVQb2NrZXRUeFNlbmQsXG4gIHN1Ym1pdFBvY2tldFR4U2VuZCxcbiAgcHJlcGFyZVBvY2tldFR4Q3VzdG9tLFxuICBzdWJtaXRQb2NrZXRUeEN1c3RvbSxcbiAgcHJlcGFyZVBvY2tldFBlcnNvbmFsU2lnbixcbiAgc3VibWl0UG9ja2V0UGVyc29uYWxTaWduLFxuICBnZXRQb2NrZXRCYWxhbmNlcyxcbiAgZ2V0UG9ja2V0QWN0aXZpdGllcyxcbn0gZnJvbSBcIkByZXBvL2FwaS1jbGllbnQvcG9ja2V0c1wiO1xuaW1wb3J0IHtcbiAgZ2V0VXNlck9wZXJhdGlvbixcbiAgY2FuY2VsVXNlck9wZXJhdGlvbixcbn0gZnJvbSBcIkByZXBvL2FwaS1jbGllbnQvdXNlci1vcGVyYXRpb25zXCI7XG5pbXBvcnQge1xuICBnZXRBZGRyZXNzQm9vayxcbiAgdXBzZXJ0QWRkcmVzc0Jvb2tFbnRyeSxcbiAgZGVsZXRlQWRkcmVzc0Jvb2tFbnRyeSxcbn0gZnJvbSBcIkByZXBvL2FwaS1jbGllbnQvYWRkcmVzcy1ib29rXCI7XG5pbXBvcnQgdHlwZSB7IEFwaVNlc3Npb24gfSBmcm9tIFwiQC9zaGFyZWQvdHlwZXNcIjtcbmltcG9ydCB0eXBlIHsgU3RvcmFnZU1hbmFnZXIgfSBmcm9tIFwiLi4vc3RvcmFnZS1tYW5hZ2VyXCI7XG5pbXBvcnQgdHlwZSB7XG4gIFBvY2tldE1ldGFUcmFuc2FjdGlvbixcbiAgUG9ja2V0UGVyc29uYWxTaWduUHJlcGFyZVJlcXVlc3QsXG4gIFBvY2tldFBlcnNvbmFsU2lnblN1Ym1pdFJlcXVlc3QsXG4gIFBvY2tldFN1Ym1pdFJlcXVlc3QsXG4gIFBvY2tldFR4U2VuZFByZXBhcmVSZXF1ZXN0LFxufSBmcm9tIFwiQHJlcG8vYXBpLWNsaWVudC9wb2NrZXRzXCI7XG5pbXBvcnQgdHlwZSB7XG4gIEFkZHJlc3NCb29rRGVsZXRlUmVxdWVzdCxcbiAgQWRkcmVzc0Jvb2tVcHNlcnRSZXF1ZXN0LFxufSBmcm9tIFwiQHJlcG8vYXBpLWNsaWVudC9hZGRyZXNzLWJvb2tcIjtcbmltcG9ydCB0eXBlIHtcbiAgRGFwcENvbm5lY3Rpb25MaXN0UGFyYW1zLFxuICBEYXBwQ29ubmVjdGlvblByZXBhcmVSZXF1ZXN0LFxuICBEYXBwQ29ubmVjdGlvblNpZ25FdmVudFJlcXVlc3QsXG59IGZyb20gXCJAcmVwby9hcGktY2xpZW50L2RhcHBzXCI7XG5cbmNvbnN0IEFDQ0VTU19UT0tFTl9CVUZGRVJfTVMgPSA2MF8wMDA7XG5cbmV4cG9ydCBjbGFzcyBBcGlDb250cm9sbGVyIHtcbiAgY29uc3RydWN0b3IocHJpdmF0ZSBzdG9yYWdlOiBTdG9yYWdlTWFuYWdlcikge31cblxuICBhc3luYyBnZXRTZXNzaW9uKCk6IFByb21pc2U8QXBpU2Vzc2lvbj4ge1xuICAgIHJldHVybiB0aGlzLnN0b3JhZ2UuZ2V0QXBpU2Vzc2lvbigpO1xuICB9XG5cbiAgYXN5bmMgc2V0U2Vzc2lvbihwYXlsb2FkOiBBcGlTZXNzaW9uKTogUHJvbWlzZTxBcGlTZXNzaW9uPiB7XG4gICAgY29uc3QgYWNjZXNzVG9rZW5FeHBpcmVzQXQgPSBwYXlsb2FkLmFjY2Vzc1Rva2VuXG4gICAgICA/IChwYXlsb2FkLmFjY2Vzc1Rva2VuRXhwaXJlc0F0ID8/IGJ1aWxkQWNjZXNzRXhwaXJ5KHBheWxvYWQuYWNjZXNzVG9rZW4pKVxuICAgICAgOiBudWxsO1xuICAgIGNvbnN0IHNlc3Npb246IEFwaVNlc3Npb24gPSB7XG4gICAgICAuLi5wYXlsb2FkLFxuICAgICAgYWNjZXNzVG9rZW5FeHBpcmVzQXQsXG4gICAgfTtcbiAgICBhd2FpdCB0aGlzLnN0b3JhZ2Uuc2V0QXBpU2Vzc2lvbihzZXNzaW9uKTtcbiAgICByZXR1cm4gc2Vzc2lvbjtcbiAgfVxuXG4gIGFzeW5jIGNsZWFyU2Vzc2lvbigpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBhd2FpdCB0aGlzLnN0b3JhZ2UuY2xlYXJBcGlTZXNzaW9uKCk7XG4gICAgYXdhaXQgdGhpcy5zdG9yYWdlLnNldEFwaUNoYWluSWQobnVsbCk7XG4gIH1cblxuICBhc3luYyBnZXRDaGFpbklkKCk6IFByb21pc2U8bnVtYmVyIHwgbnVsbD4ge1xuICAgIHJldHVybiB0aGlzLnN0b3JhZ2UuZ2V0QXBpQ2hhaW5JZCgpO1xuICB9XG5cbiAgYXN5bmMgc2V0U2VsZWN0ZWRQb2NrZXRJZChwb2NrZXRJZDogc3RyaW5nIHwgbnVsbCk6IFByb21pc2U8dm9pZD4ge1xuICAgIGF3YWl0IHRoaXMuc3RvcmFnZS5zZXRBcGlTZWxlY3RlZFBvY2tldElkKHBvY2tldElkKTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgZ2V0VmFsaWRBY2Nlc3NUb2tlbigpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCB0aGlzLnN0b3JhZ2UuZ2V0QXBpU2Vzc2lvbigpO1xuICAgIGlmICghc2Vzc2lvbi5yZWZyZXNoVG9rZW4pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIlNFU1NJT05fRVhQSVJFRFwiKTtcbiAgICB9XG5cbiAgICBjb25zdCBoYXNWYWxpZFRva2VuID1cbiAgICAgIHNlc3Npb24uYWNjZXNzVG9rZW4gJiZcbiAgICAgIHNlc3Npb24uYWNjZXNzVG9rZW5FeHBpcmVzQXQgJiZcbiAgICAgIHNlc3Npb24uYWNjZXNzVG9rZW5FeHBpcmVzQXQgPiBEYXRlLm5vdygpICsgQUNDRVNTX1RPS0VOX0JVRkZFUl9NUztcblxuICAgIGlmIChoYXNWYWxpZFRva2VuKSB7XG4gICAgICByZXR1cm4gc2Vzc2lvbi5hY2Nlc3NUb2tlbiBhcyBzdHJpbmc7XG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlZnJlc2hlZCA9IGF3YWl0IHJlZnJlc2hXaXRoVG9rZW4oYXBpQ2xpZW50LCBzZXNzaW9uLnJlZnJlc2hUb2tlbik7XG4gICAgICBjb25zdCBhY2Nlc3NUb2tlbkV4cGlyZXNBdCA9IGJ1aWxkQWNjZXNzRXhwaXJ5KHJlZnJlc2hlZC5hY2Nlc3NUb2tlbik7XG4gICAgICBjb25zdCBuZXh0U2Vzc2lvbjogQXBpU2Vzc2lvbiA9IHtcbiAgICAgICAgLi4uc2Vzc2lvbixcbiAgICAgICAgYWNjZXNzVG9rZW46IHJlZnJlc2hlZC5hY2Nlc3NUb2tlbixcbiAgICAgICAgcmVmcmVzaFRva2VuOiByZWZyZXNoZWQucmVmcmVzaFRva2VuLFxuICAgICAgICBhY2Nlc3NUb2tlbkV4cGlyZXNBdCxcbiAgICAgIH07XG4gICAgICBhd2FpdCB0aGlzLnN0b3JhZ2Uuc2V0QXBpU2Vzc2lvbihuZXh0U2Vzc2lvbik7XG4gICAgICByZXR1cm4gcmVmcmVzaGVkLmFjY2Vzc1Rva2VuO1xuICAgIH0gY2F0Y2gge1xuICAgICAgYXdhaXQgdGhpcy5zdG9yYWdlLmNsZWFyQXBpU2Vzc2lvbigpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwiU0VTU0lPTl9FWFBJUkVEXCIpO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jIGdldE1lKCkge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgY29uc3QgbWUgPSBhd2FpdCBnZXRNZShhcGlDbGllbnQsIGFjY2Vzc1Rva2VuKTtcbiAgICBhd2FpdCB0aGlzLnN0b3JhZ2Uuc2V0QXBpUG9ja2V0cyhtZS5wb2NrZXRzKTtcbiAgICBhd2FpdCB0aGlzLnN0b3JhZ2Uuc2V0QXBpUGVuZGluZ1VzZXJPcGVyYXRpb25zKG1lLnBlbmRpbmdVc2VyT3BlcmF0aW9ucyk7XG4gICAgYXdhaXQgdGhpcy5zdG9yYWdlLnNldEFwaURhcHBDb25uZWN0aW9ucyhtZS5kYXBwQ29ubmVjdGlvbnMpO1xuICAgIGF3YWl0IHRoaXMuc3RvcmFnZS5zZXRBcGlDaGFpbklkKG1lLmNoYWluSWQpO1xuXG4gICAgY29uc3Qgc2VsZWN0ZWQgPSBhd2FpdCB0aGlzLnN0b3JhZ2UuZ2V0QXBpU2VsZWN0ZWRQb2NrZXRJZCgpO1xuICAgIGlmICghc2VsZWN0ZWQgJiYgbWUucG9ja2V0cy5sZW5ndGggPiAwKSB7XG4gICAgICBhd2FpdCB0aGlzLnN0b3JhZ2Uuc2V0QXBpU2VsZWN0ZWRQb2NrZXRJZChcbiAgICAgICAgbWUucG9ja2V0c1swXT8ucG9ja2V0SWQgPz8gbnVsbCxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG1lO1xuICB9XG5cbiAgYXN5bmMgcHJlcGFyZVBvY2tldCgpIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBwcmVwYXJlUG9ja2V0KGFwaUNsaWVudCwgYWNjZXNzVG9rZW4pO1xuICB9XG5cbiAgYXN5bmMgc3VibWl0UG9ja2V0KHJlcXVlc3Q6IFBvY2tldFN1Ym1pdFJlcXVlc3QpIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBzdWJtaXRQb2NrZXQoYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbiwgcmVxdWVzdCk7XG4gIH1cblxuICBhc3luYyBwcmVwYXJlUG9ja2V0U2VuZChcbiAgICBwb2NrZXRJZDogc3RyaW5nLFxuICAgIHJlcXVlc3Q6IFBvY2tldFR4U2VuZFByZXBhcmVSZXF1ZXN0LFxuICApIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBwcmVwYXJlUG9ja2V0VHhTZW5kKGFwaUNsaWVudCwgYWNjZXNzVG9rZW4sIHBvY2tldElkLCByZXF1ZXN0KTtcbiAgfVxuXG4gIGFzeW5jIHN1Ym1pdFBvY2tldFNlbmQocG9ja2V0SWQ6IHN0cmluZywgcmVxdWVzdDogUG9ja2V0U3VibWl0UmVxdWVzdCkge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIHN1Ym1pdFBvY2tldFR4U2VuZChhcGlDbGllbnQsIGFjY2Vzc1Rva2VuLCBwb2NrZXRJZCwgcmVxdWVzdCk7XG4gIH1cblxuICBhc3luYyBwcmVwYXJlUG9ja2V0Q3VzdG9tKFxuICAgIHBvY2tldElkOiBzdHJpbmcsXG4gICAgcmVxdWVzdDogeyBtZXRhVHJhbnNhY3Rpb25zOiBQb2NrZXRNZXRhVHJhbnNhY3Rpb25bXSB9LFxuICApIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBwcmVwYXJlUG9ja2V0VHhDdXN0b20oYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQsIHJlcXVlc3QpO1xuICB9XG5cbiAgYXN5bmMgc3VibWl0UG9ja2V0Q3VzdG9tKHBvY2tldElkOiBzdHJpbmcsIHJlcXVlc3Q6IFBvY2tldFN1Ym1pdFJlcXVlc3QpIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBzdWJtaXRQb2NrZXRUeEN1c3RvbShhcGlDbGllbnQsIGFjY2Vzc1Rva2VuLCBwb2NrZXRJZCwgcmVxdWVzdCk7XG4gIH1cblxuICBhc3luYyBwcmVwYXJlUG9ja2V0UGVyc29uYWxTaWduKFxuICAgIHBvY2tldElkOiBzdHJpbmcsXG4gICAgcmVxdWVzdDogUG9ja2V0UGVyc29uYWxTaWduUHJlcGFyZVJlcXVlc3QsXG4gICkge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIHByZXBhcmVQb2NrZXRQZXJzb25hbFNpZ24oYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQsIHJlcXVlc3QpO1xuICB9XG5cbiAgYXN5bmMgc3VibWl0UG9ja2V0UGVyc29uYWxTaWduKFxuICAgIHBvY2tldElkOiBzdHJpbmcsXG4gICAgcmVxdWVzdDogUG9ja2V0UGVyc29uYWxTaWduU3VibWl0UmVxdWVzdCxcbiAgKSB7XG4gICAgY29uc3QgYWNjZXNzVG9rZW4gPSBhd2FpdCB0aGlzLmdldFZhbGlkQWNjZXNzVG9rZW4oKTtcbiAgICByZXR1cm4gc3VibWl0UG9ja2V0UGVyc29uYWxTaWduKGFwaUNsaWVudCwgYWNjZXNzVG9rZW4sIHBvY2tldElkLCByZXF1ZXN0KTtcbiAgfVxuXG4gIGFzeW5jIGdldFBvY2tldEJhbGFuY2VzKHBvY2tldElkOiBzdHJpbmcpIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBnZXRQb2NrZXRCYWxhbmNlcyhhcGlDbGllbnQsIGFjY2Vzc1Rva2VuLCBwb2NrZXRJZCk7XG4gIH1cblxuICBhc3luYyBnZXRQb2NrZXRBY3Rpdml0aWVzKFxuICAgIHBvY2tldElkOiBzdHJpbmcsXG4gICAgcGFyYW1zPzogeyBjdXJzb3I/OiBzdHJpbmc7IGxpbWl0PzogbnVtYmVyIH0sXG4gICkge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIGdldFBvY2tldEFjdGl2aXRpZXMoYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbiwgcG9ja2V0SWQsIHBhcmFtcyk7XG4gIH1cblxuICBhc3luYyBnZXRVc2VyT3BlcmF0aW9uKG9wZXJhdGlvbklkOiBzdHJpbmcpIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiBnZXRVc2VyT3BlcmF0aW9uKGFwaUNsaWVudCwgYWNjZXNzVG9rZW4sIG9wZXJhdGlvbklkKTtcbiAgfVxuXG4gIGFzeW5jIGNhbmNlbFVzZXJPcGVyYXRpb24ob3BlcmF0aW9uSWQ6IHN0cmluZykge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIGNhbmNlbFVzZXJPcGVyYXRpb24oYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbiwgb3BlcmF0aW9uSWQpO1xuICB9XG5cbiAgYXN5bmMgbGlzdEFkZHJlc3NCb29rKCkge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIGdldEFkZHJlc3NCb29rKGFwaUNsaWVudCwgYWNjZXNzVG9rZW4pO1xuICB9XG5cbiAgYXN5bmMgdXBzZXJ0QWRkcmVzc0Jvb2socGF5bG9hZDogQWRkcmVzc0Jvb2tVcHNlcnRSZXF1ZXN0KSB7XG4gICAgY29uc3QgYWNjZXNzVG9rZW4gPSBhd2FpdCB0aGlzLmdldFZhbGlkQWNjZXNzVG9rZW4oKTtcbiAgICByZXR1cm4gdXBzZXJ0QWRkcmVzc0Jvb2tFbnRyeShhcGlDbGllbnQsIGFjY2Vzc1Rva2VuLCBwYXlsb2FkKTtcbiAgfVxuXG4gIGFzeW5jIGRlbGV0ZUFkZHJlc3NCb29rKHBheWxvYWQ6IEFkZHJlc3NCb29rRGVsZXRlUmVxdWVzdCkge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIGRlbGV0ZUFkZHJlc3NCb29rRW50cnkoYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbiwgcGF5bG9hZCk7XG4gIH1cblxuICBhc3luYyBwcmVwYXJlRGFwcENvbm5lY3Rpb24ocGF5bG9hZDogRGFwcENvbm5lY3Rpb25QcmVwYXJlUmVxdWVzdCkge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIHByZXBhcmVEYXBwQ29ubmVjdGlvbihhcGlDbGllbnQsIGFjY2Vzc1Rva2VuLCBwYXlsb2FkKTtcbiAgfVxuXG4gIGFzeW5jIGNvbmZpcm1EYXBwQ29ubmVjdGlvbihjb25uZWN0aW9uSWQ6IHN0cmluZykge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIGNvbmZpcm1EYXBwQ29ubmVjdGlvbihhcGlDbGllbnQsIGFjY2Vzc1Rva2VuLCBjb25uZWN0aW9uSWQpO1xuICB9XG5cbiAgYXN5bmMgcmVqZWN0RGFwcENvbm5lY3Rpb24oY29ubmVjdGlvbklkOiBzdHJpbmcpIHtcbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IGF3YWl0IHRoaXMuZ2V0VmFsaWRBY2Nlc3NUb2tlbigpO1xuICAgIHJldHVybiByZWplY3REYXBwQ29ubmVjdGlvbihhcGlDbGllbnQsIGFjY2Vzc1Rva2VuLCBjb25uZWN0aW9uSWQpO1xuICB9XG5cbiAgYXN5bmMgZGlzY29ubmVjdERhcHBDb25uZWN0aW9uKGNvbm5lY3Rpb25JZDogc3RyaW5nKSB7XG4gICAgY29uc3QgYWNjZXNzVG9rZW4gPSBhd2FpdCB0aGlzLmdldFZhbGlkQWNjZXNzVG9rZW4oKTtcbiAgICByZXR1cm4gZGlzY29ubmVjdERhcHBDb25uZWN0aW9uKGFwaUNsaWVudCwgYWNjZXNzVG9rZW4sIGNvbm5lY3Rpb25JZCk7XG4gIH1cblxuICBhc3luYyBsaXN0RGFwcENvbm5lY3Rpb25zKHBhcmFtcz86IERhcHBDb25uZWN0aW9uTGlzdFBhcmFtcykge1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuID0gYXdhaXQgdGhpcy5nZXRWYWxpZEFjY2Vzc1Rva2VuKCk7XG4gICAgcmV0dXJuIGxpc3REYXBwQ29ubmVjdGlvbnMoYXBpQ2xpZW50LCBhY2Nlc3NUb2tlbiwgcGFyYW1zKTtcbiAgfVxuXG4gIGFzeW5jIHJlY29yZERhcHBDb25uZWN0aW9uU2lnbkV2ZW50KFxuICAgIGNvbm5lY3Rpb25JZDogc3RyaW5nLFxuICAgIHBheWxvYWQ6IERhcHBDb25uZWN0aW9uU2lnbkV2ZW50UmVxdWVzdCxcbiAgKSB7XG4gICAgY29uc3QgYWNjZXNzVG9rZW4gPSBhd2FpdCB0aGlzLmdldFZhbGlkQWNjZXNzVG9rZW4oKTtcbiAgICByZXR1cm4gcmVjb3JkRGFwcENvbm5lY3Rpb25TaWduRXZlbnQoXG4gICAgICBhcGlDbGllbnQsXG4gICAgICBhY2Nlc3NUb2tlbixcbiAgICAgIGNvbm5lY3Rpb25JZCxcbiAgICAgIHBheWxvYWQsXG4gICAgKTtcbiAgfVxufVxuIiwiLy8gQmFja2dyb3VuZCBTZXJ2aWNlIFdvcmtlciAtIE1haW4gZW50cnkgcG9pbnQgKEFQSS1maXJzdClcblxuaW1wb3J0IHsgU3RvcmFnZU1hbmFnZXIgfSBmcm9tIFwiLi9zdG9yYWdlLW1hbmFnZXJcIjtcbmltcG9ydCB7IE1lc3NhZ2VIYW5kbGVyIH0gZnJvbSBcIi4vbWVzc2FnZS1oYW5kbGVyXCI7XG5pbXBvcnQgeyBBcGlDb250cm9sbGVyIH0gZnJvbSBcIi4vY29udHJvbGxlcnMvYXBpLWNvbnRyb2xsZXJcIjtcbmltcG9ydCB0eXBlIHsgTWVzc2FnZSB9IGZyb20gXCJAL3NoYXJlZC90eXBlc1wiO1xuaW1wb3J0IHsgaW5pdGlhbGl6ZUFwaUNsaWVudCB9IGZyb20gXCJAL2xpYi9hcGkvY2xpZW50XCI7XG5cbmNvbnNvbGUubG9nKFwiW0JhY2tncm91bmRdIEdyYW5kcGEgRGVGaSBFeHRlbnNpb24gbG9hZGVkXCIpO1xuY29uc29sZS5sb2coXG4gIFwiW0JhY2tncm91bmRdIFNlcnZpY2UgV29ya2VyIElEOlwiLFxuICBzZWxmLnJlZ2lzdHJhdGlvbj8uYWN0aXZlPy5zY3JpcHRVUkwsXG4pO1xuXG4vLyBLZWVwIHNlcnZpY2Ugd29ya2VyIGFsaXZlXG5sZXQga2VlcEFsaXZlSW50ZXJ2YWw6IG51bWJlciB8IHVuZGVmaW5lZDtcblxuZnVuY3Rpb24ga2VlcFNlcnZpY2VXb3JrZXJBbGl2ZSgpIHtcbiAgaWYgKGtlZXBBbGl2ZUludGVydmFsKSB7XG4gICAgY2xlYXJJbnRlcnZhbChrZWVwQWxpdmVJbnRlcnZhbCk7XG4gIH1cbiAga2VlcEFsaXZlSW50ZXJ2YWwgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG4gICAgY29uc29sZS5sb2coXCJbQmFja2dyb3VuZF0gS2VlcC1hbGl2ZSBwaW5nXCIpO1xuICB9LCAyMDAwMCkgYXMgdW5rbm93biBhcyBudW1iZXI7XG59XG5cbmtlZXBTZXJ2aWNlV29ya2VyQWxpdmUoKTtcblxuc2VsZi5hZGRFdmVudExpc3RlbmVyKFwiZXJyb3JcIiwgKGV2ZW50KSA9PiB7XG4gIGNvbnNvbGUuZXJyb3IoXCJbQmFja2dyb3VuZF0gVW5jYXVnaHQgZXJyb3I6XCIsIGV2ZW50LmVycm9yKTtcbiAgY29uc29sZS5lcnJvcihcIltCYWNrZ3JvdW5kXSBFcnJvciBtZXNzYWdlOlwiLCBldmVudC5tZXNzYWdlKTtcbiAgY29uc29sZS5lcnJvcihcIltCYWNrZ3JvdW5kXSBFcnJvciBzdGFjazpcIiwgZXZlbnQuZXJyb3I/LnN0YWNrKTtcbiAgY29uc29sZS5lcnJvcihcbiAgICBcIltCYWNrZ3JvdW5kXSBFcnJvciBhdDpcIixcbiAgICBldmVudC5maWxlbmFtZSxcbiAgICBldmVudC5saW5lbm8sXG4gICAgZXZlbnQuY29sbm8sXG4gICk7XG59KTtcblxuc2VsZi5hZGRFdmVudExpc3RlbmVyKFwidW5oYW5kbGVkcmVqZWN0aW9uXCIsIChldmVudCkgPT4ge1xuICBjb25zb2xlLmVycm9yKFwiW0JhY2tncm91bmRdIFVuaGFuZGxlZCBwcm9taXNlIHJlamVjdGlvbjpcIiwgZXZlbnQucmVhc29uKTtcbiAgY29uc29sZS5lcnJvcihcIltCYWNrZ3JvdW5kXSBSZWplY3Rpb24gc3RhY2s6XCIsIGV2ZW50LnJlYXNvbj8uc3RhY2spO1xuICBjb25zb2xlLmVycm9yKFwiW0JhY2tncm91bmRdIFByb21pc2U6XCIsIGV2ZW50LnByb21pc2UpO1xufSk7XG5cbi8vIEluaXRpYWxpemUgbWFuYWdlcnNcbmNvbnN0IHN0b3JhZ2UgPSBuZXcgU3RvcmFnZU1hbmFnZXIoKTtcbmNvbnN0IGFwaUNvbnRyb2xsZXIgPSBuZXcgQXBpQ29udHJvbGxlcihzdG9yYWdlKTtcbmNvbnN0IG1lc3NhZ2VIYW5kbGVyID0gbmV3IE1lc3NhZ2VIYW5kbGVyKHN0b3JhZ2UsIGFwaUNvbnRyb2xsZXIpO1xuXG5hc3luYyBmdW5jdGlvbiBpbml0aWFsaXplRXh0ZW5zaW9uKCkge1xuICBjb25zb2xlLmxvZyhcIltCYWNrZ3JvdW5kXSBJbml0aWFsaXppbmcgZXh0ZW5zaW9uLi4uXCIpO1xuICBhd2FpdCBQcm9taXNlLmFsbChbc3RvcmFnZS5pbml0aWFsaXplKCksIGluaXRpYWxpemVBcGlDbGllbnQoKV0pO1xuICBjb25zb2xlLmxvZyhcIltCYWNrZ3JvdW5kXSBFeHRlbnNpb24gaW5pdGlhbGl6ZWRcIik7XG59XG5cbmNocm9tZS5ydW50aW1lLm9uSW5zdGFsbGVkLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcbiAgY29uc29sZS5sb2coXCJbQmFja2dyb3VuZF0gRXh0ZW5zaW9uIGluc3RhbGxlZFwiKTtcbiAgYXdhaXQgaW5pdGlhbGl6ZUV4dGVuc2lvbigpO1xufSk7XG5cbnR5cGUgQmFja2dyb3VuZFJlc3BvbnNlID1cbiAgfCB7IHN1Y2Nlc3M6IHRydWU7IGRhdGE6IHVua25vd24gfVxuICB8IHsgc3VjY2VzczogZmFsc2U7IGVycm9yOiBzdHJpbmcgfTtcblxuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKFxuICAoXG4gICAgbWVzc2FnZTogTWVzc2FnZSxcbiAgICBzZW5kZXI6IGNocm9tZS5ydW50aW1lLk1lc3NhZ2VTZW5kZXIsXG4gICAgc2VuZFJlc3BvbnNlOiAocmVzcG9uc2U6IEJhY2tncm91bmRSZXNwb25zZSkgPT4gdm9pZCxcbiAgKSA9PiB7XG4gICAgY29uc29sZS5sb2coXCJbQmFja2dyb3VuZF0gUmVjZWl2ZWQgbWVzc2FnZTpcIiwgbWVzc2FnZS50eXBlKTtcbiAgICBjb25zb2xlLmxvZyhcbiAgICAgIFwiW0JhY2tncm91bmRdIE1lc3NhZ2UgcGF5bG9hZDpcIixcbiAgICAgIFwicGF5bG9hZFwiIGluIG1lc3NhZ2UgPyBtZXNzYWdlLnBheWxvYWQgOiBcIm5vIHBheWxvYWRcIixcbiAgICApO1xuICAgIGNvbnNvbGUubG9nKFwiW0JhY2tncm91bmRdIFNlbmRlcjpcIiwgc2VuZGVyLnRhYj8uaWQgfHwgXCJwb3B1cFwiLCBzZW5kZXIudXJsKTtcblxuICAgIHRyeSB7XG4gICAgICBtZXNzYWdlSGFuZGxlclxuICAgICAgICAuaGFuZGxlTWVzc2FnZShtZXNzYWdlLCBzZW5kZXIpXG4gICAgICAgIC50aGVuKChyZXNwb25zZSkgPT4ge1xuICAgICAgICAgIGNvbnNvbGUubG9nKFxuICAgICAgICAgICAgXCJbQmFja2dyb3VuZF0gTWVzc2FnZSBoYW5kbGVkIHN1Y2Nlc3NmdWxseTpcIixcbiAgICAgICAgICAgIG1lc3NhZ2UudHlwZSxcbiAgICAgICAgICApO1xuICAgICAgICAgIHNlbmRSZXNwb25zZSh7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IHJlc3BvbnNlIH0pO1xuICAgICAgICB9KVxuICAgICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIltCYWNrZ3JvdW5kXSBNZXNzYWdlIGhhbmRsZXIgZXJyb3I6XCIsIGVycm9yKTtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiW0JhY2tncm91bmRdIEVycm9yIHR5cGU6XCIsIGVycm9yLmNvbnN0cnVjdG9yLm5hbWUpO1xuICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJbQmFja2dyb3VuZF0gRXJyb3IgbWVzc2FnZTpcIiwgZXJyb3IubWVzc2FnZSk7XG4gICAgICAgICAgY29uc29sZS5lcnJvcihcIltCYWNrZ3JvdW5kXSBFcnJvciBzdGFjazpcIiwgZXJyb3Iuc3RhY2spO1xuXG4gICAgICAgICAgc2VuZFJlc3BvbnNlKHtcbiAgICAgICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICAgICAgZXJyb3I6IGVycm9yLm1lc3NhZ2UgfHwgXCJVbmtub3duIGVycm9yXCIsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKFxuICAgICAgICBcIltCYWNrZ3JvdW5kXSBTeW5jaHJvbm91cyBlcnJvciBpbiBtZXNzYWdlIGhhbmRsZXI6XCIsXG4gICAgICAgIGVycm9yLFxuICAgICAgKTtcbiAgICAgIHNlbmRSZXNwb25zZSh7XG4gICAgICAgIHN1Y2Nlc3M6IGZhbHNlLFxuICAgICAgICBlcnJvcjogZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiBcIlVua25vd24gZXJyb3JcIixcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIHJldHVybiB0cnVlO1xuICB9LFxuKTtcblxuY2hyb21lLnJ1bnRpbWUub25TdGFydHVwLmFkZExpc3RlbmVyKGFzeW5jICgpID0+IHtcbiAgY29uc29sZS5sb2coXCJbQmFja2dyb3VuZF0gRXh0ZW5zaW9uIHN0YXJ0ZWQgb24gYnJvd3NlciBzdGFydHVwXCIpO1xuICBhd2FpdCBpbml0aWFsaXplRXh0ZW5zaW9uKCk7XG59KTtcblxuLy8gRXhwb3J0IGZvciB0ZXN0aW5nXG5leHBvcnQgeyBzdG9yYWdlLCBtZXNzYWdlSGFuZGxlciB9O1xuIl0sIm5hbWVzIjpbInN0b3JhZ2UiXSwibWFwcGluZ3MiOiI7QUFhQSxNQUFNLHNCQUFrQztBQUFBLEVBQ3RDLGFBQWE7QUFBQSxFQUNiLGNBQWM7QUFBQSxFQUNkLHNCQUFzQjtBQUFBLEVBQ3RCLGNBQWM7QUFBQSxFQUNkLE1BQU07QUFDUjtBQUVBLFNBQVMsZUFDUCxRQUNBLEtBQ0EsVUFDRztBQUNILFFBQU0sUUFBUSxPQUFPLEdBQUc7QUFDeEIsU0FBUSxTQUFlO0FBQ3pCO0FBRUEsU0FBUyxnQkFBZ0IsT0FBdUI7QUFDOUMsTUFBSTtBQUNGLFVBQU0sTUFBTSxJQUFJLElBQUksS0FBSztBQUN6QixVQUFNLFdBQVcsSUFBSSxTQUFTLFlBQUE7QUFDOUIsVUFBTSxXQUFXLElBQUksU0FBUyxZQUFBO0FBQzlCLFVBQU0sT0FBTyxJQUFJO0FBQ2pCLFVBQU0sY0FDSixLQUFLLFNBQVMsS0FDZCxFQUNHLGFBQWEsWUFBWSxTQUFTLFNBQ2xDLGFBQWEsV0FBVyxTQUFTO0FBRXRDLFVBQU0sT0FBTyxjQUFjLEdBQUcsUUFBUSxJQUFJLElBQUksS0FBSztBQUNuRCxXQUFPLEdBQUcsUUFBUSxLQUFLLElBQUk7QUFBQSxFQUM3QixRQUFRO0FBQ04sV0FBTyxNQUFNLEtBQUEsRUFBTyxZQUFBO0FBQUEsRUFDdEI7QUFDRjtBQUVPLE1BQU0sZUFBZTtBQUFBLEVBQ2xCLHNCQUFzQixPQUtuQjtBQUNULFdBQU87QUFBQSxNQUNMLE1BQU07QUFBQSxNQUNOLE1BQU0sY0FBYyxZQUFBO0FBQUEsTUFDcEIsT0FBTyxNQUFNLE9BQU87QUFBQSxNQUNwQixNQUFNO0FBQUEsSUFBQSxFQUNOLEtBQUssR0FBRztBQUFBLEVBQ1o7QUFBQSxFQUVRLHNCQUFzQixPQUE4QztBQUMxRSxRQUFJLENBQUMsU0FBUyxPQUFPLFVBQVUsU0FBVSxRQUFPO0FBQ2hELFVBQU0sU0FBUztBQUNmLFdBQ0UsT0FBTyxPQUFPLGlCQUFpQixZQUMvQixPQUFPLE9BQU8sV0FBVyxZQUN6QixPQUFPLE9BQU8scUJBQXFCLFlBQ25DLE9BQU8sT0FBTyxTQUFTLGFBQ3RCLE9BQU8sZ0JBQWdCLFlBQVksT0FBTyxnQkFBZ0IsWUFDM0QsT0FBTyxPQUFPLGtCQUFrQixZQUNoQyxPQUFPLE9BQU8sWUFBWTtBQUFBLEVBRTlCO0FBQUEsRUFFQSxNQUFNLGFBQTRCO0FBQ2hDLFVBQU0sV0FBVyxNQUFNLEtBQUssT0FBQTtBQUU1QixRQUFJLENBQUMsU0FBUyxVQUFVO0FBQ3RCLFlBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSTtBQUFBLFFBQzdCLENBQUMsYUFBYSxRQUFRLEdBQUc7QUFBQSxRQUN6QixDQUFDLGFBQWEsZUFBZSxHQUFHLENBQUE7QUFBQSxRQUNoQyxDQUFDLGFBQWEsV0FBVyxHQUFHO0FBQUEsUUFDNUIsQ0FBQyxhQUFhLFdBQVcsR0FBRyxDQUFBO0FBQUEsUUFDNUIsQ0FBQyxhQUFhLHNCQUFzQixHQUFHO0FBQUEsUUFDdkMsQ0FBQyxhQUFhLDJCQUEyQixHQUFHLENBQUE7QUFBQSxRQUM1QyxDQUFDLGFBQWEsb0JBQW9CLEdBQUcsQ0FBQTtBQUFBLFFBQ3JDLENBQUMsYUFBYSxZQUFZLEdBQUc7QUFBQSxRQUM3QixDQUFDLGFBQWEsU0FBUyxHQUFHO0FBQUEsTUFBQSxDQUMzQjtBQUNELGNBQVEsSUFBSSxxQ0FBcUM7QUFBQSxJQUNuRDtBQUFBLEVBQ0Y7QUFBQSxFQUVBLE1BQU0sU0FBMEM7QUFDOUMsV0FBTyxPQUFPLFFBQVEsTUFBTSxJQUFJLElBQUk7QUFBQSxFQUN0QztBQUFBLEVBRUEsTUFBTSxXQUEwQjtBQUM5QixVQUFNLE9BQU8sUUFBUSxNQUFNLE1BQUE7QUFBQSxFQUM3QjtBQUFBLEVBRUEsTUFBTSxjQUFpQztBQUNyQyxVQUFNLFNBQVUsTUFBTSxPQUFPLFFBQVEsTUFBTTtBQUFBLE1BQ3pDLGFBQWE7QUFBQSxJQUFBO0FBRWYsV0FBTyxlQUFlLFFBQVEsYUFBYSxVQUFVLGdCQUFnQjtBQUFBLEVBQ3ZFO0FBQUEsRUFFQSxNQUFNLFlBQVksVUFBbUM7QUFDbkQsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxhQUFhLFFBQVEsR0FBRyxVQUFVO0FBQUEsRUFDdEU7QUFBQSxFQUVBLE1BQU0sZUFBZSxTQUEyQztBQUM5RCxVQUFNLFdBQVcsTUFBTSxLQUFLLFlBQUE7QUFDNUIsVUFBTSxLQUFLLFlBQVksRUFBRSxHQUFHLFVBQVUsR0FBRyxTQUFTO0FBQUEsRUFDcEQ7QUFBQTtBQUFBLEVBR0EsTUFBTSxvQkFBa0U7QUFDdEUsVUFBTSxTQUFVLE1BQU0sT0FBTyxRQUFRLE1BQU07QUFBQSxNQUN6QyxhQUFhO0FBQUEsSUFBQTtBQUVmLFVBQU0sTUFBTSxlQUFlLFFBQVEsYUFBYSxpQkFBaUIsQ0FBQSxDQUFFO0FBQ25FLFVBQU0sVUFBVSxPQUFPLFFBQVEsR0FBOEI7QUFDN0QsVUFBTSxPQUE0QyxDQUFBO0FBQ2xELGVBQVcsQ0FBQyxLQUFLLEtBQUssS0FBSyxTQUFTO0FBQ2xDLFVBQUksQ0FBQyxLQUFLLHNCQUFzQixLQUFLLEVBQUc7QUFDeEMsV0FBSyxHQUFHLElBQUk7QUFBQSxJQUNkO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVBLE1BQU0saUJBQWlCLE1BQTBDO0FBQy9ELFVBQU0sUUFBUSxNQUFNLEtBQUssa0JBQUE7QUFDekIsVUFBTSxtQkFBbUI7QUFBQSxNQUN2QixLQUFLLG9CQUFvQixLQUFLO0FBQUEsSUFBQTtBQUVoQyxVQUFNLE1BQU0sS0FBSyxJQUFBO0FBQ2pCLFVBQU0sTUFBTSxLQUFLLHNCQUFzQjtBQUFBLE1BQ3JDO0FBQUEsTUFDQSxhQUFhLEtBQUs7QUFBQSxNQUNsQixlQUFlLEtBQUs7QUFBQSxNQUNwQixTQUFTLEtBQUs7QUFBQSxJQUFBLENBQ2Y7QUFDRCxVQUFNLEdBQUcsSUFBSTtBQUFBLE1BQ1gsR0FBRztBQUFBLE1BQ0gsUUFBUSxnQkFBZ0IsS0FBSyxNQUFNO0FBQUEsTUFDbkM7QUFBQSxNQUNBLGFBQWEsS0FBSyxlQUFlO0FBQUEsTUFDakMsWUFBWSxLQUFLLGNBQWM7QUFBQSxJQUFBO0FBRWpDLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsYUFBYSxlQUFlLEdBQUcsT0FBTztBQUFBLEVBQzFFO0FBQUEsRUFFQSxNQUFNLG9CQUFvQixjQUFxQztBQUM3RCxVQUFNLFFBQVEsTUFBTSxLQUFLLGtCQUFBO0FBQ3pCLGVBQVcsQ0FBQyxLQUFLLEtBQUssS0FBSyxPQUFPLFFBQVEsS0FBSyxHQUFHO0FBQ2hELFVBQUksTUFBTSxpQkFBaUIsYUFBYztBQUN6QyxhQUFPLE1BQU0sR0FBRztBQUFBLElBQ2xCO0FBQ0EsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxhQUFhLGVBQWUsR0FBRyxPQUFPO0FBQUEsRUFDMUU7QUFBQSxFQUVBLE1BQU0sOEJBQ0osUUFDQSxlQUNlO0FBQ2YsVUFBTSxRQUFRLE1BQU0sS0FBSyxrQkFBQTtBQUN6QixVQUFNLG1CQUFtQixnQkFBZ0IsTUFBTTtBQUMvQyxVQUFNLDBCQUEwQixlQUFlLFlBQUEsS0FBaUI7QUFDaEUsZUFBVyxDQUFDLEtBQUssS0FBSyxLQUFLLE9BQU8sUUFBUSxLQUFLLEdBQUc7QUFDaEQsVUFBSSxNQUFNLHFCQUFxQixpQkFBa0I7QUFDakQsVUFDRSwyQkFDQSxNQUFNLGNBQWMsWUFBQSxNQUFrQix5QkFDdEM7QUFDQTtBQUFBLE1BQ0Y7QUFDQSxhQUFPLE1BQU0sR0FBRztBQUFBLElBQ2xCO0FBQ0EsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxhQUFhLGVBQWUsR0FBRyxPQUFPO0FBQUEsRUFDMUU7QUFBQSxFQUVBLE1BQU0sa0JBQWtCLFFBS2dCO0FBQ3RDLFVBQU0sUUFBUSxNQUFNLEtBQUssa0JBQUE7QUFDekIsVUFBTSxtQkFBbUIsZ0JBQWdCLE9BQU8sTUFBTTtBQUN0RCxVQUFNLDBCQUEwQixPQUFPLGNBQWMsWUFBQTtBQUNyRCxVQUFNLFFBQVEsT0FBTyxPQUFPLEtBQUssRUFBRTtBQUFBLE1BQ2pDLENBQUMsU0FDQyxLQUFLLHFCQUFxQixvQkFDMUIsS0FBSyxnQkFBZ0IsT0FBTyxlQUM1QixLQUFLLFlBQVksT0FBTyxXQUN4QixLQUFLLGNBQWMsa0JBQWtCO0FBQUEsSUFBQTtBQUV6QyxXQUFPLFNBQVM7QUFBQSxFQUNsQjtBQUFBLEVBRUEsTUFBTSxnQkFBZ0IsUUFLRDtBQUNuQixXQUFRLE1BQU0sS0FBSyxrQkFBa0IsTUFBTSxNQUFPO0FBQUEsRUFDcEQ7QUFBQSxFQUVBLE1BQU0sbUJBQW1CLGNBQXFDO0FBQzVELFVBQU0sUUFBUSxNQUFNLEtBQUssa0JBQUE7QUFDekIsUUFBSSxZQUFZO0FBQ2hCLGVBQVcsQ0FBQyxLQUFLLElBQUksS0FBSyxPQUFPLFFBQVEsS0FBSyxHQUFHO0FBQy9DLFVBQUksS0FBSyxpQkFBaUIsYUFBYztBQUN4QyxZQUFNLEdBQUcsSUFBSTtBQUFBLFFBQ1gsR0FBRztBQUFBLFFBQ0gsWUFBWSxLQUFLLElBQUE7QUFBQSxNQUFJO0FBRXZCLGtCQUFZO0FBQUEsSUFDZDtBQUVBLFFBQUksV0FBVztBQUNiLFlBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsYUFBYSxlQUFlLEdBQUcsT0FBTztBQUFBLElBQzFFO0FBQUEsRUFDRjtBQUFBO0FBQUEsRUFHQSxNQUFNLGdCQUFxQztBQUN6QyxVQUFNLFNBQVUsTUFBTSxPQUFPLFFBQVEsTUFBTTtBQUFBLE1BQ3pDLGFBQWE7QUFBQSxJQUFBO0FBRWYsV0FBTztBQUFBLE1BQ0w7QUFBQSxNQUNBLGFBQWE7QUFBQSxNQUNiO0FBQUEsSUFBQTtBQUFBLEVBRUo7QUFBQSxFQUVBLE1BQU0sY0FBYyxTQUFvQztBQUN0RCxVQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLGFBQWEsV0FBVyxHQUFHLFNBQVM7QUFBQSxFQUN4RTtBQUFBLEVBRUEsTUFBTSxrQkFBaUM7QUFDckMsVUFBTSxLQUFLLGNBQWMsbUJBQW1CO0FBQUEsRUFDOUM7QUFBQSxFQUVBLE1BQU0sZ0JBQXFDO0FBQ3pDLFVBQU0sU0FBVSxNQUFNLE9BQU8sUUFBUSxNQUFNO0FBQUEsTUFDekMsYUFBYTtBQUFBLElBQUE7QUFFZixXQUFPLGVBQWUsUUFBUSxhQUFhLGFBQWEsQ0FBQSxDQUFnQjtBQUFBLEVBQzFFO0FBQUEsRUFFQSxNQUFNLGNBQWMsU0FBb0M7QUFDdEQsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxhQUFhLFdBQVcsR0FBRyxTQUFTO0FBQUEsRUFDeEU7QUFBQSxFQUVBLE1BQU0seUJBQWlEO0FBQ3JELFVBQU0sU0FBVSxNQUFNLE9BQU8sUUFBUSxNQUFNO0FBQUEsTUFDekMsYUFBYTtBQUFBLElBQUE7QUFFZixXQUFPLGVBQWUsUUFBUSxhQUFhLHdCQUF3QixJQUFJO0FBQUEsRUFDekU7QUFBQSxFQUVBLE1BQU0sdUJBQXVCLFVBQXdDO0FBQ25FLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSTtBQUFBLE1BQzdCLENBQUMsYUFBYSxzQkFBc0IsR0FBRztBQUFBLElBQUEsQ0FDeEM7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFNLDhCQUFpRTtBQUNyRSxVQUFNLFNBQVUsTUFBTSxPQUFPLFFBQVEsTUFBTTtBQUFBLE1BQ3pDLGFBQWE7QUFBQSxJQUFBO0FBRWYsV0FBTztBQUFBLE1BQ0w7QUFBQSxNQUNBLGFBQWE7QUFBQSxNQUNiLENBQUE7QUFBQSxJQUFDO0FBQUEsRUFFTDtBQUFBLEVBRUEsTUFBTSw0QkFDSixZQUNlO0FBQ2YsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJO0FBQUEsTUFDN0IsQ0FBQyxhQUFhLDJCQUEyQixHQUFHO0FBQUEsSUFBQSxDQUM3QztBQUFBLEVBQ0g7QUFBQSxFQUVBLE1BQU0sd0JBQXNEO0FBQzFELFVBQU0sU0FBVSxNQUFNLE9BQU8sUUFBUSxNQUFNO0FBQUEsTUFDekMsYUFBYTtBQUFBLElBQUE7QUFFZixXQUFPO0FBQUEsTUFDTDtBQUFBLE1BQ0EsYUFBYTtBQUFBLE1BQ2IsQ0FBQTtBQUFBLElBQUM7QUFBQSxFQUVMO0FBQUEsRUFFQSxNQUFNLHNCQUFzQixhQUFpRDtBQUMzRSxVQUFNLE9BQU8sUUFBUSxNQUFNLElBQUk7QUFBQSxNQUM3QixDQUFDLGFBQWEsb0JBQW9CLEdBQUc7QUFBQSxJQUFBLENBQ3RDO0FBQUEsRUFDSDtBQUFBLEVBRUEsTUFBTSxnQkFBd0M7QUFDNUMsVUFBTSxTQUFVLE1BQU0sT0FBTyxRQUFRLE1BQU07QUFBQSxNQUN6QyxhQUFhO0FBQUEsSUFBQTtBQUVmLFdBQU8sZUFBZSxRQUFRLGFBQWEsY0FBYyxJQUFJO0FBQUEsRUFDL0Q7QUFBQSxFQUVBLE1BQU0sY0FBYyxTQUF1QztBQUN6RCxVQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLGFBQWEsWUFBWSxHQUFHLFNBQVM7QUFBQSxFQUN6RTtBQUFBLEVBRUEsTUFBTSxjQUF3QztBQUM1QyxVQUFNLFNBQVUsTUFBTSxPQUFPLFFBQVEsTUFBTTtBQUFBLE1BQ3pDLGFBQWE7QUFBQSxJQUFBO0FBRWYsV0FBTyxlQUFlLFFBQVEsYUFBYSxXQUFXLElBQUk7QUFBQSxFQUM1RDtBQUFBLEVBRUEsTUFBTSxZQUFZLE9BQXVDO0FBQ3ZELFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsYUFBYSxTQUFTLEdBQUcsT0FBTztBQUFBLEVBQ3BFO0FBQ0Y7QUNuVEEsTUFBTSwwQkFBMEIsSUFBSTtBQUNwQyxNQUFNLHFCQUFxQixJQUFJO0FBQy9CLE1BQU0sMkJBQTJCO0FBb0MxQixNQUFNLGVBQWU7QUFBQSxFQUsxQixZQUNVQSxVQUNBLEtBQ1I7QUFGUSxTQUFBLFVBQUFBO0FBQ0EsU0FBQSxNQUFBO0FBRVIsV0FBTyxRQUFRLFVBQVUsWUFBWSxDQUFDLGFBQWE7QUFDakQsaUJBQVcsQ0FBQyxXQUFXLEtBQUssS0FBSyxLQUFLLHFCQUFxQjtBQUN6RCxZQUFJLE1BQU0sYUFBYSxTQUFVO0FBQ2pDLHFCQUFhLE1BQU0sU0FBUztBQUM1QixhQUFLLG9CQUFvQixPQUFPLFNBQVM7QUFDekMsY0FBTSxPQUFPLElBQUksTUFBTSxvQ0FBb0MsQ0FBQztBQUFBLE1BQzlEO0FBRUEsaUJBQVcsQ0FBQyxhQUFhLEtBQUssS0FBSyxLQUFLLHlCQUF5QjtBQUMvRCxZQUFJLE1BQU0sYUFBYSxTQUFVO0FBQ2pDLHFCQUFhLE1BQU0sU0FBUztBQUM1QixhQUFLLHdCQUF3QixPQUFPLFdBQVc7QUFDL0MsY0FBTSxPQUFPLElBQUksTUFBTSxxQ0FBcUMsQ0FBQztBQUFBLE1BQy9EO0FBRUEsaUJBQVcsQ0FBQyxXQUFXLEtBQUssS0FBSyxLQUFLLHVCQUF1QjtBQUMzRCxZQUFJLE1BQU0sYUFBYSxTQUFVO0FBQ2pDLHFCQUFhLE1BQU0sU0FBUztBQUM1QixhQUFLLHNCQUFzQixPQUFPLFNBQVM7QUFDM0MsY0FBTSxPQUFPLElBQUksTUFBTSxtQ0FBbUMsQ0FBQztBQUFBLE1BQzdEO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBOUJRLDBDQUEwQixJQUFBO0FBQUEsRUFDMUIsOENBQThCLElBQUE7QUFBQSxFQUM5Qiw0Q0FBNEIsSUFBQTtBQUFBLEVBOEJwQyxNQUFNLGNBQ0osU0FDQSxRQUNrQjtBQUNsQixZQUFRLElBQUksOEJBQThCLFFBQVEsSUFBSTtBQUV0RCxZQUFRLFFBQVEsTUFBQTtBQUFBLE1BQ2QsS0FBSztBQUNILGVBQU8sS0FBSyxrQkFBa0IsUUFBUSxTQUFTLE1BQU07QUFBQSxNQUV2RCxLQUFLO0FBQ0gsZUFBTyxLQUFLLHFCQUFxQixRQUFRLE9BQU87QUFBQSxNQUVsRCxLQUFLO0FBQ0gsZUFBTyxLQUFLLHNCQUFzQixRQUFRLFNBQVMsTUFBTTtBQUFBLE1BRTNELEtBQUs7QUFDSCxlQUFPLEtBQUssa0JBQWtCLFFBQVEsU0FBUyxNQUFNO0FBQUEsTUFFdkQsS0FBSztBQUNILGVBQU8sS0FBSyxtQkFBQTtBQUFBLE1BRWQsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJLFdBQUE7QUFBQSxNQUVsQixLQUFLO0FBQ0gsZUFBTyxLQUFLLElBQUksV0FBVyxRQUFRLE9BQU87QUFBQSxNQUU1QyxLQUFLO0FBQ0gsZUFBTyxLQUFLLElBQUksYUFBQTtBQUFBLE1BRWxCLEtBQUs7QUFDSCxlQUFPLEtBQUssSUFBSSxXQUFBO0FBQUEsTUFFbEIsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJLE1BQUE7QUFBQSxNQUVsQixLQUFLO0FBQ0gsY0FBTSxLQUFLLElBQUksb0JBQW9CLFFBQVEsUUFBUSxRQUFRO0FBQzNELGVBQU8sRUFBRSxVQUFVLFFBQVEsUUFBUSxTQUFBO0FBQUEsTUFFckMsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJLGNBQUE7QUFBQSxNQUVsQixLQUFLO0FBQ0gsZUFBTyxLQUFLLElBQUksYUFBYSxRQUFRLE9BQThCO0FBQUEsTUFFckUsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJO0FBQUEsVUFDZCxRQUFRLFFBQVE7QUFBQSxVQUNoQixRQUFRLFFBQVE7QUFBQSxRQUFBO0FBQUEsTUFHcEIsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJO0FBQUEsVUFDZCxRQUFRLFFBQVE7QUFBQSxVQUNoQixRQUFRLFFBQVE7QUFBQSxRQUFBO0FBQUEsTUFHcEIsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJO0FBQUEsVUFDZCxRQUFRLFFBQVE7QUFBQSxVQUNoQixRQUFRLFFBQVE7QUFBQSxRQUFBO0FBQUEsTUFLcEIsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJO0FBQUEsVUFDZCxRQUFRLFFBQVE7QUFBQSxVQUNoQixRQUFRLFFBQVE7QUFBQSxRQUFBO0FBQUEsTUFHcEIsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJO0FBQUEsVUFDZCxRQUFRLFFBQVE7QUFBQSxVQUNoQixRQUFRLFFBQVE7QUFBQSxRQUFBO0FBQUEsTUFHcEIsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJO0FBQUEsVUFDZCxRQUFRLFFBQVE7QUFBQSxVQUNoQixRQUFRLFFBQVE7QUFBQSxRQUFBO0FBQUEsTUFHcEIsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJLGtCQUFrQixRQUFRLFFBQVEsUUFBUTtBQUFBLE1BRTVELEtBQUs7QUFDSCxlQUFPLEtBQUssSUFBSSxvQkFBb0IsUUFBUSxRQUFRLFVBQVU7QUFBQSxVQUM1RCxRQUFRLFFBQVEsUUFBUTtBQUFBLFVBQ3hCLE9BQU8sUUFBUSxRQUFRO0FBQUEsUUFBQSxDQUN4QjtBQUFBLE1BRUgsS0FBSztBQUNILGVBQU8sS0FBSyxJQUFJLGlCQUFpQixRQUFRLFFBQVEsV0FBVztBQUFBLE1BRTlELEtBQUs7QUFDSCxlQUFPLEtBQUssSUFBSSxvQkFBb0IsUUFBUSxRQUFRLFdBQVc7QUFBQSxNQUVqRSxLQUFLO0FBQ0gsZUFBTyxLQUFLLDRCQUE0QixRQUFRLE9BQU87QUFBQSxNQUV6RCxLQUFLO0FBQ0gsZUFBTyxLQUFLLDJCQUEyQixRQUFRLE9BQU87QUFBQSxNQUV4RCxLQUFLO0FBQ0gsZUFBTyxLQUFLLHVCQUF1QixRQUFRLE9BQU87QUFBQSxNQUVwRCxLQUFLO0FBQ0gsZUFBTyxLQUFLLHNCQUFzQixRQUFRLE9BQU87QUFBQSxNQUVuRCxLQUFLO0FBQ0gsZUFBTyxLQUFLLHlCQUF5QixRQUFRLE9BQU87QUFBQSxNQUV0RCxLQUFLO0FBQ0gsZUFBTyxLQUFLLHdCQUF3QixRQUFRLE9BQU87QUFBQSxNQUVyRCxLQUFLO0FBQ0gsZUFBTyxLQUFLLElBQUksZ0JBQUE7QUFBQSxNQUVsQixLQUFLO0FBQ0gsZUFBTyxLQUFLLElBQUk7QUFBQSxVQUNkLFFBQVE7QUFBQSxRQUFBO0FBQUEsTUFHWixLQUFLO0FBQ0gsZUFBTyxLQUFLLElBQUk7QUFBQSxVQUNkLFFBQVE7QUFBQSxRQUFBO0FBQUEsTUFHWjtBQUNFLGNBQU0sSUFBSTtBQUFBLFVBQ1IseUJBQ0csUUFBOEIsUUFBUSxTQUN6QztBQUFBLFFBQUE7QUFBQSxJQUNGO0FBQUEsRUFFTjtBQUFBLEVBRVEsZ0JBQWdCLE9BQXVCO0FBQzdDLFFBQUk7QUFDRixZQUFNLE1BQU0sSUFBSSxJQUFJLEtBQUs7QUFDekIsWUFBTSxXQUFXLElBQUksU0FBUyxZQUFBO0FBQzlCLFlBQU0sV0FBVyxJQUFJLFNBQVMsWUFBQTtBQUM5QixZQUFNLE9BQU8sSUFBSTtBQUNqQixZQUFNLGNBQ0osS0FBSyxTQUFTLEtBQ2QsRUFDRyxhQUFhLFlBQVksU0FBUyxTQUNsQyxhQUFhLFdBQVcsU0FBUztBQUV0QyxZQUFNLE9BQU8sY0FBYyxHQUFHLFFBQVEsSUFBSSxJQUFJLEtBQUs7QUFDbkQsYUFBTyxHQUFHLFFBQVEsS0FBSyxJQUFJO0FBQUEsSUFDN0IsUUFBUTtBQUNOLGFBQU8sTUFBTSxLQUFBLEVBQU8sWUFBQTtBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUFBLEVBRVEsc0JBQ04sWUFDcUI7QUFDckIsVUFBTSxNQUFNLEtBQUssSUFBQTtBQUNqQixXQUFPO0FBQUEsTUFDTCxjQUFjLFdBQVc7QUFBQSxNQUN6QixRQUFRLFdBQVc7QUFBQSxNQUNuQixrQkFBa0IsV0FBVztBQUFBLE1BQzdCLE1BQU0sV0FBVztBQUFBLE1BQ2pCLGFBQWEsV0FBVztBQUFBLE1BQ3hCLFVBQVUsV0FBVztBQUFBLE1BQ3JCLGVBQWUsV0FBVztBQUFBLE1BQzFCLFNBQVMsV0FBVztBQUFBLE1BQ3BCLFlBQVksV0FBVztBQUFBLE1BQ3ZCLGFBQWEsV0FBVyxjQUNwQixLQUFLLE1BQU0sV0FBVyxXQUFXLEtBQUssTUFDdEM7QUFBQSxNQUNKLFlBQVk7QUFBQSxJQUFBO0FBQUEsRUFFaEI7QUFBQSxFQUVRLDJCQUEyQixNQUFrQztBQUNuRSxXQUFPO0FBQUEsTUFDTCxNQUFNO0FBQUEsTUFDTixPQUFPO0FBQUEsTUFDUCxTQUFTLEdBQUcsSUFBSTtBQUFBLElBQUE7QUFBQSxFQUVwQjtBQUFBLEVBRUEsTUFBYyxnQkFDWixjQUNBLE1BQ0EsU0FDZTtBQUNmLFFBQUk7QUFDRixZQUFNLEtBQUssSUFBSSw4QkFBOEIsY0FBYztBQUFBLFFBQ3pEO0FBQUEsUUFDQTtBQUFBLE1BQUEsQ0FDRDtBQUFBLElBQ0gsU0FBUyxPQUFPO0FBQ2QsY0FBUSxLQUFLLHNEQUFzRCxLQUFLO0FBQUEsSUFDMUU7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFjLDhCQUNaLFFBQ0EsUUFDcUM7QUFDckMsVUFBTSxRQUFRLE1BQU0sS0FBSyxRQUFRLGtCQUFrQjtBQUFBLE1BQ2pEO0FBQUEsTUFDQSxlQUFlLE9BQU87QUFBQSxNQUN0QixTQUFTLE9BQU87QUFBQSxNQUNoQixhQUFhO0FBQUEsSUFBQSxDQUNkO0FBQ0QsUUFBSSxPQUFPO0FBQ1QsYUFBTztBQUFBLElBQ1Q7QUFFQSxRQUFJO0FBQ0YsWUFBTSxtQkFBbUIsS0FBSyxnQkFBZ0IsTUFBTTtBQUNwRCxZQUFNLFNBQVMsTUFBTSxLQUFLLElBQUksb0JBQW9CO0FBQUEsUUFDaEQsYUFBYTtBQUFBLFFBQ2IsVUFBVSxPQUFPO0FBQUEsUUFDakIsUUFBUTtBQUFBLE1BQUEsQ0FDVDtBQUNELFlBQU0sUUFBUSxPQUFPLFlBQVk7QUFBQSxRQUMvQixDQUFDLGVBQWUsV0FBVyxxQkFBcUI7QUFBQSxNQUFBO0FBRWxELFVBQUksQ0FBQyxPQUFPO0FBQ1YsZUFBTztBQUFBLE1BQ1Q7QUFFQSxZQUFNLFNBQVMsS0FBSyxzQkFBc0IsS0FBSztBQUMvQyxZQUFNLEtBQUssUUFBUSxpQkFBaUIsTUFBTTtBQUMxQyxhQUFPO0FBQUEsSUFDVCxTQUFTLE9BQU87QUFDZCxjQUFRLEtBQUssc0RBQXNELEtBQUs7QUFDeEUsYUFBTztBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFjLGtCQUNaLFNBQ0EsUUFDQTtBQUNBLFVBQU0sWUFBWSxRQUFRLFVBQVUsT0FBTyxVQUFVLE9BQU87QUFDNUQsUUFBSSxDQUFDLFdBQVc7QUFDZCxZQUFNLElBQUksTUFBTSxvQkFBb0I7QUFBQSxJQUN0QztBQUNBLFVBQU0sU0FBUyxLQUFLLGdCQUFnQixTQUFTO0FBRTdDLFVBQU0sU0FBUyxNQUFNLEtBQUsseUJBQUE7QUFDMUIsUUFBSSxDQUFDLFFBQVE7QUFDWCxZQUFNLElBQUk7QUFBQSxRQUNSO0FBQUEsTUFBQTtBQUFBLElBRUo7QUFFQSxVQUFNLFdBQVcsTUFBTSxLQUFLLElBQUksc0JBQXNCO0FBQUEsTUFDcEQ7QUFBQSxNQUNBLGFBQWE7QUFBQSxNQUNiLGVBQWUsT0FBTztBQUFBLE1BQ3RCLFNBQVMsT0FBTztBQUFBLE1BQ2hCLFVBQVUsT0FBTztBQUFBLElBQUEsQ0FDbEI7QUFFRCxRQUFJLFNBQVMsV0FBVyxlQUFlLFdBQVc7QUFDaEQsWUFBTSxJQUFJLE1BQU0sU0FBUyxrQkFBa0Isc0JBQXNCO0FBQUEsSUFDbkU7QUFFQSxRQUNFLFNBQVMsb0JBQ1QsU0FBUyxXQUFXLFdBQVcsYUFDL0I7QUFDQSxZQUFNLEtBQUssUUFBUTtBQUFBLFFBQ2pCLEtBQUssc0JBQXNCLFNBQVMsVUFBVTtBQUFBLE1BQUE7QUFFaEQsYUFBTztBQUFBLFFBQ0wsV0FBVztBQUFBLFFBQ1gsVUFBVSxDQUFDLE9BQU8sT0FBTztBQUFBLE1BQUE7QUFBQSxJQUU3QjtBQUVBLFVBQU0sWUFBWSxPQUFPLFdBQUE7QUFDekIsVUFBTSxXQUFXLE1BQU0sS0FBSyx5QkFBeUIsU0FBUztBQUU5RCxRQUFJLFdBQVc7QUFDZixRQUFJO0FBQ0YsaUJBQVcsTUFBTSxLQUFLLDZCQUE2QixXQUFXO0FBQUEsUUFDNUQ7QUFBQSxRQUNBO0FBQUEsUUFDQSxlQUFlLE9BQU87QUFBQSxRQUN0QixZQUFZLFNBQVM7QUFBQSxRQUNyQixTQUFTO0FBQUEsVUFDUCxNQUFNLFNBQVM7QUFBQSxVQUNmLE9BQU8sU0FBUztBQUFBLFVBQ2hCLFNBQVMsU0FBUztBQUFBLFFBQUE7QUFBQSxNQUNwQixDQUNEO0FBQUEsSUFDSCxTQUFTLE9BQU87QUFDZCxZQUFNLEtBQUssSUFDUixxQkFBcUIsU0FBUyxXQUFXLFlBQVksRUFDckQsTUFBTSxNQUFNLE1BQVM7QUFDeEIsWUFBTTtBQUFBLElBQ1I7QUFFQSxRQUFJLENBQUMsVUFBVTtBQUNiLFlBQU0sS0FBSyxJQUNSLHFCQUFxQixTQUFTLFdBQVcsWUFBWSxFQUNyRCxNQUFNLE1BQU0sTUFBUztBQUN4QixZQUFNLElBQUksTUFBTSwwQkFBMEI7QUFBQSxJQUM1QztBQUVBLFVBQU0sWUFBWSxNQUFNLEtBQUssSUFBSTtBQUFBLE1BQy9CLFNBQVMsV0FBVztBQUFBLElBQUE7QUFFdEIsVUFBTSxLQUFLLFFBQVE7QUFBQSxNQUNqQixLQUFLLHNCQUFzQixVQUFVLFVBQVU7QUFBQSxJQUFBO0FBR2pELFdBQU87QUFBQSxNQUNMLFdBQVc7QUFBQSxNQUNYLFVBQVUsQ0FBQyxPQUFPLE9BQU87QUFBQSxJQUFBO0FBQUEsRUFFN0I7QUFBQSxFQUVBLE1BQWMscUJBQXFCLFNBQTZCO0FBQzlELFVBQU0sU0FBUyxNQUFNLEtBQUssaUJBQUE7QUFDMUIsUUFBSSxDQUFDLFFBQVE7QUFDWCxZQUFNLEtBQUssUUFBUSw4QkFBOEIsUUFBUSxNQUFNO0FBQy9ELGFBQU8sRUFBRSxTQUFTLEtBQUE7QUFBQSxJQUNwQjtBQUVBLFVBQU0sT0FBTyxNQUFNLEtBQUssUUFBUSxrQkFBa0I7QUFBQSxNQUNoRCxRQUFRLFFBQVE7QUFBQSxNQUNoQixlQUFlLE9BQU87QUFBQSxNQUN0QixTQUFTLE9BQU87QUFBQSxNQUNoQixhQUFhO0FBQUEsSUFBQSxDQUNkO0FBRUQsUUFBSSxNQUFNO0FBQ1IsWUFBTSxLQUFLLElBQ1IseUJBQXlCLEtBQUssWUFBWSxFQUMxQyxNQUFNLENBQUMsVUFBVTtBQUNoQixnQkFBUSxLQUFLLCtDQUErQyxLQUFLO0FBQUEsTUFDbkUsQ0FBQztBQUNILFlBQU0sS0FBSyxRQUFRLG9CQUFvQixLQUFLLFlBQVk7QUFBQSxJQUMxRDtBQUVBLFVBQU0sS0FBSyxRQUFRO0FBQUEsTUFDakIsUUFBUTtBQUFBLE1BQ1IsT0FBTztBQUFBLElBQUE7QUFFVCxXQUFPLEVBQUUsU0FBUyxLQUFBO0FBQUEsRUFDcEI7QUFBQSxFQUVBLE1BQWMsc0JBQ1osU0FDQSxRQUN3QjtBQUN4QixVQUFNLFNBQVMsT0FBTyxVQUFVLE9BQU87QUFDdkMsUUFBSSxDQUFDLFFBQVE7QUFDWCxZQUFNLElBQUksTUFBTSxvQkFBb0I7QUFBQSxJQUN0QztBQUVBLFFBQUksQ0FBQyxRQUFRLElBQUk7QUFDZixZQUFNLElBQUksTUFBTSxnQ0FBZ0M7QUFBQSxJQUNsRDtBQUVBLFVBQU0sU0FBUyxNQUFNLEtBQUssaUJBQUE7QUFDMUIsUUFBSSxDQUFDLFFBQVE7QUFDWCxZQUFNLElBQUksTUFBTSxxQkFBcUI7QUFBQSxJQUN2QztBQUVBLFVBQU0sYUFBYSxNQUFNLEtBQUssOEJBQThCLFFBQVEsTUFBTTtBQUMxRSxRQUFJLENBQUMsWUFBWTtBQUNmLFlBQU0sSUFBSSxNQUFNLG9CQUFvQjtBQUFBLElBQ3RDO0FBQ0EsUUFBSSxXQUFXLGVBQWUsV0FBVztBQUN2QyxZQUFNLElBQUksTUFBTSxzQkFBc0I7QUFBQSxJQUN4QztBQUVBLFVBQU0sS0FBSyxRQUFRLG1CQUFtQixXQUFXLFlBQVk7QUFDN0QsU0FBSyxLQUFLO0FBQUEsTUFDUixXQUFXO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxJQUFBO0FBR0YsVUFBTSxVQUNKLFdBQVcsZUFBZSxZQUN0QixLQUFLLDJCQUEyQixXQUFXLElBQUksSUFDL0M7QUFFTixVQUFNLFdBQVcsTUFBTSxLQUFLLElBQUksb0JBQW9CLE9BQU8sVUFBVTtBQUFBLE1BQ25FLGtCQUFrQjtBQUFBLFFBQ2hCO0FBQUEsVUFDRSxJQUFJLFFBQVE7QUFBQSxVQUNaLE9BQVEsUUFBUSxTQUFTO0FBQUEsVUFDekIsTUFBTyxRQUFRLFFBQVE7QUFBQSxRQUFBO0FBQUEsTUFDekI7QUFBQSxJQUNGLENBQ0Q7QUFFRCxVQUFNLFdBQVcsTUFBTSxLQUFLLGtCQUFrQixTQUFTLFdBQVc7QUFDbEUsV0FBTyxLQUFLLHNCQUFzQixTQUFTLGFBQWE7QUFBQSxNQUN0RDtBQUFBLE1BQ0EsUUFBUSxXQUFXO0FBQUEsTUFDbkI7QUFBQSxNQUNBO0FBQUEsSUFBQSxDQUNEO0FBQUEsRUFDSDtBQUFBLEVBRUEsTUFBYyxrQkFDWixTQUNBLFFBQ3dCO0FBQ3hCLFVBQU0sU0FBUyxPQUFPLFVBQVUsT0FBTztBQUN2QyxRQUFJLENBQUMsUUFBUTtBQUNYLFlBQU0sSUFBSSxNQUFNLG9CQUFvQjtBQUFBLElBQ3RDO0FBRUEsUUFBSSxPQUFPLFFBQVEsWUFBWSxVQUFVO0FBQ3ZDLFlBQU0sSUFBSSxNQUFNLGlDQUFpQztBQUFBLElBQ25EO0FBRUEsVUFBTSxTQUFTLE1BQU0sS0FBSyxpQkFBQTtBQUMxQixRQUFJLENBQUMsUUFBUTtBQUNYLFlBQU0sSUFBSSxNQUFNLHFCQUFxQjtBQUFBLElBQ3ZDO0FBRUEsVUFBTSxhQUFhLE1BQU0sS0FBSyw4QkFBOEIsUUFBUSxNQUFNO0FBQzFFLFFBQUksQ0FBQyxZQUFZO0FBQ2YsWUFBTSxJQUFJLE1BQU0sb0JBQW9CO0FBQUEsSUFDdEM7QUFDQSxRQUFJLFdBQVcsZUFBZSxXQUFXO0FBQ3ZDLFlBQU0sSUFBSSxNQUFNLHNCQUFzQjtBQUFBLElBQ3hDO0FBRUEsVUFBTSxtQkFBbUIsUUFBUSxTQUFTLFlBQUE7QUFDMUMsUUFBSSxvQkFBb0IscUJBQXFCLE9BQU8sUUFBUSxlQUFlO0FBQ3pFLFlBQU0sSUFBSSxNQUFNLGtEQUFrRDtBQUFBLElBQ3BFO0FBRUEsVUFBTSxLQUFLLFFBQVEsbUJBQW1CLFdBQVcsWUFBWTtBQUM3RCxTQUFLLEtBQUssZ0JBQWdCLFdBQVcsY0FBYyxXQUFXLFdBQVc7QUFFekUsVUFBTSxVQUNKLFdBQVcsZUFBZSxZQUN0QixLQUFLLDJCQUEyQixXQUFXLElBQUksSUFDL0M7QUFFTixVQUFNLFlBQVksT0FBTyxXQUFBO0FBQ3pCLFVBQU0sV0FBVyxNQUFNLEtBQUssc0JBQXNCLFNBQVM7QUFDM0QsV0FBTyxLQUFLLDBCQUEwQixXQUFXO0FBQUEsTUFDL0M7QUFBQSxNQUNBLFNBQVMsUUFBUTtBQUFBLE1BQ2pCLFNBQVMsT0FBTztBQUFBLE1BQ2hCLFFBQVEsV0FBVztBQUFBLE1BQ25CLFVBQVUsT0FBTztBQUFBLE1BQ2pCO0FBQUEsTUFDQTtBQUFBLElBQUEsQ0FDRDtBQUFBLEVBQ0g7QUFBQSxFQUVBLE1BQWMscUJBQXFCO0FBQ2pDLFVBQU0sS0FBSyxRQUFRLFNBQUE7QUFDbkIsV0FBTyxFQUFFLFNBQVMsS0FBQTtBQUFBLEVBQ3BCO0FBQUEsRUFFQSxNQUFjLG1CQUE2QztBQUN6RCxVQUFNLFVBQVUsTUFBTSxLQUFLLFFBQVEsY0FBQTtBQUNuQyxRQUFJLENBQUMsUUFBUSxjQUFjO0FBQ3pCLGFBQU87QUFBQSxJQUNUO0FBRUEsUUFBSSxVQUFVLE1BQU0sS0FBSyxRQUFRLGNBQUE7QUFDakMsUUFBSSxRQUFRLFdBQVcsR0FBRztBQUN4QixVQUFJO0FBQ0YsY0FBTSxLQUFLLElBQUksTUFBQTtBQUFBLE1BQ2pCLFNBQVMsT0FBTztBQUNkLGdCQUFRLEtBQUssK0NBQStDLEtBQUs7QUFBQSxNQUNuRTtBQUNBLGdCQUFVLE1BQU0sS0FBSyxRQUFRLGNBQUE7QUFBQSxJQUMvQjtBQUVBLFVBQU0sYUFBYSxNQUFNLEtBQUssUUFBUSx1QkFBQTtBQUN0QyxXQUNFLFFBQVEsS0FBSyxDQUFDLFVBQVUsTUFBTSxhQUFhLFVBQVUsS0FDckQsUUFBUSxDQUFDLEtBQ1Q7QUFBQSxFQUVKO0FBQUEsRUFFQSxNQUFjLDJCQUFxRDtBQUNqRSxVQUFNLFdBQVcsTUFBTSxLQUFLLGlCQUFBO0FBQzVCLFFBQUksVUFBVTtBQUNaLGFBQU87QUFBQSxJQUNUO0FBRUEsVUFBTSxXQUFXLE1BQU0sS0FBSyxvQkFBQTtBQUM1QixRQUFJO0FBQ0YsYUFBTyxLQUFLLG1CQUFtQixrQkFBa0I7QUFBQSxJQUNuRCxVQUFBO0FBQ0UsVUFBSSxVQUFVO0FBQ1osZUFBTyxRQUFRLE9BQU8sVUFBVSxNQUFNLE1BQVM7QUFBQSxNQUNqRDtBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQUEsRUFFQSxNQUFjLG1CQUNaLFdBQzBCO0FBQzFCLFVBQU0sUUFBUSxLQUFLLElBQUE7QUFDbkIsV0FBTyxLQUFLLFFBQVEsUUFBUSxXQUFXO0FBQ3JDLFlBQU0sU0FBUyxNQUFNLEtBQUssaUJBQUE7QUFDMUIsVUFBSSxRQUFRO0FBQ1YsZUFBTztBQUFBLE1BQ1Q7QUFDQSxZQUFNLE1BQU0sd0JBQXdCO0FBQUEsSUFDdEM7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRUEsTUFBYyxrQkFDWixhQUM2QjtBQUM3QixVQUFNLE1BQU0sT0FBTyxRQUFRO0FBQUEsTUFDekIsNENBQTRDO0FBQUEsUUFDMUM7QUFBQSxNQUFBLENBQ0Q7QUFBQSxJQUFBO0FBR0gsV0FBTyxJQUFJLFFBQVEsQ0FBQyxZQUFZO0FBQzlCLGFBQU8sUUFBUTtBQUFBLFFBQ2I7QUFBQSxVQUNFO0FBQUEsVUFDQSxNQUFNO0FBQUEsVUFDTixPQUFPO0FBQUEsVUFDUCxRQUFRO0FBQUEsVUFDUixTQUFTO0FBQUEsUUFBQTtBQUFBLFFBRVgsQ0FBQyxXQUFXO0FBQ1Ysa0JBQVEsUUFBUSxFQUFFO0FBQUEsUUFDcEI7QUFBQSxNQUFBO0FBQUEsSUFFSixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsTUFBYyx5QkFDWixXQUM2QjtBQUM3QixVQUFNLE1BQU0sT0FBTyxRQUFRO0FBQUEsTUFDekIsK0NBQStDO0FBQUEsUUFDN0M7QUFBQSxNQUFBLENBQ0Q7QUFBQSxJQUFBO0FBR0gsV0FBTyxJQUFJLFFBQVEsQ0FBQyxZQUFZO0FBQzlCLGFBQU8sUUFBUTtBQUFBLFFBQ2I7QUFBQSxVQUNFO0FBQUEsVUFDQSxNQUFNO0FBQUEsVUFDTixPQUFPO0FBQUEsVUFDUCxRQUFRO0FBQUEsVUFDUixTQUFTO0FBQUEsUUFBQTtBQUFBLFFBRVgsQ0FBQyxXQUFXO0FBQ1Ysa0JBQVEsUUFBUSxFQUFFO0FBQUEsUUFDcEI7QUFBQSxNQUFBO0FBQUEsSUFFSixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsTUFBYyxzQkFDWixXQUM2QjtBQUM3QixVQUFNLE1BQU0sT0FBTyxRQUFRO0FBQUEsTUFDekIsNENBQTRDO0FBQUEsUUFDMUM7QUFBQSxNQUFBLENBQ0Q7QUFBQSxJQUFBO0FBR0gsV0FBTyxJQUFJLFFBQVEsQ0FBQyxZQUFZO0FBQzlCLGFBQU8sUUFBUTtBQUFBLFFBQ2I7QUFBQSxVQUNFO0FBQUEsVUFDQSxNQUFNO0FBQUEsVUFDTixPQUFPO0FBQUEsVUFDUCxRQUFRO0FBQUEsVUFDUixTQUFTO0FBQUEsUUFBQTtBQUFBLFFBRVgsQ0FBQyxXQUFXO0FBQ1Ysa0JBQVEsUUFBUSxFQUFFO0FBQUEsUUFDcEI7QUFBQSxNQUFBO0FBQUEsSUFFSixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsTUFBYyxzQkFBbUQ7QUFDL0QsVUFBTSxNQUFNLE9BQU8sUUFBUSxPQUFPLG9CQUFvQjtBQUN0RCxXQUFPLElBQUksUUFBUSxDQUFDLFlBQVk7QUFDOUIsYUFBTyxRQUFRO0FBQUEsUUFDYjtBQUFBLFVBQ0U7QUFBQSxVQUNBLE1BQU07QUFBQSxVQUNOLE9BQU87QUFBQSxVQUNQLFFBQVE7QUFBQSxVQUNSLFNBQVM7QUFBQSxRQUFBO0FBQUEsUUFFWCxDQUFDLFdBQVc7QUFDVixrQkFBUSxRQUFRLEVBQUU7QUFBQSxRQUNwQjtBQUFBLE1BQUE7QUFBQSxJQUVKLENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFUSw2QkFDTixXQUNBLFNBQ2tCO0FBQ2xCLFFBQUksS0FBSyxvQkFBb0IsSUFBSSxTQUFTLEdBQUc7QUFDM0MsV0FBSyxvQkFDRixJQUFJLFNBQVMsR0FDWixPQUFPLElBQUksTUFBTSwyQkFBMkIsQ0FBQztBQUNqRCxXQUFLLG9CQUFvQixPQUFPLFNBQVM7QUFBQSxJQUMzQztBQUVBLFdBQU8sSUFBSSxRQUFRLENBQUMsU0FBUyxXQUFXO0FBQ3RDLFlBQU0sWUFBWSxXQUFXLE1BQU07QUFDakMsYUFBSyxvQkFBb0IsT0FBTyxTQUFTO0FBQ3pDLGVBQU8sSUFBSSxNQUFNLG1DQUFtQyxDQUFDO0FBQUEsTUFDdkQsR0FBRyx1QkFBdUI7QUFFMUIsV0FBSyxvQkFBb0IsSUFBSSxXQUFXO0FBQUEsUUFDdEM7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsR0FBRztBQUFBLE1BQUEsQ0FDSjtBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVRLHNCQUNOLGFBQ0EsU0FDd0I7QUFDeEIsUUFBSSxLQUFLLHdCQUF3QixJQUFJLFdBQVcsR0FBRztBQUNqRCxXQUFLLHdCQUNGLElBQUksV0FBVyxHQUNkLE9BQU8sSUFBSSxNQUFNLCtCQUErQixDQUFDO0FBQ3JELFdBQUssd0JBQXdCLE9BQU8sV0FBVztBQUFBLElBQ2pEO0FBRUEsV0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDdEMsWUFBTSxZQUFZLFdBQVcsTUFBTTtBQUNqQyxhQUFLLHdCQUF3QixPQUFPLFdBQVc7QUFDL0MsZUFBTyxJQUFJLE1BQU0sb0NBQW9DLENBQUM7QUFBQSxNQUN4RCxHQUFHLHVCQUF1QjtBQUUxQixXQUFLLHdCQUF3QixJQUFJLGFBQWE7QUFBQSxRQUM1QztBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQSxHQUFHO0FBQUEsTUFBQSxDQUNKO0FBQUEsSUFDSCxDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRVEsMEJBQ04sV0FDQSxTQUN3QjtBQUN4QixRQUFJLEtBQUssc0JBQXNCLElBQUksU0FBUyxHQUFHO0FBQzdDLFdBQUssc0JBQ0YsSUFBSSxTQUFTLEdBQ1osT0FBTyxJQUFJLE1BQU0sd0JBQXdCLENBQUM7QUFDOUMsV0FBSyxzQkFBc0IsT0FBTyxTQUFTO0FBQUEsSUFDN0M7QUFFQSxXQUFPLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVztBQUN0QyxZQUFNLFlBQVksV0FBVyxNQUFNO0FBQ2pDLGFBQUssc0JBQXNCLE9BQU8sU0FBUztBQUMzQyxlQUFPLElBQUksTUFBTSxrQ0FBa0MsQ0FBQztBQUFBLE1BQ3RELEdBQUcsdUJBQXVCO0FBRTFCLFdBQUssc0JBQXNCLElBQUksV0FBVztBQUFBLFFBQ3hDO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBLEdBQUc7QUFBQSxNQUFBLENBQ0o7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFjLDRCQUE0QixTQUFnQztBQUN4RSxVQUFNLFFBQVEsS0FBSyxvQkFBb0IsSUFBSSxRQUFRLFNBQVM7QUFDNUQsUUFBSSxDQUFDLE9BQU87QUFDVixZQUFNLElBQUksTUFBTSwyQkFBMkI7QUFBQSxJQUM3QztBQUVBLFdBQU87QUFBQSxNQUNMLFdBQVcsUUFBUTtBQUFBLE1BQ25CLFFBQVEsTUFBTTtBQUFBLE1BQ2QsZUFBZSxNQUFNO0FBQUEsTUFDckIsY0FBYyxNQUFNLFdBQVc7QUFBQSxNQUMvQixNQUFNLE1BQU0sV0FBVztBQUFBLE1BQ3ZCLFlBQVksTUFBTSxXQUFXO0FBQUEsTUFDN0IsYUFBYSxNQUFNLFFBQVE7QUFBQSxNQUMzQixjQUFjLE1BQU0sUUFBUTtBQUFBLE1BQzVCLGdCQUFnQixNQUFNLFFBQVE7QUFBQSxJQUFBO0FBQUEsRUFFbEM7QUFBQSxFQUVBLE1BQWMsMkJBQTJCLFNBSXRDO0FBQ0QsVUFBTSxRQUFRLEtBQUssb0JBQW9CLElBQUksUUFBUSxTQUFTO0FBQzVELFFBQUksQ0FBQyxPQUFPO0FBQ1YsYUFBTyxFQUFFLFNBQVMsS0FBQTtBQUFBLElBQ3BCO0FBRUEsaUJBQWEsTUFBTSxTQUFTO0FBQzVCLFNBQUssb0JBQW9CLE9BQU8sUUFBUSxTQUFTO0FBRWpELFFBQUksUUFBUSxXQUFXLFlBQVk7QUFDakMsWUFBTSxRQUFRLElBQUk7QUFDbEIsYUFBTyxFQUFFLFNBQVMsS0FBQTtBQUFBLElBQ3BCO0FBQ0EsUUFBSSxRQUFRLFdBQVcsWUFBWTtBQUNqQyxZQUFNLFFBQVEsS0FBSztBQUNuQixhQUFPLEVBQUUsU0FBUyxLQUFBO0FBQUEsSUFDcEI7QUFFQSxVQUFNLE9BQU8sSUFBSSxNQUFNLFFBQVEsU0FBUyx5QkFBeUIsQ0FBQztBQUNsRSxXQUFPLEVBQUUsU0FBUyxLQUFBO0FBQUEsRUFDcEI7QUFBQSxFQUVBLE1BQWMsdUJBQXVCLFNBQWtDO0FBQ3JFLFVBQU0sUUFBUSxLQUFLLHdCQUF3QixJQUFJLFFBQVEsV0FBVztBQUNsRSxRQUFJLENBQUMsT0FBTztBQUNWLFlBQU0sSUFBSSxNQUFNLCtCQUErQjtBQUFBLElBQ2pEO0FBRUEsV0FBTztBQUFBLE1BQ0wsYUFBYSxRQUFRO0FBQUEsTUFDckIsUUFBUSxNQUFNO0FBQUEsTUFDZCxjQUFjLE1BQU0sWUFBWSxnQkFBZ0I7QUFBQSxNQUNoRCxNQUFNLE1BQU0sWUFBWSxRQUFRO0FBQUEsTUFDaEMsWUFBWSxNQUFNLFlBQVksY0FBYztBQUFBLE1BQzVDLFNBQVMsTUFBTTtBQUFBLElBQUE7QUFBQSxFQUVuQjtBQUFBLEVBRUEsTUFBYyxzQkFBc0IsU0FLakM7QUFDRCxVQUFNLFFBQVEsS0FBSyx3QkFBd0IsSUFBSSxRQUFRLFdBQVc7QUFDbEUsUUFBSSxDQUFDLE9BQU87QUFDVixhQUFPLEVBQUUsU0FBUyxLQUFBO0FBQUEsSUFDcEI7QUFFQSxpQkFBYSxNQUFNLFNBQVM7QUFDNUIsU0FBSyx3QkFBd0IsT0FBTyxRQUFRLFdBQVc7QUFFdkQsUUFBSSxNQUFNLFlBQVk7QUFDcEIsWUFBTSxVQUNKLFFBQVEsV0FBVyxjQUNmLGFBQ0EsUUFBUSxXQUFXLGFBQ2pCLGFBQ0E7QUFDUixXQUFLLEtBQUs7QUFBQSxRQUNSLE1BQU0sV0FBVztBQUFBLFFBQ2pCO0FBQUEsUUFDQTtBQUFBLE1BQUE7QUFBQSxJQUVKO0FBRUEsUUFBSSxRQUFRLFdBQVcsYUFBYTtBQUNsQyxVQUFJLENBQUMsUUFBUSxRQUFRO0FBQ25CLGNBQU07QUFBQSxVQUNKLElBQUksTUFBTSwrQ0FBK0M7QUFBQSxRQUFBO0FBRTNELGVBQU8sRUFBRSxTQUFTLEtBQUE7QUFBQSxNQUNwQjtBQUNBLFlBQU0sUUFBUSxRQUFRLE1BQU07QUFDNUIsYUFBTyxFQUFFLFNBQVMsS0FBQTtBQUFBLElBQ3BCO0FBRUEsVUFBTSxlQUNKLFFBQVEsU0FBUztBQUNuQixVQUFNLE9BQU8sSUFBSSxNQUFNLFlBQVksQ0FBQztBQUNwQyxXQUFPLEVBQUUsU0FBUyxLQUFBO0FBQUEsRUFDcEI7QUFBQSxFQUVBLE1BQWMseUJBQXlCLFNBQWdDO0FBQ3JFLFVBQU0sUUFBUSxLQUFLLHNCQUFzQixJQUFJLFFBQVEsU0FBUztBQUM5RCxRQUFJLENBQUMsT0FBTztBQUNWLFlBQU0sSUFBSSxNQUFNLHdCQUF3QjtBQUFBLElBQzFDO0FBRUEsV0FBTztBQUFBLE1BQ0wsV0FBVyxRQUFRO0FBQUEsTUFDbkIsU0FBUyxNQUFNO0FBQUEsTUFDZixTQUFTLE1BQU07QUFBQSxNQUNmLFFBQVEsTUFBTTtBQUFBLE1BQ2QsVUFBVSxNQUFNO0FBQUEsTUFDaEIsY0FBYyxNQUFNLFlBQVksZ0JBQWdCO0FBQUEsTUFDaEQsTUFBTSxNQUFNLFlBQVksUUFBUTtBQUFBLE1BQ2hDLFlBQVksTUFBTSxZQUFZLGNBQWM7QUFBQSxNQUM1QyxTQUFTLE1BQU07QUFBQSxJQUFBO0FBQUEsRUFFbkI7QUFBQSxFQUVBLE1BQWMsd0JBQXdCLFNBS25DO0FBQ0QsVUFBTSxRQUFRLEtBQUssc0JBQXNCLElBQUksUUFBUSxTQUFTO0FBQzlELFFBQUksQ0FBQyxPQUFPO0FBQ1YsYUFBTyxFQUFFLFNBQVMsS0FBQTtBQUFBLElBQ3BCO0FBRUEsaUJBQWEsTUFBTSxTQUFTO0FBQzVCLFNBQUssc0JBQXNCLE9BQU8sUUFBUSxTQUFTO0FBRW5ELFFBQUksTUFBTSxZQUFZO0FBQ3BCLFlBQU0sVUFDSixRQUFRLFdBQVcsV0FDZixhQUNBLFFBQVEsV0FBVyxhQUNqQixhQUNBO0FBQ1IsV0FBSyxLQUFLO0FBQUEsUUFDUixNQUFNLFdBQVc7QUFBQSxRQUNqQjtBQUFBLFFBQ0E7QUFBQSxNQUFBO0FBQUEsSUFFSjtBQUVBLFFBQUksUUFBUSxXQUFXLFVBQVU7QUFDL0IsVUFBSSxDQUFDLFFBQVEsV0FBVztBQUN0QixjQUFNLE9BQU8sSUFBSSxNQUFNLDBCQUEwQixDQUFDO0FBQ2xELGVBQU8sRUFBRSxTQUFTLEtBQUE7QUFBQSxNQUNwQjtBQUNBLFlBQU0sUUFBUSxRQUFRLFNBQVM7QUFDL0IsYUFBTyxFQUFFLFNBQVMsS0FBQTtBQUFBLElBQ3BCO0FBRUEsVUFBTSxlQUNKLFFBQVEsU0FBUztBQUNuQixVQUFNLE9BQU8sSUFBSSxNQUFNLFlBQVksQ0FBQztBQUNwQyxXQUFPLEVBQUUsU0FBUyxLQUFBO0FBQUEsRUFDcEI7QUFDRjtBQzk3QkEsTUFBTSxxQkFBcUIsS0FBSyxLQUFLO0FBRXJDLFNBQVMsbUJBQW1CLE9BQWU7QUFDekMsTUFBSSxhQUFhLE1BQU0sUUFBUSxNQUFNLEdBQUcsRUFBRSxRQUFRLE1BQU0sR0FBRztBQUMzRCxRQUFNLGdCQUFnQixXQUFXLFNBQVM7QUFDMUMsTUFBSSxrQkFBa0IsRUFBRyxlQUFjO0FBQUEsV0FDOUIsa0JBQWtCLEVBQUcsZUFBYztBQUFBLFdBQ25DLGtCQUFrQixFQUFHLGVBQWM7QUFDNUMsU0FBTztBQUNUO0FBRU8sU0FBUyxvQkFBb0IsT0FBOEI7QUFDaEUsTUFBSTtBQUNGLFVBQU0sV0FBVyxNQUFNLE1BQU0sR0FBRztBQUNoQyxRQUFJLFNBQVMsU0FBUyxFQUFHLFFBQU87QUFDaEMsVUFBTSxpQkFBaUIsU0FBUyxDQUFDO0FBQ2pDLFFBQUksQ0FBQyxlQUFnQixRQUFPO0FBQzVCLFVBQU0sYUFBYSxtQkFBbUIsY0FBYztBQUNwRCxRQUFJLE9BQU8sV0FBVyxTQUFTLFdBQVksUUFBTztBQUNsRCxVQUFNLE9BQU8sV0FBVyxLQUFLLFVBQVU7QUFDdkMsVUFBTSxVQUFVLEtBQUssTUFBTSxJQUFJO0FBQy9CLFFBQUksT0FBTyxRQUFRLFFBQVEsU0FBVSxRQUFPO0FBQzVDLFdBQU8sUUFBUSxNQUFNO0FBQUEsRUFDdkIsUUFBUTtBQUNOLFdBQU87QUFBQSxFQUNUO0FBQ0Y7QUFFTyxTQUFTLGtCQUFrQixPQUFlO0FBQy9DLFNBQU8sb0JBQW9CLEtBQUssS0FBSyxLQUFLLFFBQVE7QUFDcEQ7QUM3Qk8sZUFBZSxNQUFNLFFBQVEsYUFBYTtBQUM3QyxNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxJQUFJLGdCQUFnQixZQUFZLFdBQVcsQ0FBQztBQUNyRSxXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTyw2QkFBNkIsR0FBRyxLQUFLO0FBQUEsRUFDMUY7QUFDSjtBQ1JPLGVBQWUsc0JBQXNCLFFBQVEsYUFBYSxTQUFTO0FBQ3RFLE1BQUk7QUFDQSxVQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUssaUNBQWlDLFNBQVMsWUFBWSxXQUFXLENBQUM7QUFDaEcsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8sbUNBQW1DLEdBQUcsS0FBSztBQUFBLEVBQ2hHO0FBQ0o7QUFDTyxlQUFlLHNCQUFzQixRQUFRLGFBQWEsY0FBYztBQUMzRSxNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxLQUFLLHlCQUF5QixZQUFZLFlBQVksQ0FBQSxHQUFJLFlBQVksV0FBVyxDQUFDO0FBQzNHLFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDcEIsU0FDTyxPQUFPO0FBQ1YsVUFBTSxlQUFlLHFCQUFxQixPQUFPLG1DQUFtQyxHQUFHLEtBQUs7QUFBQSxFQUNoRztBQUNKO0FBQ08sZUFBZSxxQkFBcUIsUUFBUSxhQUFhLGNBQWM7QUFDMUUsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sS0FBSyx5QkFBeUIsWUFBWSxXQUFXLENBQUEsR0FBSSxZQUFZLFdBQVcsQ0FBQztBQUMxRyxXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTyxrQ0FBa0MsR0FBRyxLQUFLO0FBQUEsRUFDL0Y7QUFDSjtBQUNPLGVBQWUseUJBQXlCLFFBQVEsYUFBYSxjQUFjO0FBQzlFLE1BQUk7QUFDQSxVQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUsseUJBQXlCLFlBQVksZUFBZSxDQUFBLEdBQUksWUFBWSxXQUFXLENBQUM7QUFDOUcsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8sMkJBQTJCLEdBQUcsS0FBSztBQUFBLEVBQ3hGO0FBQ0o7QUFDTyxlQUFlLG9CQUFvQixRQUFRLGFBQWEsUUFBUTtBQUNuRSxNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxJQUFJLHlCQUF5QjtBQUFBLE1BQ2xELEdBQUcsWUFBWSxXQUFXO0FBQUEsTUFDMUI7QUFBQSxJQUNaLENBQVM7QUFDRCxXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTyxpQ0FBaUMsR0FBRyxLQUFLO0FBQUEsRUFDOUY7QUFDSjtBQUNPLGVBQWUsOEJBQThCLFFBQVEsYUFBYSxjQUFjLFNBQVM7QUFDNUYsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sS0FBSyx5QkFBeUIsWUFBWSxnQkFBZ0IsU0FBUyxZQUFZLFdBQVcsQ0FBQztBQUNwSCxXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTyxrQ0FBa0MsR0FBRyxLQUFLO0FBQUEsRUFDL0Y7QUFDSjtBQ3hETyxlQUFlLGNBQWMsUUFBUSxhQUFhO0FBQ3JELFFBQU0saUJBQWlCLHFCQUFvQjtBQUMzQyxNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxLQUFLLDJCQUEyQixDQUFBLEdBQUk7QUFBQSxNQUN6RCxHQUFHLFlBQVksV0FBVztBQUFBLE1BQzFCLFNBQVM7QUFBQSxRQUNMLEdBQUcsWUFBWSxXQUFXLEVBQUU7QUFBQSxRQUM1QixtQkFBbUI7QUFBQSxNQUNuQztBQUFBLElBQ0EsQ0FBUztBQUNELFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDcEIsU0FDTyxPQUFPO0FBQ1YsVUFBTSxlQUFlLHFCQUFxQixPQUFPLDBCQUEwQixHQUFHLEtBQUs7QUFBQSxFQUN2RjtBQUNKO0FBQ08sZUFBZSxhQUFhLFFBQVEsYUFBYSxTQUFTO0FBQzdELFFBQU0saUJBQWlCLHFCQUFvQjtBQUMzQyxNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxLQUFLLDBCQUEwQixTQUFTO0FBQUEsTUFDN0QsR0FBRyxZQUFZLFdBQVc7QUFBQSxNQUMxQixTQUFTO0FBQUEsUUFDTCxHQUFHLFlBQVksV0FBVyxFQUFFO0FBQUEsUUFDNUIsbUJBQW1CO0FBQUEsTUFDbkM7QUFBQSxJQUNBLENBQVM7QUFDRCxXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTyx5QkFBeUIsR0FBRyxLQUFLO0FBQUEsRUFDdEY7QUFDSjtBQUNPLGVBQWUsb0JBQW9CLFFBQVEsYUFBYSxVQUFVLFNBQVMsTUFBTTtBQUNwRixRQUFNLGlCQUF5QyxxQkFBb0I7QUFDbkUsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sS0FBSyxlQUFlLFFBQVEsb0JBQW9CLFNBQVM7QUFBQSxNQUM5RSxHQUFHLFlBQVksV0FBVztBQUFBLE1BQzFCLFNBQVM7QUFBQSxRQUNMLEdBQUcsWUFBWSxXQUFXLEVBQUU7QUFBQSxRQUM1QixtQkFBbUI7QUFBQSxNQUNuQztBQUFBLElBQ0EsQ0FBUztBQUNELFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDcEIsU0FDTyxPQUFPO0FBQ1YsVUFBTSxlQUFlLHFCQUFxQixPQUFPLDRCQUE0QixHQUFHLEtBQUs7QUFBQSxFQUN6RjtBQUNKO0FBQ08sZUFBZSxtQkFBbUIsUUFBUSxhQUFhLFVBQVUsU0FBUyxNQUFNO0FBQ25GLFFBQU0saUJBQXlDLHFCQUFvQjtBQUNuRSxNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxLQUFLLGVBQWUsUUFBUSxtQkFBbUIsU0FBUztBQUFBLE1BQzdFLEdBQUcsWUFBWSxXQUFXO0FBQUEsTUFDMUIsU0FBUztBQUFBLFFBQ0wsR0FBRyxZQUFZLFdBQVcsRUFBRTtBQUFBLFFBQzVCLG1CQUFtQjtBQUFBLE1BQ25DO0FBQUEsSUFDQSxDQUFTO0FBQ0QsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8sMkJBQTJCLEdBQUcsS0FBSztBQUFBLEVBQ3hGO0FBQ0o7QUFDTyxlQUFlLHNCQUFzQixRQUFRLGFBQWEsVUFBVSxTQUFTLE1BQU07QUFDdEYsUUFBTSxpQkFBeUMscUJBQW9CO0FBQ25FLE1BQUk7QUFDQSxVQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUssZUFBZSxRQUFRLHNCQUFzQixTQUFTO0FBQUEsTUFDaEYsR0FBRyxZQUFZLFdBQVc7QUFBQSxNQUMxQixTQUFTO0FBQUEsUUFDTCxHQUFHLFlBQVksV0FBVyxFQUFFO0FBQUEsUUFDNUIsbUJBQW1CO0FBQUEsTUFDbkM7QUFBQSxJQUNBLENBQVM7QUFDRCxXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTywrQkFBK0IsR0FBRyxLQUFLO0FBQUEsRUFDNUY7QUFDSjtBQUNPLGVBQWUscUJBQXFCLFFBQVEsYUFBYSxVQUFVLFNBQVMsTUFBTTtBQUNyRixRQUFNLGlCQUF5QyxxQkFBb0I7QUFDbkUsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sS0FBSyxlQUFlLFFBQVEscUJBQXFCLFNBQVM7QUFBQSxNQUMvRSxHQUFHLFlBQVksV0FBVztBQUFBLE1BQzFCLFNBQVM7QUFBQSxRQUNMLEdBQUcsWUFBWSxXQUFXLEVBQUU7QUFBQSxRQUM1QixtQkFBbUI7QUFBQSxNQUNuQztBQUFBLElBQ0EsQ0FBUztBQUNELFdBQU8sSUFBSSxLQUFLO0FBQUEsRUFDcEIsU0FDTyxPQUFPO0FBQ1YsVUFBTSxlQUFlLHFCQUFxQixPQUFPLDhCQUE4QixHQUFHLEtBQUs7QUFBQSxFQUMzRjtBQUNKO0FBQ08sZUFBZSwwQkFBMEIsUUFBUSxhQUFhLFVBQVUsU0FBUztBQUNwRixNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxLQUFLLGVBQWUsUUFBUSwwQkFBMEIsU0FBUyxZQUFZLFdBQVcsQ0FBQztBQUNoSCxXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTyxpQ0FBaUMsR0FBRyxLQUFLO0FBQUEsRUFDOUY7QUFDSjtBQUNPLGVBQWUseUJBQXlCLFFBQVEsYUFBYSxVQUFVLFNBQVM7QUFDbkYsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sS0FBSyxlQUFlLFFBQVEseUJBQXlCLFNBQVMsWUFBWSxXQUFXLENBQUM7QUFDL0csV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8sZ0NBQWdDLEdBQUcsS0FBSztBQUFBLEVBQzdGO0FBQ0o7QUF3Q08sZUFBZSxrQkFBa0IsUUFBUSxhQUFhLFVBQVU7QUFDbkUsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sSUFBSSxlQUFlLFFBQVEsYUFBYSxZQUFZLFdBQVcsQ0FBQztBQUN6RixXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTyxnQ0FBZ0MsR0FBRyxLQUFLO0FBQUEsRUFDN0Y7QUFDSjtBQUNPLGVBQWUsb0JBQW9CLFFBQVEsYUFBYSxVQUFVLFFBQVE7QUFDN0UsTUFBSTtBQUNBLFVBQU0sTUFBTSxNQUFNLE9BQU8sSUFBSSxlQUFlLFFBQVEsZUFBZTtBQUFBLE1BQy9ELEdBQUcsWUFBWSxXQUFXO0FBQUEsTUFDMUIsUUFBUTtBQUFBLFFBQ0osUUFBUSxRQUFRO0FBQUEsUUFDaEIsT0FBTyxRQUFRO0FBQUEsTUFDL0I7QUFBQSxJQUNBLENBQVM7QUFDRCxXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTyxnQ0FBZ0MsR0FBRyxLQUFLO0FBQUEsRUFDN0Y7QUFDSjtBQ2hMTyxlQUFlLGlCQUFpQixRQUFRLGFBQWEsYUFBYTtBQUNyRSxNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxJQUFJLHVCQUF1QixXQUFXLElBQUksWUFBWSxXQUFXLENBQUM7QUFDM0YsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8saUNBQWlDLEdBQUcsS0FBSztBQUFBLEVBQzlGO0FBQ0o7QUFDTyxlQUFlLG9CQUFvQixRQUFRLGFBQWEsYUFBYTtBQUN4RSxNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxPQUFPLHVCQUF1QixXQUFXLElBQUksWUFBWSxXQUFXLENBQUM7QUFDOUYsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8sMENBQTBDLEdBQUcsS0FBSztBQUFBLEVBQ3ZHO0FBQ0o7QUNqQk8sZUFBZSxlQUFlLFFBQVEsYUFBYTtBQUN0RCxNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxJQUFJLG9CQUFvQixZQUFZLFdBQVcsQ0FBQztBQUN6RSxXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTyw2QkFBNkIsR0FBRyxLQUFLO0FBQUEsRUFDMUY7QUFDSjtBQUNPLGVBQWUsdUJBQXVCLFFBQVEsYUFBYSxTQUFTO0FBQ3ZFLE1BQUk7QUFDQSxVQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUssb0JBQW9CLFNBQVMsWUFBWSxXQUFXLENBQUM7QUFDbkYsV0FBTyxJQUFJLEtBQUs7QUFBQSxFQUNwQixTQUNPLE9BQU87QUFDVixVQUFNLGVBQWUscUJBQXFCLE9BQU8sc0JBQXNCLEdBQUcsS0FBSztBQUFBLEVBQ25GO0FBQ0o7QUFDTyxlQUFlLHVCQUF1QixRQUFRLGFBQWEsU0FBUztBQUN2RSxNQUFJO0FBQ0EsVUFBTSxNQUFNLE1BQU0sT0FBTyxPQUFPLG9CQUFvQjtBQUFBLE1BQ2hELEdBQUcsWUFBWSxXQUFXO0FBQUEsTUFDMUIsTUFBTTtBQUFBLElBQ2xCLENBQVM7QUFDRCxXQUFPLElBQUksS0FBSztBQUFBLEVBQ3BCLFNBQ08sT0FBTztBQUNWLFVBQU0sZUFBZSxxQkFBcUIsT0FBTyx3QkFBd0IsR0FBRyxLQUFLO0FBQUEsRUFDckY7QUFDSjtBQ3NCQSxNQUFNLHlCQUF5QjtBQUV4QixNQUFNLGNBQWM7QUFBQSxFQUN6QixZQUFvQkEsVUFBeUI7QUFBekIsU0FBQSxVQUFBQTtBQUFBLEVBQTBCO0FBQUEsRUFFOUMsTUFBTSxhQUFrQztBQUN0QyxXQUFPLEtBQUssUUFBUSxjQUFBO0FBQUEsRUFDdEI7QUFBQSxFQUVBLE1BQU0sV0FBVyxTQUEwQztBQUN6RCxVQUFNLHVCQUF1QixRQUFRLGNBQ2hDLFFBQVEsd0JBQXdCLGtCQUFrQixRQUFRLFdBQVcsSUFDdEU7QUFDSixVQUFNLFVBQXNCO0FBQUEsTUFDMUIsR0FBRztBQUFBLE1BQ0g7QUFBQSxJQUFBO0FBRUYsVUFBTSxLQUFLLFFBQVEsY0FBYyxPQUFPO0FBQ3hDLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFNLGVBQThCO0FBQ2xDLFVBQU0sS0FBSyxRQUFRLGdCQUFBO0FBQ25CLFVBQU0sS0FBSyxRQUFRLGNBQWMsSUFBSTtBQUFBLEVBQ3ZDO0FBQUEsRUFFQSxNQUFNLGFBQXFDO0FBQ3pDLFdBQU8sS0FBSyxRQUFRLGNBQUE7QUFBQSxFQUN0QjtBQUFBLEVBRUEsTUFBTSxvQkFBb0IsVUFBd0M7QUFDaEUsVUFBTSxLQUFLLFFBQVEsdUJBQXVCLFFBQVE7QUFBQSxFQUNwRDtBQUFBLEVBRUEsTUFBYyxzQkFBdUM7QUFDbkQsVUFBTSxVQUFVLE1BQU0sS0FBSyxRQUFRLGNBQUE7QUFDbkMsUUFBSSxDQUFDLFFBQVEsY0FBYztBQUN6QixZQUFNLElBQUksTUFBTSxpQkFBaUI7QUFBQSxJQUNuQztBQUVBLFVBQU0sZ0JBQ0osUUFBUSxlQUNSLFFBQVEsd0JBQ1IsUUFBUSx1QkFBdUIsS0FBSyxJQUFBLElBQVE7QUFFOUMsUUFBSSxlQUFlO0FBQ2pCLGFBQU8sUUFBUTtBQUFBLElBQ2pCO0FBRUEsUUFBSTtBQUNGLFlBQU0sWUFBWSxNQUFNLGlCQUFpQixXQUFXLFFBQVEsWUFBWTtBQUN4RSxZQUFNLHVCQUF1QixrQkFBa0IsVUFBVSxXQUFXO0FBQ3BFLFlBQU0sY0FBMEI7QUFBQSxRQUM5QixHQUFHO0FBQUEsUUFDSCxhQUFhLFVBQVU7QUFBQSxRQUN2QixjQUFjLFVBQVU7QUFBQSxRQUN4QjtBQUFBLE1BQUE7QUFFRixZQUFNLEtBQUssUUFBUSxjQUFjLFdBQVc7QUFDNUMsYUFBTyxVQUFVO0FBQUEsSUFDbkIsUUFBUTtBQUNOLFlBQU0sS0FBSyxRQUFRLGdCQUFBO0FBQ25CLFlBQU0sSUFBSSxNQUFNLGlCQUFpQjtBQUFBLElBQ25DO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBTSxRQUFRO0FBQ1osVUFBTSxjQUFjLE1BQU0sS0FBSyxvQkFBQTtBQUMvQixVQUFNLEtBQUssTUFBTSxNQUFNLFdBQVcsV0FBVztBQUM3QyxVQUFNLEtBQUssUUFBUSxjQUFjLEdBQUcsT0FBTztBQUMzQyxVQUFNLEtBQUssUUFBUSw0QkFBNEIsR0FBRyxxQkFBcUI7QUFDdkUsVUFBTSxLQUFLLFFBQVEsc0JBQXNCLEdBQUcsZUFBZTtBQUMzRCxVQUFNLEtBQUssUUFBUSxjQUFjLEdBQUcsT0FBTztBQUUzQyxVQUFNLFdBQVcsTUFBTSxLQUFLLFFBQVEsdUJBQUE7QUFDcEMsUUFBSSxDQUFDLFlBQVksR0FBRyxRQUFRLFNBQVMsR0FBRztBQUN0QyxZQUFNLEtBQUssUUFBUTtBQUFBLFFBQ2pCLEdBQUcsUUFBUSxDQUFDLEdBQUcsWUFBWTtBQUFBLE1BQUE7QUFBQSxJQUUvQjtBQUVBLFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFNLGdCQUFnQjtBQUNwQixVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU8sY0FBYyxXQUFXLFdBQVc7QUFBQSxFQUM3QztBQUFBLEVBRUEsTUFBTSxhQUFhLFNBQThCO0FBQy9DLFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyxhQUFhLFdBQVcsYUFBYSxPQUFPO0FBQUEsRUFDckQ7QUFBQSxFQUVBLE1BQU0sa0JBQ0osVUFDQSxTQUNBO0FBQ0EsVUFBTSxjQUFjLE1BQU0sS0FBSyxvQkFBQTtBQUMvQixXQUFPLG9CQUFvQixXQUFXLGFBQWEsVUFBVSxPQUFPO0FBQUEsRUFDdEU7QUFBQSxFQUVBLE1BQU0saUJBQWlCLFVBQWtCLFNBQThCO0FBQ3JFLFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyxtQkFBbUIsV0FBVyxhQUFhLFVBQVUsT0FBTztBQUFBLEVBQ3JFO0FBQUEsRUFFQSxNQUFNLG9CQUNKLFVBQ0EsU0FDQTtBQUNBLFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyxzQkFBc0IsV0FBVyxhQUFhLFVBQVUsT0FBTztBQUFBLEVBQ3hFO0FBQUEsRUFFQSxNQUFNLG1CQUFtQixVQUFrQixTQUE4QjtBQUN2RSxVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU8scUJBQXFCLFdBQVcsYUFBYSxVQUFVLE9BQU87QUFBQSxFQUN2RTtBQUFBLEVBRUEsTUFBTSwwQkFDSixVQUNBLFNBQ0E7QUFDQSxVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU8sMEJBQTBCLFdBQVcsYUFBYSxVQUFVLE9BQU87QUFBQSxFQUM1RTtBQUFBLEVBRUEsTUFBTSx5QkFDSixVQUNBLFNBQ0E7QUFDQSxVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU8seUJBQXlCLFdBQVcsYUFBYSxVQUFVLE9BQU87QUFBQSxFQUMzRTtBQUFBLEVBRUEsTUFBTSxrQkFBa0IsVUFBa0I7QUFDeEMsVUFBTSxjQUFjLE1BQU0sS0FBSyxvQkFBQTtBQUMvQixXQUFPLGtCQUFrQixXQUFXLGFBQWEsUUFBUTtBQUFBLEVBQzNEO0FBQUEsRUFFQSxNQUFNLG9CQUNKLFVBQ0EsUUFDQTtBQUNBLFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyxvQkFBb0IsV0FBVyxhQUFhLFVBQVUsTUFBTTtBQUFBLEVBQ3JFO0FBQUEsRUFFQSxNQUFNLGlCQUFpQixhQUFxQjtBQUMxQyxVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU8saUJBQWlCLFdBQVcsYUFBYSxXQUFXO0FBQUEsRUFDN0Q7QUFBQSxFQUVBLE1BQU0sb0JBQW9CLGFBQXFCO0FBQzdDLFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyxvQkFBb0IsV0FBVyxhQUFhLFdBQVc7QUFBQSxFQUNoRTtBQUFBLEVBRUEsTUFBTSxrQkFBa0I7QUFDdEIsVUFBTSxjQUFjLE1BQU0sS0FBSyxvQkFBQTtBQUMvQixXQUFPLGVBQWUsV0FBVyxXQUFXO0FBQUEsRUFDOUM7QUFBQSxFQUVBLE1BQU0sa0JBQWtCLFNBQW1DO0FBQ3pELFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyx1QkFBdUIsV0FBVyxhQUFhLE9BQU87QUFBQSxFQUMvRDtBQUFBLEVBRUEsTUFBTSxrQkFBa0IsU0FBbUM7QUFDekQsVUFBTSxjQUFjLE1BQU0sS0FBSyxvQkFBQTtBQUMvQixXQUFPLHVCQUF1QixXQUFXLGFBQWEsT0FBTztBQUFBLEVBQy9EO0FBQUEsRUFFQSxNQUFNLHNCQUFzQixTQUF1QztBQUNqRSxVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU8sc0JBQXNCLFdBQVcsYUFBYSxPQUFPO0FBQUEsRUFDOUQ7QUFBQSxFQUVBLE1BQU0sc0JBQXNCLGNBQXNCO0FBQ2hELFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyxzQkFBc0IsV0FBVyxhQUFhLFlBQVk7QUFBQSxFQUNuRTtBQUFBLEVBRUEsTUFBTSxxQkFBcUIsY0FBc0I7QUFDL0MsVUFBTSxjQUFjLE1BQU0sS0FBSyxvQkFBQTtBQUMvQixXQUFPLHFCQUFxQixXQUFXLGFBQWEsWUFBWTtBQUFBLEVBQ2xFO0FBQUEsRUFFQSxNQUFNLHlCQUF5QixjQUFzQjtBQUNuRCxVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU8seUJBQXlCLFdBQVcsYUFBYSxZQUFZO0FBQUEsRUFDdEU7QUFBQSxFQUVBLE1BQU0sb0JBQW9CLFFBQW1DO0FBQzNELFVBQU0sY0FBYyxNQUFNLEtBQUssb0JBQUE7QUFDL0IsV0FBTyxvQkFBb0IsV0FBVyxhQUFhLE1BQU07QUFBQSxFQUMzRDtBQUFBLEVBRUEsTUFBTSw4QkFDSixjQUNBLFNBQ0E7QUFDQSxVQUFNLGNBQWMsTUFBTSxLQUFLLG9CQUFBO0FBQy9CLFdBQU87QUFBQSxNQUNMO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFBQTtBQUFBLEVBRUo7QUFDRjtBQy9QQSxRQUFRLElBQUksNENBQTRDO0FBQ3hELFFBQVE7QUFBQSxFQUNOO0FBQUEsRUFDQSxLQUFLLGNBQWMsUUFBUTtBQUM3QjtBQUdBLElBQUk7QUFFSixTQUFTLHlCQUF5QjtBQUNoQyxNQUFJLG1CQUFtQjtBQUNyQixrQkFBYyxpQkFBaUI7QUFBQSxFQUNqQztBQUNBLHNCQUFvQixZQUFZLE1BQU07QUFDcEMsWUFBUSxJQUFJLDhCQUE4QjtBQUFBLEVBQzVDLEdBQUcsR0FBSztBQUNWO0FBRUEsdUJBQUE7QUFFQSxLQUFLLGlCQUFpQixTQUFTLENBQUMsVUFBVTtBQUN4QyxVQUFRLE1BQU0sZ0NBQWdDLE1BQU0sS0FBSztBQUN6RCxVQUFRLE1BQU0sK0JBQStCLE1BQU0sT0FBTztBQUMxRCxVQUFRLE1BQU0sNkJBQTZCLE1BQU0sT0FBTyxLQUFLO0FBQzdELFVBQVE7QUFBQSxJQUNOO0FBQUEsSUFDQSxNQUFNO0FBQUEsSUFDTixNQUFNO0FBQUEsSUFDTixNQUFNO0FBQUEsRUFBQTtBQUVWLENBQUM7QUFFRCxLQUFLLGlCQUFpQixzQkFBc0IsQ0FBQyxVQUFVO0FBQ3JELFVBQVEsTUFBTSw2Q0FBNkMsTUFBTSxNQUFNO0FBQ3ZFLFVBQVEsTUFBTSxpQ0FBaUMsTUFBTSxRQUFRLEtBQUs7QUFDbEUsVUFBUSxNQUFNLHlCQUF5QixNQUFNLE9BQU87QUFDdEQsQ0FBQztBQUdELE1BQU0sVUFBVSxJQUFJLGVBQUE7QUFDcEIsTUFBTSxnQkFBZ0IsSUFBSSxjQUFjLE9BQU87QUFDL0MsTUFBTSxpQkFBaUIsSUFBSSxlQUFlLFNBQVMsYUFBYTtBQUVoRSxlQUFlLHNCQUFzQjtBQUNuQyxVQUFRLElBQUksd0NBQXdDO0FBQ3BELFFBQU0sUUFBUSxJQUFJLENBQUMsUUFBUSxjQUFjLG9CQUFBLENBQXFCLENBQUM7QUFDL0QsVUFBUSxJQUFJLG9DQUFvQztBQUNsRDtBQUVBLE9BQU8sUUFBUSxZQUFZLFlBQVksWUFBWTtBQUNqRCxVQUFRLElBQUksa0NBQWtDO0FBQzlDLFFBQU0sb0JBQUE7QUFDUixDQUFDO0FBTUQsT0FBTyxRQUFRLFVBQVU7QUFBQSxFQUN2QixDQUNFLFNBQ0EsUUFDQSxpQkFDRztBQUNILFlBQVEsSUFBSSxrQ0FBa0MsUUFBUSxJQUFJO0FBQzFELFlBQVE7QUFBQSxNQUNOO0FBQUEsTUFDQSxhQUFhLFVBQVUsUUFBUSxVQUFVO0FBQUEsSUFBQTtBQUUzQyxZQUFRLElBQUksd0JBQXdCLE9BQU8sS0FBSyxNQUFNLFNBQVMsT0FBTyxHQUFHO0FBRXpFLFFBQUk7QUFDRixxQkFDRyxjQUFjLFNBQVMsTUFBTSxFQUM3QixLQUFLLENBQUMsYUFBYTtBQUNsQixnQkFBUTtBQUFBLFVBQ047QUFBQSxVQUNBLFFBQVE7QUFBQSxRQUFBO0FBRVYscUJBQWEsRUFBRSxTQUFTLE1BQU0sTUFBTSxVQUFVO0FBQUEsTUFDaEQsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxVQUFVO0FBQ2hCLGdCQUFRLE1BQU0sdUNBQXVDLEtBQUs7QUFDMUQsZ0JBQVEsTUFBTSw0QkFBNEIsTUFBTSxZQUFZLElBQUk7QUFDaEUsZ0JBQVEsTUFBTSwrQkFBK0IsTUFBTSxPQUFPO0FBQzFELGdCQUFRLE1BQU0sNkJBQTZCLE1BQU0sS0FBSztBQUV0RCxxQkFBYTtBQUFBLFVBQ1gsU0FBUztBQUFBLFVBQ1QsT0FBTyxNQUFNLFdBQVc7QUFBQSxRQUFBLENBQ3pCO0FBQUEsTUFDSCxDQUFDO0FBQUEsSUFDTCxTQUFTLE9BQU87QUFDZCxjQUFRO0FBQUEsUUFDTjtBQUFBLFFBQ0E7QUFBQSxNQUFBO0FBRUYsbUJBQWE7QUFBQSxRQUNYLFNBQVM7QUFBQSxRQUNULE9BQU8saUJBQWlCLFFBQVEsTUFBTSxVQUFVO0FBQUEsTUFBQSxDQUNqRDtBQUFBLElBQ0g7QUFFQSxXQUFPO0FBQUEsRUFDVDtBQUNGO0FBRUEsT0FBTyxRQUFRLFVBQVUsWUFBWSxZQUFZO0FBQy9DLFVBQVEsSUFBSSxtREFBbUQ7QUFDL0QsUUFBTSxvQkFBQTtBQUNSLENBQUM7In0=
