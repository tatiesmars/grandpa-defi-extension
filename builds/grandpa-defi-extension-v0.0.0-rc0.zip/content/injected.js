console.log("[Injected] Grandpa DeFi provider initializing");
const FALLBACK_CHAIN_ID_HEX = "0x14a34";
const EIP6963_ANNOUNCE_EVENT = "eip6963:announceProvider";
const EIP6963_REQUEST_EVENT = "eip6963:requestProvider";
const NATIVE_OLD_MAN_LOGO_SVG = `
<svg width="800" height="800" viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg" role="img" aria-labelledby="title">
  <title id="title">Old man icon</title>
  <g id="old-man" fill="none" fill-rule="evenodd">
    <path d="M53,62H13V52.409a9.784,9.784,0,0,1,6.049-8.948L33,37.5l13.951,5.961A9.784,9.784,0,0,1,53,52.409Z" fill="#D9F0E8" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <line x1="22" y1="58" x2="22" y2="53" fill="none" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <polygon points="38 46 33 50 28 46 28 34 38 34 38 46" fill="#D9F0E8" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <line x1="44" y1="58" x2="44" y2="53" fill="none" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <path d="M46.539,20.891V18.318C46.539,11.515,41.617,6,35.546,6H30.954c-6.071,0-10.993,5.515-10.993,12.318v2.573A2.634,2.634,0,0,0,17.5,23.749a2.9,2.9,0,0,0,1.165,2.173,2,2,0,0,0,2.075.329,14.856,14.856,0,0,0,9.21,11.524,13.062,13.062,0,0,0,6.187-.05l.437-.158a14.839,14.839,0,0,0,9.148-11.328,2.042,2.042,0,0,0,2.06-.262A2.833,2.833,0,0,0,48.981,24,2.665,2.665,0,0,0,46.539,20.891Z" fill="#D5E1DB" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <line x1="30" y1="53" x2="36" y2="53" fill="none" stroke="#4B5E56" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <rect x="22" y="57" width="22" height="5" fill="#4B5E56" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <path d="M39,34.769a6,6,0,0,0-12,0C27,37.955,33,44,33,44S39,37.955,39,34.769Z" fill="#D9F0E8" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <line x1="38" y1="23" x2="28" y2="23" fill="none" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <circle cx="37.5" cy="24.5" r="3.5" fill="#006A52"/>
    <circle cx="28.5" cy="24.5" r="3.5" fill="#006A52"/>
    <line x1="29" y1="14" x2="37" y2="14" fill="none" stroke="#7B8D85" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <line x1="29" y1="17" x2="37" y2="17" fill="none" stroke="#7B8D85" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <path d="M30,35a3,3,0,0,0,3-3" fill="none" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
    <path d="M33,32a3,3,0,0,0,3,3" fill="none" stroke="#006A52" stroke-linecap="round" stroke-linejoin="round" stroke-width="2px"/>
  </g>
</svg>
`;
const EIP6963_ICON_DATA_URI = `data:image/svg+xml;utf8,${encodeURIComponent(
  NATIVE_OLD_MAN_LOGO_SVG.trim()
)}`;
const GRANDPA_PROVIDER_INFO = {
  uuid: "98095ab1-4df2-4b19-ab8a-b57ce524f92f",
  name: "Grandpa Wallet",
  icon: EIP6963_ICON_DATA_URI,
  rdns: "org.grandpa.wallet"
};
class GrandpaProvider {
  isGrandpa = true;
  isMetaMask = true;
  chainId = FALLBACK_CHAIN_ID_HEX;
  selectedAddress = null;
  providers = [this];
  // Legacy MetaMask compatibility shape
  _metamask = {
    isUnlocked: async () => this._connected
  };
  _accounts = [];
  _connected = false;
  _legacyRpcId = 0;
  _listeners = /* @__PURE__ */ new Map();
  request = async (args) => {
    console.log("[Provider] Request:", args.method, args.params);
    const { method, params } = args;
    switch (method) {
      case "eth_requestAccounts":
        return this._handleRequestAccounts();
      case "eth_accounts":
        return this._accounts;
      case "eth_chainId":
        return this._ensureChainId();
      case "net_version": {
        const chainId = await this._ensureChainId();
        return Number.parseInt(chainId, 16).toString(10);
      }
      case "eth_coinbase":
        return this.selectedAddress;
      case "eth_sendTransaction":
        return this._handleSendTransaction(params);
      case "personal_sign":
        return this._handlePersonalSign(params);
      case "eth_signTypedData_v4":
        return this._handleSignTypedData(params);
      case "wallet_switchEthereumChain":
        return this._handleSwitchChain(params);
      case "wallet_addEthereumChain":
        return this._handleAddChain();
      case "wallet_getPermissions":
        return this._handleGetPermissions();
      case "wallet_requestPermissions":
        return this._handleRequestPermissions(params);
      default:
        throw new Error(`Method ${method} not supported`);
    }
  };
  enable = () => {
    return this.request({ method: "eth_requestAccounts" });
  };
  isConnected = () => {
    return this._connected;
  };
  send = (methodOrPayload, paramsOrCallback) => {
    if (typeof methodOrPayload === "string") {
      const params = typeof paramsOrCallback === "function" ? void 0 : paramsOrCallback;
      return this.request({ method: methodOrPayload, params });
    }
    const payload = {
      method: methodOrPayload.method,
      params: methodOrPayload.params
    };
    const callback = typeof paramsOrCallback === "function" ? paramsOrCallback : null;
    const id = methodOrPayload.id ?? ++this._legacyRpcId;
    const promise = this.request(payload);
    if (!callback) {
      return promise;
    }
    promise.then((result) => {
      callback(null, { id, jsonrpc: "2.0", result });
    }).catch((error) => {
      const err = error instanceof Error ? error : new Error("Unknown provider error");
      callback(err, {
        id,
        jsonrpc: "2.0",
        error: { code: -32603, message: err.message }
      });
    });
  };
  sendAsync = (payload, callback) => {
    return this.send(payload, callback);
  };
  on = (event, listener) => {
    if (!this._listeners.has(event)) {
      this._listeners.set(event, /* @__PURE__ */ new Set());
    }
    this._listeners.get(event).add(listener);
  };
  removeListener = (event, listener) => {
    const listeners = this._listeners.get(event);
    if (listeners) {
      listeners.delete(listener);
    }
  };
  handleExternalDisconnect() {
    this._connected = false;
    this._accounts = [];
    this.selectedAddress = null;
    this._emit("accountsChanged", []);
    this._emit("disconnect");
  }
  _emit(event, ...args) {
    const listeners = this._listeners.get(event);
    if (listeners) {
      listeners.forEach((listener) => {
        try {
          listener(...args);
        } catch (error) {
          console.error("[Provider] Listener error:", error);
        }
      });
    }
  }
  async _sendToBackground(type, payload) {
    const id = Math.random().toString(36).substring(7);
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        window.removeEventListener("message", listener);
        reject(new Error("Request timeout"));
      }, 3e5);
      const listener = (event) => {
        if (event.data.target !== "grandpa-page") return;
        if (event.data.id !== id) return;
        clearTimeout(timeout);
        window.removeEventListener("message", listener);
        if (event.data.error) {
          reject(new Error(event.data.error));
        } else {
          resolve(event.data.response);
        }
      };
      window.addEventListener("message", listener);
      window.postMessage(
        {
          target: "grandpa-content",
          id,
          payload: { type, payload }
        },
        "*"
      );
    });
  }
  async _handleRequestAccounts() {
    if (this._connected && this._accounts.length > 0) {
      return this._accounts;
    }
    const response = await this._sendToBackground("CONNECT_SITE", {
      origin: window.location.origin
    });
    if (response.connected) {
      await this._ensureChainId();
      this._connected = true;
      this._accounts = response.accounts;
      this.selectedAddress = response.accounts[0] ?? null;
      this._emit("connect", { chainId: this.chainId });
      this._emit("accountsChanged", this._accounts);
      return this._accounts;
    }
    throw new Error("User rejected connection");
  }
  async _handleSendTransaction(params) {
    if (!this._connected) {
      throw new Error("Not connected. Call eth_requestAccounts first.");
    }
    const txParams = Array.isArray(params) && params.length > 0 ? params[0] : params;
    if (!txParams || !txParams.to) {
      throw new Error("Invalid transaction parameters");
    }
    const txHash = await this._sendToBackground("SEND_TRANSACTION", {
      to: txParams.to,
      value: txParams.value || "0x0",
      data: txParams.data || "0x"
    });
    return txHash;
  }
  _isHexAddress(value) {
    return /^0x[a-fA-F0-9]{40}$/.test(value);
  }
  _parsePersonalSignParams(params) {
    if (Array.isArray(params)) {
      const first = params[0];
      const second = params[1];
      if (typeof first !== "string") {
        throw new Error("Invalid personal_sign params");
      }
      if (typeof second !== "string") {
        return { message: first };
      }
      const firstIsAddress = this._isHexAddress(first);
      const secondIsAddress = this._isHexAddress(second);
      if (secondIsAddress) {
        return { message: first, address: second };
      }
      if (firstIsAddress) {
        return { message: second, address: first };
      }
      return { message: first };
    }
    if (params && typeof params === "object") {
      const objectParams = params;
      const message = typeof objectParams.data === "string" ? objectParams.data : typeof objectParams.message === "string" ? objectParams.message : null;
      if (!message) {
        throw new Error("Invalid personal_sign params");
      }
      if (typeof objectParams.from === "string" && this._isHexAddress(objectParams.from)) {
        return { message, address: objectParams.from };
      }
      return { message };
    }
    throw new Error("Invalid personal_sign params");
  }
  async _handlePersonalSign(params) {
    if (!this._connected) {
      throw new Error("Not connected. Call eth_requestAccounts first.");
    }
    const parsed = this._parsePersonalSignParams(params);
    const expectedAddress = this.selectedAddress;
    if (parsed.address && expectedAddress) {
      if (parsed.address.toLowerCase() !== expectedAddress.toLowerCase()) {
        throw new Error("Requested account does not match connected account");
      }
    }
    const addressForRequest = parsed.address ?? (expectedAddress && this._isHexAddress(expectedAddress) ? expectedAddress : void 0);
    const signature = await this._sendToBackground("SIGN_MESSAGE", {
      message: parsed.message,
      address: addressForRequest
    });
    return signature;
  }
  async _handleSignTypedData(_params) {
    if (!this._connected) {
      throw new Error("Not connected. Call eth_requestAccounts first.");
    }
    throw new Error("eth_signTypedData_v4 is not supported yet");
  }
  async _handleSwitchChain(params) {
    const chainId = Array.isArray(params) ? params[0] : params;
    const current = await this._ensureChainId();
    if (chainId?.chainId !== current) {
      throw new Error(
        `Chain not supported. Only chainId ${current} is supported.`
      );
    }
    return null;
  }
  async _handleAddChain() {
    throw new Error("Adding chains not supported in MVP");
  }
  _handleGetPermissions() {
    if (!this._connected) {
      return [];
    }
    return [{ parentCapability: "eth_accounts" }];
  }
  async _handleRequestPermissions(params) {
    const request = Array.isArray(params) ? params[0] : void 0;
    const wantsAccounts = typeof request === "object" && request !== null && Object.prototype.hasOwnProperty.call(request, "eth_accounts");
    if (!wantsAccounts) {
      throw new Error("Only eth_accounts permission is supported");
    }
    await this._handleRequestAccounts();
    return [{ parentCapability: "eth_accounts" }];
  }
  async _ensureChainId() {
    try {
      const stored = await this._sendToBackground("API_GET_CHAIN_ID", {});
      if (typeof stored === "number" && stored > 0) {
        const nextChainId = `0x${stored.toString(16)}`;
        if (nextChainId !== this.chainId) {
          this.chainId = nextChainId;
          this._emit("chainChanged", this.chainId);
        }
      }
    } catch (error) {
      console.warn("[Provider] Failed to resolve chainId:", error);
    }
    return this.chainId;
  }
}
function getOrCreateProvidersList(existing2) {
  if (Array.isArray(existing2.providers)) {
    return existing2.providers;
  }
  return [existing2];
}
function hasGrandpaProvider(providers) {
  return providers.some(
    (provider) => typeof provider === "object" && provider !== null && provider.isGrandpa === true
  );
}
function announceEip6963Provider(provider) {
  const detail = {
    info: GRANDPA_PROVIDER_INFO,
    provider
  };
  window.dispatchEvent(
    new CustomEvent(EIP6963_ANNOUNCE_EVENT, { detail })
  );
}
const grandpaProvider = new GrandpaProvider();
const existing = window.ethereum ?? null;
if (!existing) {
  window.ethereum = grandpaProvider;
  console.log("[Injected] Provider injected as window.ethereum");
} else {
  const providers = getOrCreateProvidersList(existing);
  if (!hasGrandpaProvider(providers)) {
    providers.push(grandpaProvider);
    existing.providers = providers;
    console.log(
      "[Injected] Grandpa provider added to window.ethereum.providers"
    );
  } else {
    console.log("[Injected] Grandpa provider already present");
  }
}
window.addEventListener(EIP6963_REQUEST_EVENT, () => {
  announceEip6963Provider(grandpaProvider);
});
announceEip6963Provider(grandpaProvider);
setTimeout(() => announceEip6963Provider(grandpaProvider), 0);
window.addEventListener("message", (event) => {
  if (event.data.target === "grandpa-page" && event.data.type === "disconnect") {
    grandpaProvider.handleExternalDisconnect();
  }
});
window.dispatchEvent(new Event("ethereum#initialized"));
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5qZWN0ZWQuanMiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9jb250ZW50L2luamVjdGVkLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIEluamVjdGVkIFByb3ZpZGVyIC0gUnVucyBpbiBwYWdlIGNvbnRleHQsIHByb3ZpZGVzIHdpbmRvdy5ldGhlcmV1bVxuXG5jb25zb2xlLmxvZyhcIltJbmplY3RlZF0gR3JhbmRwYSBEZUZpIHByb3ZpZGVyIGluaXRpYWxpemluZ1wiKTtcblxuY29uc3QgRkFMTEJBQ0tfQ0hBSU5fSURfSEVYID0gXCIweDE0YTM0XCI7IC8vIEJhc2UgU2Vwb2xpYVxuY29uc3QgRUlQNjk2M19BTk5PVU5DRV9FVkVOVCA9IFwiZWlwNjk2Mzphbm5vdW5jZVByb3ZpZGVyXCI7XG5jb25zdCBFSVA2OTYzX1JFUVVFU1RfRVZFTlQgPSBcImVpcDY5NjM6cmVxdWVzdFByb3ZpZGVyXCI7XG5cbmludGVyZmFjZSBSZXF1ZXN0QXJndW1lbnRzIHtcbiAgbWV0aG9kOiBzdHJpbmc7XG4gIHBhcmFtcz86IHVua25vd25bXSB8IFJlY29yZDxzdHJpbmcsIHVua25vd24+O1xufVxuXG5pbnRlcmZhY2UgTGVnYWN5UnBjUGF5bG9hZCB7XG4gIGlkPzogbnVtYmVyO1xuICBqc29ucnBjPzogc3RyaW5nO1xuICBtZXRob2Q6IHN0cmluZztcbiAgcGFyYW1zPzogdW5rbm93bltdIHwgUmVjb3JkPHN0cmluZywgdW5rbm93bj47XG59XG5cbmludGVyZmFjZSBMZWdhY3lScGNSZXNwb25zZSB7XG4gIGlkOiBudW1iZXI7XG4gIGpzb25ycGM6IFwiMi4wXCI7XG4gIHJlc3VsdD86IHVua25vd247XG4gIGVycm9yPzogeyBjb2RlOiBudW1iZXI7IG1lc3NhZ2U6IHN0cmluZyB9O1xufVxuXG50eXBlIExlZ2FjeVJwY0NhbGxiYWNrID0gKFxuICBlcnJvcjogRXJyb3IgfCBudWxsLFxuICByZXNwb25zZTogTGVnYWN5UnBjUmVzcG9uc2UsXG4pID0+IHZvaWQ7XG5cbmludGVyZmFjZSBHcmFuZHBhRXRoZXJldW1MaWtlIHtcbiAgaXNHcmFuZHBhPzogYm9vbGVhbjtcbiAgcHJvdmlkZXJzPzogdW5rbm93bltdO1xufVxuXG5pbnRlcmZhY2UgRWlwNjk2M1Byb3ZpZGVySW5mbyB7XG4gIHV1aWQ6IHN0cmluZztcbiAgbmFtZTogc3RyaW5nO1xuICBpY29uOiBzdHJpbmc7XG4gIHJkbnM6IHN0cmluZztcbn1cblxuaW50ZXJmYWNlIEVpcDY5NjNBbm5vdW5jZURldGFpbCB7XG4gIGluZm86IEVpcDY5NjNQcm92aWRlckluZm87XG4gIHByb3ZpZGVyOiBHcmFuZHBhUHJvdmlkZXI7XG59XG5cbmludGVyZmFjZSBXYWxsZXRQZXJtaXNzaW9uIHtcbiAgcGFyZW50Q2FwYWJpbGl0eTogXCJldGhfYWNjb3VudHNcIjtcbn1cblxuLy8gS2VlcCB0aGlzIFNWRyBhbGlnbmVkIHdpdGggYXBwcy9uYXRpdmUvY29tcG9uZW50cy9icmFuZC9PbGRNYW5Mb2dvLnRzeCAoTElHSFRfTE9HT19TVkcpLlxuY29uc3QgTkFUSVZFX09MRF9NQU5fTE9HT19TVkcgPSBgXG48c3ZnIHdpZHRoPVwiODAwXCIgaGVpZ2h0PVwiODAwXCIgdmlld0JveD1cIjAgMCA2NCA2NFwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiByb2xlPVwiaW1nXCIgYXJpYS1sYWJlbGxlZGJ5PVwidGl0bGVcIj5cbiAgPHRpdGxlIGlkPVwidGl0bGVcIj5PbGQgbWFuIGljb248L3RpdGxlPlxuICA8ZyBpZD1cIm9sZC1tYW5cIiBmaWxsPVwibm9uZVwiIGZpbGwtcnVsZT1cImV2ZW5vZGRcIj5cbiAgICA8cGF0aCBkPVwiTTUzLDYySDEzVjUyLjQwOWE5Ljc4NCw5Ljc4NCwwLDAsMSw2LjA0OS04Ljk0OEwzMywzNy41bDEzLjk1MSw1Ljk2MUE5Ljc4NCw5Ljc4NCwwLDAsMSw1Myw1Mi40MDlaXCIgZmlsbD1cIiNEOUYwRThcIiBzdHJva2U9XCIjMDA2QTUyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlLXdpZHRoPVwiMnB4XCIvPlxuICAgIDxsaW5lIHgxPVwiMjJcIiB5MT1cIjU4XCIgeDI9XCIyMlwiIHkyPVwiNTNcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cIiMwMDZBNTJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBzdHJva2Utd2lkdGg9XCIycHhcIi8+XG4gICAgPHBvbHlnb24gcG9pbnRzPVwiMzggNDYgMzMgNTAgMjggNDYgMjggMzQgMzggMzQgMzggNDZcIiBmaWxsPVwiI0Q5RjBFOFwiIHN0cm9rZT1cIiMwMDZBNTJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBzdHJva2Utd2lkdGg9XCIycHhcIi8+XG4gICAgPGxpbmUgeDE9XCI0NFwiIHkxPVwiNThcIiB4Mj1cIjQ0XCIgeTI9XCI1M1wiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiIzAwNkE1MlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZS13aWR0aD1cIjJweFwiLz5cbiAgICA8cGF0aCBkPVwiTTQ2LjUzOSwyMC44OTFWMTguMzE4QzQ2LjUzOSwxMS41MTUsNDEuNjE3LDYsMzUuNTQ2LDZIMzAuOTU0Yy02LjA3MSwwLTEwLjk5Myw1LjUxNS0xMC45OTMsMTIuMzE4djIuNTczQTIuNjM0LDIuNjM0LDAsMCwwLDE3LjUsMjMuNzQ5YTIuOSwyLjksMCwwLDAsMS4xNjUsMi4xNzMsMiwyLDAsMCwwLDIuMDc1LjMyOSwxNC44NTYsMTQuODU2LDAsMCwwLDkuMjEsMTEuNTI0LDEzLjA2MiwxMy4wNjIsMCwwLDAsNi4xODctLjA1bC40MzctLjE1OGExNC44MzksMTQuODM5LDAsMCwwLDkuMTQ4LTExLjMyOCwyLjA0MiwyLjA0MiwwLDAsMCwyLjA2LS4yNjJBMi44MzMsMi44MzMsMCwwLDAsNDguOTgxLDI0LDIuNjY1LDIuNjY1LDAsMCwwLDQ2LjUzOSwyMC44OTFaXCIgZmlsbD1cIiNENUUxREJcIiBzdHJva2U9XCIjMDA2QTUyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlLXdpZHRoPVwiMnB4XCIvPlxuICAgIDxsaW5lIHgxPVwiMzBcIiB5MT1cIjUzXCIgeDI9XCIzNlwiIHkyPVwiNTNcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cIiM0QjVFNTZcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBzdHJva2Utd2lkdGg9XCIycHhcIi8+XG4gICAgPHJlY3QgeD1cIjIyXCIgeT1cIjU3XCIgd2lkdGg9XCIyMlwiIGhlaWdodD1cIjVcIiBmaWxsPVwiIzRCNUU1NlwiIHN0cm9rZT1cIiMwMDZBNTJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBzdHJva2Utd2lkdGg9XCIycHhcIi8+XG4gICAgPHBhdGggZD1cIk0zOSwzNC43NjlhNiw2LDAsMCwwLTEyLDBDMjcsMzcuOTU1LDMzLDQ0LDMzLDQ0UzM5LDM3Ljk1NSwzOSwzNC43NjlaXCIgZmlsbD1cIiNEOUYwRThcIiBzdHJva2U9XCIjMDA2QTUyXCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlLXdpZHRoPVwiMnB4XCIvPlxuICAgIDxsaW5lIHgxPVwiMzhcIiB5MT1cIjIzXCIgeDI9XCIyOFwiIHkyPVwiMjNcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cIiMwMDZBNTJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBzdHJva2Utd2lkdGg9XCIycHhcIi8+XG4gICAgPGNpcmNsZSBjeD1cIjM3LjVcIiBjeT1cIjI0LjVcIiByPVwiMy41XCIgZmlsbD1cIiMwMDZBNTJcIi8+XG4gICAgPGNpcmNsZSBjeD1cIjI4LjVcIiBjeT1cIjI0LjVcIiByPVwiMy41XCIgZmlsbD1cIiMwMDZBNTJcIi8+XG4gICAgPGxpbmUgeDE9XCIyOVwiIHkxPVwiMTRcIiB4Mj1cIjM3XCIgeTI9XCIxNFwiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiIzdCOEQ4NVwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZS13aWR0aD1cIjJweFwiLz5cbiAgICA8bGluZSB4MT1cIjI5XCIgeTE9XCIxN1wiIHgyPVwiMzdcIiB5Mj1cIjE3XCIgZmlsbD1cIm5vbmVcIiBzdHJva2U9XCIjN0I4RDg1XCIgc3Ryb2tlLWxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZS1saW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlLXdpZHRoPVwiMnB4XCIvPlxuICAgIDxwYXRoIGQ9XCJNMzAsMzVhMywzLDAsMCwwLDMtM1wiIGZpbGw9XCJub25lXCIgc3Ryb2tlPVwiIzAwNkE1MlwiIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZS13aWR0aD1cIjJweFwiLz5cbiAgICA8cGF0aCBkPVwiTTMzLDMyYTMsMywwLDAsMCwzLDNcIiBmaWxsPVwibm9uZVwiIHN0cm9rZT1cIiMwMDZBNTJcIiBzdHJva2UtbGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlLWxpbmVqb2luPVwicm91bmRcIiBzdHJva2Utd2lkdGg9XCIycHhcIi8+XG4gIDwvZz5cbjwvc3ZnPlxuYDtcblxuY29uc3QgRUlQNjk2M19JQ09OX0RBVEFfVVJJID0gYGRhdGE6aW1hZ2Uvc3ZnK3htbDt1dGY4LCR7ZW5jb2RlVVJJQ29tcG9uZW50KFxuICBOQVRJVkVfT0xEX01BTl9MT0dPX1NWRy50cmltKCksXG4pfWA7XG5cbmNvbnN0IEdSQU5EUEFfUFJPVklERVJfSU5GTzogRWlwNjk2M1Byb3ZpZGVySW5mbyA9IHtcbiAgdXVpZDogXCI5ODA5NWFiMS00ZGYyLTRiMTktYWI4YS1iNTdjZTUyNGY5MmZcIixcbiAgbmFtZTogXCJHcmFuZHBhIFdhbGxldFwiLFxuICBpY29uOiBFSVA2OTYzX0lDT05fREFUQV9VUkksXG4gIHJkbnM6IFwib3JnLmdyYW5kcGEud2FsbGV0XCIsXG59O1xuXG5jbGFzcyBHcmFuZHBhUHJvdmlkZXIge1xuICBwdWJsaWMgaXNHcmFuZHBhID0gdHJ1ZTtcbiAgcHVibGljIGlzTWV0YU1hc2sgPSB0cnVlO1xuICBwdWJsaWMgY2hhaW5JZCA9IEZBTExCQUNLX0NIQUlOX0lEX0hFWDtcbiAgcHVibGljIHNlbGVjdGVkQWRkcmVzczogc3RyaW5nIHwgbnVsbCA9IG51bGw7XG4gIHB1YmxpYyBwcm92aWRlcnM6IEdyYW5kcGFQcm92aWRlcltdID0gW3RoaXNdO1xuXG4gIC8vIExlZ2FjeSBNZXRhTWFzayBjb21wYXRpYmlsaXR5IHNoYXBlXG4gIHB1YmxpYyBfbWV0YW1hc2sgPSB7XG4gICAgaXNVbmxvY2tlZDogYXN5bmMgKCkgPT4gdGhpcy5fY29ubmVjdGVkLFxuICB9O1xuXG4gIHByaXZhdGUgX2FjY291bnRzOiBzdHJpbmdbXSA9IFtdO1xuICBwcml2YXRlIF9jb25uZWN0ZWQgPSBmYWxzZTtcbiAgcHJpdmF0ZSBfbGVnYWN5UnBjSWQgPSAwO1xuICBwcml2YXRlIF9saXN0ZW5lcnM6IE1hcDxzdHJpbmcsIFNldDwoLi4uYXJnczogdW5rbm93bltdKSA9PiB2b2lkPj4gPVxuICAgIG5ldyBNYXAoKTtcblxuICByZXF1ZXN0ID0gYXN5bmMgKGFyZ3M6IFJlcXVlc3RBcmd1bWVudHMpOiBQcm9taXNlPHVua25vd24+ID0+IHtcbiAgICBjb25zb2xlLmxvZyhcIltQcm92aWRlcl0gUmVxdWVzdDpcIiwgYXJncy5tZXRob2QsIGFyZ3MucGFyYW1zKTtcblxuICAgIGNvbnN0IHsgbWV0aG9kLCBwYXJhbXMgfSA9IGFyZ3M7XG5cbiAgICBzd2l0Y2ggKG1ldGhvZCkge1xuICAgICAgY2FzZSBcImV0aF9yZXF1ZXN0QWNjb3VudHNcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuX2hhbmRsZVJlcXVlc3RBY2NvdW50cygpO1xuXG4gICAgICBjYXNlIFwiZXRoX2FjY291bnRzXCI6XG4gICAgICAgIHJldHVybiB0aGlzLl9hY2NvdW50cztcblxuICAgICAgY2FzZSBcImV0aF9jaGFpbklkXCI6XG4gICAgICAgIHJldHVybiB0aGlzLl9lbnN1cmVDaGFpbklkKCk7XG5cbiAgICAgIGNhc2UgXCJuZXRfdmVyc2lvblwiOiB7XG4gICAgICAgIGNvbnN0IGNoYWluSWQgPSBhd2FpdCB0aGlzLl9lbnN1cmVDaGFpbklkKCk7XG4gICAgICAgIHJldHVybiBOdW1iZXIucGFyc2VJbnQoY2hhaW5JZCwgMTYpLnRvU3RyaW5nKDEwKTtcbiAgICAgIH1cblxuICAgICAgY2FzZSBcImV0aF9jb2luYmFzZVwiOlxuICAgICAgICByZXR1cm4gdGhpcy5zZWxlY3RlZEFkZHJlc3M7XG5cbiAgICAgIGNhc2UgXCJldGhfc2VuZFRyYW5zYWN0aW9uXCI6XG4gICAgICAgIHJldHVybiB0aGlzLl9oYW5kbGVTZW5kVHJhbnNhY3Rpb24ocGFyYW1zKTtcblxuICAgICAgY2FzZSBcInBlcnNvbmFsX3NpZ25cIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuX2hhbmRsZVBlcnNvbmFsU2lnbihwYXJhbXMpO1xuXG4gICAgICBjYXNlIFwiZXRoX3NpZ25UeXBlZERhdGFfdjRcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuX2hhbmRsZVNpZ25UeXBlZERhdGEocGFyYW1zKTtcblxuICAgICAgY2FzZSBcIndhbGxldF9zd2l0Y2hFdGhlcmV1bUNoYWluXCI6XG4gICAgICAgIHJldHVybiB0aGlzLl9oYW5kbGVTd2l0Y2hDaGFpbihwYXJhbXMpO1xuXG4gICAgICBjYXNlIFwid2FsbGV0X2FkZEV0aGVyZXVtQ2hhaW5cIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuX2hhbmRsZUFkZENoYWluKCk7XG5cbiAgICAgIGNhc2UgXCJ3YWxsZXRfZ2V0UGVybWlzc2lvbnNcIjpcbiAgICAgICAgcmV0dXJuIHRoaXMuX2hhbmRsZUdldFBlcm1pc3Npb25zKCk7XG5cbiAgICAgIGNhc2UgXCJ3YWxsZXRfcmVxdWVzdFBlcm1pc3Npb25zXCI6XG4gICAgICAgIHJldHVybiB0aGlzLl9oYW5kbGVSZXF1ZXN0UGVybWlzc2lvbnMocGFyYW1zKTtcblxuICAgICAgZGVmYXVsdDpcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBNZXRob2QgJHttZXRob2R9IG5vdCBzdXBwb3J0ZWRgKTtcbiAgICB9XG4gIH07XG5cbiAgZW5hYmxlID0gKCk6IFByb21pc2U8c3RyaW5nW10+ID0+IHtcbiAgICByZXR1cm4gdGhpcy5yZXF1ZXN0KHsgbWV0aG9kOiBcImV0aF9yZXF1ZXN0QWNjb3VudHNcIiB9KSBhcyBQcm9taXNlPHN0cmluZ1tdPjtcbiAgfTtcblxuICBpc0Nvbm5lY3RlZCA9ICgpOiBib29sZWFuID0+IHtcbiAgICByZXR1cm4gdGhpcy5fY29ubmVjdGVkO1xuICB9O1xuXG4gIHNlbmQgPSAoXG4gICAgbWV0aG9kT3JQYXlsb2FkOiBzdHJpbmcgfCBMZWdhY3lScGNQYXlsb2FkLFxuICAgIHBhcmFtc09yQ2FsbGJhY2s/OiB1bmtub3duW10gfCBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IExlZ2FjeVJwY0NhbGxiYWNrLFxuICApOiBQcm9taXNlPHVua25vd24+IHwgdm9pZCA9PiB7XG4gICAgaWYgKHR5cGVvZiBtZXRob2RPclBheWxvYWQgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgIGNvbnN0IHBhcmFtcyA9XG4gICAgICAgIHR5cGVvZiBwYXJhbXNPckNhbGxiYWNrID09PSBcImZ1bmN0aW9uXCIgPyB1bmRlZmluZWQgOiBwYXJhbXNPckNhbGxiYWNrO1xuICAgICAgcmV0dXJuIHRoaXMucmVxdWVzdCh7IG1ldGhvZDogbWV0aG9kT3JQYXlsb2FkLCBwYXJhbXMgfSk7XG4gICAgfVxuXG4gICAgY29uc3QgcGF5bG9hZDogUmVxdWVzdEFyZ3VtZW50cyA9IHtcbiAgICAgIG1ldGhvZDogbWV0aG9kT3JQYXlsb2FkLm1ldGhvZCxcbiAgICAgIHBhcmFtczogbWV0aG9kT3JQYXlsb2FkLnBhcmFtcyxcbiAgICB9O1xuICAgIGNvbnN0IGNhbGxiYWNrID1cbiAgICAgIHR5cGVvZiBwYXJhbXNPckNhbGxiYWNrID09PSBcImZ1bmN0aW9uXCIgPyBwYXJhbXNPckNhbGxiYWNrIDogbnVsbDtcbiAgICBjb25zdCBpZCA9IG1ldGhvZE9yUGF5bG9hZC5pZCA/PyArK3RoaXMuX2xlZ2FjeVJwY0lkO1xuICAgIGNvbnN0IHByb21pc2UgPSB0aGlzLnJlcXVlc3QocGF5bG9hZCk7XG5cbiAgICBpZiAoIWNhbGxiYWNrKSB7XG4gICAgICByZXR1cm4gcHJvbWlzZTtcbiAgICB9XG5cbiAgICBwcm9taXNlXG4gICAgICAudGhlbigocmVzdWx0KSA9PiB7XG4gICAgICAgIGNhbGxiYWNrKG51bGwsIHsgaWQsIGpzb25ycGM6IFwiMi4wXCIsIHJlc3VsdCB9KTtcbiAgICAgIH0pXG4gICAgICAuY2F0Y2goKGVycm9yKSA9PiB7XG4gICAgICAgIGNvbnN0IGVyciA9XG4gICAgICAgICAgZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yIDogbmV3IEVycm9yKFwiVW5rbm93biBwcm92aWRlciBlcnJvclwiKTtcbiAgICAgICAgY2FsbGJhY2soZXJyLCB7XG4gICAgICAgICAgaWQsXG4gICAgICAgICAganNvbnJwYzogXCIyLjBcIixcbiAgICAgICAgICBlcnJvcjogeyBjb2RlOiAtMzI2MDMsIG1lc3NhZ2U6IGVyci5tZXNzYWdlIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSk7XG4gIH07XG5cbiAgc2VuZEFzeW5jID0gKFxuICAgIHBheWxvYWQ6IExlZ2FjeVJwY1BheWxvYWQsXG4gICAgY2FsbGJhY2s6IExlZ2FjeVJwY0NhbGxiYWNrLFxuICApOiB2b2lkIHwgUHJvbWlzZTx1bmtub3duPiA9PiB7XG4gICAgcmV0dXJuIHRoaXMuc2VuZChwYXlsb2FkLCBjYWxsYmFjayk7XG4gIH07XG5cbiAgb24gPSAoZXZlbnQ6IHN0cmluZywgbGlzdGVuZXI6ICguLi5hcmdzOiB1bmtub3duW10pID0+IHZvaWQpOiB2b2lkID0+IHtcbiAgICBpZiAoIXRoaXMuX2xpc3RlbmVycy5oYXMoZXZlbnQpKSB7XG4gICAgICB0aGlzLl9saXN0ZW5lcnMuc2V0KGV2ZW50LCBuZXcgU2V0KCkpO1xuICAgIH1cbiAgICB0aGlzLl9saXN0ZW5lcnMuZ2V0KGV2ZW50KSEuYWRkKGxpc3RlbmVyKTtcbiAgfTtcblxuICByZW1vdmVMaXN0ZW5lciA9IChcbiAgICBldmVudDogc3RyaW5nLFxuICAgIGxpc3RlbmVyOiAoLi4uYXJnczogdW5rbm93bltdKSA9PiB2b2lkLFxuICApOiB2b2lkID0+IHtcbiAgICBjb25zdCBsaXN0ZW5lcnMgPSB0aGlzLl9saXN0ZW5lcnMuZ2V0KGV2ZW50KTtcbiAgICBpZiAobGlzdGVuZXJzKSB7XG4gICAgICBsaXN0ZW5lcnMuZGVsZXRlKGxpc3RlbmVyKTtcbiAgICB9XG4gIH07XG5cbiAgaGFuZGxlRXh0ZXJuYWxEaXNjb25uZWN0KCk6IHZvaWQge1xuICAgIHRoaXMuX2Nvbm5lY3RlZCA9IGZhbHNlO1xuICAgIHRoaXMuX2FjY291bnRzID0gW107XG4gICAgdGhpcy5zZWxlY3RlZEFkZHJlc3MgPSBudWxsO1xuICAgIHRoaXMuX2VtaXQoXCJhY2NvdW50c0NoYW5nZWRcIiwgW10pO1xuICAgIHRoaXMuX2VtaXQoXCJkaXNjb25uZWN0XCIpO1xuICB9XG5cbiAgcHJpdmF0ZSBfZW1pdChldmVudDogc3RyaW5nLCAuLi5hcmdzOiB1bmtub3duW10pOiB2b2lkIHtcbiAgICBjb25zdCBsaXN0ZW5lcnMgPSB0aGlzLl9saXN0ZW5lcnMuZ2V0KGV2ZW50KTtcbiAgICBpZiAobGlzdGVuZXJzKSB7XG4gICAgICBsaXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBsaXN0ZW5lciguLi5hcmdzKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICBjb25zb2xlLmVycm9yKFwiW1Byb3ZpZGVyXSBMaXN0ZW5lciBlcnJvcjpcIiwgZXJyb3IpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIF9zZW5kVG9CYWNrZ3JvdW5kKFxuICAgIHR5cGU6IHN0cmluZyxcbiAgICBwYXlsb2FkOiB1bmtub3duLFxuICApOiBQcm9taXNlPHVua25vd24+IHtcbiAgICBjb25zdCBpZCA9IE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cmluZyg3KTtcblxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBjb25zdCB0aW1lb3V0ID0gc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCBsaXN0ZW5lcik7XG4gICAgICAgIHJlamVjdChuZXcgRXJyb3IoXCJSZXF1ZXN0IHRpbWVvdXRcIikpO1xuICAgICAgfSwgMzAwMDAwKTtcblxuICAgICAgY29uc3QgbGlzdGVuZXIgPSAoZXZlbnQ6IE1lc3NhZ2VFdmVudCkgPT4ge1xuICAgICAgICBpZiAoZXZlbnQuZGF0YS50YXJnZXQgIT09IFwiZ3JhbmRwYS1wYWdlXCIpIHJldHVybjtcbiAgICAgICAgaWYgKGV2ZW50LmRhdGEuaWQgIT09IGlkKSByZXR1cm47XG5cbiAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXQpO1xuICAgICAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgbGlzdGVuZXIpO1xuXG4gICAgICAgIGlmIChldmVudC5kYXRhLmVycm9yKSB7XG4gICAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihldmVudC5kYXRhLmVycm9yKSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmVzb2x2ZShldmVudC5kYXRhLnJlc3BvbnNlKTtcbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIGxpc3RlbmVyKTtcblxuICAgICAgd2luZG93LnBvc3RNZXNzYWdlKFxuICAgICAgICB7XG4gICAgICAgICAgdGFyZ2V0OiBcImdyYW5kcGEtY29udGVudFwiLFxuICAgICAgICAgIGlkLFxuICAgICAgICAgIHBheWxvYWQ6IHsgdHlwZSwgcGF5bG9hZCB9LFxuICAgICAgICB9LFxuICAgICAgICBcIipcIixcbiAgICAgICk7XG4gICAgfSk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIF9oYW5kbGVSZXF1ZXN0QWNjb3VudHMoKTogUHJvbWlzZTxzdHJpbmdbXT4ge1xuICAgIGlmICh0aGlzLl9jb25uZWN0ZWQgJiYgdGhpcy5fYWNjb3VudHMubGVuZ3RoID4gMCkge1xuICAgICAgcmV0dXJuIHRoaXMuX2FjY291bnRzO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3BvbnNlID0gKGF3YWl0IHRoaXMuX3NlbmRUb0JhY2tncm91bmQoXCJDT05ORUNUX1NJVEVcIiwge1xuICAgICAgb3JpZ2luOiB3aW5kb3cubG9jYXRpb24ub3JpZ2luLFxuICAgIH0pKSBhcyB7IGNvbm5lY3RlZDogYm9vbGVhbjsgYWNjb3VudHM6IHN0cmluZ1tdIH07XG5cbiAgICBpZiAocmVzcG9uc2UuY29ubmVjdGVkKSB7XG4gICAgICBhd2FpdCB0aGlzLl9lbnN1cmVDaGFpbklkKCk7XG4gICAgICB0aGlzLl9jb25uZWN0ZWQgPSB0cnVlO1xuICAgICAgdGhpcy5fYWNjb3VudHMgPSByZXNwb25zZS5hY2NvdW50cztcbiAgICAgIHRoaXMuc2VsZWN0ZWRBZGRyZXNzID0gcmVzcG9uc2UuYWNjb3VudHNbMF0gPz8gbnVsbDtcbiAgICAgIHRoaXMuX2VtaXQoXCJjb25uZWN0XCIsIHsgY2hhaW5JZDogdGhpcy5jaGFpbklkIH0pO1xuICAgICAgdGhpcy5fZW1pdChcImFjY291bnRzQ2hhbmdlZFwiLCB0aGlzLl9hY2NvdW50cyk7XG4gICAgICByZXR1cm4gdGhpcy5fYWNjb3VudHM7XG4gICAgfVxuXG4gICAgdGhyb3cgbmV3IEVycm9yKFwiVXNlciByZWplY3RlZCBjb25uZWN0aW9uXCIpO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBfaGFuZGxlU2VuZFRyYW5zYWN0aW9uKHBhcmFtczogdW5rbm93bik6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgaWYgKCF0aGlzLl9jb25uZWN0ZWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIk5vdCBjb25uZWN0ZWQuIENhbGwgZXRoX3JlcXVlc3RBY2NvdW50cyBmaXJzdC5cIik7XG4gICAgfVxuXG4gICAgY29uc3QgdHhQYXJhbXMgPVxuICAgICAgQXJyYXkuaXNBcnJheShwYXJhbXMpICYmIHBhcmFtcy5sZW5ndGggPiAwXG4gICAgICAgID8gKHBhcmFtc1swXSBhcyB7XG4gICAgICAgICAgICB0bz86IHN0cmluZztcbiAgICAgICAgICAgIHZhbHVlPzogc3RyaW5nO1xuICAgICAgICAgICAgZGF0YT86IHN0cmluZztcbiAgICAgICAgICB9KVxuICAgICAgICA6IChwYXJhbXMgYXMge1xuICAgICAgICAgICAgdG8/OiBzdHJpbmc7XG4gICAgICAgICAgICB2YWx1ZT86IHN0cmluZztcbiAgICAgICAgICAgIGRhdGE/OiBzdHJpbmc7XG4gICAgICAgICAgfSB8IG51bGwpO1xuXG4gICAgaWYgKCF0eFBhcmFtcyB8fCAhdHhQYXJhbXMudG8pIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgdHJhbnNhY3Rpb24gcGFyYW1ldGVyc1wiKTtcbiAgICB9XG5cbiAgICBjb25zdCB0eEhhc2ggPSAoYXdhaXQgdGhpcy5fc2VuZFRvQmFja2dyb3VuZChcIlNFTkRfVFJBTlNBQ1RJT05cIiwge1xuICAgICAgdG86IHR4UGFyYW1zLnRvLFxuICAgICAgdmFsdWU6IHR4UGFyYW1zLnZhbHVlIHx8IFwiMHgwXCIsXG4gICAgICBkYXRhOiB0eFBhcmFtcy5kYXRhIHx8IFwiMHhcIixcbiAgICB9KSkgYXMgc3RyaW5nO1xuXG4gICAgcmV0dXJuIHR4SGFzaDtcbiAgfVxuXG4gIHByaXZhdGUgX2lzSGV4QWRkcmVzcyh2YWx1ZTogc3RyaW5nKTogdmFsdWUgaXMgYDB4JHtzdHJpbmd9YCB7XG4gICAgcmV0dXJuIC9eMHhbYS1mQS1GMC05XXs0MH0kLy50ZXN0KHZhbHVlKTtcbiAgfVxuXG4gIHByaXZhdGUgX3BhcnNlUGVyc29uYWxTaWduUGFyYW1zKHBhcmFtczogdW5rbm93bik6IHtcbiAgICBtZXNzYWdlOiBzdHJpbmc7XG4gICAgYWRkcmVzcz86IGAweCR7c3RyaW5nfWA7XG4gIH0ge1xuICAgIGlmIChBcnJheS5pc0FycmF5KHBhcmFtcykpIHtcbiAgICAgIGNvbnN0IGZpcnN0ID0gcGFyYW1zWzBdO1xuICAgICAgY29uc3Qgc2Vjb25kID0gcGFyYW1zWzFdO1xuXG4gICAgICBpZiAodHlwZW9mIGZpcnN0ICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIkludmFsaWQgcGVyc29uYWxfc2lnbiBwYXJhbXNcIik7XG4gICAgICB9XG5cbiAgICAgIGlmICh0eXBlb2Ygc2Vjb25kICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHJldHVybiB7IG1lc3NhZ2U6IGZpcnN0IH07XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IGZpcnN0SXNBZGRyZXNzID0gdGhpcy5faXNIZXhBZGRyZXNzKGZpcnN0KTtcbiAgICAgIGNvbnN0IHNlY29uZElzQWRkcmVzcyA9IHRoaXMuX2lzSGV4QWRkcmVzcyhzZWNvbmQpO1xuXG4gICAgICBpZiAoc2Vjb25kSXNBZGRyZXNzKSB7XG4gICAgICAgIHJldHVybiB7IG1lc3NhZ2U6IGZpcnN0LCBhZGRyZXNzOiBzZWNvbmQgfTtcbiAgICAgIH1cbiAgICAgIGlmIChmaXJzdElzQWRkcmVzcykge1xuICAgICAgICByZXR1cm4geyBtZXNzYWdlOiBzZWNvbmQsIGFkZHJlc3M6IGZpcnN0IH07XG4gICAgICB9XG4gICAgICByZXR1cm4geyBtZXNzYWdlOiBmaXJzdCB9O1xuICAgIH1cblxuICAgIGlmIChwYXJhbXMgJiYgdHlwZW9mIHBhcmFtcyA9PT0gXCJvYmplY3RcIikge1xuICAgICAgY29uc3Qgb2JqZWN0UGFyYW1zID0gcGFyYW1zIGFzIHtcbiAgICAgICAgZGF0YT86IHVua25vd247XG4gICAgICAgIG1lc3NhZ2U/OiB1bmtub3duO1xuICAgICAgICBmcm9tPzogdW5rbm93bjtcbiAgICAgIH07XG4gICAgICBjb25zdCBtZXNzYWdlID1cbiAgICAgICAgdHlwZW9mIG9iamVjdFBhcmFtcy5kYXRhID09PSBcInN0cmluZ1wiXG4gICAgICAgICAgPyBvYmplY3RQYXJhbXMuZGF0YVxuICAgICAgICAgIDogdHlwZW9mIG9iamVjdFBhcmFtcy5tZXNzYWdlID09PSBcInN0cmluZ1wiXG4gICAgICAgICAgICA/IG9iamVjdFBhcmFtcy5tZXNzYWdlXG4gICAgICAgICAgICA6IG51bGw7XG5cbiAgICAgIGlmICghbWVzc2FnZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHBlcnNvbmFsX3NpZ24gcGFyYW1zXCIpO1xuICAgICAgfVxuXG4gICAgICBpZiAoXG4gICAgICAgIHR5cGVvZiBvYmplY3RQYXJhbXMuZnJvbSA9PT0gXCJzdHJpbmdcIiAmJlxuICAgICAgICB0aGlzLl9pc0hleEFkZHJlc3Mob2JqZWN0UGFyYW1zLmZyb20pXG4gICAgICApIHtcbiAgICAgICAgcmV0dXJuIHsgbWVzc2FnZSwgYWRkcmVzczogb2JqZWN0UGFyYW1zLmZyb20gfTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB7IG1lc3NhZ2UgfTtcbiAgICB9XG5cbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJJbnZhbGlkIHBlcnNvbmFsX3NpZ24gcGFyYW1zXCIpO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBfaGFuZGxlUGVyc29uYWxTaWduKHBhcmFtczogdW5rbm93bik6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgaWYgKCF0aGlzLl9jb25uZWN0ZWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIk5vdCBjb25uZWN0ZWQuIENhbGwgZXRoX3JlcXVlc3RBY2NvdW50cyBmaXJzdC5cIik7XG4gICAgfVxuXG4gICAgY29uc3QgcGFyc2VkID0gdGhpcy5fcGFyc2VQZXJzb25hbFNpZ25QYXJhbXMocGFyYW1zKTtcbiAgICBjb25zdCBleHBlY3RlZEFkZHJlc3MgPSB0aGlzLnNlbGVjdGVkQWRkcmVzcztcbiAgICBpZiAocGFyc2VkLmFkZHJlc3MgJiYgZXhwZWN0ZWRBZGRyZXNzKSB7XG4gICAgICBpZiAocGFyc2VkLmFkZHJlc3MudG9Mb3dlckNhc2UoKSAhPT0gZXhwZWN0ZWRBZGRyZXNzLnRvTG93ZXJDYXNlKCkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiUmVxdWVzdGVkIGFjY291bnQgZG9lcyBub3QgbWF0Y2ggY29ubmVjdGVkIGFjY291bnRcIik7XG4gICAgICB9XG4gICAgfVxuXG4gICAgY29uc3QgYWRkcmVzc0ZvclJlcXVlc3QgPVxuICAgICAgcGFyc2VkLmFkZHJlc3MgPz9cbiAgICAgIChleHBlY3RlZEFkZHJlc3MgJiYgdGhpcy5faXNIZXhBZGRyZXNzKGV4cGVjdGVkQWRkcmVzcylcbiAgICAgICAgPyBleHBlY3RlZEFkZHJlc3NcbiAgICAgICAgOiB1bmRlZmluZWQpO1xuXG4gICAgY29uc3Qgc2lnbmF0dXJlID0gKGF3YWl0IHRoaXMuX3NlbmRUb0JhY2tncm91bmQoXCJTSUdOX01FU1NBR0VcIiwge1xuICAgICAgbWVzc2FnZTogcGFyc2VkLm1lc3NhZ2UsXG4gICAgICBhZGRyZXNzOiBhZGRyZXNzRm9yUmVxdWVzdCxcbiAgICB9KSkgYXMgc3RyaW5nO1xuXG4gICAgcmV0dXJuIHNpZ25hdHVyZTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgX2hhbmRsZVNpZ25UeXBlZERhdGEoX3BhcmFtczogdW5rbm93bik6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgaWYgKCF0aGlzLl9jb25uZWN0ZWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcIk5vdCBjb25uZWN0ZWQuIENhbGwgZXRoX3JlcXVlc3RBY2NvdW50cyBmaXJzdC5cIik7XG4gICAgfVxuICAgIHZvaWQgX3BhcmFtcztcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJldGhfc2lnblR5cGVkRGF0YV92NCBpcyBub3Qgc3VwcG9ydGVkIHlldFwiKTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgX2hhbmRsZVN3aXRjaENoYWluKHBhcmFtczogdW5rbm93bik6IFByb21pc2U8bnVsbD4ge1xuICAgIC8vIEZvciBNVlAsIG9ubHkgc3VwcG9ydCBvbmUgY2hhaW4gY29uZmlndXJlZCBieSBiYWNrZW5kIHNlc3Npb24uXG4gICAgY29uc3QgY2hhaW5JZCA9IChBcnJheS5pc0FycmF5KHBhcmFtcykgPyBwYXJhbXNbMF0gOiBwYXJhbXMpIGFzXG4gICAgICB8IHsgY2hhaW5JZD86IHN0cmluZyB9XG4gICAgICB8IHVuZGVmaW5lZDtcbiAgICBjb25zdCBjdXJyZW50ID0gYXdhaXQgdGhpcy5fZW5zdXJlQ2hhaW5JZCgpO1xuICAgIGlmIChjaGFpbklkPy5jaGFpbklkICE9PSBjdXJyZW50KSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBDaGFpbiBub3Qgc3VwcG9ydGVkLiBPbmx5IGNoYWluSWQgJHtjdXJyZW50fSBpcyBzdXBwb3J0ZWQuYCxcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBfaGFuZGxlQWRkQ2hhaW4oKTogUHJvbWlzZTxudWxsPiB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiQWRkaW5nIGNoYWlucyBub3Qgc3VwcG9ydGVkIGluIE1WUFwiKTtcbiAgfVxuXG4gIHByaXZhdGUgX2hhbmRsZUdldFBlcm1pc3Npb25zKCk6IFdhbGxldFBlcm1pc3Npb25bXSB7XG4gICAgaWYgKCF0aGlzLl9jb25uZWN0ZWQpIHtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgcmV0dXJuIFt7IHBhcmVudENhcGFiaWxpdHk6IFwiZXRoX2FjY291bnRzXCIgfV07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIF9oYW5kbGVSZXF1ZXN0UGVybWlzc2lvbnMoXG4gICAgcGFyYW1zOiB1bmtub3duLFxuICApOiBQcm9taXNlPFdhbGxldFBlcm1pc3Npb25bXT4ge1xuICAgIGNvbnN0IHJlcXVlc3QgPSBBcnJheS5pc0FycmF5KHBhcmFtcykgPyBwYXJhbXNbMF0gOiB1bmRlZmluZWQ7XG4gICAgY29uc3Qgd2FudHNBY2NvdW50cyA9XG4gICAgICB0eXBlb2YgcmVxdWVzdCA9PT0gXCJvYmplY3RcIiAmJlxuICAgICAgcmVxdWVzdCAhPT0gbnVsbCAmJlxuICAgICAgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHJlcXVlc3QsIFwiZXRoX2FjY291bnRzXCIpO1xuXG4gICAgaWYgKCF3YW50c0FjY291bnRzKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJPbmx5IGV0aF9hY2NvdW50cyBwZXJtaXNzaW9uIGlzIHN1cHBvcnRlZFwiKTtcbiAgICB9XG5cbiAgICBhd2FpdCB0aGlzLl9oYW5kbGVSZXF1ZXN0QWNjb3VudHMoKTtcbiAgICByZXR1cm4gW3sgcGFyZW50Q2FwYWJpbGl0eTogXCJldGhfYWNjb3VudHNcIiB9XTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgX2Vuc3VyZUNoYWluSWQoKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3Qgc3RvcmVkID0gYXdhaXQgdGhpcy5fc2VuZFRvQmFja2dyb3VuZChcIkFQSV9HRVRfQ0hBSU5fSURcIiwge30pO1xuICAgICAgaWYgKHR5cGVvZiBzdG9yZWQgPT09IFwibnVtYmVyXCIgJiYgc3RvcmVkID4gMCkge1xuICAgICAgICBjb25zdCBuZXh0Q2hhaW5JZCA9IGAweCR7c3RvcmVkLnRvU3RyaW5nKDE2KX1gO1xuICAgICAgICBpZiAobmV4dENoYWluSWQgIT09IHRoaXMuY2hhaW5JZCkge1xuICAgICAgICAgIHRoaXMuY2hhaW5JZCA9IG5leHRDaGFpbklkO1xuICAgICAgICAgIHRoaXMuX2VtaXQoXCJjaGFpbkNoYW5nZWRcIiwgdGhpcy5jaGFpbklkKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLndhcm4oXCJbUHJvdmlkZXJdIEZhaWxlZCB0byByZXNvbHZlIGNoYWluSWQ6XCIsIGVycm9yKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuY2hhaW5JZDtcbiAgfVxufVxuXG5mdW5jdGlvbiBnZXRPckNyZWF0ZVByb3ZpZGVyc0xpc3QoZXhpc3Rpbmc6IEdyYW5kcGFFdGhlcmV1bUxpa2UpOiB1bmtub3duW10ge1xuICBpZiAoQXJyYXkuaXNBcnJheShleGlzdGluZy5wcm92aWRlcnMpKSB7XG4gICAgcmV0dXJuIGV4aXN0aW5nLnByb3ZpZGVycztcbiAgfVxuICByZXR1cm4gW2V4aXN0aW5nXTtcbn1cblxuZnVuY3Rpb24gaGFzR3JhbmRwYVByb3ZpZGVyKHByb3ZpZGVyczogdW5rbm93bltdKTogYm9vbGVhbiB7XG4gIHJldHVybiBwcm92aWRlcnMuc29tZShcbiAgICAocHJvdmlkZXIpID0+XG4gICAgICB0eXBlb2YgcHJvdmlkZXIgPT09IFwib2JqZWN0XCIgJiZcbiAgICAgIHByb3ZpZGVyICE9PSBudWxsICYmXG4gICAgICAocHJvdmlkZXIgYXMgR3JhbmRwYUV0aGVyZXVtTGlrZSkuaXNHcmFuZHBhID09PSB0cnVlLFxuICApO1xufVxuXG5mdW5jdGlvbiBhbm5vdW5jZUVpcDY5NjNQcm92aWRlcihwcm92aWRlcjogR3JhbmRwYVByb3ZpZGVyKTogdm9pZCB7XG4gIGNvbnN0IGRldGFpbDogRWlwNjk2M0Fubm91bmNlRGV0YWlsID0ge1xuICAgIGluZm86IEdSQU5EUEFfUFJPVklERVJfSU5GTyxcbiAgICBwcm92aWRlcixcbiAgfTtcbiAgd2luZG93LmRpc3BhdGNoRXZlbnQoXG4gICAgbmV3IEN1c3RvbUV2ZW50PEVpcDY5NjNBbm5vdW5jZURldGFpbD4oRUlQNjk2M19BTk5PVU5DRV9FVkVOVCwgeyBkZXRhaWwgfSksXG4gICk7XG59XG5cbmNvbnN0IGdyYW5kcGFQcm92aWRlciA9IG5ldyBHcmFuZHBhUHJvdmlkZXIoKTtcbmNvbnN0IGV4aXN0aW5nID0gKHdpbmRvdy5ldGhlcmV1bSBhcyBHcmFuZHBhRXRoZXJldW1MaWtlIHwgdW5kZWZpbmVkKSA/PyBudWxsO1xuXG5pZiAoIWV4aXN0aW5nKSB7XG4gIHdpbmRvdy5ldGhlcmV1bSA9IGdyYW5kcGFQcm92aWRlciBhcyB1bmtub3duO1xuICBjb25zb2xlLmxvZyhcIltJbmplY3RlZF0gUHJvdmlkZXIgaW5qZWN0ZWQgYXMgd2luZG93LmV0aGVyZXVtXCIpO1xufSBlbHNlIHtcbiAgY29uc3QgcHJvdmlkZXJzID0gZ2V0T3JDcmVhdGVQcm92aWRlcnNMaXN0KGV4aXN0aW5nKTtcbiAgaWYgKCFoYXNHcmFuZHBhUHJvdmlkZXIocHJvdmlkZXJzKSkge1xuICAgIHByb3ZpZGVycy5wdXNoKGdyYW5kcGFQcm92aWRlcik7XG4gICAgZXhpc3RpbmcucHJvdmlkZXJzID0gcHJvdmlkZXJzO1xuICAgIGNvbnNvbGUubG9nKFxuICAgICAgXCJbSW5qZWN0ZWRdIEdyYW5kcGEgcHJvdmlkZXIgYWRkZWQgdG8gd2luZG93LmV0aGVyZXVtLnByb3ZpZGVyc1wiLFxuICAgICk7XG4gIH0gZWxzZSB7XG4gICAgY29uc29sZS5sb2coXCJbSW5qZWN0ZWRdIEdyYW5kcGEgcHJvdmlkZXIgYWxyZWFkeSBwcmVzZW50XCIpO1xuICB9XG59XG5cbndpbmRvdy5hZGRFdmVudExpc3RlbmVyKEVJUDY5NjNfUkVRVUVTVF9FVkVOVCwgKCkgPT4ge1xuICBhbm5vdW5jZUVpcDY5NjNQcm92aWRlcihncmFuZHBhUHJvdmlkZXIpO1xufSk7XG5hbm5vdW5jZUVpcDY5NjNQcm92aWRlcihncmFuZHBhUHJvdmlkZXIpO1xuc2V0VGltZW91dCgoKSA9PiBhbm5vdW5jZUVpcDY5NjNQcm92aWRlcihncmFuZHBhUHJvdmlkZXIpLCAwKTtcblxuLy8gTGlzdGVuIGZvciBkaXNjb25uZWN0XG53aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcIm1lc3NhZ2VcIiwgKGV2ZW50KSA9PiB7XG4gIGlmIChcbiAgICBldmVudC5kYXRhLnRhcmdldCA9PT0gXCJncmFuZHBhLXBhZ2VcIiAmJlxuICAgIGV2ZW50LmRhdGEudHlwZSA9PT0gXCJkaXNjb25uZWN0XCJcbiAgKSB7XG4gICAgZ3JhbmRwYVByb3ZpZGVyLmhhbmRsZUV4dGVybmFsRGlzY29ubmVjdCgpO1xuICB9XG59KTtcblxuLy8gQW5ub3VuY2UgcHJvdmlkZXIgZm9yIGxlZ2FjeSBkZXRlY3QtcHJvdmlkZXIgaW50ZWdyYXRpb25zXG53aW5kb3cuZGlzcGF0Y2hFdmVudChuZXcgRXZlbnQoXCJldGhlcmV1bSNpbml0aWFsaXplZFwiKSk7XG4iXSwibmFtZXMiOlsiZXhpc3RpbmciXSwibWFwcGluZ3MiOiJBQUVBLFFBQVEsSUFBSSwrQ0FBK0M7QUFFM0QsTUFBTSx3QkFBd0I7QUFDOUIsTUFBTSx5QkFBeUI7QUFDL0IsTUFBTSx3QkFBd0I7QUFnRDlCLE1BQU0sMEJBQTBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBdUJoQyxNQUFNLHdCQUF3QiwyQkFBMkI7QUFBQSxFQUN2RCx3QkFBd0IsS0FBQTtBQUMxQixDQUFDO0FBRUQsTUFBTSx3QkFBNkM7QUFBQSxFQUNqRCxNQUFNO0FBQUEsRUFDTixNQUFNO0FBQUEsRUFDTixNQUFNO0FBQUEsRUFDTixNQUFNO0FBQ1I7QUFFQSxNQUFNLGdCQUFnQjtBQUFBLEVBQ2IsWUFBWTtBQUFBLEVBQ1osYUFBYTtBQUFBLEVBQ2IsVUFBVTtBQUFBLEVBQ1Ysa0JBQWlDO0FBQUEsRUFDakMsWUFBK0IsQ0FBQyxJQUFJO0FBQUE7QUFBQSxFQUdwQyxZQUFZO0FBQUEsSUFDakIsWUFBWSxZQUFZLEtBQUs7QUFBQSxFQUFBO0FBQUEsRUFHdkIsWUFBc0IsQ0FBQTtBQUFBLEVBQ3RCLGFBQWE7QUFBQSxFQUNiLGVBQWU7QUFBQSxFQUNmLGlDQUNGLElBQUE7QUFBQSxFQUVOLFVBQVUsT0FBTyxTQUE2QztBQUM1RCxZQUFRLElBQUksdUJBQXVCLEtBQUssUUFBUSxLQUFLLE1BQU07QUFFM0QsVUFBTSxFQUFFLFFBQVEsT0FBQSxJQUFXO0FBRTNCLFlBQVEsUUFBQTtBQUFBLE1BQ04sS0FBSztBQUNILGVBQU8sS0FBSyx1QkFBQTtBQUFBLE1BRWQsS0FBSztBQUNILGVBQU8sS0FBSztBQUFBLE1BRWQsS0FBSztBQUNILGVBQU8sS0FBSyxlQUFBO0FBQUEsTUFFZCxLQUFLLGVBQWU7QUFDbEIsY0FBTSxVQUFVLE1BQU0sS0FBSyxlQUFBO0FBQzNCLGVBQU8sT0FBTyxTQUFTLFNBQVMsRUFBRSxFQUFFLFNBQVMsRUFBRTtBQUFBLE1BQ2pEO0FBQUEsTUFFQSxLQUFLO0FBQ0gsZUFBTyxLQUFLO0FBQUEsTUFFZCxLQUFLO0FBQ0gsZUFBTyxLQUFLLHVCQUF1QixNQUFNO0FBQUEsTUFFM0MsS0FBSztBQUNILGVBQU8sS0FBSyxvQkFBb0IsTUFBTTtBQUFBLE1BRXhDLEtBQUs7QUFDSCxlQUFPLEtBQUsscUJBQXFCLE1BQU07QUFBQSxNQUV6QyxLQUFLO0FBQ0gsZUFBTyxLQUFLLG1CQUFtQixNQUFNO0FBQUEsTUFFdkMsS0FBSztBQUNILGVBQU8sS0FBSyxnQkFBQTtBQUFBLE1BRWQsS0FBSztBQUNILGVBQU8sS0FBSyxzQkFBQTtBQUFBLE1BRWQsS0FBSztBQUNILGVBQU8sS0FBSywwQkFBMEIsTUFBTTtBQUFBLE1BRTlDO0FBQ0UsY0FBTSxJQUFJLE1BQU0sVUFBVSxNQUFNLGdCQUFnQjtBQUFBLElBQUE7QUFBQSxFQUV0RDtBQUFBLEVBRUEsU0FBUyxNQUF5QjtBQUNoQyxXQUFPLEtBQUssUUFBUSxFQUFFLFFBQVEsdUJBQXVCO0FBQUEsRUFDdkQ7QUFBQSxFQUVBLGNBQWMsTUFBZTtBQUMzQixXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQUEsRUFFQSxPQUFPLENBQ0wsaUJBQ0EscUJBQzRCO0FBQzVCLFFBQUksT0FBTyxvQkFBb0IsVUFBVTtBQUN2QyxZQUFNLFNBQ0osT0FBTyxxQkFBcUIsYUFBYSxTQUFZO0FBQ3ZELGFBQU8sS0FBSyxRQUFRLEVBQUUsUUFBUSxpQkFBaUIsUUFBUTtBQUFBLElBQ3pEO0FBRUEsVUFBTSxVQUE0QjtBQUFBLE1BQ2hDLFFBQVEsZ0JBQWdCO0FBQUEsTUFDeEIsUUFBUSxnQkFBZ0I7QUFBQSxJQUFBO0FBRTFCLFVBQU0sV0FDSixPQUFPLHFCQUFxQixhQUFhLG1CQUFtQjtBQUM5RCxVQUFNLEtBQUssZ0JBQWdCLE1BQU0sRUFBRSxLQUFLO0FBQ3hDLFVBQU0sVUFBVSxLQUFLLFFBQVEsT0FBTztBQUVwQyxRQUFJLENBQUMsVUFBVTtBQUNiLGFBQU87QUFBQSxJQUNUO0FBRUEsWUFDRyxLQUFLLENBQUMsV0FBVztBQUNoQixlQUFTLE1BQU0sRUFBRSxJQUFJLFNBQVMsT0FBTyxRQUFRO0FBQUEsSUFDL0MsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxVQUFVO0FBQ2hCLFlBQU0sTUFDSixpQkFBaUIsUUFBUSxRQUFRLElBQUksTUFBTSx3QkFBd0I7QUFDckUsZUFBUyxLQUFLO0FBQUEsUUFDWjtBQUFBLFFBQ0EsU0FBUztBQUFBLFFBQ1QsT0FBTyxFQUFFLE1BQU0sUUFBUSxTQUFTLElBQUksUUFBQTtBQUFBLE1BQVEsQ0FDN0M7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNMO0FBQUEsRUFFQSxZQUFZLENBQ1YsU0FDQSxhQUM0QjtBQUM1QixXQUFPLEtBQUssS0FBSyxTQUFTLFFBQVE7QUFBQSxFQUNwQztBQUFBLEVBRUEsS0FBSyxDQUFDLE9BQWUsYUFBaUQ7QUFDcEUsUUFBSSxDQUFDLEtBQUssV0FBVyxJQUFJLEtBQUssR0FBRztBQUMvQixXQUFLLFdBQVcsSUFBSSxPQUFPLG9CQUFJLEtBQUs7QUFBQSxJQUN0QztBQUNBLFNBQUssV0FBVyxJQUFJLEtBQUssRUFBRyxJQUFJLFFBQVE7QUFBQSxFQUMxQztBQUFBLEVBRUEsaUJBQWlCLENBQ2YsT0FDQSxhQUNTO0FBQ1QsVUFBTSxZQUFZLEtBQUssV0FBVyxJQUFJLEtBQUs7QUFDM0MsUUFBSSxXQUFXO0FBQ2IsZ0JBQVUsT0FBTyxRQUFRO0FBQUEsSUFDM0I7QUFBQSxFQUNGO0FBQUEsRUFFQSwyQkFBaUM7QUFDL0IsU0FBSyxhQUFhO0FBQ2xCLFNBQUssWUFBWSxDQUFBO0FBQ2pCLFNBQUssa0JBQWtCO0FBQ3ZCLFNBQUssTUFBTSxtQkFBbUIsRUFBRTtBQUNoQyxTQUFLLE1BQU0sWUFBWTtBQUFBLEVBQ3pCO0FBQUEsRUFFUSxNQUFNLFVBQWtCLE1BQXVCO0FBQ3JELFVBQU0sWUFBWSxLQUFLLFdBQVcsSUFBSSxLQUFLO0FBQzNDLFFBQUksV0FBVztBQUNiLGdCQUFVLFFBQVEsQ0FBQyxhQUFhO0FBQzlCLFlBQUk7QUFDRixtQkFBUyxHQUFHLElBQUk7QUFBQSxRQUNsQixTQUFTLE9BQU87QUFDZCxrQkFBUSxNQUFNLDhCQUE4QixLQUFLO0FBQUEsUUFDbkQ7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNIO0FBQUEsRUFDRjtBQUFBLEVBRUEsTUFBYyxrQkFDWixNQUNBLFNBQ2tCO0FBQ2xCLFVBQU0sS0FBSyxLQUFLLE9BQUEsRUFBUyxTQUFTLEVBQUUsRUFBRSxVQUFVLENBQUM7QUFFakQsV0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDdEMsWUFBTSxVQUFVLFdBQVcsTUFBTTtBQUMvQixlQUFPLG9CQUFvQixXQUFXLFFBQVE7QUFDOUMsZUFBTyxJQUFJLE1BQU0saUJBQWlCLENBQUM7QUFBQSxNQUNyQyxHQUFHLEdBQU07QUFFVCxZQUFNLFdBQVcsQ0FBQyxVQUF3QjtBQUN4QyxZQUFJLE1BQU0sS0FBSyxXQUFXLGVBQWdCO0FBQzFDLFlBQUksTUFBTSxLQUFLLE9BQU8sR0FBSTtBQUUxQixxQkFBYSxPQUFPO0FBQ3BCLGVBQU8sb0JBQW9CLFdBQVcsUUFBUTtBQUU5QyxZQUFJLE1BQU0sS0FBSyxPQUFPO0FBQ3BCLGlCQUFPLElBQUksTUFBTSxNQUFNLEtBQUssS0FBSyxDQUFDO0FBQUEsUUFDcEMsT0FBTztBQUNMLGtCQUFRLE1BQU0sS0FBSyxRQUFRO0FBQUEsUUFDN0I7QUFBQSxNQUNGO0FBRUEsYUFBTyxpQkFBaUIsV0FBVyxRQUFRO0FBRTNDLGFBQU87QUFBQSxRQUNMO0FBQUEsVUFDRSxRQUFRO0FBQUEsVUFDUjtBQUFBLFVBQ0EsU0FBUyxFQUFFLE1BQU0sUUFBQTtBQUFBLFFBQVE7QUFBQSxRQUUzQjtBQUFBLE1BQUE7QUFBQSxJQUVKLENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxNQUFjLHlCQUE0QztBQUN4RCxRQUFJLEtBQUssY0FBYyxLQUFLLFVBQVUsU0FBUyxHQUFHO0FBQ2hELGFBQU8sS0FBSztBQUFBLElBQ2Q7QUFFQSxVQUFNLFdBQVksTUFBTSxLQUFLLGtCQUFrQixnQkFBZ0I7QUFBQSxNQUM3RCxRQUFRLE9BQU8sU0FBUztBQUFBLElBQUEsQ0FDekI7QUFFRCxRQUFJLFNBQVMsV0FBVztBQUN0QixZQUFNLEtBQUssZUFBQTtBQUNYLFdBQUssYUFBYTtBQUNsQixXQUFLLFlBQVksU0FBUztBQUMxQixXQUFLLGtCQUFrQixTQUFTLFNBQVMsQ0FBQyxLQUFLO0FBQy9DLFdBQUssTUFBTSxXQUFXLEVBQUUsU0FBUyxLQUFLLFNBQVM7QUFDL0MsV0FBSyxNQUFNLG1CQUFtQixLQUFLLFNBQVM7QUFDNUMsYUFBTyxLQUFLO0FBQUEsSUFDZDtBQUVBLFVBQU0sSUFBSSxNQUFNLDBCQUEwQjtBQUFBLEVBQzVDO0FBQUEsRUFFQSxNQUFjLHVCQUF1QixRQUFrQztBQUNyRSxRQUFJLENBQUMsS0FBSyxZQUFZO0FBQ3BCLFlBQU0sSUFBSSxNQUFNLGdEQUFnRDtBQUFBLElBQ2xFO0FBRUEsVUFBTSxXQUNKLE1BQU0sUUFBUSxNQUFNLEtBQUssT0FBTyxTQUFTLElBQ3BDLE9BQU8sQ0FBQyxJQUtSO0FBTVAsUUFBSSxDQUFDLFlBQVksQ0FBQyxTQUFTLElBQUk7QUFDN0IsWUFBTSxJQUFJLE1BQU0sZ0NBQWdDO0FBQUEsSUFDbEQ7QUFFQSxVQUFNLFNBQVUsTUFBTSxLQUFLLGtCQUFrQixvQkFBb0I7QUFBQSxNQUMvRCxJQUFJLFNBQVM7QUFBQSxNQUNiLE9BQU8sU0FBUyxTQUFTO0FBQUEsTUFDekIsTUFBTSxTQUFTLFFBQVE7QUFBQSxJQUFBLENBQ3hCO0FBRUQsV0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUVRLGNBQWMsT0FBdUM7QUFDM0QsV0FBTyxzQkFBc0IsS0FBSyxLQUFLO0FBQUEsRUFDekM7QUFBQSxFQUVRLHlCQUF5QixRQUcvQjtBQUNBLFFBQUksTUFBTSxRQUFRLE1BQU0sR0FBRztBQUN6QixZQUFNLFFBQVEsT0FBTyxDQUFDO0FBQ3RCLFlBQU0sU0FBUyxPQUFPLENBQUM7QUFFdkIsVUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM3QixjQUFNLElBQUksTUFBTSw4QkFBOEI7QUFBQSxNQUNoRDtBQUVBLFVBQUksT0FBTyxXQUFXLFVBQVU7QUFDOUIsZUFBTyxFQUFFLFNBQVMsTUFBQTtBQUFBLE1BQ3BCO0FBRUEsWUFBTSxpQkFBaUIsS0FBSyxjQUFjLEtBQUs7QUFDL0MsWUFBTSxrQkFBa0IsS0FBSyxjQUFjLE1BQU07QUFFakQsVUFBSSxpQkFBaUI7QUFDbkIsZUFBTyxFQUFFLFNBQVMsT0FBTyxTQUFTLE9BQUE7QUFBQSxNQUNwQztBQUNBLFVBQUksZ0JBQWdCO0FBQ2xCLGVBQU8sRUFBRSxTQUFTLFFBQVEsU0FBUyxNQUFBO0FBQUEsTUFDckM7QUFDQSxhQUFPLEVBQUUsU0FBUyxNQUFBO0FBQUEsSUFDcEI7QUFFQSxRQUFJLFVBQVUsT0FBTyxXQUFXLFVBQVU7QUFDeEMsWUFBTSxlQUFlO0FBS3JCLFlBQU0sVUFDSixPQUFPLGFBQWEsU0FBUyxXQUN6QixhQUFhLE9BQ2IsT0FBTyxhQUFhLFlBQVksV0FDOUIsYUFBYSxVQUNiO0FBRVIsVUFBSSxDQUFDLFNBQVM7QUFDWixjQUFNLElBQUksTUFBTSw4QkFBOEI7QUFBQSxNQUNoRDtBQUVBLFVBQ0UsT0FBTyxhQUFhLFNBQVMsWUFDN0IsS0FBSyxjQUFjLGFBQWEsSUFBSSxHQUNwQztBQUNBLGVBQU8sRUFBRSxTQUFTLFNBQVMsYUFBYSxLQUFBO0FBQUEsTUFDMUM7QUFDQSxhQUFPLEVBQUUsUUFBQTtBQUFBLElBQ1g7QUFFQSxVQUFNLElBQUksTUFBTSw4QkFBOEI7QUFBQSxFQUNoRDtBQUFBLEVBRUEsTUFBYyxvQkFBb0IsUUFBa0M7QUFDbEUsUUFBSSxDQUFDLEtBQUssWUFBWTtBQUNwQixZQUFNLElBQUksTUFBTSxnREFBZ0Q7QUFBQSxJQUNsRTtBQUVBLFVBQU0sU0FBUyxLQUFLLHlCQUF5QixNQUFNO0FBQ25ELFVBQU0sa0JBQWtCLEtBQUs7QUFDN0IsUUFBSSxPQUFPLFdBQVcsaUJBQWlCO0FBQ3JDLFVBQUksT0FBTyxRQUFRLFlBQUEsTUFBa0IsZ0JBQWdCLGVBQWU7QUFDbEUsY0FBTSxJQUFJLE1BQU0sb0RBQW9EO0FBQUEsTUFDdEU7QUFBQSxJQUNGO0FBRUEsVUFBTSxvQkFDSixPQUFPLFlBQ04sbUJBQW1CLEtBQUssY0FBYyxlQUFlLElBQ2xELGtCQUNBO0FBRU4sVUFBTSxZQUFhLE1BQU0sS0FBSyxrQkFBa0IsZ0JBQWdCO0FBQUEsTUFDOUQsU0FBUyxPQUFPO0FBQUEsTUFDaEIsU0FBUztBQUFBLElBQUEsQ0FDVjtBQUVELFdBQU87QUFBQSxFQUNUO0FBQUEsRUFFQSxNQUFjLHFCQUFxQixTQUFtQztBQUNwRSxRQUFJLENBQUMsS0FBSyxZQUFZO0FBQ3BCLFlBQU0sSUFBSSxNQUFNLGdEQUFnRDtBQUFBLElBQ2xFO0FBRUEsVUFBTSxJQUFJLE1BQU0sMkNBQTJDO0FBQUEsRUFDN0Q7QUFBQSxFQUVBLE1BQWMsbUJBQW1CLFFBQWdDO0FBRS9ELFVBQU0sVUFBVyxNQUFNLFFBQVEsTUFBTSxJQUFJLE9BQU8sQ0FBQyxJQUFJO0FBR3JELFVBQU0sVUFBVSxNQUFNLEtBQUssZUFBQTtBQUMzQixRQUFJLFNBQVMsWUFBWSxTQUFTO0FBQ2hDLFlBQU0sSUFBSTtBQUFBLFFBQ1IscUNBQXFDLE9BQU87QUFBQSxNQUFBO0FBQUEsSUFFaEQ7QUFDQSxXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRUEsTUFBYyxrQkFBaUM7QUFDN0MsVUFBTSxJQUFJLE1BQU0sb0NBQW9DO0FBQUEsRUFDdEQ7QUFBQSxFQUVRLHdCQUE0QztBQUNsRCxRQUFJLENBQUMsS0FBSyxZQUFZO0FBQ3BCLGFBQU8sQ0FBQTtBQUFBLElBQ1Q7QUFDQSxXQUFPLENBQUMsRUFBRSxrQkFBa0IsZ0JBQWdCO0FBQUEsRUFDOUM7QUFBQSxFQUVBLE1BQWMsMEJBQ1osUUFDNkI7QUFDN0IsVUFBTSxVQUFVLE1BQU0sUUFBUSxNQUFNLElBQUksT0FBTyxDQUFDLElBQUk7QUFDcEQsVUFBTSxnQkFDSixPQUFPLFlBQVksWUFDbkIsWUFBWSxRQUNaLE9BQU8sVUFBVSxlQUFlLEtBQUssU0FBUyxjQUFjO0FBRTlELFFBQUksQ0FBQyxlQUFlO0FBQ2xCLFlBQU0sSUFBSSxNQUFNLDJDQUEyQztBQUFBLElBQzdEO0FBRUEsVUFBTSxLQUFLLHVCQUFBO0FBQ1gsV0FBTyxDQUFDLEVBQUUsa0JBQWtCLGdCQUFnQjtBQUFBLEVBQzlDO0FBQUEsRUFFQSxNQUFjLGlCQUFrQztBQUM5QyxRQUFJO0FBQ0YsWUFBTSxTQUFTLE1BQU0sS0FBSyxrQkFBa0Isb0JBQW9CLENBQUEsQ0FBRTtBQUNsRSxVQUFJLE9BQU8sV0FBVyxZQUFZLFNBQVMsR0FBRztBQUM1QyxjQUFNLGNBQWMsS0FBSyxPQUFPLFNBQVMsRUFBRSxDQUFDO0FBQzVDLFlBQUksZ0JBQWdCLEtBQUssU0FBUztBQUNoQyxlQUFLLFVBQVU7QUFDZixlQUFLLE1BQU0sZ0JBQWdCLEtBQUssT0FBTztBQUFBLFFBQ3pDO0FBQUEsTUFDRjtBQUFBLElBQ0YsU0FBUyxPQUFPO0FBQ2QsY0FBUSxLQUFLLHlDQUF5QyxLQUFLO0FBQUEsSUFDN0Q7QUFDQSxXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0Y7QUFFQSxTQUFTLHlCQUF5QkEsV0FBMEM7QUFDMUUsTUFBSSxNQUFNLFFBQVFBLFVBQVMsU0FBUyxHQUFHO0FBQ3JDLFdBQU9BLFVBQVM7QUFBQSxFQUNsQjtBQUNBLFNBQU8sQ0FBQ0EsU0FBUTtBQUNsQjtBQUVBLFNBQVMsbUJBQW1CLFdBQStCO0FBQ3pELFNBQU8sVUFBVTtBQUFBLElBQ2YsQ0FBQyxhQUNDLE9BQU8sYUFBYSxZQUNwQixhQUFhLFFBQ1osU0FBaUMsY0FBYztBQUFBLEVBQUE7QUFFdEQ7QUFFQSxTQUFTLHdCQUF3QixVQUFpQztBQUNoRSxRQUFNLFNBQWdDO0FBQUEsSUFDcEMsTUFBTTtBQUFBLElBQ047QUFBQSxFQUFBO0FBRUYsU0FBTztBQUFBLElBQ0wsSUFBSSxZQUFtQyx3QkFBd0IsRUFBRSxRQUFRO0FBQUEsRUFBQTtBQUU3RTtBQUVBLE1BQU0sa0JBQWtCLElBQUksZ0JBQUE7QUFDNUIsTUFBTSxXQUFZLE9BQU8sWUFBZ0Q7QUFFekUsSUFBSSxDQUFDLFVBQVU7QUFDYixTQUFPLFdBQVc7QUFDbEIsVUFBUSxJQUFJLGlEQUFpRDtBQUMvRCxPQUFPO0FBQ0wsUUFBTSxZQUFZLHlCQUF5QixRQUFRO0FBQ25ELE1BQUksQ0FBQyxtQkFBbUIsU0FBUyxHQUFHO0FBQ2xDLGNBQVUsS0FBSyxlQUFlO0FBQzlCLGFBQVMsWUFBWTtBQUNyQixZQUFRO0FBQUEsTUFDTjtBQUFBLElBQUE7QUFBQSxFQUVKLE9BQU87QUFDTCxZQUFRLElBQUksNkNBQTZDO0FBQUEsRUFDM0Q7QUFDRjtBQUVBLE9BQU8saUJBQWlCLHVCQUF1QixNQUFNO0FBQ25ELDBCQUF3QixlQUFlO0FBQ3pDLENBQUM7QUFDRCx3QkFBd0IsZUFBZTtBQUN2QyxXQUFXLE1BQU0sd0JBQXdCLGVBQWUsR0FBRyxDQUFDO0FBRzVELE9BQU8saUJBQWlCLFdBQVcsQ0FBQyxVQUFVO0FBQzVDLE1BQ0UsTUFBTSxLQUFLLFdBQVcsa0JBQ3RCLE1BQU0sS0FBSyxTQUFTLGNBQ3BCO0FBQ0Esb0JBQWdCLHlCQUFBO0FBQUEsRUFDbEI7QUFDRixDQUFDO0FBR0QsT0FBTyxjQUFjLElBQUksTUFBTSxzQkFBc0IsQ0FBQzsifQ==
